﻿# PDFtoAgent Intelligent Launcher by @30niorcrypto
$OutputEncoding = [System.Text.Encoding]::UTF8
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8

function Write-Badge { param($tag, $msg, $color="Cyan") Write-Host "  [$tag] " -ForegroundColor $color -NoNewline; Write-Host $msg }

Clear-Host
Write-Host "  +===============================================================================+" -ForegroundColor Cyan
Write-Host "  |                                                                               |" -ForegroundColor Cyan
Write-Host "  |     ____   ____  _____       _                  _                    _        |" -ForegroundColor Cyan
Write-Host "  |    |  _ \ |  _ \|  ___|     | |_  ___          / \   __ _  ___ _ __ | |_      |" -ForegroundColor Cyan
Write-Host "  |    | |_) || | | | |_        | __|/ _ \        / _ \ / _  |/ _ \ '_ \| __|     |" -ForegroundColor Cyan
Write-Host "  |    |  __/ | |_| |  _|       | |_| (_) |      / ___ \ (_| |  __/ | | | |_      |" -ForegroundColor Cyan
Write-Host "  |    |_|    |____/|_|          \__|\___/      /_/   \_\__, |\___|_| |_|\__|     |" -ForegroundColor Cyan
Write-Host "  |                                                      |___/                    |" -ForegroundColor Cyan
Write-Host "  |                                                                               |" -ForegroundColor Cyan
Write-Host "  |   >> AI Agent MCP Server  : stock-market-barometer-hamilton                   |" -ForegroundColor Yellow
Write-Host "  |   >> Crafted with <3 by   : @30niorcrypto                                     |" -ForegroundColor Green
Write-Host "  |   >> GitHub Repository    : https://github.com/30niorcrypto/PDFtoAgent        |" -ForegroundColor Magenta
Write-Host "  |   >> X / Twitter          : @30niorcrypto                                     |" -ForegroundColor Cyan
Write-Host "  |                                                                               |" -ForegroundColor Cyan
Write-Host "  +===============================================================================+" -ForegroundColor Cyan
Write-Host ""

# 1. Resolve package root and parse config/.env
$pkgRoot = if (Test-Path "$PSScriptRoot/python_embedded") { $PSScriptRoot } else { (Get-Item "$PSScriptRoot/..").FullName }
$envPath = if (Test-Path "$PSScriptRoot/.env") { "$PSScriptRoot/.env" } elseif (Test-Path "$pkgRoot/config/.env") { "$pkgRoot/config/.env" } elseif (Test-Path "$pkgRoot/.env") { "$pkgRoot/.env" } else { "" }

$provider = "ollama"
$model = "nomic-embed-text:v1.5"
$nomicKey = ""
$openAiKey = ""

if ($envPath -and (Test-Path $envPath)) {
    Get-Content $envPath | ForEach-Object {
        $line = $_.Trim()
        if ($line -match "^EMBEDDING_PROVIDER\s*=\s*(.+)$") { $provider = $matches[1].Trim().ToLower() }
        if ($line -match "^OLLAMA_EMBEDDING_MODEL\s*=\s*(.+)$") { $model = $matches[1].Trim() }
        if ($line -match "^NOMIC_API_KEY\s*=\s*(.+)$") { $nomicKey = $matches[1].Trim() }
        if ($line -match "^OPENAI_API_KEY\s*=\s*(.+)$") { $openAiKey = $matches[1].Trim() }
    }
}

Write-Badge "INFO" "Target Skill      : stock-market-barometer-hamilton" "Yellow"
Write-Badge "INFO" "Active Embeddings : $provider" "Yellow"

# 2. Check Embedding Requirements
if ($provider -eq "nomic") {
    if (-not $nomicKey) {
        Write-Badge "WARN" "NOMIC_API_KEY is empty in config/.env file!" "Red"
        Write-Badge "HINT" "Get your free API key at https://atlas.nomic.ai and add NOMIC_API_KEY=... in config/.env" "Yellow"
        pause; exit 1
    }
    Write-Badge "OK" "Using Nomic Cloud Embeddings (1M free tokens/mo) - Zero local install!" "Green"
}
elseif ($provider -eq "openai") {
    if (-not $openAiKey) {
        Write-Badge "WARN" "OPENAI_API_KEY is empty in config/.env file!" "Red"
        pause; exit 1
    }
    Write-Badge "OK" "Using OpenAI Cloud Embeddings!" "Green"
}
else {
    # Provider is Ollama
    Write-Host "`n  -------------------------------------------------------------------------------" -ForegroundColor DarkGray
    Write-Host "  >> Checking Local Ollama Engine" -ForegroundColor Cyan
    Write-Host "  -------------------------------------------------------------------------------" -ForegroundColor DarkGray
    
    $ollamaInstalled = $false
    if (Get-Command ollama -ErrorAction SilentlyContinue) {
        $ollamaInstalled = $true
    }
    else {
        $localOllama = "$($env:LOCALAPPDATA)\Programs\Ollama\ollama.exe"
        if (Test-Path $localOllama) {
            $ollamaInstalled = $true
            $env:Path = "$($env:LOCALAPPDATA)\Programs\Ollama;" + $env:Path
        }
    }

    if (-not $ollamaInstalled) {
        Write-Badge "!" "Ollama is required for local embeddings but was not found on your system." "Yellow"
        Write-Badge "+" "Automatically installing Ollama CLI via Windows Package Manager (winget)..." "Cyan"
        Write-Host "     Please wait a moment while it finishes..." -ForegroundColor DarkGray
        
        winget install --id Ollama.Ollama -e --accept-package-agreements --accept-source-agreements --silent
        
        $machinePath = [System.Environment]::GetEnvironmentVariable('Path', 'Machine')
        $userPath = [System.Environment]::GetEnvironmentVariable('Path', 'User')
        $env:Path = "$machinePath;$userPath"
        $localOllama = "$($env:LOCALAPPDATA)\Programs\Ollama\ollama.exe"
        if (Test-Path $localOllama) {
            $env:Path = "$($env:LOCALAPPDATA)\Programs\Ollama;" + $env:Path
        }
        Write-Badge "OK" "Ollama installed successfully!" "Green"
    } else {
        Write-Badge "OK" "Ollama is installed." "Green"
    }

    # Check if Ollama daemon is running
    $running = $false
    try {
        $tags = Invoke-RestMethod -Uri "http://127.0.0.1:11434/api/tags" -Method Get -TimeoutSec 2 -ErrorAction SilentlyContinue
        $running = $true
    } catch {}

    if (-not $running) {
        Write-Badge "+" "Starting Ollama background engine (ollama serve)..." "Cyan"
        Start-Process "ollama" -ArgumentList "serve" -WindowStyle Hidden
        $attempts = 0
        while (-not $running -and $attempts -lt 15) {
            Start-Sleep -Seconds 1
            $attempts++
            try {
                $tags = Invoke-RestMethod -Uri "http://127.0.0.1:11434/api/tags" -Method Get -TimeoutSec 2 -ErrorAction SilentlyContinue
                $running = $true
            } catch {}
        }
        if (-not $running) {
            Write-Badge "WARN" "Ollama service taking longer to start. Proceeding anyway..." "Yellow"
        } else {
            Write-Badge "OK" "Ollama service is active on http://127.0.0.1:11434." "Green"
        }
    } else {
        Write-Badge "OK" "Ollama service is active on http://127.0.0.1:11434." "Green"
    }

    # Check if model is pulled
    $modelClean = $model.Replace(":latest", "")
    $hasModel = $false
    if ($tags -and $tags.models) {
        foreach ($m in $tags.models) {
            if ($m.name -like "$modelClean*" -or $m.model -like "$modelClean*") {
                $hasModel = $true; break
            }
        }
    }

    if (-not $hasModel) {
        Write-Badge "!" "Embedding model '$model' (~270MB) not found in Ollama." "Yellow"
        Write-Badge "+" "Downloading '$model' into Ollama now..." "Cyan"
        ollama pull $model
        Write-Badge "OK" "Model '$model' ready!" "Green"
    } else {
        Write-Badge "OK" "Embedding model '$model' is ready." "Green"
    }
}

Write-Host "`n  -------------------------------------------------------------------------------" -ForegroundColor DarkGray
Write-Host "  >> Launching PDFtoAgent MCP Server" -ForegroundColor Cyan
Write-Host "  -------------------------------------------------------------------------------" -ForegroundColor DarkGray
Write-Badge "LINK" "Server Endpoint: http://127.0.0.1:8765/mcp" "Green"
Write-Badge "INFO" "Transport      : Streamable HTTP (SSE compatible)" "Cyan"
Write-Badge "CTRL" "Press Ctrl+C in this window anytime to stop the server." "Magenta"
Write-Host ""

Set-Location $pkgRoot
& "$pkgRoot\python_embedded\python.exe" -m core.mcp.server --skill stock-market-barometer-hamilton --transport streamable-http --host 127.0.0.1 --port 8765
if ($LASTEXITCODE -ne 0) {
    Write-Host "`n[ERROR] Server exited with an error code." -ForegroundColor Red
    pause
}
