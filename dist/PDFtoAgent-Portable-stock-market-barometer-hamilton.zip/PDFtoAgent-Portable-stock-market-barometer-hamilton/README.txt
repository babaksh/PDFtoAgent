======================================================================
  PDFtoAgent Standalone Portable MCP Server
  Target: stock-market-barometer-hamilton
  Crafted by: Babak (https://github.com/babaksh)
======================================================================

QUICK START:
1. Double-click 'run_server.bat' to launch the server.
2. The FastMCP server will be online at:
   http://127.0.0.1:8765/mcp
3. Keep the terminal window open while using the tools in your AI apps.

======================================================================
CONNECTING TO YOUR AI APPS:
======================================================================

1. CLAUDE DESKTOP:
   In Claude Desktop, click Settings (gear icon) -> Developer -> Edit Config.
   Paste the following block into your claude_desktop_config.json:

   {
     "mcpServers": {
       "stock-market-barometer-hamilton": {
         "command": "npx",
         "args": ["-y", "mcp-remote", "http://127.0.0.1:8765/mcp"]
       }
     }
   }
   Restart Claude Desktop and look for the hammer icon!

----------------------------------------------------------------------
2. GOOGLE ANTIGRAVITY:
   Option A (Via Settings UI):
   - Open Settings (Ctrl + ,) -> Antigravity -> MCP Servers -> Add Server.
   - Name: stock-market-barometer-hamilton
   - URL:  http://127.0.0.1:8765/mcp

   Option B (Via Configuration File):
   - Add to ~/.gemini/config/mcp_config.json:
   {
     "mcpServers": {
       "stock-market-barometer-hamilton": {
         "serverUrl": "http://127.0.0.1:8765/mcp"
       }
     }
   }

----------------------------------------------------------------------
3. CHATGPT DESKTOP (macOS & Windows):
   - Open ChatGPT Settings -> Apps & Connectors -> Add MCP Server.
   - Name:      stock-market-barometer-hamilton
   - Transport: Streamable HTTP
   - URL:       http://localhost:8765/mcp

----------------------------------------------------------------------
4. CURSOR & WINDSURF:
   - Open Settings (Ctrl + Shift + J) -> Features -> MCP Servers.
   - Click '+ Add New MCP Server':
     Type: SSE / HTTP (Streamable HTTP)
     Name: stock-market-barometer-hamilton
     URL:  http://localhost:8765/mcp

----------------------------------------------------------------------
5. OPENCLAW:
   - Add to openclaw.json:
   {
     "mcp": {
       "servers": {
         "stock-market-barometer-hamilton": {
           "url": "http://localhost:8765/mcp",
           "transport": "streamable-http"
         }
       }
     }
   }

======================================================================
CONFIGURATION & EMBEDDINGS (config/.env):
======================================================================
By default, the server uses local Ollama (100% offline, lightweight ~500MB RAM).
If you prefer cloud embeddings (0MB local RAM usage), open:
  config/.env
and set:
  EMBEDDING_PROVIDER=nomic
  NOMIC_API_KEY=your_free_nomic_api_key
(Get 1M free tokens/mo at https://atlas.nomic.ai).

======================================================================
100% PORTABLE & ZERO INSTALL:
======================================================================
This distribution does NOT modify your Windows Registry or system environment.
To uninstall or remove, simply delete this folder.
