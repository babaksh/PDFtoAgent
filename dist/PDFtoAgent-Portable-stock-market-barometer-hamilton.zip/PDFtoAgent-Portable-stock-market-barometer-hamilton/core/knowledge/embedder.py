"""
Embedding provider abstraction.

Supports three back-ends selected by ``settings.embedding_provider``:

* ``"openai"``  – OpenAI Embeddings API (``text-embedding-3-small`` by default).
                  Requires a valid ``OPENAI_API_KEY``.
* ``"local"``   – Sentence-Transformers model running fully offline
                  (``all-MiniLM-L6-v2`` by default).
* ``"ollama"``  – Ollama local embeddings (``nomic-embed-text`` by default).
                  Requires Ollama running locally.
"""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING

from ..config import settings

if TYPE_CHECKING:
    from openai import OpenAI as _OpenAIClient
    from sentence_transformers import SentenceTransformer as _STModel

logger = logging.getLogger(__name__)

# Batch sizes chosen to stay well within API / memory limits.
_OPENAI_BATCH_SIZE = 512
_LOCAL_BATCH_SIZE = 64
_OLLAMA_BATCH_SIZE = 32


class Embedder:
    """
    Generates dense embedding vectors for a list of strings.

    Parameters are read entirely from ``settings``; no constructor arguments
    are required.

    Usage
    -----
    ::

        embedder = Embedder()
        vectors = embedder.embed(["hello world", "another sentence"])
        single  = embedder.embed_one("just one string")
    """

    def __init__(self) -> None:
        self.provider: str = settings.embedding_provider

        if self.provider == "openai":
            from openai import OpenAI

            kwargs = {"api_key": settings.openai_api_key}
            if getattr(settings, "openai_base_url", ""):
                kwargs["base_url"] = settings.openai_base_url
            self._client: _OpenAIClient = OpenAI(**kwargs)
            self._model_name: str = settings.openai_embedding_model
            logger.info("Embedder ready – provider=openai, model=%s", self._model_name)

        elif self.provider == "local":
            from sentence_transformers import SentenceTransformer

            model_name = settings.local_embedding_model
            self._st: _STModel = SentenceTransformer(model_name)
            logger.info("Embedder ready – provider=local, model=%s", model_name)

        elif self.provider == "ollama":
            self._model_name: str = settings.ollama_embedding_model
            self._host: str = settings.ollama_embedding_host
            logger.info(
                "Embedder ready – provider=ollama, model=%s, host=%s",
                self._model_name,
                self._host,
            )

        elif self.provider == "nomic":
            self._api_key: str = getattr(settings, "nomic_api_key", "")
            self._model_name: str = getattr(settings, "nomic_embedding_model", "nomic-embed-text-v1.5")
            logger.info("Embedder ready – provider=nomic, model=%s", self._model_name)

        else:
            raise ValueError(
                f"Unknown embedding_provider '{self.provider}'. "
                "Expected 'openai', 'local', 'ollama', or 'nomic'."
            )

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def embed(self, texts: list[str]) -> list[list[float]]:
        """
        Return one embedding vector per string in *texts*.

        Texts are processed in batches to avoid API rate-limit and memory
        constraints.  The returned list is in the same order as *texts*.

        Parameters
        ----------
        texts:
            List of strings to embed.  An empty list returns ``[]``.

        Returns
        -------
        list[list[float]]
            Parallel list of float vectors.
        """
        if not texts:
            return []

        if self.provider == "openai":
            return self._embed_openai(texts)
        elif self.provider == "local":
            return self._embed_local(texts)
        elif self.provider == "ollama":
            return self._embed_ollama(texts)
        elif self.provider == "nomic":
            return self._embed_nomic(texts)
        return []

    def embed_one(self, text: str) -> list[float]:
        """Convenience wrapper – embed a single string and return its vector."""
        return self.embed([text])[0]

    # ------------------------------------------------------------------
    # Provider-specific helpers
    # ------------------------------------------------------------------

    def _embed_openai(self, texts: list[str]) -> list[list[float]]:
        """Call the OpenAI Embeddings API in batches."""
        results: list[list[float]] = []

        for start in range(0, len(texts), _OPENAI_BATCH_SIZE):
            batch = texts[start : start + _OPENAI_BATCH_SIZE]
            try:
                response = self._client.embeddings.create(
                    model=self._model_name,
                    input=batch,
                )
                results.extend(item.embedding for item in response.data)
            except Exception as exc:
                logger.error(
                    "OpenAI embedding failed for batch [%d:%d]: %s",
                    start,
                    start + len(batch),
                    exc,
                )
                raise

        return results

    def _embed_local(self, texts: list[str]) -> list[list[float]]:
        """Run inference through the local Sentence-Transformers model."""
        results: list[list[float]] = []

        for start in range(0, len(texts), _LOCAL_BATCH_SIZE):
            batch = texts[start : start + _LOCAL_BATCH_SIZE]
            try:
                # encode() returns a numpy array; convert to plain Python lists.
                embeddings = self._st.encode(batch, show_progress_bar=False)
                results.extend(vec.tolist() for vec in embeddings)
            except Exception as exc:
                logger.error(
                    "Local embedding failed for batch [%d:%d]: %s",
                    start,
                    start + len(batch),
                    exc,
                )
                raise

        return results

    def _embed_ollama(self, texts: list[str]) -> list[list[float]]:
        """Call the Ollama embeddings API in batches."""
        import json
        import urllib.error
        import urllib.request

        results: list[list[float]] = []

        for start in range(0, len(texts), _OLLAMA_BATCH_SIZE):
            batch = texts[start : start + _OLLAMA_BATCH_SIZE]
            try:
                batch_embeddings: list[list[float]] = []
                for text in batch:
                    payload = json.dumps({
                        "model": self._model_name,
                        "prompt": text,
                    }).encode("utf-8")

                    req = urllib.request.Request(
                        f"{self._host}/api/embeddings",
                        data=payload,
                        headers={"Content-Type": "application/json"},
                    )

                    with urllib.request.urlopen(req, timeout=settings.ollama_embed_timeout) as response:
                        data = json.loads(response.read().decode("utf-8"))
                        batch_embeddings.append(data["embedding"])

                results.extend(batch_embeddings)
            except Exception as exc:
                logger.error(
                    "Ollama embedding failed for batch [%d:%d]: %s",
                    start,
                    start + len(batch),
                    exc,
                )
                raise

        return results

    def _embed_nomic(self, texts: list[str]) -> list[list[float]]:
        """Call Nomic Atlas Embeddings API (free 1M tokens/month)."""
        import json
        import urllib.request

        if not self._api_key:
            raise ValueError(
                "NOMIC_API_KEY is not set. Get a free API key at https://atlas.nomic.ai "
                "and set NOMIC_API_KEY in your .env file."
            )

        results: list[list[float]] = []
        batch_size = 64
        for start in range(0, len(texts), batch_size):
            batch = texts[start : start + batch_size]
            payload = json.dumps({
                "model": self._model_name,
                "texts": batch,
                "task_type": "search_query",
            }).encode("utf-8")
            req = urllib.request.Request(
                "https://api-atlas.nomic.ai/v1/embedding/text",
                data=payload,
                headers={
                    "Authorization": f"Bearer {self._api_key}",
                    "Content-Type": "application/json",
                },
                method="POST",
            )
            try:
                with urllib.request.urlopen(req, timeout=30) as resp:
                    data = json.loads(resp.read().decode("utf-8"))
                    results.extend(data.get("embeddings", []))
            except Exception as exc:
                logger.error(
                    "Nomic embedding API failed for batch [%d:%d]: %s",
                    start,
                    start + len(batch),
                    exc,
                )
                raise

        return results
