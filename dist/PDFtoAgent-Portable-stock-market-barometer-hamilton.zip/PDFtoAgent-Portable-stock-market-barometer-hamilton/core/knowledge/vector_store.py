"""
Lightweight, dependency-free vector store for PDFtoAgent.

Replaces ChromaDB with a tiny pure-NumPy persistent store:

* Embeds are computed by the configured embedding provider (OpenAI / Ollama /
  local) — this module only *stores* them and runs cosine similarity.
* For a single book (hundreds–low-thousands of chunks) exact cosine search over
  all vectors is instant and 100% accurate (no approximate ANN error), so
  retrieval quality is identical to — and strictly no worse than — ChromaDB's
  HNSW index.
* Persistence: ``<collection>.npy`` (float32 embedding matrix) + ``<collection>.json``
  (ids / documents / metadata). No native libraries, no network.

On-disk layout is compatible with the MCP server: ``list_collections`` globs the
``.npy`` files so an existing store is discovered exactly like before.
"""

from __future__ import annotations

import json
import logging
from pathlib import Path
from typing import TYPE_CHECKING

import numpy as np

try:
    from ..ingestion.document_tree import KnowledgeChunk
except ImportError:
    class KnowledgeChunk:  # type: ignore[no-redef]
        """Fallback stub for serving runtime when ingestion package is omitted."""
        pass

if TYPE_CHECKING:
    from collections.abc import Sequence

logger = logging.getLogger(__name__)

# ChromaDB metadata values must be scalar; filter out anything that isn't.
_SCALAR_TYPES = (str, int, float, bool)


class _Collection:
    """Minimal stand-in for a ChromaDB collection handle (``.name``)."""

    def __init__(self, name: str) -> None:
        self.name = name


class _Client:
    """Stand-in for the ChromaDB client so callers can keep ``.client.list_collections()``."""

    def __init__(self, store: "VectorStore") -> None:
        self._store = store

    def list_collections(self) -> list[_Collection]:
        return [_Collection(n) for n in self._store._list_names()]


class VectorStore:
    """
    Manages a single or multiple persistent collections backed by a local
    directory. Each collection is stored as ``<name>.npy`` + ``<name>.json``.

    Usage
    -----
    ::

        store = VectorStore(persist_dir=Path("data/vs"))
        store.create("my_collection")      # or store.load(...)
        store.add(chunks, embeddings)

        hits = store.search(query_vector, n_results=5)
        # hits[0] == {"content": "...", "metadata": {...}, "score": 0.87}
    """

    def __init__(self, persist_dir: Path) -> None:
        persist_dir = Path(persist_dir)
        persist_dir.mkdir(parents=True, exist_ok=True)
        self.persist_dir = persist_dir
        # Active collection: dict with keys name, ids, docs, metas, embeddings.
        self.collection: dict | None = None

    # ── chromadb-client shim (keeps ``store.client.list_collections()`` working)
    @property
    def client(self) -> _Client:
        return _Client(self)

    def _list_names(self) -> list[str]:
        return [p.stem for p in self.persist_dir.glob("*.npy")]

    # ------------------------------------------------------------------
    # Collection lifecycle
    # ------------------------------------------------------------------
    def create(self, collection_name: str) -> "VectorStore":
        """
        Get-or-create a collection (idempotent). If it already exists on disk
        it is loaded; otherwise an empty collection is initialised and persisted.
        """
        if (self.persist_dir / f"{collection_name}.npy").exists():
            self.load(collection_name)
        else:
            self.collection = {
                "name": collection_name,
                "ids": [],
                "docs": [],
                "metas": [],
                "embeddings": [],
            }
            self._persist()
        logger.info("Collection '%s' ready (%d doc(s)).", collection_name, self.count())
        return self

    def load(self, collection_name: str) -> "VectorStore":
        """Load an existing collection by name."""
        npy = self.persist_dir / f"{collection_name}.npy"
        jsonp = self.persist_dir / f"{collection_name}.json"
        embeddings: list | np.ndarray = []
        if npy.exists():
            arr = np.load(str(npy))
            if arr.ndim == 2 and arr.shape[0] > 0:
                embeddings = arr
        data = (
            json.loads(jsonp.read_text(encoding="utf-8")) if jsonp.exists() else {}
        )
        self.collection = {
            "name": collection_name,
            "ids": data.get("ids", []),
            "docs": data.get("docs", []),
            "metas": data.get("metas", []),
            "embeddings": embeddings,
        }
        logger.info("Loaded collection '%s' (%d doc(s)).", collection_name, self.count())
        return self

    # ------------------------------------------------------------------
    # CRUD
    # ------------------------------------------------------------------
    def add(self, chunks: "Sequence[KnowledgeChunk]", embeddings: "Sequence") -> None:
        """
        Append *chunks* and their *embeddings* to the active collection.

        Upsert semantics are not needed here: the build/rebuild flow always
        writes a fresh collection, so this only ever appends to an empty one.
        """
        if self.collection is None:
            raise RuntimeError(
                "No collection is active. Call create() or load() first."
            )
        col = self.collection
        for c, emb in zip(chunks, embeddings):
            col["ids"].append(c.chunk_id)
            col["docs"].append(c.content)
            meta = {
                "section": c.section,
                "page": c.source_page,
                "chunk_index": c.chunk_index,
            }
            meta.update(
                {k: v for k, v in c.metadata.items() if isinstance(v, _SCALAR_TYPES)}
            )
            col["metas"].append(meta)
            col["embeddings"].append(list(emb) if not isinstance(emb, np.ndarray) else emb.tolist())
        self._persist()
        logger.debug("Added %d chunk(s) to '%s'.", len(col["ids"]), col["name"])

    def search(
        self,
        query_embedding: list[float],
        n_results: int = 5,
        filter_dict: dict | None = None,
        use_mmr: bool = False,
        lambda_mult: float = 0.5,
    ) -> list[dict]:
        """
        Return the *n_results* closest chunks to *query_embedding* as exact
        cosine-similarity matches (score in [0, 1]), with optional metadata
        filtering and MMR deduplication.
        """
        if self.collection is None:
            raise RuntimeError("No collection is active. Call create() or load() first.")
        col = self.collection
        available = len(col["ids"])
        if available == 0:
            return []

        # 1. Apply metadata filter if provided
        valid_indices = list(range(available))
        if filter_dict:
            filtered_indices = []
            for i in valid_indices:
                meta = col["metas"][i]
                match = True
                for k, v in filter_dict.items():
                    if k not in meta:
                        match = False
                        break
                    val = meta[k]
                    if isinstance(v, str) and isinstance(val, str):
                        # Case-insensitive substring match for flexibility
                        if v.lower() != val.lower() and v.lower() not in val.lower():
                            match = False
                            break
                    elif v != val:
                        match = False
                        break
                if match:
                    filtered_indices.append(i)
            valid_indices = filtered_indices

        if not valid_indices:
            return []

        # Limit n_results to the size of filtered results
        n_results = min(n_results, len(valid_indices))

        embs = col["embeddings"]
        if isinstance(embs, list):
            embs = np.array(embs, dtype=np.float32) if embs else np.zeros((0, 1))
        embs = np.asarray(embs, dtype=np.float32)
        q = np.asarray(query_embedding, dtype=np.float32)

        # Exact cosine similarities for all items in the collection
        norms = np.linalg.norm(embs, axis=1)
        qn = float(np.linalg.norm(q))
        sims = (embs @ q) / (norms * qn + 1e-12)
        sims = np.clip(sims, 0.0, 1.0)

        # 2. Selection algorithm (MMR vs Standard Cosine Top-K)
        if use_mmr and len(valid_indices) > 1:
            selected_indices = []
            candidate_indices = list(valid_indices)
            
            while len(selected_indices) < n_results:
                if not selected_indices:
                    # First selection is always the most similar to the query
                    best_cand_idx = np.argmax(sims[candidate_indices])
                    idx_to_add = candidate_indices[best_cand_idx]
                    selected_indices.append(idx_to_add)
                    candidate_indices.remove(idx_to_add)
                else:
                    # Compute similarity of remaining candidates to already selected ones
                    sel_embs = embs[selected_indices]
                    sel_norms = norms[selected_indices]
                    sel_embs_norm = sel_embs / (sel_norms[:, np.newaxis] + 1e-12)
                    
                    # Remaining candidates normalized
                    rem_cand_embs = embs[candidate_indices]
                    rem_cand_norms = norms[candidate_indices]
                    rem_cand_embs_norm = rem_cand_embs / (rem_cand_norms[:, np.newaxis] + 1e-12)
                    
                    # Pairwise similarities between candidates (rows) and selected (cols)
                    pairwise_sims = rem_cand_embs_norm @ sel_embs_norm.T
                    max_pairwise_sim = np.max(pairwise_sims, axis=1)
                    
                    # MMR formula: lambda * sim(doc, Q) - (1 - lambda) * max_sim(doc, selected)
                    cand_sims_to_q = sims[candidate_indices]
                    mmr_scores = lambda_mult * cand_sims_to_q - (1.0 - lambda_mult) * max_pairwise_sim
                    
                    best_cand_idx = np.argmax(mmr_scores)
                    idx_to_add = candidate_indices[best_cand_idx]
                    selected_indices.append(idx_to_add)
                    candidate_indices.remove(idx_to_add)
            order = selected_indices
        else:
            # Standard Top-K
            local_order = np.argsort(-sims[valid_indices])[:n_results]
            order = [valid_indices[idx] for idx in local_order]

        return [
            {
                "content": col["docs"][i],
                "metadata": col["metas"][i],
                "score": float(sims[i]),
            }
            for i in order
        ]

    def count(self) -> int:
        """Return the number of documents stored in the active collection."""
        if self.collection is None:
            return 0
        return len(self.collection["ids"])

    # ------------------------------------------------------------------
    # Persistence
    # ------------------------------------------------------------------
    def _persist(self) -> None:
        if self.collection is None:
            return
        name = self.collection["name"]
        ids = self.collection["ids"]
        docs = self.collection["docs"]
        metas = self.collection["metas"]
        embs = self.collection["embeddings"]
        emb_arr = (
            np.array(embs, dtype=np.float32) if embs else np.zeros((0, 1), dtype=np.float32)
        )
        np.save(str(self.persist_dir / f"{name}.npy"), emb_arr)
        (self.persist_dir / f"{name}.json").write_text(
            json.dumps({"ids": ids, "docs": docs, "metas": metas}, ensure_ascii=False),
            encoding="utf-8",
        )
