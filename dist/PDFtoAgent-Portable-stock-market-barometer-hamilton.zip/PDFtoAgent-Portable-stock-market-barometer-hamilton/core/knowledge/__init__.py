"""
Knowledge processing sub-package.

``Embedder`` and ``VectorStore`` are always available. ``Chunker`` and
``KnowledgeExtractor`` belong to the *build-time* RAG pipeline and are imported
defensively: the minimal serving image intentionally omits them, so importing
this package must never fail inside a runtime container.
"""

from __future__ import annotations

from .embedder import Embedder
from .vector_store import VectorStore

try:
    from .chunker import Chunker
    from .extractor import KnowledgeExtractor
except ImportError:
    # Build-time RAG pipeline (chunker / extractor) is not shipped in the
    # runtime image. The serving container never calls them, so this is
    # expected and importing core.knowledge must still succeed.
    Chunker = KnowledgeExtractor = None  # type: ignore[assignment]

__all__ = ["Chunker", "Embedder", "KnowledgeExtractor", "VectorStore"]
