"""
Runtime configuration for the containerized PDFtoAgent MCP server.

Minimal, self-contained settings required exclusively for serving MCP tools
and handling semantic search embeddings. Contains zero pipeline, prompt,
or agentic internals.
"""

from pathlib import Path
from typing import Literal

from pydantic import AliasChoices, Field
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(
        env_file=(".env", "config/.env"),
        env_file_encoding="utf-8",
        extra="ignore",
    )

    # Base paths & router threshold
    skills_dir: Path = Path("skills")
    mcp_tool_router_threshold: int = 30

    # Embedding provider selection ("openai", "ollama", "local", "nomic")
    embedding_provider: Literal["openai", "local", "ollama", "nomic"] = "openai"

    # Nomic Atlas free cloud embeddings
    nomic_api_key: str = ""
    nomic_embedding_model: str = "nomic-embed-text-v1.5"

    # OpenAI / OpenRouter embeddings
    openai_api_key: str = ""
    openai_base_url: str = ""
    openai_embedding_model: str = "text-embedding-3-small"

    # Ollama embeddings (accepts OLLAMA_EMBEDDING_HOST or OLLAMA_HOST)
    ollama_embedding_host: str = Field(
        default="http://127.0.0.1:11434",
        validation_alias=AliasChoices("ollama_embedding_host", "ollama_host"),
    )
    ollama_embedding_model: str = Field(
        default="nomic-embed-text:v1.5",
        validation_alias=AliasChoices("ollama_embedding_model", "ollama_model"),
    )
    ollama_embed_timeout: float = 60.0

    # Local fallback
    local_embedding_model: str = "all-MiniLM-L6-v2"


settings = Settings()

