"""PDFtoAgent – core package."""
