"""
MCP server for a PDFtoAgent skill package.

Usage:
    python -m core.mcp.server --skill <skill_name>

Loads two layers of tools:
  1. Base tools  — always available (knowledge_search, explain_concept)
  2. Generated tools — Python files in skills/<name>/tools/ auto-imported

Uses stdio transport so OpenClaw (and any MCP-compatible host) can spawn it
as a subprocess and communicate over standard I/O.
"""

from __future__ import annotations

import argparse
import importlib.util
import functools
import inspect
import json
import logging
import os
import re
import shutil
import sys
from pathlib import Path

from mcp.server.fastmcp import FastMCP, Image
from mcp.types import ImageContent, ResourceLink

from ..config import settings
try:
    from ..ingestion.ocr_quality import is_ocr_quality_file
except ImportError:
    def is_ocr_quality_file(path) -> bool:
        name = Path(path).name
        return name == "OCR_QUALITY_SUMMARY.md" or name.endswith(".ocr_report.md")
from ..knowledge.embedder import Embedder
from ..knowledge.vector_store import VectorStore

# Base RAG tools exposed by BOTH the standalone RAG server and the full MCP
# server. Kept in sync with core/skill/packager.py:RAG_BASE_TOOLS (the copy the
# packager uses when generating SKILL.md). Duplicated here because the RAG-only
# Docker image strips core/skill at build time.
RAG_BASE_TOOLS: list = [
    ("knowledge_search", "Semantic search across ALL book content with MMR diversity filtering; filter by section/page/type."),
    ("explain_concept", "Look up any concept, term, or technique from the book and return its definition with source."),
    ("rag_get_figure", "Retrieve a specific figure's high-resolution image, caption, context, and source section/page."),
    ("rag_list_figures", "List all figures, captions, and pages in the book or within a specific section."),
    ("rag_get_section", "Retrieve the full markdown text of a specific book section/chapter by name."),
    ("get_section", "Alias of rag_get_section (returns text without loading images by default)."),
    ("rag_get_section_slice", "Retrieve a targeted slice of a section (single page or sub-heading)."),
    ("list_tools", "List all available tools with descriptions."),
    ("rag_get_figure_base64", "Return a figure's image as base64 TEXT (plus metadata) for saving to a workspace."),
]

logger = logging.getLogger(__name__)


def _normalise_section_title(title: str) -> str:
    """Clean OCR artifacts and encoding noise from a section title."""
    import unicodedata
    t = unicodedata.normalize("NFKC", title)
    t = re.sub(r"[\x00-\x1f\x7f]", " ", t)
    t = re.sub(r"\s+", " ", t).strip()
    # Basic quotes clean
    for q in ('"', "'", '`', '“', '”'):
        if t.count(q) % 2 != 0:
            t = t.replace(q, '')
    return t


def create_server(skill_name: str) -> FastMCP:
    """
    Build and return a configured :class:`FastMCP` instance for *skill_name*.

    Locates the skill directory, loads base tools plus every ``.py`` file
    found in ``skills/<name>/tools/``, and registers them via
    :meth:`FastMCP.add_tool`.
    """
    # Resolve skill directory (hyphenated Agent-Skills layout, then legacy
    # underscore layout, then a bare folder).
    if skill_name.startswith("skill-"):
        bare_name = skill_name[len("skill-"):]
    elif skill_name.startswith("skill_"):
        bare_name = skill_name[len("skill_"):]
    else:
        bare_name = skill_name
    hyphen_name = bare_name.replace("_", "-").lower()
    underscore_name = bare_name.replace("-", "_")
    candidates = [
        settings.skills_dir / f"skill-{hyphen_name}",
        settings.skills_dir / f"skill-{bare_name}",
        settings.skills_dir / f"skill_{underscore_name}",
        settings.skills_dir / f"skill_{bare_name}",
        settings.skills_dir / hyphen_name,
        settings.skills_dir / bare_name,
    ]
    skill_dir = next((c for c in candidates if c.exists()), None)
    if skill_dir is None:
        print(
            f"[PDFtoAgent] Error: skill '{bare_name}' not found.\n"
            f"  Checked: {candidates}\n"
            f"Use 'python -m interface.cli list' to see available skills.",
            file=sys.stderr,
        )
        sys.exit(1)

    # Load metadata
    meta_path = skill_dir / "metadata.json"
    if not meta_path.exists():
        print(
            f"[PDFtoAgent] Error: metadata.json not found in '{skill_dir}'.",
            file=sys.stderr,
        )
        sys.exit(1)

    metadata: dict = json.loads(meta_path.read_text(encoding="utf-8"))
    title: str = metadata.get("title", bare_name)
    knowledge_dir = skill_dir / "knowledge"
    vector_store_dir = knowledge_dir / "vector_store"
    # Allow overriding the vector store location (e.g. a writable tmpfs when the
    # container root FS is mounted read-only).
    vs_override = os.environ.get("PDTOAGENT_VECTOR_STORE_DIR")
    if vs_override:
        vector_store_dir = Path(vs_override)

    # Load SKILL.md as the server instructions — this is the standard MCP
    # mechanism: clients (OpenClaw, Claude Desktop, Cursor, ...) receive the
    # instructions string automatically in their initialize response and use
    # it as the system prompt for the agent.
    skill_md_path = skill_dir / "SKILL.md"
    if skill_md_path.exists():
        instructions = skill_md_path.read_text(encoding="utf-8")
    else:
        instructions = (
            f"You are an expert AI assistant with deep knowledge of '{title}'. "
            "Use the available tools to answer questions, run calculations, "
            "and apply methods from the source book. "
            "Always ground answers in the book's content and cite sections."
        )

    # Create the FastMCP server
    mcp = FastMCP(
        name=bare_name,
        instructions=instructions,
    )

    # Also expose SKILL.md as a read-able MCP resource for on-demand access.
    if skill_md_path.exists():
        @mcp.resource("skill://instructions")
        def _get_skill_md() -> str:
            return skill_md_path.read_text(encoding="utf-8")

    # ── Layer 1: Base tools (knowledge_search, explain_concept) ──────────────
    _register_base_tools(mcp, knowledge_dir, vector_store_dir)

    # ── Layer 2: Generated tools from tools/ directory ────────────────────────
    # Hybrid exposure (Anthropic progressive-disclosure guidance):
    #   • flat   — every generated tool is registered directly (small skill)
    #   • router — only 3 meta-tools (search_tools / get_tool / run_tool) are
    #              registered; the agent DISCOVERS tools on demand, so the
    #              model context never floods with hundreds of schemas.
    tools_dir = skill_dir / "tools"
    if tools_dir.exists():
        entries = _collect_tool_entries(tools_dir, knowledge_dir)
        # The exposure mode is driven solely by the env/config threshold
        # (MCP_TOOL_ROUTER_THRESHOLD) — it is the single source of truth, so
        # changing the .env value takes effect immediately without re-packaging.
        # The metadata.json values are only a package-time record; if they
        # disagree with the current threshold we warn (the SKILL.md was written
        # for a different mode and should be regenerated).
        threshold = settings.mcp_tool_router_threshold
        exposure = "router" if len(entries) >= threshold else "flat"
        pkg_exposure = metadata.get("tool_exposure")
        if pkg_exposure and pkg_exposure != exposure:
            logger.warning(
                "Skill '%s' was packaged as '%s' but MCP_TOOL_ROUTER_THRESHOLD=%d "
                "now selects '%s'. Re-run packaging (or adjust the threshold) so "
                "SKILL.md matches the runtime.",
                bare_name, pkg_exposure, threshold, exposure,
            )
        if exposure == "router":
            _register_router_tools(mcp, entries)
            logger.info(
                "Tool exposure: ROUTER (%d tools behind search_tools/run_tool).",
                len(entries),
            )
        else:
            _register_flat_tools(mcp, entries)
            logger.info("Tool exposure: FLAT (%d tools).", len(entries))
    else:
        logger.warning("No tools/ directory found in skill '%s'.", bare_name)

    return mcp


# ---------------------------------------------------------------------------
# Base tool registration
# ---------------------------------------------------------------------------


def _register_base_tools(
    mcp: FastMCP,
    knowledge_dir: Path,
    vector_store_dir: Path,
    sections_dir: Path | None = None,
) -> None:
    """Register the always-present RAG-based tools.

    ``knowledge_dir`` is the root used for resolving image paths (e.g. an
    ``images/`` folder referenced by ``<figure src="...">`` tags). ``sections_dir``
    is where the source markdown sections live; it defaults to
    ``knowledge_dir / "sections"`` but callers using a different layout (such as
    the standalone RAG server, which keeps markdown under ``<rag_dir>/markdown``)
    can pass it explicitly.
    """
    if sections_dir is None:
        sections_dir = knowledge_dir / "sections"
    manifest_path = knowledge_dir / "tools_manifest.json"
    embedder = Embedder()

    # Lazy-init vector store
    _vs: dict = {}

    def _get_vs() -> VectorStore | None:
        if "store" not in _vs:
            if vector_store_dir.exists():
                try:
                    store = VectorStore(persist_dir=vector_store_dir)
                    # Collect all collection names and load the first one
                    collections = store.client.list_collections()
                    if collections:
                        store.load(collections[0].name)
                        _vs["store"] = store
                    else:
                        _vs["store"] = None
                except Exception as exc:
                    logger.error("Failed to load vector store: %s", exc)
                    _vs["store"] = None
            else:
                _vs["store"] = None
        return _vs["store"]

    def _extract_images_from_content(content: str) -> list:
        """
        Parses <figure src="images/..." alt="..."> tags in content and returns
        a list of MCP ImageContent objects (base64-encoded) for files on disk.
        """
        import base64 as _b64
        import re
        _mime_map = {
            ".png": "image/png", ".jpg": "image/jpeg", ".jpeg": "image/jpeg",
            ".gif": "image/gif", ".webp": "image/webp", ".bmp": "image/bmp",
        }
        fig_pattern = re.compile(r'<figure\s+src="([^"]+)"', re.IGNORECASE)
        images = []
        for src in fig_pattern.findall(content):
            # src is typically 'images/fig_X_Y.png'
            img_path = knowledge_dir / src
            if img_path.exists():
                try:
                    data = _b64.b64encode(img_path.read_bytes()).decode()
                    mime = _mime_map.get(img_path.suffix.lower(), "image/png")
                    images.append(ImageContent(type="image", data=data, mimeType=mime))
                except Exception as e:
                    logger.warning("Failed to load Image %s: %s", img_path, e)
        return images

    def _normalize_figure_id(fid: str) -> str:
        """Flexibly normalize a figure id to the canonical 'X_Y' form."""
        clean = fid.strip().lower()
        clean = re.sub(r'^(?:figure|fig)\s*[:_.-]?\s*', '', clean)
        dot = re.match(r'^(\d+)\.(\d+)$', clean)
        if dot:
            clean = f"{dot.group(1)}_{dot.group(2)}"
        return clean

    def _resolve_figure_image(fid: str) -> tuple[Path | None, str | None]:
        """
        Resolve a figure id to its on-disk image path and canonical id.

        Tries the vector-store figure chunks first (metadata), then falls back
        to scanning the source markdown sections for the ``<figure>`` tag.
        Returns ``(None, None)`` when nothing matches.
        """
        clean = _normalize_figure_id(fid)
        store = _get_vs()
        col = store.collection if store else None
        if col is None and store is not None:
            try:
                collections = store.client.list_collections()
                if collections:
                    store.load(collections[0].name)
                    col = store.collection
            except Exception as exc:  # noqa: BLE001
                logger.warning("Could not load collection for figure lookup: %s", exc)
                col = None

        if col is not None:
            for i, meta in enumerate(col["metas"]):
                if meta.get("type") != "figure":
                    continue
                mfid = str(meta.get("figure_id", "")).strip().lower().replace(".", "_")
                if mfid == clean or clean in mfid or mfid in clean:
                    src = meta.get("image_src", "")
                    if src:
                        p = knowledge_dir / src
                        if p.exists():
                            return p, str(meta.get("figure_id", fid))

        # Fallback: scan source markdown for the <figure> tag.
        _fig_re = re.compile(
            r'<figure\s+src="([^"]+)"\s+alt="([^"]*)">.*?Figure\s+(\d+(?:\.\d+)*)\s*—\s*(.*?)\*.*?</figure>',
            re.DOTALL | re.IGNORECASE,
        )
        for mf in sorted((p for p in sections_dir.glob("*.md") if not is_ocr_quality_file(p))):
            try:
                content = mf.read_text(encoding="utf-8")
            except Exception:
                continue
            for m in _fig_re.finditer(content):
                fig_num = m.group(3)
                if fig_num.replace(".", "_") == clean or clean in fig_num.replace(".", "_"):
                    p = knowledge_dir / m.group(1)
                    if p.exists():
                        return p, fig_num
        return None, None

    def _codex_path(p: Path) -> str:
        """Format *p* as a host-absolute path that Codex / Claude Desktop render
        as a clickable link: plain absolute path with forward slashes and a
        leading '/' on Windows drive paths (e.g. '/D:/.../fig_2_7.png')."""
        posix = p.resolve().as_posix()
        if re.match(r"^[A-Za-z]:/", posix):
            return "/" + posix
        return posix

    def _figure_display_path(img_path: Path, canonical_id: str) -> str | None:
        """Return a host-accessible absolute path for *img_path*, suitable for a
        clickable link in a LOCAL chat client (e.g. Codex on the same host).

        This is intentionally opt-in via environment variables, because in
        containerized/remote clients (e.g. Claude Desktop running in its own
        container) the server's filesystem is not reachable and a raw host path
        would be meaningless or misleading. Returns ``None`` when no display
        path should be emitted.

        - ``PDTOAGENT_FIGURE_PUBLIC_DIR``: copy the PNG into this (shared /
          volume-mounted) directory and return that path -- the robust choice
          for deployments where the client cannot see the server's filesystem.
        - ``PDTOAGENT_FIGURE_DISPLAY_PATH``: emit the plain absolute path of the
          existing on-disk image (no copy) -- fine for local, non-containerized
          servers whose filesystem the client can already reach.
        """
        public_dir = os.environ.get("PDTOAGENT_FIGURE_PUBLIC_DIR")
        if public_dir:
            try:
                dst = Path(public_dir)
                dst.mkdir(parents=True, exist_ok=True)
                target = dst / f"figure-{canonical_id.replace('.', '_')}.png"
                shutil.copyfile(img_path, target)
                return _codex_path(target)
            except Exception as exc:  # noqa: BLE001
                logger.warning("Could not copy figure to public dir: %s", exc)
        if os.environ.get("PDTOAGENT_FIGURE_DISPLAY_PATH"):
            return _codex_path(img_path)
        return None

    @mcp.resource("skill://figure/{figure_id}")
    def _figure_resource(figure_id: str) -> Image:
        """
        Expose each book figure as an addressable MCP resource so clients can
        fetch it on demand via ``resources/read`` (or reference it by URI)
        instead of the server pushing raw image bytes.
        """
        path, _ = _resolve_figure_image(figure_id)
        if path is None:
            raise FileNotFoundError(f"Figure '{figure_id}' not found.")
        return Image(path=str(path))

    @mcp.tool()
    async def knowledge_search(
        query: str,
        n_results: int = 5,
        section_filter: str | None = None,
        page_filter: int | None = None,
        type_filter: str | None = None,
        use_mmr: bool = True,
    ) -> list | str:
        """
        Semantic search across all book content with filtering and diversity controls (MMR).
        
        Parameters:
        - query: Semantic search query.
        - n_results: Number of top documents to return.
        - section_filter: Optional substring filter for the section name (e.g. "chapter 1").
        - page_filter: Optional exact page number filter (1-based, matching printed book page).
        - type_filter: Optional type filter, choose either "text" or "figure".
        - use_mmr: Whether to use Maximal Marginal Relevance to diversify results and avoid duplicates.
        """
        store = _get_vs()
        if store is None:
            return "Vector store not available for this skill."
        try:
            # Prepare metadata filters
            filter_dict = {}
            if section_filter:
                filter_dict["section"] = section_filter
            if page_filter is not None:
                # Internally page indices in metadata are 0-based, printed pages are usually 1-based (or we map directly)
                # To be flexible, we match either raw page index or page index + 1
                # Let's check both or normalize to metadata page number (which is 0-based index)
                filter_dict["page"] = page_filter - 1
            if type_filter:
                filter_dict["type"] = type_filter

            query_embedding = embedder.embed_one(query)
            results = store.search(
                query_embedding,
                n_results=n_results,
                filter_dict=filter_dict if filter_dict else None,
                use_mmr=use_mmr,
            )
            if not results:
                return "No results found matching your filters."
                
            lines = [f"Search results for: '{query}' (MMR={use_mmr}, filters={filter_dict})\n"]
            full_content = ""
            for i, r in enumerate(results, 1):
                meta = r.get("metadata", {})
                section = meta.get("section", "Unknown section")
                page = meta.get("page", 0) + 1  # Display as 1-based
                score = r.get("score", 0)
                chunk_type = meta.get("type", "text")
                fig_id_str = f", figure_id='{meta['figure_id']}'" if chunk_type == "figure" and "figure_id" in meta else ""
                
                lines.append(
                    f"[{i}] (score={score:.2f}, type='{chunk_type}'{fig_id_str}, section='{section}', page={page})\n"
                    f"{r['content']}"
                )
                full_content += "\n" + r['content']
            
            text_result = "\n\n".join(lines)
            
            # Extract and encode images if we have any figure chunks or HTML tags
            images = _extract_images_from_content(full_content)
            if images:
                return [text_result] + images
            return text_result
        except Exception as exc:
            return f"Search failed: {exc}"

    @mcp.tool()
    async def explain_concept(term: str) -> list | str:
        """
        Look up any concept, term, or technique mentioned in the book.
        Returns the book's definition with the source section.
        If any figure images are found in the definitions, they are returned as well.
        """
        store = _get_vs()
        if store is None:
            return "Vector store not available for this skill."
        try:
            query_embedding = embedder.embed_one(f"definition of {term}")
            # Use MMR by default to get diverse aspects of the concept
            results = store.search(query_embedding, n_results=3, use_mmr=True)
            if not results:
                return f"No content found for term: '{term}'"
            lines = [f"From the book about '{term}':\n"]
            full_content = ""
            for r in results:
                meta = r.get("metadata", {})
                section = meta.get("section", "Unknown section")
                page = meta.get("page", 0) + 1  # 1-based
                lines.append(f"[Section: {section}, Page: {page}]\n{r['content']}")
                full_content += "\n" + r['content']
                
            text_result = "\n\n".join(lines)
            images = _extract_images_from_content(full_content)
            if images:
                return [text_result] + images
            return text_result
        except Exception as exc:
            return f"Concept lookup failed: {exc}"

    @mcp.tool()
    async def rag_get_figure(figure_id: str) -> list | str:
        """
        Retrieve a specific figure's high-resolution image, descriptive caption, 
        surrounding context, and source section/page.
        
        Parameters:
        - figure_id: Flexible identifier (e.g. 'fig_2_7', '2.7', 'Figure 2.7', 'page_6_img_0').
        """
        store = _get_vs()
        if store is None:
            return "Vector store not available for this skill."
            
        # Clean figure ID input: normalize to "X_Y" or raw string
        clean_id = figure_id.strip().lower()
        
        # Strip prefixes like "figure ", "fig ", "fig_"
        clean_id = re.sub(r'^(?:figure|fig)\s*[:_.-]?\s*', '', clean_id)
        # Replace dot with underscore if it's decimal-like, e.g., "2.7" -> "2_7"
        dot_match = re.match(r'^(\d+)\.(\d+)$', clean_id)
        if dot_match:
            clean_id = f"{dot_match.group(1)}_{dot_match.group(2)}"
            
        logger.info("Normalized figure search ID: %r -> %r", figure_id, clean_id)
        
        # Find the figure chunk by scanning the collection metadata directly.
        # This is an EXACT metadata lookup, so we don't need a query embedding
        # at all -- which avoids any dependency on the embedder's vector
        # dimension (the previous hardcoded [0.0]*1536 dummy broke with
        # embedders that use a different size, e.g. nomic-embed-text = 768).
        col = store.collection
        if col is None:
            try:
                collections = store.client.list_collections()
                if collections:
                    store.load(collections[0].name)
                    col = store.collection
            except Exception as exc:  # noqa: BLE001
                logger.warning("Could not load collection for figure lookup: %s", exc)

        target_chunk = None
        if col is not None:
            for i, meta in enumerate(col["metas"]):
                if meta.get("type") != "figure":
                    continue
                fid = str(meta.get("figure_id", "")).strip().lower().replace(".", "_")
                if fid == clean_id or clean_id in fid or fid in clean_id:
                    target_chunk = {
                        "content": col["docs"][i],
                        "metadata": meta,
                    }
                    break
                    
            if target_chunk is None:
                # Try finding file mapping in case it's on disk but not in vector store
                mapping_path = knowledge_dir.parent / "RAG" / "figure_mapping.json"
                if mapping_path.exists():
                    try:
                        mapping = json.loads(mapping_path.read_text(encoding="utf-8"))
                        # Search keys
                        for k, v in mapping.items():
                            norm_k = k.lower().replace(".", "_")
                            if norm_k == clean_id or clean_id in norm_k or norm_k in clean_id:
                                # We found a mapping! Let's build a synthetic response
                                img_src = v[0] if isinstance(v, list) else v
                                # Check file
                                img_path = knowledge_dir / img_src
                                if img_path.exists():
                                    import base64 as _b64
                                    data = _b64.b64encode(img_path.read_bytes()).decode()
                                    mime = "image/png" if img_src.endswith(".png") else "image/jpeg"
                                    img_obj = ImageContent(type="image", data=data, mimeType=mime)
                                    text_res = f"### Figure {k}\n\nImage mapping found on disk: {img_src}\n\n*Direct figure extraction completed.*"
                                    return [text_res, img_obj]
                    except Exception as e:
                        logger.warning("Failed reading figure mapping: %s", e)
                        
                # Fallback: scan the source markdown sections for the figure tag
                # so the image is still returned even if no figure chunk was
                # indexed in the vector store.
                _fig_re = re.compile(
                    r'<figure\s+src="([^"]+)"\s+alt="([^"]*)">.*?Figure\s+(\d+(?:\.\d+)*)\s*—\s*(.*?)\*.*?</figure>',
                    re.DOTALL | re.IGNORECASE,
                )
                for mf in sorted((p for p in sections_dir.glob("*.md") if not is_ocr_quality_file(p))):
                    try:
                        _content = mf.read_text(encoding="utf-8")
                    except Exception:
                        continue
                    for _m in _fig_re.finditer(_content):
                        _fig_num = _m.group(3)
                        if _fig_num.replace(".", "_") == clean_id or clean_id in _fig_num.replace(".", "_"):
                            _img_src = _m.group(1)
                            _caption = _m.group(4).strip()
                            _img_path = knowledge_dir / _img_src
                            if _img_path.exists():
                                import base64 as _b64
                                _data = _b64.b64encode(_img_path.read_bytes()).decode()
                                _mime = "image/png" if _img_src.endswith(".png") else "image/jpeg"
                                _img_obj = ImageContent(type="image", data=_data, mimeType=_mime)
                                _display = _figure_display_path(_img_path, _fig_num)
                                _text_res = (
                                    f"### Figure {_fig_num}: {_caption}\n"
                                    f"- **Source file:** {mf.name}\n"
                                    f"- **Resource URI:** skill://figure/{_fig_num}\n"
                                )
                                if _display:
                                    _text_res += f"- **Image file:** {_display}\n\n"
                                _text_res += f"**Descriptive Context:**\n{_m.group(0)}\n"
                                _link = ResourceLink(
                                    type="resource_link",
                                    uri=f"skill://figure/{_fig_num}",
                                    name=f"Figure {_fig_num}",
                                    title=f"Figure {_fig_num}: {_caption}",
                                    mimeType=_mime,
                                )
                                return [_text_res, _img_obj, _link]

                return (
                    f"Figure '{figure_id}' (normalized: '{clean_id}') not found.\n"
                    f"Try using 'rag_list_figures' to see all valid figure IDs in the book."
                )
                
            meta = target_chunk["metadata"]
            caption = meta.get("caption", "No description available.")
            section = meta.get("section", "Unknown section")
            page = meta.get("page", 0) + 1
            img_src = meta.get("image_src", "")
            canonical_id = meta.get("figure_id", figure_id)

            text_result = (
                f"### Figure {canonical_id}: {caption}\n"
                f"- **Section:** {section}\n"
                f"- **Page:** {page}\n"
                f"- **Resource URI:** skill://figure/{canonical_id}\n\n"
                f"**Descriptive Context:**\n{target_chunk['content']}\n"
            )

            # Load and encode the exact image file
            if img_src:
                img_path = knowledge_dir / img_src
                if img_path.exists():
                    display = _figure_display_path(img_path, canonical_id)
                    if display:
                        text_result += f"- **Image file:** {display}\n\n"
                    try:
                        import base64 as _b64
                        data = _b64.b64encode(img_path.read_bytes()).decode()
                        mime = "image/png" if img_src.endswith(".png") else "image/jpeg"
                        img_obj = ImageContent(type="image", data=data, mimeType=mime)
                        link = ResourceLink(
                            type="resource_link",
                            uri=f"skill://figure/{canonical_id}",
                            name=f"Figure {canonical_id}",
                            title=f"Figure {canonical_id}: {caption}",
                            mimeType=mime,
                        )
                        return [text_result, img_obj, link]
                    except Exception as e:
                        logger.warning("Failed to base64 encode figure image %s: %s", img_path, e)

            return text_result

    @mcp.tool()
    async def rag_get_figure_base64(figure_id: str) -> str:
        """
        Retrieve a figure and return its image as a BASE64 TEXT string (plus
        metadata) instead of an image content block. The result is a plain
        ``TextContent`` (JSON), so the client receives processable text rather
        than a display-only image block -- e.g. it can decode and write the
        file into its own (possibly restricted) workspace via a filesystem tool
        such as Desktop Commander.

        For large images (>= ~1 MB) the base64 payload can bloat context; in
        that case prefer ``resources/read`` on ``skill://figure/<id>`` if the
        client supports it.
        """
        store = _get_vs()
        img_path, canonical = _resolve_figure_image(figure_id)
        if img_path is None:
            return json.dumps(
                {
                    "error": f"Figure '{figure_id}' not found.",
                    "hint": "Use rag_list_figures to see valid figure IDs.",
                },
                ensure_ascii=False,
            )
        try:
            import base64 as _b64

            raw = img_path.read_bytes()
            b64 = _b64.b64encode(raw).decode()
        except Exception as exc:
            return json.dumps({"error": f"Failed to read image: {exc}"}, ensure_ascii=False)

        caption = ""
        section = ""
        page = 0
        col = store.collection if store else None
        if col is not None:
            clean = _normalize_figure_id(figure_id)
            for i, meta in enumerate(col["metas"]):
                if meta.get("type") != "figure":
                    continue
                mfid = str(meta.get("figure_id", "")).strip().lower().replace(".", "_")
                if mfid == clean or clean in mfid or mfid in clean:
                    caption = meta.get("caption", "")
                    section = meta.get("section", "")
                    page = meta.get("page", 0) + 1
                    break

        mime = "image/png" if img_path.suffix.lower() == ".png" else "image/jpeg"
        size = len(raw)
        result = {
            "figure_id": canonical or figure_id,
            "filename_suggestion": f"figure-{canonical or figure_id}.png",
            "caption": caption,
            "section": section,
            "page": page,
            "mime_type": mime,
            "size_bytes": size,
            "data_uri": f"data:{mime};base64,{b64}",
            "base64": b64,
        }
        # Warn (don't block) when the payload is large enough to bloat context;
        # clients with resource support should prefer resources/read on the
        # skill://figure/<id> URI instead.
        if size > 1024 * 1024:
            result["warning"] = (
                f"Image is {size / 1024 / 1024:.1f} MB; returning base64 may "
                f"bloat context. Prefer resources/read on skill://figure/"
                f"{canonical or figure_id} if your client supports it."
            )
        return json.dumps(result, ensure_ascii=False)

    @mcp.tool()
    async def rag_list_figures(section_name: str | None = None) -> str:
        """
        List all available figures, captions, and pages in the book or within a specific section.
        Does not return the image bytes, only list of figures to choose from.
        """
        if not sections_dir.exists():
            return "Sections folder not found."
            
        fig_pattern = re.compile(
            r'<figure\s+src="([^"]+)"\s+alt="([^"]*)">.*?Figure\s+(\d+(?:\.\d+)*)\s*—\s*(.*?)\*.*?</figure>',
            re.DOTALL | re.IGNORECASE
        )
        # Fallback page-based pattern
        fallback_fig_pattern = re.compile(
            r'<figure\s+src="([^"]+)"\s+alt="([^"]*)">.*?Image from page\s+(\d+).*?</figure>',
            re.DOTALL | re.IGNORECASE
        )
        
        figures_found = []
        
        # Determine files to search
        md_files = sorted((p for p in sections_dir.glob("*.md") if not is_ocr_quality_file(p)))
        if section_name:
            query = section_name.lower().strip()
            # Filter files matching section name
            md_files = [
                f for f in md_files 
                if query in f.name.lower() or query in _normalise_section_title(f.stem).lower()
            ]
            if not md_files:
                return f"No section matching '{section_name}' found to list figures from."
                
        for mf in md_files:
            sect_title = mf.stem.split("_", 1)[-1].replace("_", " ").title()
            try:
                content = mf.read_text(encoding="utf-8")
                # Parse strict figure tags
                for match in fig_pattern.finditer(content):
                    img_src = match.group(1)
                    alt_text = match.group(2)
                    fig_num = match.group(3)
                    caption = match.group(4).strip()
                    figures_found.append({
                        "id": fig_num,
                        "caption": caption,
                        "section": sect_title,
                        "file": mf.name,
                    })
                # Parse fallback figures
                for match in fallback_fig_pattern.finditer(content):
                    img_src = match.group(1)
                    alt_text = match.group(2)
                    page_num = match.group(3)
                    img_filename = os.path.basename(img_src)
                    fig_id_val = img_filename.replace("fig_", "").replace(".png", "").replace(".jpg", "")
                    figures_found.append({
                        "id": fig_id_val,
                        "caption": alt_text or f"Image from page {page_num}",
                        "section": sect_title,
                        "file": mf.name,
                    })
            except Exception as e:
                logger.warning("Failed listing figures in %s: %s", mf.name, e)
                
        if not figures_found:
            return "No figures found matching your query."
            
        lines = ["### List of Figures:\n"]
        for i, fig in enumerate(figures_found, 1):
            lines.append(
                f"{i}. **Figure ID:** `{fig['id']}`\n"
                f"   - **Caption:** {fig['caption']}\n"
                f"   - **Section:** {fig['section']} (File: {fig['file']})\n"
            )
        return "\n".join(lines)

    @mcp.tool()
    async def rag_get_section(section_name: str, include_images: bool = False) -> list | str:
        """
        Retrieve the full markdown text of a specific book section/chapter by name.
        
        Parameters:
        - section_name: Target section or chapter name (supports partial matching).
        - include_images: If True, pulls embedded figure images as base64. 
          If more than 5 figures are found, images are omitted, and figure IDs are returned as a list to prevent context flooding.
        """
        if not sections_dir.exists():
            return "Section files not available for this skill."
            
        query = section_name.lower().strip()
        candidates = list((p for p in sections_dir.glob("*.md") if not is_ocr_quality_file(p)))
        
        best = None
        best_score = 0
        for f in candidates:
            slug = "_".join(f.stem.split("_")[1:]).lower()
            title_in_file = ""
            try:
                first_line = f.read_text(encoding="utf-8").split("\n", 1)[0]
                title_in_file = first_line.lstrip("#").strip().lower()
            except Exception:
                pass
            for candidate_str in (slug, title_in_file):
                if query in candidate_str or candidate_str in query:
                    score = len(set(query.split()) & set(candidate_str.split()))
                    if score > best_score:
                        best_score = score
                        best = f
                        
        if best is None:
            available = [
                "_".join(f.stem.split("_")[1:]).replace("_", " ")
                for f in sorted(candidates)
            ]
            return (
                f"Section '{section_name}' not found.\n"
                f"Available sections:\n" +
                "\n".join(f"  - {s}" for s in available)
            )
            
        try:
            content = best.read_text(encoding="utf-8")
            text_result = f"[Section file: {best.name}]\n\n{content}"
            
            if not include_images:
                return text_result
                
            # Check image count before loading them
            fig_pattern = re.compile(r'<figure\s+src="([^"]+)"', re.IGNORECASE)
            fig_sources = fig_pattern.findall(content)
            
            if len(fig_sources) > 5:
                # Extract figure IDs for listing instead of loading heavy base64
                fig_id_pattern = re.compile(r'Figure\s+(\d+(?:\.\d+)*)', re.IGNORECASE)
                fig_ids = fig_id_pattern.findall(content)
                warn_msg = (
                    f"\n\n--- ⚠️ SMART SAFEGUARD ---\n"
                    f"This section contains {len(fig_sources)} images, which exceeds the optimal threshold (5).\n"
                    f"To protect your context window and speed up response time, image files were omitted.\n"
                    f"You can retrieve any specific image by passing its Figure ID to 'rag_get_figure(figure_id)'.\n\n"
                    f"Figures available in this section:\n" +
                    "\n".join(f"  - Figure {fid}" for fid in fig_ids)
                )
                return text_result + warn_msg
                
            images = _extract_images_from_content(content)
            if images:
                return [text_result] + images
            return text_result
            
        except Exception as exc:
            return f"Could not read section: {exc}"

    # Alias get_section to rag_get_section for backward compatibility
    @mcp.tool()
    async def get_section(section_name: str) -> list | str:
        """
        Retrieve the full markdown text of a specific book section by name.
        Uses the optimized rag_get_section tool under the hood (without loading heavy images by default).
        """
        return await rag_get_section(section_name, include_images=False)

    @mcp.tool()
    async def rag_get_section_slice(
        section_name: str,
        page_number: int | None = None,
        heading: str | None = None,
    ) -> list | str:
        """
        Retrieve a highly targeted slice of a book section (either a single page or a sub-heading).
        Very useful for minimizing context window size and reading only what's needed.
        
        Parameters:
        - section_name: Target section or chapter name.
        - page_number: Optional 1-based page number to extract.
        - heading: Optional sub-heading title to extract (case-insensitive substring match).
        """
        if not sections_dir.exists():
            return "Section files not available for this skill."
            
        query = section_name.lower().strip()
        candidates = list((p for p in sections_dir.glob("*.md") if not is_ocr_quality_file(p)))
        
        best = None
        best_score = 0
        for f in candidates:
            slug = "_".join(f.stem.split("_")[1:]).lower()
            title_in_file = ""
            try:
                first_line = f.read_text(encoding="utf-8").split("\n", 1)[0]
                title_in_file = first_line.lstrip("#").strip().lower()
            except Exception:
                pass
            for candidate_str in (slug, title_in_file):
                if query in candidate_str or candidate_str in query:
                    score = len(set(query.split()) & set(candidate_str.split()))
                    if score > best_score:
                        best_score = score
                        best = f
                        
        if best is None:
            available = [
                "_".join(f.stem.split("_")[1:]).replace("_", " ")
                for f in sorted(candidates)
            ]
            return (
                f"Section '{section_name}' not found.\n"
                f"Available sections:\n" +
                "\n".join(f"  - {s}" for s in available)
            )
            
        try:
            content = best.read_text(encoding="utf-8")
            
            # --- Page-based slicing ---
            if page_number is not None:
                # Page markers are 0-based in Markdown (e.g. <!-- PAGE:4 --> corresponds to printed page 5)
                target_page_idx = page_number - 1
                start_marker = f"<!-- PAGE:{target_page_idx} -->"
                
                if start_marker not in content:
                    # Let's search all existing page markers in file
                    markers = [int(p) for p in re.findall(r'<!-- PAGE:(\d+) -->', content)]
                    if markers:
                        min_p, max_p = min(markers) + 1, max(markers) + 1
                        return f"Page {page_number} is out of bounds for section '{section_name}'. Pages available: {min_p} to {max_p}."
                    return f"No page markers found in section '{section_name}'."
                    
                start_pos = content.find(start_marker)
                
                # Find the next page marker to slice up to
                next_marker_match = re.search(r'<!-- PAGE:(\d+) -->', content[start_pos + len(start_marker):])
                if next_marker_match:
                    end_pos = start_pos + len(start_marker) + next_marker_match.start()
                    slice_text = content[start_pos:end_pos].strip()
                else:
                    slice_text = content[start_pos:].strip()
                    
                text_result = f"[Slice: Section '{best.name}', Page {page_number}]\n\n{slice_text}"
                images = _extract_images_from_content(slice_text)
                if images:
                    return [text_result] + images
                return text_result
                
            # --- Heading-based slicing ---
            if heading is not None:
                cleaned_heading = heading.strip().lower()
                lines = content.splitlines()
                
                heading_lines_indices = []
                for idx, line in enumerate(lines):
                    if line.startswith("#"):
                        # Extract clean title from markdown heading
                        h_title = line.lstrip("#").strip().lower()
                        if cleaned_heading in h_title or h_title in cleaned_heading:
                            heading_lines_indices.append((idx, line))
                            
                if not heading_lines_indices:
                    # Collect all available headings to guide the agent
                    all_headings = [l.strip() for l in lines if l.startswith("#")]
                    return (
                        f"Heading '{heading}' not found in section '{section_name}'.\n"
                        f"Available headings in this section:\n" +
                        "\n".join(f"  {h}" for h in all_headings)
                    )
                    
                # Take the first matched heading
                start_line_idx, heading_line_raw = heading_lines_indices[0]
                # Determine level of heading, e.g. "## Subsection" -> level 2
                heading_level = len(heading_line_raw) - len(heading_line_raw.lstrip("#"))
                
                # Consume lines until we find another heading of the same or higher level (fewer '#' characters)
                slice_lines = [heading_line_raw]
                for idx in range(start_line_idx + 1, len(lines)):
                    line = lines[idx]
                    if line.startswith("#"):
                        current_level = len(line) - len(line.lstrip("#"))
                        if current_level <= heading_level:
                            break
                    slice_lines.append(line)
                    
                slice_text = "\n".join(slice_lines).strip()
                text_result = f"[Slice: Section '{best.name}', Heading '{heading_line_raw.lstrip('#').strip()}']\n\n{slice_text}"
                images = _extract_images_from_content(slice_text)
                if images:
                    return [text_result] + images
                return text_result
                
            return "Please provide either 'page_number' or 'heading' to slice the section."
            
        except Exception as exc:
            return f"Slicing failed: {exc}"

    @mcp.tool()
    async def list_tools() -> str:
        """List all tools available in this skill package with descriptions."""
        lines = ["RAG base tools (always available):"]
        for n, d in RAG_BASE_TOOLS:
            lines.append(f"  - `{n}` — {d}")
        if manifest_path.exists():
            try:
                manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
                tools = manifest.get("tools", [])
                if tools:
                    lines.append(
                        f"\nGenerated tools ({manifest.get('valid', 0)} valid):"
                    )
                    for t in tools:
                        status = "✅" if t.get("is_valid") else "❌"
                        lines.append(f"  {status} {t['name']} — {t.get('description', '')}")
                else:
                    lines.append("\nNo generated tools in this package.")
            except Exception as exc:
                lines.append(f"\n(Could not read generated-tools manifest: {exc})")
        else:
            lines.append("\nNo generated-tools manifest (RAG-only package).")
        return "\n".join(lines)


# ---------------------------------------------------------------------------
# Generated tool loading (registry + flat / router exposure)
# ---------------------------------------------------------------------------


class _ToolEntry:
    """One callable generated tool (a public async function in a module)."""

    __slots__ = ("name", "fn", "description", "schema", "section", "module")

    def __init__(self, name, fn, description, schema, section, module) -> None:
        self.name = name
        self.fn = fn
        self.description = description
        self.schema = schema or {}
        self.section = section
        self.module = module

    # -- rendering helpers -------------------------------------------------

    def signature(self) -> str:
        try:
            return f"{self.name}{inspect.signature(self.fn)}"
        except (ValueError, TypeError):
            return f"{self.name}(...)"

    def render(self, full: bool = False) -> str:
        lines = [f"• {self.signature()}"]
        if self.description:
            lines.append(f"    {self.description}")
        if self.section:
            lines.append(f"    source section: {self.section}")
        if full:
            doc = inspect.getdoc(self.fn) or ""
            if doc:
                lines.append("    docstring:")
                lines.extend(f"      {ln}" for ln in doc.splitlines())
            if self.schema.get("properties"):
                lines.append(
                    "    parameters (JSON Schema): "
                    + json.dumps(self.schema, ensure_ascii=False)
                )
        return "\n".join(lines)


def _collect_tool_entries(tools_dir: Path, knowledge_dir: Path) -> list[_ToolEntry]:
    """Import every tool module and return one entry per public async function.

    Metadata (description / schema / source section) is enriched from
    ``knowledge/tools_manifest.json`` when available; the live function object
    remains the execution authority.
    """
    manifest_meta: dict[str, dict] = {}
    manifest_path = knowledge_dir / "tools_manifest.json"
    if manifest_path.exists():
        try:
            manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
            for t in manifest.get("tools", []):
                if t.get("name"):
                    manifest_meta[t["name"]] = t
        except Exception as exc:
            logger.warning("Could not read tools_manifest.json: %s", exc)

    entries: list[_ToolEntry] = []
    for tool_file in sorted(tools_dir.glob("*.py")):
        if tool_file.name == "__init__.py":
            continue
        try:
            fns = _load_tool_functions(tool_file)
        except Exception as exc:
            logger.error("Failed to load tools from '%s': %s", tool_file.name, exc)
            continue
        if not fns:
            logger.warning("No public async function found in '%s'.", tool_file.name)
            continue
        for fn in fns:
            meta = manifest_meta.get(fn.__name__, {})
            doc_first = (inspect.getdoc(fn) or "").strip().splitlines()
            description = meta.get("description") or (
                doc_first[0] if doc_first else fn.__name__
            )
            sections = meta.get("source_sections") or []
            entries.append(_ToolEntry(
                name=fn.__name__,
                fn=fn,
                description=description,
                schema=meta.get("parameters_schema") or {},
                section=sections[0] if sections else "",
                module=tool_file.stem,
            ))
    return entries


def _wrap_safe_tool(fn):
    """Wrap a generated tool function with a protective runtime net.

    Preserves the signature, docstring, and type annotations for FastMCP schema
    generation. If the tool raises an uncaught exception on unexpected edge-case
    inputs, catches it and returns a standard JSON error response instead of crashing
    the MCP server connection or leaking raw protocol transport errors.
    """
    @functools.wraps(fn)
    async def _safe_tool_wrapper(*args, **kwargs):
        try:
            return await fn(*args, **kwargs)
        except Exception as exc:
            tool_name = getattr(fn, "__name__", "tool")
            logger.error("Runtime exception in tool '%s': %s", tool_name, exc, exc_info=True)
            return json.dumps({
                "result": None,
                "error": f"Runtime execution error ({type(exc).__name__}): {exc}",
                "metadata": {
                    "tool": tool_name,
                    "error_type": type(exc).__name__,
                },
            }, ensure_ascii=False)
    return _safe_tool_wrapper


def _register_flat_tools(mcp: FastMCP, entries: list[_ToolEntry]) -> None:
    """Register EVERY generated tool directly as its own MCP tool."""
    for e in entries:
        safe_fn = _wrap_safe_tool(e.fn)
        mcp.add_tool(safe_fn, name=e.name, description=e.description or e.name)
        logger.info("Registered generated tool: '%s'", e.name)
    logger.info("Registered %d generated tool(s) (flat).", len(entries))


# ---------------------------------------------------------------------------
# Router exposure — Tool Library pattern (progressive disclosure)
# ---------------------------------------------------------------------------


class _ToolIndex:
    """Searchable index over the tool library.

    Semantic (embedding) ranking with a graceful, permanent fallback to
    lexical scoring when the embedding backend is unavailable. Lexical
    scoring alone is fully offline and deterministic.
    """

    def __init__(self, entries: list[_ToolEntry]) -> None:
        self.entries = entries
        self._docs = [
            f"{e.name}. {e.description} Section: {e.section}. "
            f"Parameters: {', '.join((e.schema.get('properties') or {}).keys())}"
            for e in entries
        ]
        self._embeddings: list[list[float]] | None = None
        self._embedder: Embedder | None = None
        self._embedding_ok = True  # optimistic until the first failure

    # -- semantic ----------------------------------------------------------

    def _try_semantic(self, query: str, k: int) -> list[tuple[float, _ToolEntry]] | None:
        if not self._embedding_ok:
            return None
        try:
            if self._embedder is None:
                self._embedder = Embedder()
            if self._embeddings is None:
                self._embeddings = self._embedder.embed(self._docs)
            qv = self._embedder.embed_one(query)

            def _cos(a: list[float], b: list[float]) -> float:
                num = sum(x * y for x, y in zip(a, b))
                da = sum(x * x for x in a) ** 0.5
                db = sum(y * y for y in b) ** 0.5
                return num / (da * db) if da and db else 0.0

            scored = [
                (_cos(qv, ev), e)
                for ev, e in zip(self._embeddings, self.entries)
            ]
            scored.sort(key=lambda t: t[0], reverse=True)
            return scored[:k]
        except Exception as exc:
            logger.warning("Embedding search unavailable (%s) — lexical fallback.", exc)
            self._embedding_ok = False
            return None

    # -- lexical -----------------------------------------------------------

    def _lexical(self, query: str, k: int) -> list[tuple[float, _ToolEntry]]:
        q_tokens = {t for t in _tokenize(query) if len(t) > 1}
        scored: list[tuple[float, _ToolEntry]] = []
        for e in self.entries:
            name_tokens = set(_tokenize(e.name))
            desc_tokens = set(_tokenize(e.description))
            extra_tokens = set(_tokenize(e.section)) | {
                t for p in (e.schema.get("properties") or {}) for t in _tokenize(p)
            }
            score = (
                3.0 * len(q_tokens & name_tokens)
                + 2.0 * len(q_tokens & desc_tokens)
                + 1.0 * len(q_tokens & extra_tokens)
            )
            joined = query.lower().replace(" ", "_")
            if joined and joined in e.name.lower():
                score += 5.0
            if score > 0:
                scored.append((score, e))
        scored.sort(key=lambda t: t[0], reverse=True)
        return scored[:k]

    def search(self, query: str, k: int = 5) -> list[tuple[float, _ToolEntry]]:
        hits = self._try_semantic(query, k)
        if hits is not None:
            return hits
        return self._lexical(query, k)


def _tokenize(text: str) -> list[str]:
    import re
    return re.findall(r"[a-z0-9]+", (text or "").lower())


def _register_router_tools(mcp: FastMCP, entries: list[_ToolEntry]) -> None:
    """Register the Tool Library meta-tools instead of every tool.

    The agent workflow is: ``search_tools`` → (optional ``get_tool``) →
    ``run_tool``. All generated tools stay fully available; only their
    DISCOVERY is deferred, so the model context stays small no matter how
    many tools the book produced.
    """
    index = _ToolIndex(entries)
    by_name = {e.name: e for e in entries}
    chapters: dict[str, list[str]] = {}
    for e in entries:
        chapters.setdefault(e.section or e.module, []).append(e.name)

    @mcp.tool()
    async def search_tools(query: str, n_results: int = 5) -> str:
        """
        Search this skill's computational tool library by capability.
        ALWAYS call this first when the user asks for a calculation: describe
        what you need (e.g. "detect price vectors", "build imbalance bars") and
        it returns the best-matching tools with their exact signatures.
        Then execute the chosen tool with run_tool(name, arguments).
        """
        if not query or not query.strip():
            return "Provide a non-empty query describing the capability you need."
        hits = index.search(query.strip(), k=max(1, min(int(n_results), 20)))
        if not hits:
            return (
                "No matching tools. Try different terms, or browse chapters:\n"
                + "\n".join(f"- {c}: {', '.join(names)}" for c, names in chapters.items())
            )
        out = [f"Top {len(hits)} tool(s) for: '{query}'\n"]
        for score, e in hits:
            out.append(e.render(full=False) + f"\n    relevance: {score:.2f}")
        out.append(
            "\nNext: call run_tool(name=<tool name>, arguments={...}) — or "
            "get_tool(<name>) for the full parameter schema."
        )
        return "\n\n".join(out)

    @mcp.tool()
    async def get_tool(name: str) -> str:
        """
        Get the full specification of one tool from the library:
        signature, docstring, parameter JSON schema, and source section.
        Use after search_tools when you need exact parameter details.
        """
        e = by_name.get(name)
        if e is None:
            close = [n for n in by_name if name.lower() in n.lower()] or list(by_name)[:15]
            return f"Tool '{name}' not found. Did you mean: {', '.join(close[:15])}"
        return e.render(full=True)

    @mcp.tool()
    async def run_tool(name: str, arguments: dict) -> str:
        """
        Execute a tool from the library by name with keyword arguments.
        Example: run_tool(name="detect_vectors",
                          arguments={"prices": [100.0, 101.9, 100.2]})
        Returns the tool's JSON result string ({"result", "error", "metadata"}).
        Find tool names and signatures with search_tools / get_tool first.
        """
        e = by_name.get(name)
        if e is None:
            close = [n for n in by_name if name.lower() in n.lower()]
            hint = f" Did you mean: {', '.join(close[:10])}?" if close else ""
            return json.dumps({
                "result": None,
                "error": f"Tool '{name}' not found.{hint}",
                "metadata": {"hint": "Use search_tools to discover tools."},
            }, ensure_ascii=False)
        try:
            result = await e.fn(**(arguments or {}))
        except TypeError as exc:
            return json.dumps({
                "result": None,
                "error": f"Invalid arguments for {e.signature()}: {exc}",
                "metadata": {
                    "tool": name,
                    "hint": f"Use get_tool('{name}') for the exact parameter schema.",
                },
            }, ensure_ascii=False)



        except Exception as exc:
            return json.dumps({
                "result": None,
                "error": f"Tool '{name}' raised an error ({type(exc).__name__}): {exc}",
                "metadata": {
                    "tool": name,
                    "error_type": type(exc).__name__,
                },
            }, ensure_ascii=False)
        if isinstance(result, str):
            return result
        try:
            return json.dumps(result, ensure_ascii=False, default=str)
        except Exception:
            return str(result)

    logger.info(
        "Registered router meta-tools (search_tools / get_tool / run_tool) "
        "over %d library tool(s).", len(entries),
    )


def _load_tool_functions(tool_file: Path):
    """
    Load a Python file as a module and return ALL public async functions
    defined at module level, or an empty list if none are found.
    """
    spec = importlib.util.spec_from_file_location(
        f"_skill_tool_{tool_file.stem}", str(tool_file)
    )
    if spec is None or spec.loader is None:
        return []

    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)  # type: ignore[union-attr]

    return [
        obj for name, obj in inspect.getmembers(module, inspect.iscoroutinefunction)
        if not name.startswith("_")
    ]


# ---------------------------------------------------------------------------
# Entry point
def create_rag_server(rag_dir: Path) -> FastMCP:
    """Build a FastMCP server that exposes ONLY the RAG knowledge base.

    Loads ``<rag_dir>/vector_store`` (NumPy vector store) and ``<rag_dir>/markdown``
    (source sections) and registers retrieval tools. No generated skill tools
    and no skill package are required — this is purely the book's knowledge,
    so an agent gets semantic search without the calculation tools.
    """
    rag_dir = Path(rag_dir)
    vs_dir = rag_dir / "vector_store"
    vs_override = os.environ.get("PDTOAGENT_VECTOR_STORE_DIR")
    if vs_override:
        vs_dir = Path(vs_override)
    md_dir = rag_dir / "markdown"
    if not vs_dir.exists():
        print(
            f"[PDFtoAgen] Error: vector store not found at '{vs_dir}'.\n"
            f"  Build it first with: python -m interface.cli rag --name <skill>",
            file=sys.stderr,
        )
        sys.exit(1)

    store = VectorStore(persist_dir=vs_dir)
    collections = store.client.list_collections()
    if not collections:
        print(f"[PDFtoAgen] Error: no vector store collection in '{vs_dir}'.", file=sys.stderr)
        sys.exit(1)
    store.load(collections[0].name)

    skill_md_path = rag_dir / "SKILL.md"
    if skill_md_path.exists():
        instructions = skill_md_path.read_text(encoding="utf-8")
    else:
        instructions = (
            f"You are a retrieval assistant for the knowledge base at '{rag_dir}'. "
            "Use knowledge_search to find the most relevant passages, "
            "rag_get_figure / rag_list_figures to work with figures, "
            "rag_get_section / rag_get_section_slice to read full or partial "
            "source sections, and explain_concept to look up terms. "
            "Ground every answer in the retrieved content and cite the section name."
        )

    name = f"{rag_dir.parent.name}_RAG"
    mcp = FastMCP(name=name, instructions=instructions)

    # Expose SKILL.md as a readable MCP resource when present (so the agent can
    # re-read the book/tool overview on demand).
    if skill_md_path.exists():
        @mcp.resource("skill://instructions")
        def _get_skill_md() -> str:
            return skill_md_path.read_text(encoding="utf-8")

    # Reuse the exact same rich RAG tool set as the full skill server so both
    # the standalone RAG server and the full MCP server expose the same tools.
    _register_base_tools(mcp, rag_dir, vs_dir, sections_dir=md_dir)

    return mcp


# ---------------------------------------------------------------------------


def main() -> None:
    parser = argparse.ArgumentParser(
        prog="python -m core.mcp.server",
        description="Start the PDFtoAgent MCP server for a skill package.",
    )
    parser.add_argument(
        "--skill",
        required=False,
        default=None,
        metavar="SKILL_NAME",
        help="Skill slug (with or without a 'skill-' / 'skill_' prefix).",
    )
    parser.add_argument(
        "--rag",
        required=False,
        default=None,
        metavar="RAG_DIR",
        help="Path to a self-contained RAG folder (vector_store/ + markdown/). "
        "Serves ONLY the knowledge base (no generated tools).",
    )
    parser.add_argument(
        "--transport",
        choices=["stdio", "sse", "streamable-http"],
        default="stdio",
        help="MCP transport. 'stdio' spawns as a subprocess (default). "
        "'sse'/'streamable-http' expose an HTTP endpoint so an external "
        "agent (on the same host) can connect over the network.",
    )
    parser.add_argument(
        "--host",
        default=os.environ.get("MCP_HOST", "127.0.0.1"),
        help="Bind host for network transports (default from MCP_HOST / 127.0.0.1).",
    )
    parser.add_argument(
        "--port",
        type=int,
        default=int(os.environ.get("MCP_PORT", "8765")),
        help="Bind port for network transports (default from MCP_PORT / 8765).",
    )
    args = parser.parse_args()

    if bool(args.skill) == bool(args.rag):
        parser.error("specify exactly one of --skill or --rag")
    logging.basicConfig(level=logging.INFO, stream=sys.stderr)
    mcp = create_rag_server(args.rag) if args.rag else create_server(args.skill)

    if args.transport == "stdio":
        mcp.run(transport="stdio")
        return

    # Network transport — bind inside the container; restrict external access at
    # the host's port-mapping level (e.g. -p 127.0.0.1:8765:8765).
    try:
        mcp.settings.host = args.host
        mcp.settings.port = args.port
    except Exception:  # pragma: no cover - settings may be immutable on some versions
        pass
    run_sig = inspect.signature(mcp.run)
    run_kwargs: dict = {"transport": args.transport}
    if "host" in run_sig.parameters:
        run_kwargs["host"] = args.host
    if "port" in run_sig.parameters:
        run_kwargs["port"] = args.port
    logger.info("Serving MCP over %s at %s:%s", args.transport, args.host, args.port)
    mcp.run(**run_kwargs)


if __name__ == "__main__":
    main()
