"""
core.mcp – MCP server package for PDFtoAgent skill packages.
"""
