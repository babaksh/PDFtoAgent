@echo off
chcp 65001 >nul
title PDFtoAgent - stock-market-barometer-hamilton by @30niorcrypto
cd /d "%~dp0"
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0config\launcher.ps1"
if errorlevel 1 pause
