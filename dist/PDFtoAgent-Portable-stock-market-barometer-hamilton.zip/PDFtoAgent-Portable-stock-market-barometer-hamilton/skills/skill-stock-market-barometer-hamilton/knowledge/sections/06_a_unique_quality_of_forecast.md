# A UNIQUE QUALITY OF FORECAST

# A UNIQUE QUALITY OF FORECAST

<!-- PAGE:57 -->

## A UNIQUE QUALITY OF FORECAST

THERE are two Wall Streets. One of them is the Wall Street of fact, slowly arriving at definition out of a chaos of misconception. The other is the Wall Street of fiction; the Wall Street of sensational newspapers, of popularity-hunting politicians; the Wall Street of false dramatic interpretation, whose characters are no more real than the types of the old-fashioned melodrama of fifty years ago—those caricatures which have had an astonishing and unintelligent revival on the moving-picture screen. It was felt that our second chapter might well be devoted to that popular misconception, Wall Street of the movies.

### Major Movements Are Unmanipulated

One of the greatest of misconceptions, that which has militated most against the usefulness of the stock market barometer, is the belief that manipulation can falsify stock market movements otherwise authoritative and instructive. The writer claims no more authority than may come from twenty-six years of stark intimacy with Wall Street, preceded by practical acquaintance with the London Stock Exchange, the Paris Bourse and even that wildly speculative market in gold shares, "Between the Chains," in Johannesburg in 1895. But in all that experience, for what it may be worth, it is impossible to recall a single instance of a major market movement which depended for its impetus, or even for its genesis, upon manipulation. These discussions have been made in vain if they have failed to show that all the primary bull markets and every primary bear market have been vindicated, in the course of their development and before their close, by the facts of general business, however much over-speculation or over-liquidation may have tended to excess, as they always do, in the last stage of the primary swing.

### A Financial Impossibility

This is a sweeping statement, but I am convinced of its fundamental truth. When James R. Keene took up the task of marketing two hundred and twenty thousand shares of Amalgamated Copper, for the people who had brought about that amalgamation but had not been able to float the stock, it is estimated that in the course of distribution he must have traded in at least seven hundred thousand shares of that stock. He carried the price to above par to realize a net of ninety to ninety-six for his employers. This was a relatively small stock capitalization; but let us assume that some syndicate, larger than any that the stock market has ever seen, necessarily involving the co-operation of all the great banking institutions, undertook to manufacture the general bull market without which Keene's efforts would have been worse than wasted.

Let us concede that this super-syndicate could afford to ignore the large number of active securities outside of the forty active stocks taken in our railroad and industrial averages and defy all trained public opinion. Let us assume that they had accumulated for the rise, against all their previous practice and conviction, without, by some miracle, arousing suspicion, not two hundred and twenty thousand shares of stock, but a hundred times that number.

Anybody who learned in the little red school house that two and two make four must see that we are here leading ourselves into an arithmetical impossibility. This syndicate would presumably not be content with less than a forty-point net profit, and its actual trades, before it had established a broad general market even equivalent to that Keene established for Amalgamated Copper, alone would therefore amount to something like one hundred and twenty million shares, which, taking them at par, would involve financing to the amount of many billions of dollars—so much financing, in fact, that the great banks concerned would presumably relinquish all their other business and confine themselves to the syndicate operations alone. Such a syndicate could not have done this, or a tithe of this, at any time during the existence of our national banking system. Does anybody think it would be possible to undertake such a panic-breeding operation with the assistance of the Federal Reserve system?

### Where Manipulation Was Possible

To state the terms of a corresponding bear operation, where every wealthy member of the syndicate is

<!-- PAGE:58 -->

necessarily already a large holder in stocks, bonds, real estate and industrial production, would reduce the whole thing to the wildest absurdity. My mind refuses even to grasp it. Keene, in a broad bull market, to distribute a number of shares amounting to one-twenty-fifth of the common stock alone of the United States Steel Corporation, had behind him all the wealth and influence of the powerful Standard Oil group. When he distributed United States Steel common and preferred he had behind him not only the great Morgan banking influences but those of every group that came into that steel combination, with the general approval of a public which correctly recognized a wonderful and even unprecedented expansion in production and trade. But even with that backing could he have multiplied his efforts a hundredfold? The merchant, the banker, the manufacturer who studies the stock market barometer with reference to the major swings, can dismiss from his mind altogether the idea that they are falsified by manipulation.

### Roger W. Babson's Theory

But the idea is widely held. There is no intention here to arouse or encourage controversy, and if I take an example from Roger W. Babson and his book on Business Barometers, he will, I am sure, readily understand that it is not intended in criticism or depreciation of his highly sincere work. It is only fair to Mr. Babson to say, also, that the extract I give here was published in 1909 (the italics are Mr. Babson's):

> A slowly sagging market usually means that the ablest speculators expect in the near future a period of depression in general business; and a slowly rising market usually means that prosperous business conditions may be expected, unless the decline or rise is artificial and caused by manipulation. In fact, if it were not for manipulation, merchants could almost rely on the stock market alone as a barometer, and let these large market operators stand the expense of collecting the data necessary for determining fundamental conditions. Unfortunately, however, it is impossible by studying the stock market alone to distinguish between artificial movements and natural movements; therefore, although bankers and merchants may watch the stock market as one of the barometers, yet they should give to it only a fair and proportional amount of weight.

—*Business Barometers Used in the Accumulation of Money*, by Roger W. Babson; second edition, 1910.

### Mr. Babson's Chart

What sort of barometer should we have if we had to make allowances for a tube of mercury that was too short, or for a general lack of accuracy in the delicate and sensitive mechanism of the aneroid? The stock market barometer is not perfect, or, to put it more correctly, the adolescent science of reading it is far from having attained perfection. But it is not imperfect in the sense Mr. Babson here assumes. It does discharge its function of prediction, when viewed over any reasonable length of time, with almost uncanny accuracy.

Let us take a few examples from Mr. Babson's own picture chart, those composite "plots" above and below a consistently rising line representing the steady increase in a growing country's wealth, and we shall see how the stock market predicted each of them before Mr. Babson had the material to draw them in the squares of his instructive and striking chart. To those who are unfamiliar with a publication so interesting it may be said that he divides his chart with columns for each month of the year vertically, and completes his squares horizontally with numbered lines showing the area covered by all the factors of business, above or below a gradually rising middle line across the chart representing the growing wealth of the country.

### How the Stock Market Predicted

It will be observed that where these areas are shallow they tend to become broader in time consumed, and where the time to complete the area is less the depression or expansion is deeper or higher, as the case may be, the black areas above or below being assumed to balance each other, at least approximately.

One of these black areas of depression shown in the Babson chart began in 1903, only developing recognizable space in the latter part of that year, and continued throughout 1904, finally emerging above the line of growing wealth in the earlier part of 1905. The stock market anticipated this area of business depression, for a primary bear swing began in September, 1902, and ran until the corresponding month of 1903. Mr. Babson's area of depression was still ruling when the market became mildly bullish, in September, 1903, and

<!-- PAGE:59 -->

strongly bullish before the following June; while the Babson area of depression was not completed till the end of that year—1904.

The Babson chart does not show any great degree of expansion until 1906, although it foreshadows it in September, 1905. But the stock market barometer foresaw all Mr. Babson's expansion, and the long bull market continued up to January, 1907, overrunning itself—a tendency of bull markets and bear markets alike.

### A True Barometer

Mr. Babson's area of expansion reached its high maximum in 1907, when a bear stock market swing had already set in, continuing for eleven months until early December of that year, predicting that length of time ahead of Mr. Babson's truly calculated area of depression, which was deep, but not long in duration, and lasted till the end of 1908. His subsequent expansion area above the line did not begin to show itself in market strength until the end of July of 1908; but the stock market barometer once again foretold the coming prosperity in a bull market which had its genesis in December, 1907, and its culmination in August, 1909, beginning from that time to predict with equal accuracy, and well in advance, Mr. Babson's next period of depression.

Surely this shows that the stock market is a barometer, and that the Babson chart is more strictly a record, from which, of course, people as intelligent as its industrious compilers can draw valuable guidance for the future. To use a much-abused word, the stock market barometer is **unique**. You will remember that "unique" is a word which takes no qualifying adjective. Our barometer is not rather unique, or almost unique, or virtually unique. There is just one of it, and it cannot be duplicated. It does predict, as this simple illustration has shown, the condition of business many months ahead, and no other index, or combination of indices, can assume to do that.

Our highly scientific and competent Weather Bureau often explodes the fallacy of any assumed radical change in general weather conditions. It does not pretend to go back to the glacial age. It tells us that there have been droughts and hard winters before, coming at uncertain and incalculable intervals. When it attempts specific prophecy—a single particular from its immense collection of generals—it is merely guessing. Does anybody who happened to be in Washington at the time remember the "fair and warmer" weather prophesied over the Taft inauguration? I went over the Pennsylvania Railroad on the following day, when the storm had leveled every telegraph pole between New York and Philadelphia. It was even said that some of the special trains had so far missed the parade that they were not in Washington then. Even the aneroid barometer can only forecast a limited number of hours ahead, according to the atmospheric pressure.

### Cycles Overestimated

There are other compilations, and that of Harvard University will be noticed in a more appropriate place.

<!-- PAGE:60 -->

I am inclined to think that all attach too much force to the cycle theory, very much as we have seen that Charles H. Dow did in splitting the favored ten-year cycle into an assumed but non-existent five-year bear market and a similar five-year bull market. But Mr. Babson would tell you that his areas of expansion and even of inflation, extending not five years but two years or less than three in point of time, do not necessarily blow their tops off in a final explosion and that the bottom does not drop out of his period of depression. A stock market crisis may occur in the middle of a bull market, like the Northern Pacific panic of 1901; or a near-panic, with a development more serious and radical, may occur in the course of a major bear swing in the stock market, as in 1907. Mr. Babson correctly shows that the latter was followed by a business depression that had already been foreshadowed in the downward stock market movement.

If all panics and industrial crises arose from the same causes and could be predicted with the suggested rythmical certainty, they would never happen because they would always be foreseen. This sounds something like an Irish "bull," but it may well stand as a statement of the fact. Was it not an Irishman who said that an Irish bull differed from other bulls in the respect that it was always pregnant? I do not here go deeply into this question of cycles, because it is abundantly clear that the stock market is little moved by any such consideration.

### Order Is Heaven's First Law

If Wall Street is the general reservoir for the collection of the country's tiny streams of liquid capital, it is the clearing house for all the tiny contributions to the sum of truth about the facts of business. It cannot be too often repeated that the stock market movement represents the deductions from the accumulation of that truth, including the facts on building and real estate, bank clearings, business failures, money conditions, foreign trade, gold movements, commodity prices, investment markets, crop conditions, railroad earnings, political factors and social conditions, but all of these with an almost limitless number of other things, each having its tiny trickle of stock market effect.

It will be seen from this how true the postulate made in an earlier discussion was when it was said that nobody in Wall Street knows all the facts, to say nothing of the meaning of all the facts. But the impartial, passionless market barometer records them as certainly as the column of mercury records the atmospheric pressure. There is nothing fortuitous about the stock market movement, and I think I have shown that it cannot to any profitable extent be perverted to the ends of deception. There must be laws governing these things, and it is our present purpose to see if we cannot formulate them usefully.

Many years ago George W. Cable said: "What we call chance may be the operation of a law so vast that we only touch its orbit once or twice in a lifetime." There

<!-- PAGE:61 -->

is no need to lose ourselves in the mazes of predestination and forecordination, or reduce the Westminster Confession to absurdity by saying that life is just one damned thing after another. But we shall all recognize that **order is Heaven's first law**, and that organized society, in the Stock Exchange or elsewhere, will tend to obey that law even if the unaided individual intelligence is not great enough to grasp it.