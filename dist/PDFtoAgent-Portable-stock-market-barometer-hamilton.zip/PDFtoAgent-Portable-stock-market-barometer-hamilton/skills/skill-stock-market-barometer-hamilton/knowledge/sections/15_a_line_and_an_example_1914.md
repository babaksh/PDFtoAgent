# A "LINE" AND AN EXAMPLE—1914

# A "LINE" AND AN EXAMPLE—1914

<!-- PAGE:184 -->

## A "LINE" AND AN EXAMPLE—1914

IN past discussions of the stock market barometer—the record by daily averages of the closing "bid" prices of a number of selected industrial and railroad stocks, taken in two separate groups to check and confirm each other—emphasis has been laid upon what is called a "line." It is needless to say that no inference of value can be drawn from a single day's trading. However large the transactions may be, they cannot show the general trend. This daily fluctuation is merely the third and least important movement defined in Dow's theory of the averages. If we could imagine such a thing as an irregular daily tidal movement it is just that. The general level of the sea is not changed by an abnormally high tide in the Bay of Fundy or a tidal bore in the mouth of some Chinese river. The ocean's real encroachments and recessions take time.

### A Definition

The line, therefore, may be considered as often preceding an appreciable recovery in a primary bear market or a well-defined reaction in a primary bull market, and, rarely, as the possible turning of a major movement. It can almost be set down as axiomatic for all our purposes that a line is and must necessarily

<!-- PAGE:185 -->

be either one of accumulation or one of distribution. For a time the buying and selling power are in equilibrium. There are some most significant lines in the history of the averages to which reference has already been made.

### Predicting the War

To show the special value of the averages as a barometer forecasting what even Wall Street itself does not know in any general sense or at any rate does not realize, the extraordinary line made by both averages, industrials and railroads, in the months of May, June and July, 1914, preceding the outbreak of the Great War, is here submitted. No severer test of the averages could be chosen. The war came as a surprise to the whole world. Did the stock market foresee it? It may be fairly claimed that it did, and had predicted it, or trouble of the most momentous character, before the end of July, while the German army crossed into Belgium on August 3d–4th.

Let it be remembered that a primary bear movement had then been in progress in the stock market since October, 1912. In May, 1914, both averages started to make a line of unusual length. The fluctuations in the railroads were between one hundred and three and one hundred and one, and in the industrials between eighty-one and seventy-nine. Only once, on June 25th, did the railroads give a warning at one hundred. This was taken back the following day with a continuance of the line in both averages up to July

<!-- PAGE:186 -->

18th in the case of the railroads and July 27th in the case of the industrials. At the latter date, eight days before the German army invaded Belgium, the industrials confirmed the warning the railroads had given.

### Definition of a "Line"

The accompanying figure chart, taken from May 1, 1914, to July 30th, answers many questions. The line, like others recorded in the averages, was presumably one of accumulation or distribution. At the end of April the bear market had continued for nineteen months, and there is fair conjecture that had there been no war this would have proved a line of accumulation, followed by the bull market which actually started in the ensuing December, soon after the Stock Exchange reopened for business.

This chart answers also the questions as to the dimensions or breadth of a line, which, of course, in theory may be prolonged indefinitely and in this instance had actually extended over sixty-six trading days in the industrials and seventy-one in the railroads. It will be seen that three points was the extreme range in the industrials and four points that in the more stable railroad stocks. The line proved to have been one of distribution, and indeed the market had become so saturated with stocks that the Stock Exchange closed its doors for the first time since the gold panic of 1873.

<!-- PAGE:187 -->

*Figure — AVERAGES FROM MAY 1, 1914 TO CLOSING OF THE STOCK EXCHANGE*

Each figure represents the average closing bid price of twenty railroad stocks and twelve industrial stocks, and a complete trading day.

#### RAILROADS

|   | MAY |   |   |   |   |   |   |   |   |
|---|---|---|---|---|---|---|---|---|---|
|   |   | 103 | 103 | 103 | 103 | 103 | 103 | 103 | 103 |
| 102 | 102 | 102 | 102 | 102 | 102 | 102 | 102 | 102 | 102 |
|   |   | 101 | 101 | 101 |   |   |   |   |   |

|   | JUNE |   |   |   |   |   |   |   |   |
|---|---|---|---|---|---|---|---|---|---|
|   |   | 103 | 103 | 103 | 103 | 103 | 103 | 103 | 103 |
| 102 | 102 | 102 | 102 |   |   |   |   |   |   |
| 101 |   | 102 | 102 | 102 | 102 | 102 | 102 |   | 102 |
|   |   | 101 |   |   |   |   |   | 101 | 101 |
|   |   | 100 |   |   |   |   |   |   | 100 |

|   | JULY |   |   |   |   |   |   |   |   |
|---|---|---|---|---|---|---|---|---|---|
|   |   | 103 |   |   |   |   |   |   |   |
| 102 | 102 | 102 | 102 | 102 | 102 |   |   |   |   |
|   |   | 101 | 101 | 101 | 101 |   |   |   |   |
|   |   | 100 | 100 | 100 | 100 |   |   |   |   |
|   |   |   |   |   |   | 98 | 98 | 98 |   |
|   |   |   |   |   |   | 97 | 97 | 97 | 97 |
|   |   |   |   |   |   |   | 97 | 97 | 97 |
|   |   |   |   |   |   |   |   | 96 | 96 |
|   |   |   |   |   |   |   |   |   |   |
|   |   |   |   |   |   |   |   |   | 94 |
|   |   |   |   |   |   |   |   |   |   |
|   |   |   |   |   |   |   |   |   | 93 |

#### INDUSTRIALS

|   | MAY |   |   |   |   |   |   |   |   |
|---|---|---|---|---|---|---|---|---|---|
|   |   | 81 | 81 | 81 | 81 | 81 | 81 | 81 | 81 |
|   |   | 80 | 80 | 80 | 80 | 80 | 80 | 80 | 80 |
|   |   | 79 | 79 | 79 | 79 | 79 |   |   |   |

|   | JUNE |   |   |   |   |   |   |   |   |
|---|---|---|---|---|---|---|---|---|---|
|   |   | 81 | 81 | 81 | 81 | 81 | 81 | 81 | 81 |
|   |   | 80 | 80 | 80 | 80 | 80 | 80 | 80 | 80 |
|   |   |   |   |   |   |   |   | 79 |   |

|   | JULY |   |   |   |   |   |   |   |   |
|---|---|---|---|---|---|---|---|---|---|
|   |   | 81 | 81 | 81 | 81 | 81 | 81 | 81 | 81 |
|   |   | 80 | 80 | 80 | 80 | 80 | 80 | 80 | 80 |
|   |   |   |   |   |   |   |   | 79 | 79 |
|   |   |   |   |   |   |   |   |   |   |
|   |   |   |   |   |   |   |   |   |   |
|   |   |   |   |   |   |   |   |   | 79 |
|   |   |   |   |   |   |   |   |   |   |
|   |   |   |   |   |   |   |   |   |   |
|   |   |   |   |   |   |   |   |   |   |
|   |   |   |   |   |   |   |   |   | 76 |

<!-- PAGE:188 -->

### What Had Happened?

What had happened? German holders of American stocks and the best informed European bankers had sold in this market. If there had been no war all this would have been absorbed by the American investor at the unrepresentative low prices prevailing in a bear market which in July, 1914, had been operative for twenty-two months. All of it was absorbed by the American investor in the following year. The supply from Europe then, and subsequently, as the war forced foreign holders to realize, and war loans compelled the liquidation of other investments, took the place of the normal supply of new investment securities which it is the duty of Wall Street to create through concentration of opportunity and of savings and the bringing of the two things together. Over-regulation of the railroads, now recognized to have been an economic crime, had paralyzed their power to create new capital long before the war. The public attention had been diverted for five years before that calamity to industrial opportunity, some of it, like the shady oil promotions of our inflation period, of a dangerously speculative character. Without the foreign sales of American securities and the war, turning us in effect from a debtor to a creditor nation, there would have been a dearth of capital opportunity; and this is why after the all-revealing break late in July the market made only a relatively small decline on the reopening of the Stock Exchange, in December, immediately swinging into one of its great bull periods.

<!-- PAGE:189 -->

### Relation to Volume

Knowledge is valuable not merely for telling us what to do but for telling us what to avoid. Inside information, so called, is a dangerous commodity in Wall Street, especially if you trade upon it, but at least it guards you against the rumors which cannot possibly be so. Diligent study of the averages will sufficiently show where a "line," having proved to be one of accumulation, has given definite information, not merely useful to the trader but valuable to those who look upon the stock market as a means of forecasting the trend of the country's general business.

Here is an appropriate opportunity for adding something about volume of sales. This volume is much less significant than is generally supposed. It is purely relative, and what would be a large volume in one state of the market supply might well be negligible in a greatly active market. If the line means absorption, this absorption sums up the market supply, whether it be three hundred thousand shares or three million. Showers of rain vary in intensity, area and duration. But they all result from the moisture in the air reaching saturation point. Rain is rain whether it covers a county or a state, in five hours or five days.

### How to Know a Bull Market

It might well be asked, how are we to tell when a secondary swing, upward for instance, has developed into a primary bull market? The result is seen in

<!-- PAGE:190 -->

the averages in a succession of zig-zag steps. If the secondary swing reacts a little after what would ordinarily be its culmination in a primary bear market but does not decline to the old low figures, and subsequently recovers to points better than the new high established on the earlier rally, we may assume with confidence that a primary bull market of indefinite length has been established. It is, of course, impossible for the barometer to predict the duration of the movement, any more than the aneroid can tell us on October 30th what the weather will be on Election Day.

### Barometrical Limitations

There is no need to expect omniscience from an aneroid barometer, which, as we know, frequently takes back its predictions and would be a most untrustworthy guide for the mariner if it did not. This is true of the stock market barometer, which must be intelligently read. Surgeons and physicians in our time have been greatly helped, to the lasting advantage of human life and comfort, by the X-ray photograph. But these medical men will tell you that the photograph itself must be read by an expert; that to the mere general practitioner not accustomed to its frequent use it may be unintelligible or misleading. The results of an X-ray to disclose, for instance, pyorrhea "pockets" at the roots of the teeth would be meaningless to the layman and perhaps even to some dentists. But any dentist could qualify himself

<!-- PAGE:191 -->

to read those indications, and it is here submitted that any intelligent layman with a sympathetic interest in the stock market movement, by no means necessarily speculative, can read the stock market barometer.

### Speculation's Necessity and Function

Wall Street is a mystery to many men who have unsuccessfully tried to speculate there without knowledge, only to become convinced that they have in some way been cheated in what is no better than a gambling game. It has not been the purpose of these chapters to discuss ethical questions; as, for instance, the morality of speculation or the line which divides speculation from gambling, or the place of gambling in the Ten Commandments, or the supposed special sinfulness of short selling. The personal opinion of the writer is that speculation within a man's means is unaffected by any question of morality. Perhaps this is only another way of saying that its morality is taken for granted, just as the lawful conduct of a man's business is assumed. If the man chooses to make speculation his business, or part of his business, the ethical question becomes purely academic. Speculation is one of the greatest essentials in the development of a nation. The spirit which inspires it can be called by prettier names, like adventure and enterprise. Certainly if no one had been willing to take a speculative risk for a larger profit than mere investment provided the railroads of the United States would have stopped at the eastern foothills of the Alleghenies, and what the maps of

<!-- PAGE:192 -->

our childhood called “the great American desert,” now our great wheat and corn-producing states, would have remained a desert for all we knew to the contrary.

Rudyard Kipling once said that if the British army had always waited for supports the British Empire would have stopped at Margate beach. The speculator in the stock market, or any free market, is a fact and not a theory. He is the embryo investor who does not wait for supports. It will be a bad day for this country, and a sign that having ceased to grow it has begun to dwindle, when it abandons free markets and the free speculation which they necessarily entail.

### Difficult But Not Unfair

It is not true to say that the outside speculator always loses money in Wall Street if he continues speculating long enough, as the present writer (who does not trade on margin himself) can testify from numerous instances to the contrary. But the man who means to hold his own in an encounter requiring capital, courage, judgment, caution, and arduously acquired information from study must devote the same attention to that business that he would to any other business. So far as Wall Street is concerned, the simile of a game of chance is always a bad and misleading one. But it may be said that to those who will not or cannot comply with the conditions of the game when playing against expert exponents of it, trading in Wall Street is a sheer gamble, with a deadly percentage in favor of the dealer (who does not need to be dis-

<!-- PAGE:193 -->

honest) and against such a player. No one would play auction bridge against scientific players without learning how to bid and how to draw correct inferences in the play. He would refrain, if only out of mercy for his prospective partner. But the man who will not risk his own and his partner's money in that way will not hesitate to speculate in Wall Street. Is it surprising that he loses his money?

### Who Makes the Market?

This seems an appropriate place to answer a question which may be said to go to the root of the matter. **"Who makes the market?"** The manipulators? The great banking houses of issue with new securities to float? The professional traders on the floor of the Stock Exchange? The large individual "operators" who talk to newspaper reporters of their profits and tell Congressional committees how they made them, but never say a word about their losses? Certainly not. The market is made by the saving, investing public of the whole United States, first, last and all the time. There is no possible financial combination which can manipulate a bull market, by propaganda or in any other way, when the combined intelligence of the investing public sees that it is time to curtail their commitments in view of a coming decline in prices, earnings and the volume of trade. The most an expert manipulator can do is to stimulate activity in a particular stock, or a small group in a market which is already rising on its merits, with the approval

<!-- PAGE:194 -->

of public sentiment. We hear about the successful manipulation of the market, in United States Steel or Amalgamated Copper, by the late James R. Keene in 1901 and 1902; but we hear nothing of almost innumerable attempts to manipulate for distribution abandoned because the general trend of the market made the operation profitless and dangerous. The great private financing houses are normally sellers of securities because it is their business to manufacture them, in the promotion of new enterprises, and the direction of the great reservoir of public capital into such channels. Individual Wall Street capitalists buy for private investment, and I could tell, from the wills filed for probate, of the unbelievable minor errors of judgment of this kind made by men so well informed as the late J. Pierpont Morgan or the late E. H. Harriman, to name only two of many.

### Speculation's Sound Basis

It has been said before that the stock market represents, in a crystallized form, the aggregate of all America knows about its own business, and, incidentally, about the business of its neighbors. When a man finds his jobbing trade or his factory showing a surplus he tends to invest that surplus in easily negotiable securities. If this improvement is general it is all reflected and anticipated in the market, for he can buy in July and carry on ample margin what he knows he can pay for outright when he divides profits at the end of the year. He does not wait till the end of the

<!-- PAGE:195 -->

year, because he realizes that the knowledge he possesses in July will by that time have become common property, and will have been discounted in the price. He buys ahead just as he buys the raw materials for his factory ahead, at a time when the securities or the raw materials look cheap. It is important to note that this is, in the very best sense, **sentiment**, which comes from the Latin verb *sentire*—"to perceive by the senses and the mind, to feel, to think." This is anything but sentimentalism, which is not encouraged in Wall Street.

### Sentiment

Wall Street knows what sentiment is. It is a thing of high empirise, of adventure, of noble effort to a worthy end. It carried Boone across the Appalachians, and the Argonauts of 1849 through the passes of the Rocky Mountains. It is something we inherit from our forefathers of Shakespeare's time. It is what they brought with them when they put out upon the trackless sea, defying the galleons of Spain, and named a plantation on an unknown continent after their Virgin Queen. Virginia is still here but, as Austin Dobson sings, and Admiral Dewey might have asked, where are the galleons of Spain? This sentiment is a life-giving principle in national growth, not to be confused with sentimental statutes for "an official state flower," with "smile weeks" and slop-over "mothers' days." In the English-speaking race it is a perception which greatly survives for great occa-

<!-- PAGE:196 -->

sions. It was sentiment which first gave a kingly funeral, and a memorial stone in Westminster Abbey, to the Unknown Soldier who had saved the race. It was sentiment which made all London still its voice and hold its breath, one year, to the minute, after the declaration of the armistice. I spent those exalted two minutes at the Mansion House Corner, in the City of London, in November, 1919. It was a moving sight, indeed, when it could bring tears to the eyes of the hardened newspaper reporter.

A great price movement is not the ordained outcome of enlightened individual choice, or even of individual leadership. It is a thing far greater and more impressive, at least to one who has learned, from personal contact, in Wall Street and out,

> “How very weak the very wise,
> How very small the very great are.”