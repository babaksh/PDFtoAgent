# CYCLES AND STOCK MARKET RECORDS

# CYCLES AND STOCK MARKET RECORDS

<!-- PAGE:9 -->

## CYCLES AND STOCK MARKET RECORDS

AN English economist whose unaffected humanity always made him remarkably readable, the late William Stanley Jevons, propounded the theory of a connection between commercial panics and spots on the sun. He gave a series of dates from the beginning of the seventeenth century, showing an apparent coincidence between the two phenomena. It is entirely human and likable that he belittled a rather ugly commercial squeeze of two centuries ago because there were not then a justifying number of spots on the sun. Writing in the New York Times early in 1905, in comment on the Jevons theory, I said that while Wall Street in its heart believed in a cycle of panic and prosperity, it did not care if there were enough spots on the sun to make a straight flush. Youth is temerarious and irreverent. Perhaps it would have been more polite to say that the accidental periodic association proved nothing, like the exact coincidence of presidential elections with leap years.

### Cycles and the Poets

Many teachers of economics, and many business men without pretension even to the more modest title

<!-- PAGE:10 -->

of student, have a profound and reasonable faith in a cycle in the affairs of men. It does not need an understanding of the Einstein theory of relativity to see that the world cannot possibly progress in a straight line in its moral development. The movement would be at least more likely to resemble the journey of our satellite around the sun, which, with all its planetary attendants, is moving toward the constellation of Vega. Certainly the poets believe in the cycle theory. There is a wonderful passage in Byron's *Childe Harold* which, to do it justice, should be read from the preceding apostrophe to Metella's Tower. This was Byron's cycle:

> "Here is the moral of all human tales,
> 'Tis but the same rehearsal of the past;
> First freedom and then glory; when that fails
> Wealth, vice, corruption, barbarism at last,
> And history, with all her volumes vast,
> Hath but one page."

There seems to be a cycle of panics and of times of prosperity. Anyone with a working knowledge of modern history could recite our panic dates—1837, 1857, 1866 (Overend-Gurney panic in London), 1873, 1884, 1893, 1907, if he might well hesitate to add the deflation year of 1920. Panics, at least, show a variable interval between them, from ten to fourteen years, with the intervals apparently tending to grow longer. In a subsequent chapter we shall analyze this cycle theory, to test its possible usefulness.

<!-- PAGE:11 -->

### Periodicity

But the pragmatic basis for the theory, a working hypothesis if nothing more, lies in human nature itself. Prosperity will drive men to excess, and repentance for the consequence of those excesses will produce a corresponding depression. Following the dark hour of absolute panic, labor will be thankful for what it can get and will save slowly out of smaller wages, while capital will be content with small profits and quick returns. There will be a period of readjustment like that which saw the reorganization of most of the American railroads after the panic of 1893. Presently we wake up to find that our income is in excess of our expenditure, that money is cheap, that the spirit of adventure is in the air. We proceed from dull or quiet business times to real activity. This gradually develops into extended speculation, with high money rates, inflated wages and other familiar symptoms. After a period of years of good times the strain of the chain is on its weakest link. There is a collapse like that of 1907, a depression foreshadowed in the stock market and in the price of commodities, followed by extensive unemployment, often an actual increase in savings-bank deposits, but a complete absence of money available for adventure.

### Need for a Barometer

Read over Byron's lines again and see if the parallel is not suggestive. What would discussion of business

<!-- PAGE:12 -->

be worth if we could not bring at least a little of the poet's imagination into it? But unfortunately crises are brought about by too much imagination. What we need are soulless barometers, price indexes and averages to tell us where we are going and what we may expect. The best, because the most impartial, the most remorseless of these barometers, is the recorded average of prices in the stock exchange. With varying constituents and, in earlier years, with a smaller number of securities, but continuously these have been kept by the Dow-Jones news service for thirty years or more.

There is a method of reading them which has been fruitful of results, although the reading has on occasion displeased both the optimist and the pessimist. A barometer predicts bad weather, without a present cloud in the sky. It is useless to take an axe to it merely because a flood of rain will destroy the crop of cabbages in poor Mrs. Brown's backyard. It has been my lot to discuss these averages in print for many years past, on the tested theory of the late Charles H. Dow, the founder of *The Wall Street Journal*. It might not be becoming to say how constantly helpful the analysis of the price movement proved. But one who ventures on that discussion, who reads that barometer, learns to keep in mind the natural indignation against himself for the destruction of Mrs. Brown's cabbages.

### Dow's Theory

Dow's theory is fundamentally simple. He showed that there are, simultaneously, three movements in

<!-- PAGE:13 -->

progress in the stock market. The major is the **primary movement**, like the bull market which set in with the re-election of McKinley in 1900 and culminated in September, 1902, checked but not stopped by the famous stock market panic consequent on the Northern Pacific corner in 1901; or the primary bear market which developed about October, 1919, culminating June-August, 1921.

It will be shown that this primary movement tends to run over a period of at least a year and is generally much longer. Coincident with it, or in the course of it, is Dow's **secondary movement**, represented by sharp rallies in a primary bear market and sharp reactions in a primary bull market. A striking example of the latter would be the break in stocks on May 9, 1901. In like secondary movements the industrial group (taken separately from the railroads) may recover much more sharply than the railroads, or the railroads may lead, and it need hardly be said that the twenty active railroad stocks and the twenty industrials, moving together, will not advance point for point with each other even in the primary movement. In the long advance which preceded the bear market beginning October, 1919, the railroads worked lower and were comparatively inactive and neglected, obviously because at that time they were, through government ownership and guaranty, practically out of the speculative field and not exercising a normal influence on the speculative barometer. Under the resumption of private ownership they will tend to regain much of their old significance.

<!-- PAGE:14 -->

### The Theory's Implications

Concurrently with the primary and secondary movement of the market, and constant throughout, there obviously was, as Dow pointed out, the underlying fluctuation from day to day.

It must here be said that the average is deceptive for speculation in individual stocks. What would have happened to a speculator who believed that a secondary reaction was due in May, 1901, as foreshadowed by the averages, if of all the stocks to sell short on that belief he had chosen Northern Pacific? Some traders did, and they were lucky if they covered at sixty-five points loss.

Dow's theory in practice develops many implications. One of the best tested of them is that the two averages corroborate each other, and that there is never a primary movement, rarely a secondary movement, where they do not agree. Scrutiny of the average figures will show that there are periods where the fluctuations for a number of weeks are within a narrow range; as, for instance, where the industrials do not sell below seventy or above seventy-four, and the railroads above seventy-seven or below seventy-three. This is technically called **"making a line,"** and experience shows that it indicates a period either of distribution or of accumulation. When the two averages rise above the high point of the line, the indication is strongly bullish. It may mean a secondary rally in a bear market; it meant, in 1921, the inauguration of a primary bull movement, extending into 1922.

If, however, the two averages break through the

<!-- PAGE:15 -->

lower level, it is obvious that the market for stocks has reached what meteorologists would call "saturation point." Precipitation follows—a secondary bear movement in a bull market, or the inception of a primary downward movement like that which developed in October, 1919. After the closing of the Stock Exchange, in 1914, the number of industrials chosen for comparison was raised from twelve to twenty and it seemed as if the averages would be upset, especially as spectacular movements in stocks such as General Electric made the fluctuations in the industrials far more impressive than those in the railroads. But students of the averages have carried the twenty chosen stocks back and have found that the fluctuations of the twenty in the previous years, almost from day to day, coincided with the recorded fluctuations of the twelve stocks originally chosen.

### Dow-Jones Averages the Standard

The Dow-Jones average is still standard, although it has been extensively imitated. There have been various ways of reading it; but nothing has stood the test which has been applied to Dow's theory. The weakness of every other method is that extraneous matters are taken in, from their tempting relevance. There have been unnecessary attempts to combine the volume of sales and to read the average with reference to commodity index numbers. But it must be obvious that the averages have already taken those things into account, just as the barometer considers

<!-- PAGE:16 -->

everything which affects the weather. The price movement represents the aggregate knowledge of Wall Street and, above all, its aggregate knowledge of coming events.

Nobody in Wall Street knows everything. I have known what used to be called the "Standard Oil crowd," in the days of Henry H. Rogers, consistently wrong on the stock market for years together. It is one thing to have "inside information" and another thing to know how stocks will act upon it. The market represents everything everybody knows, hopes, believes, anticipates, with all that knowledge sifted down to what Senator Dolliver once called, in quoting a *Wall Street Journal* editorial in the United States Senate, the **bloodless verdict of the market place**.