# MAJOR MARKET SWINGS

# MAJOR MARKET SWINGS

<!-- PAGE:48 -->

## MAJOR MARKET SWINGS

IT may be said, in continuing the discussion of what Charles H. Dow actually published in the columns of *The Wall Street Journal*, on his now well-known theory of the stock price movement as shown by the averages, and it must be emphasized, that he was consciously devising a scientific barometer for practical use. Remember the difference between the thermometer and a barometer. The thermometer records actual temperature at the moment, just as the stock ticker records actual prices. But it is essentially the business of a barometer to predict. In that lies its great value, and in that lies the value of Dow's Theory. The stock market is the barometer of the country's, and even of the world's, business, and the theory shows how to read it.

### The Averages Sufficient in Themselves

It stands alone in this respect, for a sufficient reason. Wall Street has been called "the muddy source of the nation's prosperity," and we need not concern ourselves with question-begging adjectives. The sum and tendency of the transactions in the Stock Exchange represent the sum of all Wall Street's knowledge of the past, immediate and remote, applied to the discounting of the future. There is no need to add to the averages, as some statisticians do, elaborate compilations of commodity price index numbers, bank clearings, fluctuations in exchange, volume of domestic and foreign trade or anything else. Wall Street considers all these things. It properly regards them as experience of the past, if only of the immediate past, to be used for estimating the future. They are merely creating causes of the weather predicted.

It is a common superstition, exemplified in the Pujo Committee's inquiry into some supposed supercontrol of banking and finance, that "powerful interests" in Wall Street exist which have a sort of monopoly of knowledge and use it to their own nefarious ends. The stock market is bigger than all of them, and the financial interests of Wall Street are seldom combined except momentarily to stop a panic, as in the crisis of 1907. Taken separately, or even in temporary alliance, these interests are often wrong in their estimate of the stock market. In the days of H. H. Rogers and the supposedly all-powerful activities of what was called the Standard Oil group, I have known that group wrong on stocks for months and even years together. There was no shrewder judge of business conditions as affecting great enterprises than Henry H. Rogers, but I have heard him argue seriously that it was not he that was wrong but the stock market and the headstrong public.

### Bigger Than any Manipulation

In the price movements, as Dow correctly saw, the sum of every scrap of knowledge available to Wall Street is reflected as far ahead as the clearest vision in Wall Street can see. The market is not saying what the condition of business is to-day. It is saying what that condition will be months ahead. Even with manipulation, embracing not one but several leading stocks, the market is saying the same thing, and is bigger than the manipulation. The manipulator only foresees values which he expects and hopes, sometimes wrongly, the investing public will appreciate later. Manipulation for the advance is impossible in a primary bear market. Any great instances of designed manipulation—and they are few in number—occurred in a primary bull market, necessarily so because the market sees more than the manipulator. A personal experience of not only Wall Street but other great markets has taught that manipulation in a falling market is practically non-existent. The bear trader carries his own letter of marque, and fights for his own hand. A major bear swing has always been amply justified by future events, or for exception, as in 1917, by terrifying future possibilities.

<!-- PAGE:49 -->

### Writing in a Bull Market

Starting feebly near the end of June, 1900, with a pitifully small volume of transactions, four months before the re-election of McKinley, a bull market developed which covered a period of more than twenty-six months. This was interrupted by the May panic of 1901, arising out of the Northern Pacific corner, proving to be only a secondary downward swing of a typical, if violent, kind. It was during the course of this bull market that Dow wrote the editorials in *The Wall Street Journal* to which reference has here been freely made because they contain the substance of his theory. He had designed a barometer for practical use, and it is characteristic of the man that he proceeded to apply it, to find out if it had the vital quality of dependable forecast. It is a pity that he could not have lived to test it in the twelve months' bear market which followed. All subsequent market swings, up or down, have proved the value of his method.

Throughout that bull market his forecasts were remarkably accurate, if necessarily general and not applied to particular stocks or small groups. He was correct in the essential matter of the adjustment of prices to values. His concluding editorials were published in July, 1902, not long before his death. In those he foresaw that prices were outrunning values, and that within a few months the market would begin to predict a contraction in railroad earnings, at least a slower development in the great industrial groups, and contraction of trade elsewhere.

### Primary Movements

It will be well to give here the major swings from the time Dow wrote to the end of the bear market which culminated in 1921. They are as follows:

| | |
| --- | --- |
| 1. Up. | June, 1900, to Sept., 1902. |
| 2. Down. | Sept., 1902, to Sept., 1903. |
| 3. Up. | Sept., 1903, to Jan., 1907. |
| 4. Down. | Jan., 1907, to Dec., 1907. |

<!-- PAGE:50 -->

| 5. Up. | Dec., 1907, to Aug., 1909. |
| --- | --- |
| 6. Down. | Aug., 1909, to July, 1910. |
| 7. Up. | July, 1910, to Oct., 1912. |
| 8. Down. | Oct., 1912, to Dec., 1914. |
| 9. Up. | Dec., 1914, to Oct., 1916. |
| 10. Down. | Oct., 1916, to Dec., 1917. |
| 11. Up. | Dec., 1917, to Oct.-Nov., 1919. |
| 12. Down. | Nov., 1919, to June-Aug., 1921. |
| 13. Up. | Aug., 1921, to Mar., 1923. |
| 14. Down. | Mar., 1923, to Oct., 1923. |
| 15. Up. | Oct., 1923, to |

If the late J. Pierpont Morgan said that he was "a bull on the United States," this exhibit confirms his judgment. In that period of twenty-three years the bull markets lasted rather less than twice as long as the bear markets. The average duration of seven major bull swings is twenty-five months; while the average duration of seven major bear swings is fifteen months.

It will be noted from the table that the longest major swing upward was that from September 22, 1903, to January 5, 1907. The actual top of the averages was January 22, 1906, with a subsequent irregular decline of some months and a like irregular recovery, all within the year 1906, to a figure close to the old high point. This is therefore taken as the end of that primary movement, although the secondary swing of 1906 was by far the most extended of which we have any record. This exceptional year, of which the San Francisco earthquake was the feature, will be fully discussed in a subsequent chapter. The other five bull markets show periods of from something over nineteen months to a few days less than twenty-seven months.

<!-- PAGE:51 -->

### Startling Predictions

The longest of the six bear markets here illustrated extended to nearly twenty-seven months, including the outbreak of the Great War and the hundred days' closing of the Stock Exchange, culminating immediately before Christmas, 1914. That was a black Christmas, as some of us may happen to remember; but it was followed, in 1915, by the tremendous boom in the production of material for the combatants in a war which America had not then entered—a boom which the stock market predicted with the greatest accuracy at a time when the business of the country was hardly beginning to grasp its significance.

Two of these six bear markets did not last quite a year, one of them less than a month more, and one of them less than fifteen months. There seems sufficient material here to say that a bear market is normally appreciably shorter than a bull market; perhaps as secondary downward swings in a primary rising average are short and sharp, with a halting recovery consuming a longer time than the decline.

<!-- PAGE:52 -->

### The Market Is Always Right—

It will be shown at a later stage that throughout these great market movements it was possible from the stock market barometer to predict, some valuable distance ahead, the development of the business of the country. These discussions would fail in their purpose if they did not make the subject clear to the unfinancial layman—interesting to the man who never bought a share of speculative stock in his life. A barometer is a necessity for all vessels at sea, from the smallest coasting schooner to the *Aquitania*. It means as much, and even more, to the "Bolivar" of Kipling's ballad, "swamping in the sea," watching, in despair,

> "Some damned liner's lights go by, like a grand hotel"

as it does to the navigating officers on the liner's bridge. There is no business so small that it can afford to disregard the stock market barometer. Certainly there is no business so large that it dare disregard it. Indeed the most serious mistakes in the management of great business have come from a failure of these navigators of the great liners of the sea of commerce to take heed when the passionless, disinterested stock market called their attention to bad weather ahead.

### —and Never Thanked

When, in the United States Senate, the late Senator Dolliver, reading an editorial of *The Wall Street Journal*, said, "Listen to the bloodless verdict of the market place," he saw the merciless accuracy of that verdict; because it is, and necessarily must be, based upon all the evidence, even when given by unconscious and unwilling witnesses.

No wonder the rural politician can so easily make Wall Street the scapegoat for depressing conditions, affecting his farmer constituents no more than the rest of us. Wall Street is guilty in their eyes, for they are willing enough to hold Wall Street responsible for a

<!-- PAGE:53 -->

condition which it merely foresaw and predicted. It was said in a preceding chapter that the prophet of calamity will make himself hated in any case, and hated all the more if his predictions come true. But Wall Street's predictions do come true. Its predictions of prosperity, duly fulfilled as we have seen, are forgotten. Its predictions of adversity are remembered, and by none more than the man who ignored those predictions and is therefore the more bound to find somebody other than himself to blame.

<!-- PAGE:54 -->

### Wall Street the Farmer's Friend

Wall Street is often called "provincial" by politicians and others actuated by an unreasoning sectional jealousy of the necessary financial center of the country. The country can have only one such center, although the framers of the Federal Reserve Act, overloading it with sectional politics, tried hard to make twelve. The farmers say, or their political spokesman says, "What does Wall Street know about farming?" Wall Street knows more than all the farmers put together ever knew, with all the farmers have forgotten. It can, moreover, refresh its memory instantly at any moment. It employs the ablest of the farmers, and its experts are better even than those of our admirable, and little appreciated, Department of Agriculture, whose publications Wall Street reads even if the farmer neglects them.

The stock market which began to break at the end of October and the beginning of November, 1919, when the farmer was insanely pooling his wheat for $3 a bushel and his cotton for forty cents a pound, knew more than the farmer about cotton and wheat. And that barometer was telling him then to get out, to sell what he had at the market price and to save himself while there was yet time. He blames Wall Street and the Federal Reserve banking system and everyone but his own deluded and prejudiced self. He thinks he can change it all by getting his Congressman to take an axe to break the barometer. He is trying to break the barometers of the grain trade in Chicago and Minneapolis, the barometers of the cotton trade in New Orleans and New York.

<!-- PAGE:55 -->

Twenty years ago, at the demand of her farmers, Germany broke her grain barometer, with destructive legislation. What was the consequence? She had to construct a new barometer on the old plan, and it was the farmers who paid for it in advance out of their own pockets. The Germans have learned to let free markets alone, a thing the British always knew, and built up the greatest empire, with the widest commerce the world ever saw, on exactly that knowledge.