# RUNNING TRUE TO FORM, 1922-1925

# RUNNING TRUE TO FORM, 1922-1925

<!-- PAGE:264 -->

## RUNNING TRUE TO FORM, 1922-1925

WHEN *The Stock Market Barometer* first appeared serially in the columns of *Barron's*, mostly in the latter part of 1921, the order of the chapters adopted in the subsequent publication of the book was not used. Indeed, this study of Dow's theory of the price movement did not start out with the intention of making a book of itself. It was what an incurable newspaper man like myself would call a newspaper assignment. It partook, to some extent, of the character of contemporary criticism. This is curiously true of one of the most important chapters, the fifteenth, *"A Line and an Example—1914."* That article was submitted to the editor of *Barron's* with an entirely different line for illustration.

### A "Line" in Illustration

All students of the averages will remember the broad rule that a "line" in the daily average indicates distribution or accumulation; and that after either saturation or scarcity has come about the movement of the averages above or below the line gives an important indication of the future movement of the market. Obviously, their advance above a "line" representing many days' trading and all within a range of three points or so indicates that the floating supply of stocks has been exhausted and that it is necessary to bid up in order to tempt a new volume of selling. Conversely, a movement below that line indicates the familiar saturation point, where the clouds resolve themselves into rain. There follows a marked recession in the market, to a point where stocks once more become attractive to buyers.

That fifteenth chapter was submitted to the editor of *Barron's* at the bottom of a major bear movement. The line first chosen for illustration was that which was then in the making. He considered such prediction altogether too daring, although I was willing enough to put Dow's theory and my conception of it to the hazard of such a test. The result would have been a remarkable vindication of the theory. But counsels of prudence prevailed and the illustrative line taken shows the action, or rather the inaction, of stocks during May, June and July of 1914, before the outbreak of the World War. There can be no question that the illustration chosen was the right one, both for historical purposes and for the subsequent authority of the book, which has, to my gratification, assumed a position of its own, with several times the circulation which the cautious publishers anticipated.

What is true enough to have become familiar and, therefore unimpressive, is that the book itself applied Dow's theory to an actual market and predicted, in the most positive way, the major bull movement which set in during the time of publication, serially, in the columns of *Barron's*.

<!-- PAGE:265 -->

I have been asked to bring the topic down to date for this new edition, pointing out how the theory has been verified, or modified, in the three years which have elapsed since *The Stock Market Barometer* was first published. The topic should be interesting and useful, and I hope that a lifelong sense of humor will keep me from indulging in boasts about my inspiration as a prophet, even if it is necessary to furnish a few illustrations, from these columns and those of *The Wall Street Journal*, of the way in which the application of Dow's theory has been successfully made since 1922.

### Some Successful Forecast

Since the publication of *The Stock Market Barometer* the market has experienced a major upward (bull) movement in which the industrials, between Aug. 24, 1921, and March 20, 1923, advanced over 61 points, while the railroads between June 20, 1921, advanced from 65.52 to 93.99 on Sept. 11, 1922, or 28.47 points, and had only lost about three points of this when the high point of the industrials was recorded in the following March. *The Wall Street Journal* and *Barron's* were both entirely clear on this bull movement, the former saying, on Feb. 11, 1922:

> "At present the major swing of the market is upwards."

The final paragraph of that study is significant:

> "The answer to inquirers, therefore, is that we are still in a bull market and that it should run much further, possibly well into 1923, and certainly for a time well beyond the improvement in general business which it forecasts."

<!-- PAGE:266 -->

That was sufficiently explicit, not merely as regards the movement of the stock market interpreted by the Dow theory but upon the improvement in general business which, in due course, followed the rise in the barometer. When the twenty industrials had advanced 26 points, or in the following June, it was said: "There is no reason to suppose that the present bull market is within months of its culmination." Remember that the bull movement really ran into March, 1923. The presence of a line was noted May 8, 1922, although no bearish inference was drawn. On the 22nd of May the resumption of the bull movement was noted, while its continuance "well into 1923" was again inferred. I note that in an interview given in Boston on June 16 I repeated the conviction that the stock market was likely to run further in the upward direction and that it would be all the better for the secondary reaction which had occurred about that time. A tendency to check in the railroad averages was noted in the "Study in the Price Movement" published July 8, but it was then said: "With this proviso it may be said that the indication in the averages is distinctly bullish."

### A Secondary Reaction

It has been said elsewhere in these pages that the prediction of secondary reactions is a chancy sort of business and is not here encouraged although in September *The Wall Street Journal* and *Barron's* rather looked for a reaction, recognizing it on September 19. This may be called merely a good guess, by the scoffer,

<!-- PAGE:267 -->

especially if he was wrong on the market, but at any rate on September 30 the industrials had reacted nearly six points from the high of the bull movement and the railroads more than four points. On October 18 the "Study in the Price Movement" said:

> "The stock market today, after a typical secondary reaction, is pointing clearly to the resumption of the major upward movement which developed in August, 1921."

It would be wearisome to recall all such predictions. I prefer to call them inferences. The bullish inference was again drawn on November 3. As late as Jan. 16, 1923, the "extended but by no means unprecedented secondary reaction" was discussed, but the primary upward movement was shown still to dominate.

### A Short Bear Movement

For purposes of convenience the short major bear swing may be said to have set in after the top of the industrials was reached in March, 1923. On April 4 the "Study in the Price Movement" called attention to a bearish indication from the line of distribution. Taken all through, the bear market did not last long, and it is noteworthy that while the studies in "the Price Movement" were bearish they were slow to concede the primary reaction, evidently influenced by the fact that the previous bull movement had been decidedly slow. The decline continued to look rather like a secondary reaction in a bull market. The total recession worked out to 20 points in the industrials,

<!-- PAGE:268 -->

culminating Oct. 27, 1923, as far as the industrials were concerned, while at that date the railroads were down rather more than 17 points, although the actual low had been early in the previous August. Rather for convenience of record this conspicuously short bear movement has been taken as primary, but a plausible case might be put up for dating the present bull market from the turn in 1921, when *The Stock Market Barometer* was appearing serially and was even charged with being indelicately bullish.

### Influence of Taxes

What was unquestionably a new influence in the stock market had made itself felt in the averages. Congress had been in session all summer and on Aug. 29, 1923, *The Wall Street Journal* had a careful study of the way politics, by dangerous interference with business, had falsified, or to a large extent neutralized, the very barometers of business itself. Income tax and surtax were then at their highest points and *The Wall Street Journal* said:

> "There is a reason why the barometer in the past few months has been deflected by an influence not felt before in a major bull market. This influence undoubtedly is the cumulative effect of the income surtax.
>
> "Brokers can tell how steadily the dividend-paying common stocks, representing thirty out of the forty taken in the two averages, have been sold by large holders on any development of comparative strength. It is correct to call this a new factor, although it has been germinating since the bull market started in the autumn of 1921. The whole theory of the stock market

<!-- PAGE:269 -->

barometer is based upon the assumption that pressure on stocks can only forecast coming liquidation of general business. But here, for the first time in the history of the averages, is a pressure of stock for sale which bears no reference to coming events.

> "It is as though a hot coal or a lump of ice had been applied to the bulb of a thermometer. If it is too much to hope that Congress may see a return to sanity in taxation, this is a condition which will nevertheless cure itself, but only over a period of time beyond present calculation. That stage will be reached when every one of the twenty active railroad common stocks and the twenty industrials is as widely held as the stock of the Pennsylvania Railroad, where the average holding is round about fifty shares per stockholder.
>
> "A rich man cannot afford to hold a common stock returning him six per cent. on its cost. Not only is he liable to see more than half of the return deducted by the taxgatherer; such a holding pulls up the tax he must pay on all his other income. He, therefore, has been a steady seller for many months past, and this is 'inside' selling with a vengeance. It is well informed selling, in a way, but obviously it need not predict the general course of business. Congress, in imposing impossible taxes, has not merely laid a handicap on the country's business. It has falsified the very barometer of business."

That temporary influence is now in course of removal so far as Congress is concerned but the State taxes must have some not entirely negligible effect.

<!-- PAGE:270 -->

### A New Bull Market

It would be hypocritical to say that I have really wished I had never written *The Stock Market Barometer*. It is true to say that I have witnessed with regret the way in which crude adaptations of Dow's complete theory have been taken by tipsters and market quacks to bolster up their unsound conclusions, drawn from an incomplete understanding of the principles involved in reading the averages. On Feb. 4, 1924, after refraining, in disgust at the clamor of tipsters, from discussing the price movement editorially, *The Wall Street Journal* said:

> "On the method of reading the averages which is known as Dow's theory, the stock market is in a major bull movement, after the shortest major bear movement of record, one lasting barely eight months. So far as the low of the present movement is concerned, it would presumably date from November 1; but the bull point was given after both the industrial and railroad averages had made one of the most consistent lines of accumulation on record, emerging on the bull side last December (1923)."

It was noted there, as an eminently satisfactory reason for a bull market, that stocks were selling well below the line of values and had not discounted the possibilities of legitimate business expansion. Here again the barometer was right. The business expansion came in due course, slackening in the latter part of the year. This was curiously matched by a substantial secondary reaction in both averages from the high in the industrials of 105.57 on August 20 to the low of 99.18 recorded October 14, paralleled by a reaction of more than six points in the railroads, the averages having seen the low of that movement on October 14.

Since that time the bull movement has been in full swing, developing great activity immediately after the election, when a number of stock tipsters advised taking profits, and selling the market short, on the theory that "the good news was out." As the real odds were something like forty to one that Coolidge would beat

<!-- PAGE:271 -->

Davis,—they were openly twelve to one before the election—the “good news” was really the resumed expansion of general business which the market barometer had been predicting.

### A Changed Technical Condition

There is a technical condition which has developed in the present bull market and one which did not exist before. Here is substantially what I have had to say about it in another place:

Studies of the stock market, based upon Dow’s well known theory of the triple market movement as disclosed by the average prices of the industrials and the railroads taken separately for comparison, have been astonishingly right in forecasting the broad upward movement of the stock market and indicating its continuance. The present major bull market, however, is subject to a condition which did not exist before, and it is important to consider the bearing of that limitation.

While the Stock Exchange Governing Committee has been strengthening its control over the conduct of business for a good many years past and certainly since the time when the unlisted department was abolished, the more stringent regulation has been of entirely recent development. It has only been in the past year or two that the governors have assumed to tell the strongest brokerage houses how much of an account they may carry on their capital. In the not very old days a Stock Exchange house took all the sound business it could get, trusting to its own ingenuity to find a means of carrying an expanded account in a big bull market.

<!-- PAGE:272 -->

This has been drastically changed, and it is now an open secret that a considerable number of brokerage houses are carrying for customers all the stock the Exchange's law allows. Their position is eminently safe, but their policy is obviously changed. The way to make money in a bull market is to buy what you can afford when the upward movement is fairly assured, expand your bull account on the profits, hold on to the larger part of your interest, selling in periods of marked strength, and making up to the proportion you can afford in the inevitable secondary reactions.

But this is not the kind of customer a Stock Exchange house wants. It means the tying up of a substantial amount of capital, with commissions for purchases or sales only earned once in a few weeks. The broker likes the customer to pay commissions every day, although it is anything but profitable to the latter, because the attempt to guess the daily fluctuation is far more like gambling than speculation.

One result of the broker's new limitations is that stock in small quantities has been widely bought for cash and that wealthy customers are financing their own bull account through their own bankers in many parts of the country outside New York. This leaves some uncertainty as to the real extent of the bull account, but also a hitherto unknown degree of stability, because there is less likelihood of a flood of selling orders all at one time.

<!-- PAGE:273 -->

In the natural way of evolution the result will probably be to concentrate business among fewer houses, each with a much larger working capital than has hitherto been considered necessary. What is at least certain is that there is nothing in the new condition to change the rules for reading the stock market barometer.

### Barometrical Indications

It would be timid to conclude this discussion without saying what I think of the barometrical indications writing in August, 1925. There is obviously a strong and well distributed bull account, and there is absolutely no indication in the averages that the bull market has culminated. Counting from the end of the short bear market in the latter part of 1923, the duration of the major swing has not been long and there are still many stocks which are demonstrably selling below the line of values. I think this assumption, if we could calculate an average line of values, would be true of the railroad and partly true of the industrial groups, in spite of their considerable advance.

All indications point to a further upward movement carrying into next year, although secondary reactions of substantial proportions would be very much in order.

Nothing has developed since the first publication of *The Stock Market Barometer* to shake my faith in the great utility of a common-sense interpretation of the price movement. It may be valueless for individual stocks, except that these do not commonly make serious

<!-- PAGE:274 -->

advances except when the general trend of the market is upwards. The one chosen by the speculator may lag behind and never catch up.

<!-- PAGE:275 -->

I am not greatly interested in encouraging people to speculate in Wall Street, but I am humbly gratified that the business of the country has had its attention drawn to such a barometrical guide. It has been freely criticised by authorities of some weight, but has continued its useful service to the general business of the country.