# ITS GREATEST VINDICATION—1917

# ITS GREATEST VINDICATION—1917

<!-- PAGE:210 -->

## ITS GREATEST VINDICATION—1917

IF there had not been a bear market in stocks in the year 1917 it is probable that this series of discussions would never have been prepared. I should have felt that inferences from the sum of knowledge and intelligence represented by the market movement were empiric, or based upon insufficient premises. I should have said that the market was, for some incomprehensible reason, unable to look beyond the borders of the United States. It would have seemed plain that it was incapable of taking a sane and self-protective view of international affairs. Its findings might have been worth little more than the fluctuations in turnips at the crossroads grocery, for our chain of reasoning is as strong as its weakest link. But there was a major bear swing from October–November, 1916, until December of the following year which may justly be called the barometer's greatest vindication.

### Uncertainty of the War Outlook

One of those precipitate critics who has failed to grasp the principle so constantly repeated in these discussions—that of the analyzed triple movement of the stock market and its bearing upon future events—asked why the market in the year 1917 made a warning major bear movement although business charts continued to show a large volume of practical prosperity, then and in the following year; while Babson's familiar black area of good business was never once below his amended line of growth, from the latter part of 1915 to near the end of 1920? But what constituted the excess volume of American business during the earlier war years? Was it not making supplies for the combatants? Were we not feeding them and arming them, and taking payment in I O U's? Have we not many billions of the I O U's outstanding, some of them never likely to be paid?

These things are important to remember, but there was a specific reason why there was a bear market in 1917, apart from the fact that the stock market kept its head, and did not treat war profits as a complete offset to the destruction of our past and future foreign customers. For the whole of that year the issue of the war was in doubt. The sum of market knowledge did not preclude a final German victory. Not until the end of 1917 did the stock market barometer begin to predict that the allies would win. The bull market which was born in December of that year anticipated the armistice by eleven months, and the failure of Germany's last tremendous drive by six months. However bravely we believe right must triumph, the wish, in 1917, was father to the thought. The bear market which then concluded had been a measure of insurance.

<!-- PAGE:211 -->

It offers a demonstration of the market's vision higher than anything we have previously analyzed.

### If Germany Had Won

Many readers must have asked themselves what would have happened to the world if Germany and her allies had won. Many more must have dismissed the possibility as too dreadful to contemplate. Conditions are bad enough now, in all conscience. But what would they have been with France crushed, Belgium enslaved, Italy in a state of anarchy, Great Britain ruined, bankrupt and unable to feed herself, with her merchant marine destroyed? What would have been the burden of the hundreds of billions of ransom Germany would have laid upon the world? How should we have liked her for a neighbor in the Caribbean? There has been a disintegration of nations, or perhaps a rebirth of nationalities (some possibly spurious), which has produced sufficiently grave consequences. But what would have happened to the world if the British Empire had been brought to irrecoverable wreck?

Such a possibility might well daunt the staunchest heart, but the stock market faced it, in 1917. It asked itself exactly these questions. Admiral Sims has told us since how desperate was the condition which the allies at that time confidentially admitted. It was not until the end of that year that our assistance became effective, although we had gone to war, largely unprepared, in the spring. The stock market did not

<!-- PAGE:212 -->

know then (for no man knew) whether we should not be too late. There was little question that we might save our own skins, but it was the business of the market to insure against the consequences if we failed to save the allies.

It has been said, in an earlier discussion, that the stock market takes into account many other things in addition to those chosen for tabulation and analysis by the most complete information bureau. Honest compilers of such records would be the last to contend that the warning movement of the stock market is limited in its application to a mere reflection of the coming business of the United States only.

### Britain's National Debt

It will be highly instructive to treat in another discussion of the quiet years of contracted business which followed the bull market of 1908–9 and preceded the great war boom. There is a manifest connection between the bear market before the war and an event which, nevertheless, upset all calculations. It was a thing so vast that even now we are at a loss to find precedents in history, although there are incomplete ones following the long quarter of a century of war which culminated with the battle of Waterloo in 1815. We can probably get a better parallel there than some observers have supposed, if we accept length as to some degree offsetting intensity, and take the relative size of the conflicts compared with population and national wealth. There is one significant illustration

<!-- PAGE:213 -->

which has not been offered elsewhere, so far as I know. It is that of the British national debt after the immense losses of the Napoleonic wars. Great Britain's debt at that time (1815–16) represented $31\frac{1}{2}$ per cent of her estimated national wealth. Throughout the greater part of the century, and during the long reign of Queen Victoria, the debt was gradually paid off, until, previous to the Boer War (1899–1902) it amounted to not much more than 4 per cent of the estimated wealth.

In round figures, the Boer War cost Great Britain about a billion dollars, and raised the proportion of debt to national wealth to over 6 per cent. In the years between 1902 and 1914, in spite of the steady increase in the cost of living and the growth of taxation, the British national debt was again declining, although it did not reach the low proportion to national wealth of 1899. The British debt now is estimated at 33 per cent of the national wealth, or a proportion of about $1\frac{1}{2}$ per cent more than that at the conclusion of the Napoleonic wars, which had lasted, with a three-year interregnum, from 1793 to 1815. No doubt it is a formidably high proportion. But it is far from a hopeless proportion; and this is a basic reason why, of all the money units depreciated in the conflict, the British pound sterling approximates respectably in exchange credit to the American dollar.

<!-- PAGE:214 -->

### One of Our Own Liabilities

In 1917 the stock market was asking itself what would happen to the pound sterling, and everything else, if Germany won. If the German printing presses are working overtime to turn out paper marks, what sort of currencies would the allies be circulating now had the German drive in the spring of 1918 succeeded?

We have satisfied ourselves by analysis that the essential quality of the stock market barometer is its foresight. Could there have been a more striking instance of the clarity of its vision than that salutary bear market, when we were deceiving ourselves with paper profits, inflation wages and inflation prices?

In 1916 we had placed in the hands of the labor unions, through the Adamson Act, the power to inflate wages without guaranty of any corresponding productive return. Congress, with a presidential election in sight, had tried to buy votes, lulling the American consumer and taxpayer, who were to pay the bill, with professions of a philanthropic desire to inaugurate shorter hours with consequent greater safety for the railroad traveler. Of course the Adamson Act did not mean shorter hours but only earlier, and more, overtime. The hours of railroad labor were actually lengthened; for it was made strictly to the interest of the men, up to sixteen hours, to stretch their day to the legal limit. We know now what the demoralizing effect upon other labor was, in every department of industry. With such a precedent no wage demand was too preposterous after our own entry into the war, early in 1917, had tied our hands. There was hardly a single manufacturer in the country, and certainly not a consumer, who did not reap the deadly consequences of that humiliating Congressional surrender.

<!-- PAGE:215 -->

### What Watered Labor Means

In an earlier chapter, that on *Water in the Barometer*, I have alluded to watered labor as being incomparably more deadly than watered capital. How many billions of our national debt might not have been deducted, as never incurred, if there had been no such dilution? Mr. Piez, director-general of the Emergency Fleet Corporation during the war, estimated that the efficiency of labor had been dangerously reduced through smaller individual output and larger wages, the latter only excused by the higher prices for commodities of which those wages themselves had been the automatic cause. He said:

> "Labor had been deliberately slack during the war. In the Atlantic Coast shipyards workmen received $2 for the same time that a year ago (1916) brought only $1, but that the individual output was only two-thirds of what it had been a year before."

Guy Morrison Walker, in *The Things That Are Caesar's*, quoting Director-General Piez, says that the unit of cost production during our share in the war was only one-third what it was at the beginning of hostilities. Estimating our national debt at $24,000,000,000 and deducting from it all, up to $11,000,000,000, owed by the allied nations who borrowed from us, there remains $13,000,000,000, of which a large part, possibly half, constitutes watered labor. But we are to remember that in the advances to the allies, which were made not in cash but in the necessaries of war, of which labor was the costliest

<!-- PAGE:216 -->

item, the water was also present in the same proportions. It was less the cash wages than the slacking, shirking and bad work. If we took all the water which has ever been squeezed out of corporation capitalization, by the remorseless stock market, we should not have a sum anything nearly approaching the shamelessly watered labor upon which we and our children and our children's children must continue to pay interest for half a century to come.

### Paying for Bad Work

It has not been difficult to show the largely nominal character of "water" in capitalization. How relatively seldom has it represented any real loss, to anybody, compared with the irreparable losses from watered labor! How unsatisfying must seem the industrial and commercial activity, recorded of the five years of the war in graphic statistical tabulation, when we have deducted from it the triple price for that prosperity for which from henceforth we have to pay. Everyone of those sham dollars must be met in real dollars. Every wasted hour of bad work or shirked work has to be paid for in an hour of good work.

### Secondary Inflation—And After

If I had to forecast the coming major bull swing in stocks, and the area of a possible secondary inflation, likely to be much less than that of the war but sufficiently obvious, I would compare it with the six years which followed the battle of Waterloo in Great

<!-- PAGE:217 -->

Britain. It was in 1821 that the Bank of England went back upon a gold basis, and the premium upon gold disappeared. A self-deluded House of Commons admitted in 1819 that the famous Bullion Report was right, and that fiat money was wrong. And then followed the years in which the deflation of the war levels was taken in hand by a nation in which every sixth person was a registered pauper. Dare we suppose that we shall not pay our relatively lighter bill in some such way as this, sooner or later? It is less than four years since the armistice. The bull market in progress while this is written may or may not carry us to a date corresponding to that of 1821 in Europe. We are in no such desperate condition as Great Britain was then. But our foreign customers have an almost incalculably greater reckoning to meet. It is not a problem which can be solved by quack remedies. It can, indeed, be settled only by throwing the quack remedies out of the window, for the patient has been doped to the danger point.

### Unsuspected Qualities of the Barometer

But sufficient unto the day is the evil thereof. The stock market barometer is enough for our purpose in that it records, well in advance, the periods of depression and prosperity alike, giving, as we have seen, the signal for a clear track ahead and the warning of danger. The averages are saying now that general business will be more active and more cheerful in the summer of 1922. The barometer does not profess to predict the duration of such prosperity, although

<!-- PAGE:218 -->

on close scrutiny it seems to give tolerably clear indications of the character of the boom or depression which it forecasts. The business depression of 1908–9, predicted by the bear market of 1907, was deep rather than long. The period of prosperity of the latter part of 1909 and 1910 was more extended but much shallower; and the market bull movement which preceded it was also slower and longer than the bear market, while its range was correspondingly less. This is strikingly true of the narrower later fluctuations, both in business and in the stock market, with the latter characteristically preceding the former. It was only in the war years that the preceding major swings of the stock market became as vigorous as the developments in our trade.

It is also noteworthy that during those quiet years of narrow fluctuations before the war the volume of transactions in stocks, as shown in our twenty-five-year chart, contracted also. The average monthly transactions compare in volume, upon the whole, rather unfavorably with those preceding the re-election of McKinley in 1900. The years 1911, 1912, 1913, and 1914 show a volume of trading below that recorded in the years 1897, 1898, 1899, and 1900; and the year 1899 made a better showing in the average transactions than any one of the later years here taken for comparison.

### Forecasting the War

We may say, therefore, that the stock market does in a measure foresee, although probably in a way not

<!-- PAGE:219 -->

sufficiently definite to be of much practical usefulness, the character, and even the dimensions, of the thing it predicts. One thing it foresaw, so far as human knowledge could, was the war itself. Somebody knew that it was a lively possibility, and the bear market which preceded the war was no accident or mere coincidence. It will be remembered that in the latter part of 1912 a bear movement set in, of decidedly mild intensity compared with most of the bear movements of the past and especially those to which we have given particular consideration. There was an area of business depression of no great depth in 1914 which could be offered as partly convincing justification of the preceding major bear swing. But there can be little doubt that the decline was also influenced by liquidation of stock held by those who realized the dangerous possibilities in the German attitude toward other nations. This must have started somewhere about the opening of the Kiel Canal, strategically connecting the Baltic with the North Sea through German territory.

It may be justly claimed that the bear market, quite apart from predicting a contraction in business, was also discounting the possibilities of war. In a previous study, referring to the line of distribution made in 1914, before the outbreak of hostilities, it was shown that foreign liquidation was responsible for turning what would normally have been a line of accumulation into a line of distribution, during the period of almost three months of equilibrium so represented. To those who profess themselves dissatisfied that the major stock market movements are not always immediately

<!-- PAGE:220 -->

adjustable to the various current business charts, it may be said that the fault is not in our barometer. That is universal, and takes note of international facts where those tabulations do not. If, therefore, they inadequately confirm our deductions, so much the worse for them. We have found that the more severe the test we apply to our barometer the more triumphantly does it vindicate its usefulness. It would be difficult to overestimate the value of its prescience both before the war and in the course of the conflict.

What if the war had come at the top of a bull market?