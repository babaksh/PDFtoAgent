# CHARLES H. DOW, AND HIS THEORY

# CHARLES H. DOW, AND HIS THEORY

<!-- PAGE:29 -->

## CHARLES H. DOW, AND HIS THEORY

TO judge from a large number of letters received from readers of past discussions on Dow's theory of the averages, and on panic and prosperity cycles generally, that theory is assumed to be something in the nature of a sure way to make money in Wall Street. It may be said at once that it bears no resemblance to any "martingale" or system of beating the bank. Some of the questions show more intelligence and understanding than this, and one of them at least deserves an extended reply.

### A Newspaper Man, and More

"Who was Dow, and where can I read his theory?" Charles H. Dow was the founder of the Dow-Jones financial news service in New York, and founder and first editor of *The Wall Street Journal*. He died in December, 1902, in his fifty-second year. He was an experienced newspaper reporter, with an early training under Samuel Bowles, the great editor of the *Springfield Republican*. Dow was a New Englander, intelligent, self-repressed, ultra-conservative; and he knew his business. He was almost judicially cold in the consideration of any subject, whatever the fervor of discussion. It would be less than just to say that I never saw him angry; I never saw him even excited.

<!-- PAGE:30 -->

His perfect integrity and good sense commanded the confidence of every man in Wall Street, at a time when there were few efficient newspaper men covering the financial section, and of these still fewer with any deep knowledge of finance.

Dow also had the advantage of some years experience on the floor of the Stock Exchange. It came about in a rather curious way. The late Robert Goodbody, an Irishman, a Quaker and an honor to Wall Street, came over from Dublin to America. As the New York Stock Exchange requires that every member shall be an American citizen, Charles H. Dow became his partner. During the time necessary for Robert Goodbody to naturalize, Dow held a seat in the Stock Exchange and executed orders on the floor. When Goodbody became an American citizen Dow withdrew from the Exchange and returned to his more congenial newspaper work.

### Dow's Caution, and His Theory

Knowing and liking Dow, with whom I worked in the last years of his life, I was often, with many of his friends, exasperated by his overconservatism. It showed itself particularly in his editorials in *The Wall Street Journal*, to which it is now necessary to allude because they are the only written record of Dow's theory of the price movement. He would write a strong, readable and convincing editorial, on a public question affecting finance and business, and in the last paragraph would add safeguards and saving clauses which not merely took the sting out of it but took the

<!-- PAGE:31 -->

“wallop” out of it. In the language of the prize ring, he pulled his punches.

He was almost too cautious to come out with a flat, dogmatic statement of his theory, however sound it was and however close and clear his reasoning might be. He wrote, mostly in 1901 and the first half of 1902, a number of editorials dealing with methods of stock speculation. His theory must be disinterred from those editorials, where it is illustrative and incidental and never the main subject of discussion. It is curious also that in one of his earliest statements of the price movement he makes an indefensible claim. Under the caption “Swings Within Swings,” in the Review and Outlook of *The Wall Street Journal* of January 4, 1902, he says:

> “Nothing is more certain than that the market has three well defined movements which fit into each other. The first is the daily variation due to local causes and the balance of buying or selling at that particular time. The secondary movement covers a period ranging from ten days to sixty days, averaging probably between thirty and forty days. The third swing is the great move covering from four to six years.”

### Where Dow Went Wrong

Remember that Dow wrote this twenty years ago, and that he had not the records for analysis of the stock market movement which are now available. The extent of the primary movement, as given in this quotation, is proved to be far too long by subsequent experience; and a careful examination has shown me that the major swing before Dow wrote was never “from

<!-- PAGE:32 -->

'four to six years,' rarely three years and oftener less than two.

But Dow always had a reason for what he said, and his intellectual honesty assures those who knew him that it was at least an arguable reason. It was based upon his profound belief in the recurrence of financial crises, at periodic intervals (as shown by recorded financial history), of a little more than ten years. Dow assumed for that period one primary bull market and one primary bear market, and therefore split the ten-year period in half. It was rather like the little boy who, being asked to name ten arctic animals, submitted "five seals and five polar bears"

### Panic Dates of Jevons

In the opening chapter we spoke of historic panics, of Professor Stanley Jevons, and of his theory connecting such crises with the recurrence of spots on the sun and their assumed influence upon the weather and crops. I said that the reasoning was about as good as associating presidential elections with leap years. But here are the dates of commercial crises in England as recorded by Jevons, and it is fair to say that they are sufficiently impressive. These years are 1701, 1711, 1712, 1731-32, 1742, 1752, 1763, 1772-3, 1783, 1793, 1804-5, 1815, 1825, 1836, 1847, 1857, 1866, and 1873.

As Dow says in an editorial quoting these dates, published in *The Wall Street Journal* on July 9, 1902:

<!-- PAGE:33 -->

> “This makes a very good showing for the ten-year theory and is supported, to a considerable extent, by what has occurred in this country during the past century.”

Dow's account of the successive crises in this country (he had personal experience of three of them—1873, 1884 and 1893) was so good and interesting that it is well worth quoting here. So far as Jevons's dates are concerned, it is curious to note that he omitted one serious crisis near the beginning of his list. That occurred in 1715, and was precipitated by the Scottish invasion of England in that year to restore the Stuarts to the English throne. It is rather human of Jevons to omit it, if, as I suspect, there were not enough spots on the sun in that year to fit the parallel.

### Dow on Our Own Crises

Here is Dow's account of our own crises:

> “The first crisis in the United States during the nineteenth century came in 1814, and was precipitated by the capture of Washington by the British on the 24th of August in that year. The Philadelphia and New York banks suspended payments, and for a time the crisis was acute. The difficulties leading up to this period were the great falling off in foreign trade caused by the embargo and non-intercourse acts of 1808, the excess of public expenditures over public receipts, and the creation of a large number of state banks taking the place of the old United States Bank. Many of these state banks lacked capital and issued currency without sufficient security.

#### 1819, 1825, and 1837

> “There was a near approach to a crisis in 1819 as the result of a tremendous contraction of bank circulation. The previous

<!-- PAGE:34 -->

increase of bank issues had prompted speculation, the contraction caused a serious fall in the prices of commodities and real estate. This, however, was purely a money panic as far as its causes were concerned.

> “The European crisis in 1825 caused a diminished demand for American products and led to lower prices and some money stringency in 1826. The situation, however, did not become very serious and was more in the nature of an interruption to progress than a reversal of conditions.

> “The year 1837 brought a great commercial panic, for which there was abundant cause. There had been rapid industrial and commercial growth, with a multitude of enterprises established ahead of the time. Crops were deficient, and breadstuffs were imported. The refusal of the government to extend the charter of the United States Bank had caused a radical change in the banking business of the country, while the withdrawal of public deposits and their lodgment with state banks had given the foundation for abnormal speculation.

#### 1847, 1857, and 1866

> “The panic in Europe in 1847 exerted but little influence in this country, although there was a serious loss in specie, and the Mexican war had some effect in checking enterprises. These effects, however, were neutralized somewhat by large exports of breadstuffs and later by the discovery of gold in 1848-9.

> “There was a panic of the first magnitude in 1857, following the failure of the Ohio Life Insurance and Trust Company in August. This panic came unexpectedly, although prices had been falling for some months. There had been very large railroad building, and the proportion of specie held by banks was very small in proportion to their loans and deposits. One of the features of this period was the great number of failures. The banks generally suspended payments in October.

> “The London panic in 1866, precipitated by the failure of Overend, Gurney & Co., was followed by heavy fall in prices in the Stock Exchange here. In April there had been a corner

<!-- PAGE:35 -->

in Michigan Southern and rampant speculation generally, from which the relapse was rather more than normal.

#### 1873, 1884, and 1893

> “The panic of September, 1873, was a commercial as well as a Stock Exchange panic. It was the outcome of an enormous conversion of floating into fixed capital. Business had been expanded on an enormous scale, and the supply of money became insufficient for the demands made upon it. Credit collapsed, and the depression was extremely serious.

> “The year 1884 brought a Stock Exchange smash but not a commercial crisis. The failure of the Marine Bank, Metropolitan Bank and Grant & Ward in May was accompanied by a large fall in prices and a general check which was felt throughout the year. The Trunk Line war, which had lasted for several years, was one of the factors in this period.

> “The panic of 1893 was the outcome of a number of causes—uncertainty in regard to the currency situation, the withdrawal of foreign investments and the fear of radical tariff legislation. The anxiety in regard to the maintenance of the gold standard was undoubtedly the chief factor, as it bore upon many others.”

### A Weak Prediction

With a caution in prediction which is not merely New England but almost Scottish, Dow, in a typical final paragraph, goes on to say:

> “Judging by the past and by the developments of the last six years, it is not unreasonable to suppose that we may get at least a Stock Exchange flurry in the next few years.”

So far from being unreasonable, it was not even a daring guess. It was more than a “flurry” in 1907, five years after, when the New York banks resorted to clearing-house certificates and the stock market

<!-- PAGE:36 -->

grazed a panic by a bare five minutes. But the prediction was made during a primary upward swing which culminated in September of the year 1902, three months before Dow died.

Events soon disproved Dow's five-year primary swings, arrived at by splitting the assumed ten-year cycle in half. There was a primary bear market from September, 1902, lasting nearly a year. A primary bull market originated in September, 1903, becoming definitely marked by June, 1904, and culminating in January, 1907—a period of three years and four months; while the primary bear market which followed it and covered the period of the crisis of 1907 lasted until the following December—a period of eleven months.

### Nelson's Book on Speculation

All that Dow ever printed is in *The Wall Street Journal*, and only by search through the precious files of Wall Street's Bible can his theory of the stock market price movement be reconstructed. But at the end of 1902 the late S. A. Nelson wrote and published an unpretentious book called *The A B C of Stock Speculation*. It is long out of print, but may occasionally be picked up from the second-hand booksellers. He tried to persuade Dow to write the book, and, failing that, he incorporated in it all that he could find of what Dow had said on stock speculation in *The Wall Street Journal*. Of the thirty-five chapters in the book, fifteen (Chapters V to XIX inclusive) are editorials, some slightly abridged, from *The Wall Street

<!-- PAGE:37 -->

Journal*, covering such subjects as "Scientific Speculation," "Methods of Reading the Market," "Methods of Trading" and market swings generally—all of them interesting but not suitable for entire reproduction here, although they will be sufficiently quoted in subsequent chapters.

Nelson's is a conscientious and sensible little book. He was a conscientious and sensible little man—one we loved and laughed at, for young reporters could not take him as seriously as he took himself. His autographed copy lies before me as I write, and I can see his pathetic figure and earnest, strained face—he was dying of tuberculosis—as I read his rather conventional discussions on the morality of speculation. He died not long after, far away from his beloved Wall Street, but it was he who evolved the name of **"Dow's Theory."** It was an honorable ascription, to which Dow is fully entitled; for if many people had recognized meaning in traceable movements in the stock market—the great and useful barometer of trade—it was Dow who first formulated those ideas in a practical way.