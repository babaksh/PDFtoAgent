# FORECASTING A BULL MARKET—1908-1909

# FORECASTING A BULL MARKET—1908-1909

<!-- PAGE:140 -->

## FORECASTING A BULL MARKET—1908-1909

CONTINUING the important and, indeed, vital subject of the prediction value of the stock market barometer, if we are to prove the validity of Dow's theory of the price movement, the analyses of the stock market averages published at irregular periods in *The Wall Street Journal* in 1907–8 may be here submitted. These are of record, and there is a personal reason why they should have impressed themselves upon my memory. At the end of the year 1907 the late Sereno S. Pratt, a man of sound economic knowledge, sterling character and exceptional ability as a newspaper man, relinquished the editorial chair of *The Wall Street Journal* for the dignified and less exacting post of secretary to the New York Chamber of Commerce.

<!-- PAGE:141 -->

## Impersonal Editorials

Apart from the fact that they are not signed, newspaper editorials have far less of any personal quality than the public supposes or politicians assume. The editor is, of course, personally responsible for them, not only to the proprietors of the paper but civilly and criminally under the law. His own editorials are checked, when necessary, by the experts of the paper who “cover” particular subjects, and what they write editorially is in turn subject to the editor's revision. Several competent persons have seen and criticized an editorial before it appears, in any well-conducted paper. I succeeded Pratt at the beginning of 1908, but it is impossible for me to say, even if the matter were not in some degree confidential, to what extent the editorial discussions of the averages were a matter of individual thought, although the methods of an editor unconsciously impress themselves upon his staff. At any rate Pratt and I were of one mind in the method of reading the averages which the paper had inherited from Charles H. Dow, its founder.

## Detecting the End of a Bear Swing

It will be remembered, from the preceding article, that there was a short but severe major bear swing lasting throughout 1907, really culminating on November 21st of that year. In the last week of November the industrial stocks rallied sharply, as they might equally have done in a secondary upward swing in a bear market; and the most difficult of all barometer problems, that of calling the turn of the market, presented itself. On December 5th *The Wall Street Journal* said:

> "Since November 21st, when the average price of twenty railroad stocks touched 81.41, its lowest point, there has been an advance of 7.70 to 89.11, which was the record at the close of yesterday's strong market. During these ten days there have been only two days of decline. This is a very substantial rally, and perhaps it is too rapid, all things considered, although it still leaves prices on a basis which would seem to discount in large part the reasonable trade contraction of the future.”

On December 23d there was an incidental reference to the averages in the discussion of the general developments of the week. The writer seems to have felt rather than asserted the change, which it would have been rash to predict, and said:

> “It will be noticed that there has been quite a typical movement of the average price of railroad stocks. It declined twenty-six points from July 20th to November 21st. It rallied nine points in the following fortnight, reacted four points in the next ten days, and has rallied two points in the past week. This is really the shortened swing of the pendulum, as it approaches equilibrium.”

<!-- PAGE:142 -->

## A Self-Correcting Barometer

Before we go further it is necessary to say something about the secondary movement of which this paragraph gives a simple, concrete instance, sufficient for our present purposes. It will be observed that the reaction following the rally from the low points of the bear market was checked before it reached the old low, and for purposes of record it may be said that the movement of the twelve industrial stocks then used in the average was roughly parallel and confirmatory. Perhaps the last sentence in the paragraph quoted is the most illuminating if it were intended to develop in this article the meaning and function of the secondary swing. It may be said that in that way our barometer tends to adjust itself. At the turn of a bear market there is a chaos of knowledge of all kinds, and an almost inextricable confusion of opinion, which is gradually resolving itself into order. It follows that speculators and investors tend to anticipate the market movement and often look too far ahead.

<!-- PAGE:143 -->

## Right Too Soon

It would be possible to offer endless instances of people who lost money in Wall Street because they were right too soon. One illuminating instance occurs to me as far back as the bull market which developed in the summer preceding the re-election of McKinley in 1900. One of the most conspicuous traders on the floor then was a partner in an active arbitrage house which has long since gone out of existence. For the sake of the layman it may be explained that an arbitrage house is (or was) one of those which did business by cable exchange with the London market, taking advantage of the fluctuating differences between the prices in the forenoon on the New York Stock Exchange and those in what at that time of our day would be the afternoon in the London Exchange. But in those dull summer days there was not enough business for the arbitrage houses, or anybody else. The total recorded transactions, which have in their time exceeded three million shares a day, dwindled down to considerably less than a hundred thousand.

Louis Wormser, however, was as active as a trader could be on the floor in such circumstances. He was bullish all through the summer. Other traders complained that he went about spoiling what little market there was in any stock which was momentarily active. It is fair to say that he was entirely within his rights as a floor trader and a member of the Exchange. The market did not begin to gain strength or volume until the last few weeks of the presidential campaign. Wormser was then on the right side and followed the market up. I suspect he even fancied he was leading it. For three days after the election stocks were very strong. They were so strong that he was convinced the bull movement had sufficiently discounted the re-election of McKinley. He turned bearish, and probably lost in a few days all he may have made on the bull side in the preceding five months. That bull market, as we have shown, did not culminate until September, 1902, in spite of the serious interruption of the Northern Pacific corner and panic. This is an excellent example of a speculator who saw only one of the many factors where the market saw all of them, and who was not content to trust the barometer. It may, indeed, have been that Wormser's prominence in a restricted market, a relatively large frog in a small puddle, had given him the impression, by no means singular, that he alone constituted the market, as he sometimes had in the dull days preceding the rise.

<!-- PAGE:144 -->

## A Courageous Prediction

Returning to the bull market of 1908 and 1909, which *The Wall Street Journal* was evidently beginning to foresee, on December 25, 1907, that newspaper said, *"We have seen the low price for the year in all probability."* On January 10, 1908, when the country was still quivering from the shock of the developments of 1907, when the clearing-house certificates were a vivid reality, *The Wall Street Journal*, manifestly judging by the barometer alone, was able to record a significant rally. Speaking of this preliminary movement, it says that it gives

> “the impression that it is one of those sharp fluctuations which follow an extreme low point and precede, at greater or less distance, a permanent turn in the tide.”

That seems fairly courageous and clear as a prediction, and one of exactly the conservative kind business men were being led to expect from the general consideration of the stock market barometer. Let us keep in mind that Dow’s theory is not a system devised for beating the speculative game, an infallible method of playing the market. The averages, indeed, must be read with a single heart. They become deceptive if and when the wish is father to the thought. We have all heard that when the neophyte meddles with the magician’s wand he is apt to raise the devil.

<!-- PAGE:145 -->

## Reviewing the Collapse

Prediction was anything but a comfortable task in the beginning of a bull market which nobody at that time would concede, much less forecast with any degree of certainty. In an earlier chapter of this series great stress was laid on the suddenness with which business collapsed in 1907. *The Wall Street Journal* recalls the conditions, and the startling change, in its editorial of January 24, 1908:

> “Consider, for instance, the rapidity with which the pendulum of business has swung in this country from extreme prosperity to great prostration. Almost in a single night the situation changed from one extreme to another. Even after the panic had swept through Wall Street with terrific force a high official of a leading railroad commented upon the fact that the traffic of his line had the day before touched high-water mark. Three weeks later the same official reported that the business of the line had fallen off abruptly. Anecdotes of this kind could be multiplied indefinitely.
>
> “It is only three months since the panic started in Wall Street, and yet that time has been sufficient to produce what amounts to a revolution in the economic conditions of the country. Three months ago there were not cars enough to move the freight. Now there are several tens of thousands of empty freight cars on the sidings and in the terminals. Three months ago the iron and steel trade was at the very height of its activity. It took only five or six weeks to cut off the demand and to close mills. If a chart were drawn to describe the reduction in iron and steel production in the past ten weeks, it would make almost a perpendicular line, so sudden and extreme has been the contraction.”

<!-- PAGE:146 -->

## A Bull Market Recognized

These extracts could be supplemented by and contrasted with the uniformly bullish inferences drawn from the stock market barometer during the winter and spring of 1908, when the business of the country was, apparently, in the deepest stage of depression. The depression was recognized; but the fact that the stock market was acting not upon the things of the moment but upon all the facts, as far ahead as it could see them, was never allowed to become obscure. It will be seen that *The Wall Street Journal* set forth the known facts in the paragraphs quoted above. A well-known chart showed its lowest point of depression at that time and did not cross its medial line, to begin its ensuing area of expansion, until the following November. But the stock market anticipated that record by a clear twelve months, and the faithful barometer predicted the recovery when there was apparently not a patch of clear sky on the horizon.

<!-- PAGE:147 -->

## Reprobating the "Frivolous" Recovery

Looking back on those days of early responsibility, it is matter of thankfulness to me to have had Dow's sound theory to back me in the face of unbelievably virulent criticism. In the mind of the demagogue Wall Street can never be forgiven for being right when he is wrong. The country at that time was full of all kinds of agitation for the curbing, controlling, regulating and general bedeviling of business. Discontent was general, and it was a winter of unemployment. Some of the letters received, in which this bullish attitude of the stock market was denounced in the most unmeasured terms, would sound funny now, although they were anything but funny then. We seemed to be in the position of the "coon" at the country fair who puts his head through a hole in a sheet as a target for those willing to pay their nickels for the privilege of a shot at him. The lightest accusation was that Wall Street was *"fiddling while Rome was burning."* The general charge took the form that guilty manipulation by gamblers was in progress.

<!-- PAGE:148 -->

If you will refer back to the twenty-five-year chart published with an earlier discussion you will note that the recorded sales at that time were the lowest since 1904, indicating a market so narrow that manipulation would have been wasted even if it had been possible. But that charge is always made in a bear market and in the transition period between a major decline and its succeeding upward movement. If I had not already advanced so many arguments to prove what an inconsiderable factor manipulation really is, the volume of sales itself would be sufficient to make my point. But these sturdy protestants thought otherwise, and continued to fill my wastebasket with revilings for many months to come. For a time at least, a bull market was positively unpopular.

## Relevance of the Volume of Trading

It is worth while to note here that the volume of trading is always larger in a bull market than in a bear market. It expands as prices go up and contracts as they decline. A moment's thought will reveal the reason. When the market has been under long depression many people have lost money, actually and on paper, and the fund for speculation or speculative investment is correspondingly contracted. On the advance, however, many people are making money, actually and on paper, and the wellnigh universal experience has been that in the last stages of a bull market they trade in stocks beyond their real resources. This is uniformly true of major bull swings, but is subject

<!-- PAGE:149 -->

to great modification in the secondary movements. A sharp reaction in a bull market will often stimulate the volume of business. There is a picturesque example of this in the most spectacular reaction of the kind. The average monthly sales in May, 1901, have not been closely approached since. They were more than one million eight hundred thousand shares a day, including Saturdays, when there is only two hours of trading, and it was on the 9th of May that the Northern Pacific panic took place. There will be an opportunity to take up the secondary swing in some detail in a future discussion, and it is not necessary for our purpose to expand upon the subject now.

<!-- PAGE:150 -->

## An Unbiased Mind

Not to be tedious, but to counter the charge of saying *"I told you so,"* on *ex post facto* evidence, it has been necessary to offer these examples of the practical use of the stock market barometer. There is, indeed, little in these predictions to excite boasting. Any intelligent student of the averages who has once grasped the principle of the stock market barometer can draw such deductions for himself, provided he brings to the task a really unbiased mind. An interest in the stock market would be almost certain to weaken his judgment. It is only human to foresee what you hope and, indeed, what you expected when you bought stocks for the rise or sold them short. But the analyst of the price movement, writing for the guidance of others, must be absolutely disinterested. There are all sorts of traps to catch him if he is not, particularly if he has previously committed himself to inferences not clearly justified by the premises. Sheer pride of opinion has ruined more speculators in the stock market than all other causes put together.

<!-- PAGE:151 -->

## An Unfortunate Guess

One of the shortest ways of going wrong is to accept an indication by one average which has not been clearly confirmed by the other. On May 10, 1921, the *New York American* ventured into prophecy on its financial page. To reinforce its prediction its forecaster published a reproduction of the Dow-Jones chart. As the chart and the accompanying figures were taken without acknowledgment, altruists who believe that ill-gotten gains do not prosper will hear with satisfaction that the author of the Hearst *American* article did not even understand the meaning of what he had appropriated. He announced a bull movement for the industrial stocks, even prescribing its limits, a degree of prophecy hitherto unsuspected in the barometer; while the railroad stocks, as he expressed it, *"marked time."* It was a most unfortunate guess, for the industrials declined a further thirteen points, making their new low in June; while the railroads, so far from marking time, also showed a substantial reaction.

<!-- PAGE:152 -->

## Averages Must Confirm Each Other

This was a case where the observer was misled by a bullish indication given in the industrial average which was not confirmed by the railroads. The former had been making what we have learned to call **a line**, and after a secondary rally in a bear market showed some strength, at a figure above the line and calculated to suggest accumulation if there had been any evidence of the same thing in the railroad stocks. But there was nothing of the kind, and it is to be hoped that the readers of the Hearst *American* article did not follow the tip; for the industrials, as shown by the averages, did not cross the closing figure of the day on which the bullish advice was given until the second trading day of December, seven months after.

It is possible, however, for us to assume charitably that this expounder of the barometer was not quite so superficial as he sounds. There may have been in his mind a recollection of the bull market of 1919, which the industrials made entirely off their own bat. If you will study the chart published with a later chapter, headed *"An Exception to Prove the Rule,"* you will see that such an experience could not be repeated unless our railroad stocks returned to government ownership and guaranty—a condition which at that time took them entirely out of the speculative class and left them moving downward with bonds and other securities held for fixed income. These, as we know, inevitably decline in price with an advance in the cost of living, which was then in full flood.

This illustration serves to emphasize the fact that while the two averages may vary in strength they will not materially vary in direction, especially in a major movement. Throughout all the years in which both averages have been kept this rule has proved entirely dependable. It is not only true of the major swings of the market but it is approximately true of the secondary reactions and rallies. It would not be true of the daily fluctuation, and it might be utterly misleading so far as individual stocks are concerned. The indications of a single average can, and do, look seductively like the real thing, as I have discovered to my cost; for in that way I find, upon analysis of articles written long ago, that I more than once went wrong. It says much for the value of our barometer that error came from trusting it too little rather than too much.

<!-- PAGE:153 -->

## Sticking to Our Text

It has been suggested that I should discuss the causes which were related to the major movements of the stock market—the depressions in business, the recoveries and the alleged or real overexpansion. I have my own opinion about the causes of the panic of 1907. I do not agree with writers rated as competent as myself, who ascribe it to E. H. Harriman and the “overexpansion” of the American railroads from 1901 to 1906; who choose to think that the advance in the Bank of England rate to the sufficiently startling figure of 7 per cent at the end of 1906 was a direct result of gambling in railroad stocks by Mr. Roosevelt’s “malefactors of great wealth.” And by no stretch of faith can I believe that Harriman produced a panic in Alexandria, Egypt, in April, 1907; another in Japan within a month; what the London *Economist* called “the biggest financial disaster that had overtaken the city since 1857” in Hamburg in October; and still another in Chile—all preceding our own crisis at the end of October. It has seemed to me that the subsequent paralysis of railroad development, which should have gone on at the billion-dollar-a-year rate James J. Hill suggested in 1906, but was suspended almost entirely, was a much more serious matter for the country than the reciprocal ownership of railroad stocks of E. H. Harriman’s plans. There could be no menace to the public there, with the Interstate Commerce Commission to protect us through the freight rates.

But all this is beside the point. I am writing about the barometer, not about the weather. History reads queerly fourteen years after the event to those who were in a position to know the facts, who might even have been, to at least a modest extent, part of that history. But where it is necessary to review history here these discussions will still stick to the text.