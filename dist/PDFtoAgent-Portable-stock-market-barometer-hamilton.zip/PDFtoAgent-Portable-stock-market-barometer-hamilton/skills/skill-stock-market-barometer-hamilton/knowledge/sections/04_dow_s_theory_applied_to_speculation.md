# DOW'S THEORY, APPLIED TO SPECULATION

# DOW'S THEORY, APPLIED TO SPECULATION

<!-- PAGE:38 -->

## Chapter IV

## DOW'S THEORY, APPLIED TO SPECULATION

WE have seen in past discussions of Dow's theory of the stock-market price movement that the essence of it could be summed up in three sentences. In an editorial published December 19, 1900, he says, in *The Wall Street Journal*:

> “The market is always to be considered as having three movements, all going on at the same time. The first is the narrow movement from day to day. The second is the short swing, running from two weeks to a month or more; the third is the main movement, covering at least four years in its duration.”

It has already been shown that his third and main movement may complete itself in much less than Dow's assumed four years, and also how an attempt to divide the ten-year period of the panic cycle theory into a bear and bull market of approximately five years each led to an unconscious exaggeration. That, however, is immaterial. Dow had successfully formulated a theory of the market movements of the highest value, and had synchronized those movements so that those who came after him could construct a business barometer.

### The Truth Beneath Speculation

This is the essence of Dow's theory, and it need hardly be said that he did not see, or live to see, all

<!-- PAGE:39 -->

that it implied. He never wrote a single editorial on the theory alone, but returns to it to illustrate his discussions on stock-market speculation, and the underlying facts and truths responsible not only for speculation (using the word in its best and most useful sense) but for the market itself.

It is not surprising that *The Wall Street Journal* received many inquiries as to the assumptions it made on the basis of Dow's major premise. On January 4, 1902, Dow replies to a pertinent question, and any thoughtful reader of these pages should be able to answer it himself. The correspondent asks him, *"For some time you have been writing rather bullish on the immediate market, yet a little bearish in a larger sense. How do you make this consistent?"* Dow's reply was, of course, that he was bullish after the secondary swing but that he did not think, in view of stock values from earnings of record, that a bull market which had then been operative sixteen months could run much further. It was a curious contraction, incidentally, of his own minimum four-year estimate, but that major upward swing as a matter of fact ran until the following September. It may be said that such a swing always outruns values. In its final stage it is discounting possibilities only.

### A Useful Definition

In the same editorial Dow goes on to give a useful definition from which legitimate inferences may be drawn. He says:

<!-- PAGE:40 -->

> “It is a bull period as long as the average of one high point exceeds that of previous high points. It is a bear period when the low point becomes lower than the previous low points. It is often difficult to judge whether the end of an advance has come because the movement of prices is that which would occur if the main tendency had changed. Yet, it may only be an unusually pronounced secondary movement.”

This passage contains, by implication, both the idea of **"double tops"** and **"double bottoms"** (which I frankly confess I have not found essential or greatly useful) and the idea of a **"line,"** as shown in the narrow fluctuation of the averages over a recognized period, necessarily one either of accumulation or distribution. This has been found to be of the greatest service in showing the further persistence of the main movement, or the possible termination of the secondary movement, so apt to be mistaken for the initiation of a new major trend. I shall, in a later chapter, analyze such a "line," made in the stock market in 1914.

### Successful Forecast

In subsequent discussions there will be no difficulty in showing, from the various studies in the price movement since 1902, standing for record in the columns of *The Wall Street Journal*, that the method for a forecast of the main market movement and for a correct discrimination between that and the secondary movement had been provided in Dow's theory, and that it has been used with surprising accuracy. A prophet, especially in Wall Street, takes his life in his hands. If his predictions are always of the rosiest

<!-- PAGE:41 -->

whatever the facts of the situation may be, he will at worst be merely called a fool for his pains. The charge against him will be far more serious if he sees that a boom has overrun itself, and says so. If he is bearish and right he will be accused of unworthy motives. He will even be held contributory to the decline which he foresaw, although his motives may have been of the highest and he may have not a penny of interest in the market either way.

### "Recalling" a Prophet

Is the American public so ungrateful to its Micaiahs and Cassandras as this? Yes, indeed, and more so. It does not like unpleasant truths. In 1912, when Colonel C. McD. Townsend of the United States Engineers, an army man with a brilliant record then and since, was president of the Mississippi River Commission, he predicted, from the height of the water in the upper rivers, one of the greatest Mississippi floods. He warned the city of New Orleans that the flood might be expected in a month's time, recommending the most vigorous and immediate steps to lessen the calamity. Was New Orleans grateful? Its citizens held an indignation meeting to demand from President Taft the recall of this "calamity howler" and "dangerous alarmist." Mr. Taft characteristically kept his head, and Colonel Townsend was not removed. A good deal of property in the Mississippi Valley was "removed," and it is needless to record that New Orleans did not escape. The railroads and great

<!-- PAGE:42 -->

industrial concerns, where they were likely to be affected, took the warning seriously, with advantage to themselves. The mayor of New Orleans subsequently rescinded the resolution, with an apology. Anyone who knows one of the ablest and least advertised engineers in the United States Army will readily understand that Townsend regarded the mayor and the previous mass meeting with equal indifference.

### Synchronizing the Price Movement

It has been said before that Dow's theory is in no sense to be regarded as a gambler's system for beating the game. Any trader would disregard it at his peril, but Dow himself never considered it in that light, as I can testify from many discussions with him. I was writing the stock market paragraphs of the Dow-Jones news service and *The Wall Street Journal* in those days, and it was, of course, essential that I should thoroughly understand so scientific a method of synchronizing the market movement. Many men in Wall Street knew Dow and set their experience at his service. His mind was cautious to a fault, but logical and intellectually honest. I did not always agree with him and he was oftener right than I. When he was wrong it was clearly from lack of accurate data such as is now available.

### Necessary Knowledge

It would perhaps be well to point out here that a knowledge of the major movement of the market,

<!-- PAGE:43 -->

whether up or down, is necessary for the successful flotation of any largely capitalized enterprise. In a future discussion it will be convenient and highly interesting to illustrate, from James R. Keene's own admissions, how he distributed Amalgamated Copper to an oversanguine public at a time when the Boston News Bureau, to its everlasting honor, was warning New England investors to have nothing to do with that property at anything like the prices asked, or allow themselves to be deceived by the quarterly dividend of 1 1⁄2 per cent and a half per cent extra. That rate was retained at a time when *The Wall Street Journal* was openly calling the company a "blind pool," and showing, as the Boston News Bureau had shown, that neither the conditions of the copper trade nor the capitalization itself justified the flotation price. But Keene could never have distributed the stock except during the known major swing of a great bull market. He had exactly the same condition to help him in the much more formidable, and creditable, task of distributing the enormous capitalization of the United States Steel Corporation. That stock could never have been sold, and its sale would never have been attempted, in the subsequent bear market of 1903.

### An Instructive Editorial

It would be unfair to Dow if the reader were not given the opportunity of extracting for himself some light on Dow's own application of his theory, or at any rate some idea of his method in the series of

<!-- PAGE:44 -->

editorials which, as I have said before, dealt primarily with stock speculation as such and only incidentally with rules for reading the market. Here is an editorial, almost in full, published on July 20, 1901, only ten weeks after the panic which resulted from the Northern Pacific corner. At the time he wrote he did not see clearly that it was not a culmination of a major swing but a peculiarly violent secondary reaction in a primary bull market. He speaks first of individual stocks:

> “There is what is called the book method. Prices are set down, giving each change of one point as it occurs, forming thereby lines having a general horizontal direction but running into diagonals as the market moves up and down. There come times when a stock with a good degree of activity will stay within a narrow range of prices, say two points, until there has formed quite a long horizontal line of these figures. The formation of such a line sometimes suggests that stock has been accumulated or distributed, and this leads other people to buy or sell at the same time. Records of this kind kept for the last fifteen years seem to support the theory that the manipulation necessary to acquire stock is oftentimes detected in this way.

> “Another method is what is called the theory of double tops. Records of trading show that in many cases when a stock reaches top it will have a moderate decline and then go back again to near the highest figures. If after such a move, the price again recedes, it is liable to decline some distance.

> “Those, however, who attempt to trade on this theory alone find a good many exceptions and a good many times when signals are not given.

### Trading on Averages

> “There are those who trade on the theory of averages. It is true that in a considerable period of time the market has about

<!-- PAGE:45 -->

as many days of advance as it has of decline. If there come a series of days of advance, there will almost surely come the balancing days of decline.

> “The trouble with this system is that the small swings are always part of the larger swings, and while the tendency of events equally liable to happen is always toward equality, it is also true that every combination possible is liable to occur, and there frequently come long swings, or, in the case of stock trading, an extraordinary number of days of advance or decline which fit properly into the theory when regarded on a long scale, but which are calculated to upset any operations based on the expectation of a series of short swings.

> “A much more practicable theory is that founded on the law of action and reaction. It seems to be a fact that a primary movement in the market will generally have a secondary movement in the opposite direction of at least three-eighths of the primary movement. If a stock advances ten points, it is very likely to have a relapse of four points or more. The law seems to hold good no matter how far the advance goes. A rise of twenty points will not infrequently bring a decline of eight points or more.

> “It is impossible to tell in advance the length of any primary movement, but the further it goes, the greater the reaction when it comes, hence the more certainty of being able to trade successfully on that reaction.

> “A method employed by some operators of large experience is that of responses. The theory involved is this: The market is always under more or less manipulation. A large operator who is seeking to advance the market does not buy everything on the list, but puts up two or three leading stocks either by legitimate buying or by manipulation. He then watches the effect on the other stocks. If sentiment is bullish, and people are disposed to take hold, those who see this rise in two or three stocks immediately begin to buy other stocks and the market rises to a higher level. This is the public response, and is an indication that the leading stocks will be given another lift and that the general market will follow.

<!-- PAGE:46 -->

> "If, however, leading stocks are advanced and others do not follow, it is evidence that the public is not disposed to buy. As soon as this is clear the attempt to advance prices is generally discontinued. This method is employed more particularly by those who watch the tape. But it can be read at the close of the day in our record of transactions by seeing what stocks were put up within specified hours and whether the general market followed or not. The best way of reading the market is to read from the standpoint of values. The market is not like a balloon plunging hither and thither in the wind. As a whole, it represents a serious, well-considered effort on the part of far-sighted and well-informed men to adjust prices to such values as exist or which are expected to exist in the not too remote future. The thought with great operators is not whether a price can be advanced, but whether the value of property which they propose to buy will lead investors and speculators six months hence to take stock at figures from ten to twenty points above present prices.

> "In reading the market, therefore, the main point is to discover what a stock can be expected to be worth three months hence and then to see whether manipulators or investors are advancing the price of that stock toward those figures. It is often possible to read movements in the market very clearly in this way. To know values is to comprehend the meaning of movements in the market."

There are assumptions here to which modifications might be offered, but there is no need. It would be impossible to show, except by the research of records covering at least half a century, that there are as many days of advance as of decline. The information would be valueless if obtained. It amounts to saying that heads and tails will equalize themselves if a coin is spun a sufficient number of times.

But what may be commended is Dow's clarity and

<!-- PAGE:47 -->

sterling good sense. What he had to say was worth saying and he stopped when he had said it—a rare virtue in editorial writing. His feeling for the essential fact and for the underlying truth, without which the fact is bare and impertinent, will be readily remarked. He dealt with speculation as a fact, and could still show forth its truth without profitless moralizing, or confusing it with gambling. It will be well to imitate his point of view in further discussion, both on his theory and on the immense and useful significance of the stock market generally.