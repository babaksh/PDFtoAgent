# AN EXCEPTION TO PROVE THE RULE

# AN EXCEPTION TO PROVE THE RULE

<!-- PAGE:197 -->

## AN EXCEPTION TO PROVE THE RULE

A PROVERB has been called the wisdom of many and the wit of one. Sometimes, when the controversialist finds the proverb inconvenient, he calls it a glittering generality or a truism. A French philosopher told us that all generalizations are fallacious, "including this one." But a truism is presumably true, even if it is trite. It is said that there is no rule without an exception, but as a sufficient number of exceptions would make it necessary to formulate a new rule, especially in economics, the proverb which best suits our purpose is that which says that the exception proves the rule, although Coke's "Exceptio probat regulam de rebus exceptis" is not what we want. But the proverb is even startlingly true about what may be called the great exception in the stock market averages.

Our two averages of railroad and industrial stocks must confirm each other to give weight to any inference drawn from the price movement. The history of the stock market as shown by these averages, going back many years, proves conclusively that the two averages move together. But there was one exception to this rule, and it is the more valuable for our purpose in that it is the exception which proves the rule we have set up.

<!-- PAGE:198 -->

### Some Necessary History

It adds to the interest of the study of this subject that it is necessary to make excursions into contemporary history to explain the meaning of the price movement, often only fully apparent after the movement has been under way for many months. In 1918, for some nine months after we had entered the Great War, both averages showed a primary bull market with a strong secondary reaction over the end of that year. During that year the railroad stocks fully shared that upward swing but subsequently sold off, making almost a bear market of their own in 1919, when the industrials were strongest. Letters were written during the serial publication of these discussions, in which this well-known fact was adduced as a reason for rejecting the entire theory based upon the averages. But if ever an exception proved the rule this one does.

Remember that the industrial and railroad stocks used in the averages are essentially speculative. Only to a limited extent are they held for fixed income by people to whom safety of the principal should be the main consideration, and their holders are constantly changing. If they were not speculative they would be useless for a stock market barometer. The reason why railroad stocks during 1919 did not share the bull market in the industrials was that, through government ownership and government guaranty, they had in a real sense ceased, for the time at least, to be speculative. They could not advance in any market,

<!-- PAGE:199 -->

*Figure — MOVEMENT OF STOCK-MARKET AVERAGES*

<!-- PAGE:201 -->

bull or bear, more than enough to discount the estimated value of that guaranty.

### An Impaired Barometer

Thus for a year or more the averages had half their usual value as a barometer, or indeed less than half, for the movement in the industrials lacked the essential confirmation of a corresponding movement in the speculative railroad stocks. It is made clear by the accompanying chart that during that period the railroads followed not the speculative market but the market for bonds. They had nothing to expect beyond the government guaranty, unless, indeed, far-sighted holders of them could have foreseen the destruction of earning capacity resulting from the colossal waste of government ownership and its subsequent collapse. It will be shown that the railroad stocks during the period of that ownership paralleled the speculative industrials accidentally and for different reasons, only so far as to discount the supposed value of a government guaranty; relapsed, and recovered with an ensuing price movement governed essentially by the totally different conditions which are compelling in the case of bonds.

### An Important Distinction

There is some need to point out here the essential difference between a bond and a stock. The stock is a partnership obligation, while the bond is a debt, a

<!-- PAGE:202 -->

mortgage, a liability ranking ahead of the stock. The stockholder is a partner in the business, while the bondholder is a creditor of the company. The bondholder has lent the concern his money on the fixed assets, such as the railroad's real estate or the manufacturer's mills. But the essence of the bond is that its speculative feature to the holder is subordinate, or even non-existent. It is held for its income return. The price fluctuates strictly according to the purchasing power of the income. The price of the bond will be high when the necessaries of life are low, and the investment bond will decline in price as the cost of necessaries advances. It would be easy, but constantly misleading, to say that the price of bonds is regulated by the value of money. The interest rate fluctuates from day to day, and only by the issue terms of long-time bonds can we get any idea of the quotation for money over a long period of years, which is at the best an estimate, and often wrong.

### A Definition for the Layman

It is simplest to say that the price of securities held for fixed income is in inverse ratio to the cost of living. If the latter is high the price of bonds or other securities held for fixed income will be low and their apparent yield, measured in dollars, will be large. If the cost of living is low the price of securities held for fixed income will be high and the apparent income, represented by the yield in dollars, will be correspondingly less.

<!-- PAGE:203 -->

### Effects of Government Guaranty

It is plain, then, that with a government guaranty of a minimum return, based upon the average earnings of three years ended June 30, 1917, the railroads entered the fixed income class. If they had continued speculative, with no government guaranty and no government ownership, their fluctuations would not have been governed by the cost of living but by their earning capacity, and chiefly by their prospective earning capacity; for it cannot be too often repeated that the stock market is not reflecting conditions as they are to-day but conditions as far ahead as the combined intelligence of the country there concentrated can foresee them.

Let us consider the history of the war period as it affected the railroad stocks. When we entered the war, in the spring of 1917, the arrangement between the government and the railroads was purely tentative. So far as the stockholders knew, their investments were still speculative, and these followed the speculative trend. It was not until late on the day after Christmas, 1917, that the announcement that the railroads would be definitely taken over by the government was made. The stock market had not time to discount the new ownership on that day, but on the following day, December 27th, the average price of the twenty active railroad stocks closed at 78.08—an advance of no less than 6.41 points from the closing prices of the day before. For not more than two days previously was the idea that the roads would be per-

<!-- PAGE:204 -->

manently taken over considered seriously in the Street, although it had been expected for some time past that the government would advance the money for maturing obligations and capital improvements. On the morning of the day of the announcement one of the New York newspapers, in the confidence of the Wilson Administration, had a story to the effect that the plan was to take the roads over for a compensation based on the average of five years' net earnings. It is impossible to plumb the depths of Mr. Wilson's mind, but this new ownership was assumed, then and for long afterwards, to be permanent government ownership for all intents and purposes.

### How the Averages Diverged

From the accompanying chart it will be seen that in the rally throughout 1918 from the bear swing which had followed the first bull market of the Great War—that culminating in October, 1916—the railroad averages had accompanied the industrials in a steady advance. But from the time when the fate of the stockholders became dominated by government management and guaranty the two averages parted company. The high point of the movement in railroads was made in October, 1918, while the bull market in the industrial stocks did not culminate until November, 1919. Toward midsummer of the latter year the railroads had made some recovery, after a break following the first impetuous buying on government guaranty. But from that point they steadily

<!-- PAGE:205 -->

declined while the principal advance in the industrials was made, continuing to do so while the preliminary movement of the great decline of 1920 was in progress. In 1920 they ran counter to the falling industrials, on the way up actually crossing the industrials on the way down, in the autumn of 1920. There was simultaneously a confirmatory recovery in bonds.

### The Esch-Cummins Act

It will be seen that the decline in the railroads in 1919 and the recovery in 1920 virtually paralleled the movement of the average daily prices of forty representative bonds in those years. It will be noticed how closely this corresponded to the inflation and subsequent deflation of the cost of living. During the spring and summer of 1919, while Mr. Wilson was absent in Europe, it was frequently reported that he was disappointed with the unexpected costliness and inefficiency of government ownership, and that he would seek an early opportunity for a return of the railroads to their private owners. There is reason to believe that he did expect, or at least hope, to return them about August 1, 1919, anticipating that Congress would have passed appropriate legislation by that time. Congress was working on the Esch-Cummins bill, now called the Transportation Act, which dragged through the summer and autumn until, on November 16th, the House of Representatives passed the measure. It was at that time, or early in December, that the President positively declared that he would return the roads

<!-- PAGE:206 -->

on January 1st. But the Senate did not pass the Esch-Cummins bill until late in February, 1920; so that the President was compelled to extend the limit he had fixed by two months.

### Selling "Ex-Control"

But more than nine months before, in May, 1919, when the railroad average was making the first figure of a "double top," completed in July, *The Wall Street Journal* said that the strength of these stocks in the face of discouraging reports of earnings might be due to the fact that they were beginning to sell "ex-control." There is no question that the decline from the point of the further (July) rally to the early low of 1920 was due to the appalling damage inflicted by government ownership, which actually, in most cases, had raised the operating cost above the operating revenue. The principal item, wages, had been advanced beyond all reason, by a management which was political rather than financial, and the cost of everything the railroads consumed had been multiplied. The war administration had actually bid up railroad ties in Maine against itself, the only buyer, from thirty-seven cents each to $1.40. It is noteworthy also that at that time the large but absolutely necessary increase in rates to render the railroads self-supporting under private operation was only being discussed. It was in fact not granted by the Interstate Commerce Commission until the time of its usefulness had passed.

<!-- PAGE:207 -->

### A Difference of Kind

Federal control actually ended on February 28, 1920, two days after the signing of the Esch-Cummins act, which, however, extended federal compensation for another six months, created the Labor Board and gave the Interstate Commerce Commission the 6 per cent net return as a rule of rate-making. Rates were not advanced until the following August, but Wall Street knew that they must necessarily be advanced, and, as usual, discounted that advantage as far ahead as it could see it—in this case nearly six months.

In considering the effect of the war upon business and production it is well to assure ourselves as to what extent the conditions it created are different, in kind or only in degree, from those following other wars. This was a difference in kind. Without help from other quarters the industrial stocks made a bull market off their own bat—a thing they had never done before. Stress is laid upon this fundamental difference here, and the causes which created it, because unless it is thoroughly explained and grasped it is inevitable that teachers and students of the future, to whom these discussions are intended to appeal quite as much as to the readers of the present, will become confused and discouraged, in the face of what might well be considered irreconcilable difficulties and discrepancies. Still another instance will be furnished of a like searching test.

<!-- PAGE:208 -->

### A Sense of Proportion—and of Humor

There is no need for us to fall in love with our theory or to regard it in the false perspective of the enthusiast for any fad. If you hold a silver dollar at arm's length you can see it in its correct relation to surrounding objects. If you bring it too close to the eye its relation to those objects will become distorted and exaggerated, and you can hold it so close that you can see nothing else. Heaven forbid that I should attempt to found a school of economists prepared to die for the thesis that the world wabbles along on a theory of averages. There is no cry here for disciples. We can forgive a great deal to the founder of a school, but we can seldom forgive the school. Let us, therefore, hold the stock market barometer at such a readable distance from the eye that we shall not consider the barometer more important than the weather it predicts. We have sound theory to go upon, or this and the preceding chapters have been written in vain. Don't let us overwork it, as so many statisticians do. Scientists, even the greatest, are inclined to worship their hypotheses, with humiliating results. Herbert Spencer, the great synthetic philosopher, once said to the late Professor Huxley: "You may hardly believe it, but I, myself, wrote the beginning and at least the framework of a tragedy." "I can quite believe it," said Huxley. "I know the plot. It was how a perfectly beautiful theory was murdered by an ugly little fact."

<!-- PAGE:209 -->

### Our Material Is Mostly Modern

Some disappointment has been expressed that Charles H. Dow said so little that was definite upon his own theory of the market movement, or was able to draw so few of the inferences which were implicit in that theory, to say nothing of the practical and useful truths developed from its application. The wonder is that he got so far with the scanty materials then available. In the latter part of 1902, when Dow died, but six of the twenty industrial stocks now in the average were in the average then, and the number of such stocks used was only twelve. Ten years before, it would have been impossible to find a sufficient number of representative and consistently active industrial stocks to make an average at all. The old averages, and I wish I were able to show examples of the market movement back as far as 1860, with at least a single average for fifteen stocks, had not the advantage of their present double form. We see how vitally important it is to have two averages correcting and confirming each other. But when McKinley was re-elected it was necessary to include Western Union even in the railroad averages, for lack of a consistent degree of activity in a sufficient number of stocks. We need not belittle the pioneers, or overpraise them. They necessarily had to break ground for themselves and improvise their own tools, while we, with all the benefit of their experience, only too often turn out work which is certainly less creative and often less sincere.