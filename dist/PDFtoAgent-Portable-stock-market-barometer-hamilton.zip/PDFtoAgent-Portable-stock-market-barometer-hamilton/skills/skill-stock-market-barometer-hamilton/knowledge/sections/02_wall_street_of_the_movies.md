# WALL STREET OF THE MOVIES

# WALL STREET OF THE MOVIES

<!-- PAGE:17 -->

## WALL STREET OF THE MOVIES

WE shall prove, by strict analysis, the fidelity of the stock market barometer, tested over a long period of years. With the aid of Dow's theory of the price movement we shall examine the major swings upwards or downwards, extending from less than a year to three years or more; their secondary interruption in reactions or rallies, as the case may be; and the relatively unimportant but always present daily fluctuation. We shall see that all these movements are based upon the sum of Wall Street's knowledge of the business of the country; that they have no more to do with morality than the precession of the equinoxes, and that manipulation cannot materially deflect the barometer.

### Movies and Melodrama

But, to judge from some of my correspondence, the case must not even be argued, because it is alleged that Wall Street does not come into court with clean hands. It has seemed, in the past, at least discouraging to point out how the dispassionate, the almost inhuman, movement of the market has nothing whatever to do with the occasional scandals which disfigure the record of every market for anything anywhere. But the proportion of people who only feel is, to those who think, overwhelming. The former are in such a

<!-- PAGE:18 -->

majority that concession must be made to them, although I still decline to apologize for the stock market. I should as soon think of apologizing for the meridian of Greenwich. To quote one of the best known of Grover Cleveland's useful platitudes, it is a condition and not a theory which confronts us.

In the popular imagination there is a fearful and wonderful picture of Wall Street—something we may call the Wall Street of the movies. What the English call the cinema is our modern substitute for the conventional melodrama of our grandfathers. Its characters are curiously the same. Its villains and vampires are not like anything in real life; but they behave as consistent villains or vampires ought to behave if they are to satisfy critics who never saw a specimen of either. Many years ago Jerome K. Jerome wrote a chapter on stage law. He showed that on the English stage the loss of a three-and-six-penny marriage certificate invalidated the marriage. In the event of death the property of the testator went to the person who could secure possession of the will. If the rich man died without a will the property went to the nearest villain. In those days lawyers looked like lawyers—on the stage. The detective looked like a gimlet-eyed sleuth, and a financier looked so like a financier that it positively seemed to hurt his face.

### Financiers of Fiction

Our modern financier on the screen looks like that, especially in the “close-ups.” But he is no new creation.

<!-- PAGE:19 -->

I remember reading a magazine story, a score of years ago, of a stock market coup by a great "manipulator," of the type of James R. Keene. The illustrations were well drawn and even thrilling. In one of them Keene, or his prototype, was depicted bending dramatically over a Consolidated Stock Exchange ticker! It is to be presumed that he was smashing the market with ten-share lots. Only a Keene could do it, and only a Keene of the movies at that. Doubtless the author of the story, Mr. Edwin Lefevre, who was dissipating his talents in hazy financial paragraphs for the *New York Globe* at that time, felt that he had been artistically frustrated. But perhaps he had himself to thank. Here is his own description of such a manipulator. It is in a short story published in 1901, called *The Break in Turpentine*:

> "Now, manipulators of stocks are born, not made. The art is most difficult, for stocks should be manipulated in such wise that they will not look manipulated. Anybody can buy stocks or can sell them. But not every one can sell stocks and at the same time convey the impression that he is buying them, and that prices therefore must inevitably go much higher. It requires boldness and consummate judgment, knowledge of technical stock market conditions, infinite ingenuity and mental agility, absolute familiarity with human nature, a careful study of the curious psychological phenomena of gambling and long experience with the Wall Street public and with the wonderful imagination of the American people; to say nothing of knowing thoroughly the various brokers to be employed, their capabilities, limitations and personal temperaments; also, their price."

That is professedly fiction, and, incidentally, more true and respectable as art than the product of the melodrama or the screen. It lays no stress on the deeper knowledge of values and business conditions necessary to assure the existence of the kind of market which alone makes manipulation possible. Truth is stranger than fiction, and perhaps harder to write, although the remark is open to an obvious retort.

<!-- PAGE:20 -->

### Silk Hats and Strained Faces

Not long ago there appeared a letter to a popular newspaper, notorious for what may be called the anti-Wall Street complex. It professed to give, in a series of gasps, the impressions of a Western stranger on visiting Wall Street. One of these "flashlights" was, "silk hats and strained faces." Let me be exact. I have seen a silk hat in Wall Street. It was when Mayor Seth Low opened the new Stock Exchange in 1901. My stenographer, bless her honest heart, said it was real stylish. But financiers of the movies tend to wear silk hats, just as the heroes in melodrama, even when reduced to penury and rags, wore patent-leather shoes. A screen financier without a silk hat would be like an egg without salt. We cannot otherwise infer, as we are required, that he is a bad egg.

### "A Long Way Back for Soup"

Only a few years ago there was a severely localized scandal over a "corner" in a stock called Stutz Motor, for which no true market had been established. Nobody was hurt except a few speculators who chose to sell the thing short. They paid up without whin-

<!-- PAGE:21 -->

ing. But it formed an irresistible text for a popular attack upon Wall Street. One of the New York newspapers said that the incident was only in a piece with "the Metropolitan Traction corruptionists, the New Haven wreckers, the Rock Island wreckers, and" what it called, with a free rendering of history, "the life insurance corruptionists." This was in a newspaper professing to sell news. It did not tell its readers that the last of the Metropolitan Street Railway financing happened twenty years before. Even the foolish and indefensible capitalization of the surface lines of New York, unloaded on what was then called the Interborough Metropolitan Company, was fifteen years old. The life insurance investigation, which, incidentally, neither charged nor proved "corruption," went back sixteen years. Even the last essay in misjudged New Haven financing, a comparatively minor matter, occurred fully eleven years earlier; that of Rock Island, nineteen years before; while that favorite charge against Wall Street, the recapitalization of the Chicago & Alton, was carried through in 1899 and not a soul saw anything wrong with it until 1907. I suppose I write myself down a hopeless reactionist when I say that, with the fullest knowledge of the facts, I cannot see anything reprehensible in it now.

### Widows and Orphans

Even an incident so spectacular as the Northern Pacific corner, with the purely stock market panic which it produced, cannot be pleaded as an example of a kind

<!-- PAGE:22 -->

of manipulation which would disable our barometer. That particular panic occurred in the course of a primary bull market. It produced merely a severe secondary reaction, for the upward movement was resumed and did not culminate until sixteen months afterwards. That incident of 1901, however, is still alive and kicking, so far as the politicians who denounce Wall Street are concerned. It is remarkable that all the stock affected in these bygone incidents is alleged to have been held by widows and orphans. I wish somebody would marry that widow and adopt, or even spank, the orphan. After depriving their trustees of the commonest business sense they have no right to come around in this indelicate way and remind us of our crimes. There is a lucrative engagement waiting for them elsewhere—in the movies.

### Dow's Theory True of any Stock Market

Let us be serious, and get back to our text. The law that governs the movement of the stock market, formulated here, would be equally true of the London Stock Exchange, the Paris Bourse or even the Berlin Boerse. But we may go further. The principles underlying that law would be true if those Stock Exchanges and ours were wiped out of existence. They would come into operation again, automatically and inevitably, with the re-establishment of a free market in securities in any great Capital. So far as I know, there has not been a record corresponding to the Dow-Jones averages kept by any of the London financial

<!-- PAGE:23 -->

publications. But the stock market there would have the same quality of forecast which the New York market has if similar data were available.

It would be possible to compile from the London Stock Exchange list two or more representative groups of stocks and show their primary, their secondary and their daily movements over the period of years covered by Wetenhall's list and the London Stock Exchange official list. An average made up of the prices of the British railroads might well confirm our own. There is in London a longer and more diversified list of industrial stocks to draw upon. The averages of the South African mining stocks in the Kaffir market, properly compiled from the first Transvaal gold rush in 1889, would have an interest all their own. They would show how gold mining tends to flourish when other industries are stagnant or even prostrated. The comparison of that average with the movement of securities held for fixed income would be highly instructive to the economist. It would demonstrate in the most vivid way the relation of the purchasing power of gold to bonds held for investment. It would prove conclusively the axiom that the price of securities held for fixed income is in inverse ratio to the cost of living, as we shall see for ourselves in a later chapter.

<!-- PAGE:24 -->

### The Fact Without the Truth is False

It is difficult, and with many observers it has proved impossible, to regard Wall Street comprehendingly from the inside. Just as it will be shown that the market is bigger than the manipulator, bigger than all the financiers put together, so it is true that the stock market barometer is in a way bigger than the stock market itself. A modern writer, G. K. Chesterton, has said that the fact without the truth is sterile, that the fact without the truth is even false. It was not until Charles H. Dow propounded his theory of the price movement that any real attempt had been made to elicit and set forth the truth contained in the fact of the stock market. Can we make it possible for the man whose business brings him into the midst of that whirling machinery to understand the power which moves it, and even something of the way that power is generated? Apparently the only picture which has hitherto reached the popular retina is the distorted image which we have called the Wall Street of the movies.

### Homage Vice Pays to Virtue

Why does the swindling oil-stock promoter circularize his victims from some reputable address in the financial district, and use all sorts of inducements to get his stock quoted in the financial columns of reputable metropolitan newspapers? Would he do that if the public he addresses, the investor and the speculator,—the investor in embryo,—really believed that Wall Street was the sink of iniquity which the country politician depicts? If that were truly the case the shady promoter would seek other quarters. But he

<!-- PAGE:25 -->

uses the financial district because he knows that its credit and integrity are the best in the world. Hypocrisy is the tribute which vice pays to virtue. He would have no use for a Wall Street as rotten as himself. Indeed, if the financial district were one tithe as corrupt as the demagogues who abuse it there would be no problem for them to propound. The money center of the United States would fall to pieces of its own rottenness. All this is true, and yet if the exact contrary were the case the theory of the stock-market movement would still be valid.

### Rhodes and Morgan

It will not be charged that the writer is like the dyer's hand, subdued to what he works in, if his illustrations have been chosen mainly from the financial district. There is a Wall Street engaged upon tasks so serious, so exacting, that it has neither time nor inclination to be crooked. If it is true, as we have seen, that nobody can know all the facts which at any one time influence the stock-market movement, it is true, as any of us can record from personal experience, that some have far more knowledge than others. The men who really know lift you out of this scuffle of petty criticism and recrimination. When they are rich men their wealth is incidental, the most obvious means to larger ends, but not an end in itself.

When I was following my profession in South Africa, a quarter of a century ago, I was thrown in contact with Cecil John Rhodes. He had definite ideas

<!-- PAGE:26 -->

and large conceptions, far above the mere making of money. Money was necessary to the carrying out of his ideas, to the extension of white civilization from the Cape to Cairo, with a railroad as the outward and visible sign of something of even spiritual significance. In the respect of intuitive intelligence I have met only one man like him—the late J. Pierpont Morgan. It was impossible to follow the rapidity of their mental processes. There was something phenomenal about it, like the performances of mathematically gifted children who can give you the square root of a number in thousands with a few moments of mental calculation. Other well-known men—speaking perhaps from the point of view of a reporter—seemed to have mental processes much like our own. Most of the great captains of industry I have met, like James J. Hill and Edward H. Harriman, had a quality essential to a first-rate thinker. They could eliminate the irrelevant. They could grasp the fundamental fact in a page of verbiage. But Rhodes and Morgan could do more. They could reason to an often startling but sound conclusion before you could state the premises.

### Not Indescribable

And these men were rich, almost fortuitously. They had great tasks to accomplish, and it was necessary that they should have the financial means which made achievement possible. In the past few years we have heard a great deal about “ideals,” and found that most of them were half-digested opinions. But there is a

<!-- PAGE:27 -->

Wall Street with an ideal. There has usually been, and I hope there always will be, the right man to take the right objective view at the right moment. Not long ago I heard a lecturer setting forth what he called the "indescribable" beauties of the Grand Canyon of the Colorado. In the space of an hour and a quarter he proved conclusively that those beauties were indescribable, at least so far as he was concerned. But Milton could have described them, or the Psalmist. Perhaps any reasonably intelligent man could give you an idea of that natural wonder if he set forth simply the spiritual truth in the physical fact before him.

### The Unchangeable

I feel I have said before, perhaps in editorials you read to-day, and forget to-morrow, what I am saying now. The problems of humanity do not change, because human nature is what it has been as far back as human record tells. **"Cycles"** are as old as organized humanity. The changes we see are superficial, especially where sincere and intelligent men so legislate that they may the better live together in peace and good will. The human heart is essential to all progress. Reform starts there, and not in the halls of legislation.

### The Bells of Trinity

Facing the western end of Wall Street, casting its shadow from the setting sun upon the most criticized and least understood section of a great nation, stands the spire of Trinity. We have often heard its bells

<!-- PAGE:28 -->

ringing the old familiar Christmas hymns. The shepherds will be watching their flocks again, all seated on the ground. It may well be that, hearing those bells, the glory of the Lord shall in some manner shine round about us. There is little that laws can do to make men happier or richer or more contented. There is no form of government to-day, without its parallel, and warning, in the past. There is none in the past of which it could not be said that only righteousness exalteth a nation. Wall Street knows as well as the most disinterested of its critics that goodness and justice and sacrifice and love are the foundation of all good government, because in that spirit alone a people truly governs itself.

We have said that the laws we are studying are fundamental, axiomatic, self-evident. And in this higher truth surely there is something permanent which would remain if the letter of the Constitution of the United States had become an interesting study for the archeologist, and the surviving writings of our day were classical in a sense their authors never dreamed. Such a foundation is permanent because truth has in it the element of the divine.