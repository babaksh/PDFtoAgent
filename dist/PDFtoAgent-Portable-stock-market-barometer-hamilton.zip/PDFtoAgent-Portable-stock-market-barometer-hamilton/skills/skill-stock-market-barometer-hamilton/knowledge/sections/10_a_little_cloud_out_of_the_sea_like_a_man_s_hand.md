# A LITTLE CLOUD OUT OF THE SEA, LIKE A MAN’S HAND

# A LITTLE CLOUD OUT OF THE SEA, LIKE A MAN’S HAND

<!-- PAGE:113 -->

## “A LITTLE CLOUD OUT OF THE SEA, LIKE A MAN’S HAND”—1906

IN discussions such as these it is necessary to anticipate objections and explain apparent discrepancies. There is nothing more deceptively fascinating than a hypothesis which holds together too well. Out of that sort of theory much obstinate dogma arises, which seems able to continue its existence after time has proved the theory unsound or inadequate. We have established what is called Dow's theory of the price movement—the major swing, the secondary reaction or rally, and the daily fluctuation—and out of it have been able to evolve a working method of reading the stock market barometer so constituted. But we are to guard ourselves against being too cocksure, and to recognize that while there is no rule without an exception, any exception should prove the rule.

### The San Francisco Earthquake

The year 1906 presents an interesting problem in this way. It is the problem of an arrested main bull movement or an accentuated secondary reaction, according to the way you look at it. It has been said that major bull markets and bear markets alike tend to overrun themselves. If the stock market were omniscient it would protect itself against this over-

<!-- PAGE:114 -->

inflation or over-liquidation, as it automatically protects itself against everything which it can possibly foresee. But we must concede that, even when we have allowed for the further established fact that the stock market represents the sum of all available knowledge about the conditions of business and the influences which affect business, it cannot protect itself against what it cannot foresee. It could not foresee the San Francisco earthquake of April 18, 1906, or the subsequent devastating fire.

### Tactful to Call it a Fire

If you want to make yourself popular with that somewhat strident individual, the California "native son," you will not even allude to the San Francisco earthquake. In California it is considered bad manners to do anything of the sort. All that is conceded there is the fire. For our purpose the earthquake admits of no argument. Chronic California boosters, however, cannot permit a general impression that there might be, for instance, another earthquake in San Francisco as bad as the last. A fire, on the other hand, might occur to any city, anywhere, without detracting from those natural advantages of climate and other things of which California is so proud. There is nothing more charming than the naivete of the Los Angeles native, who says *"It is a fine day, if I say so myself."* But earthquakes are different. They put the Pacific coast in a class by itself, and a class not at all to the taste of the inhabitants. As Beau Brummell, the great English dandy of the early years of last century, said: *"A hole may be the result of an accident which could happen to any gentleman, but a darn is premeditated poverty."*

### Effect on the Stock Market

But the San Francisco earthquake came up in a clear sky, and took an already reactionary stock market by surprise. You will remember the clause in the Lloyds ship insurance policies which excepts *"the act of God and the King's enemies."* This aberration of Nature was an exception, and it went far to explain an exceptional year in the record of the stock-market barometer. There was an undoubted bull market from September, 1903, reaching a high point in January, 1906. It did not hold that point without recession; and it may be said that as a general rule there is often no marked warning line of distribution at the top of a major bull swing, especially when that bull swing has overrun itself, as, for instance, it did in 1919. The market in the spring of 1906 was declining, but with no such precipitancy as to indicate the bull market would not be resumed, or had even been much overbought when the earthquake occurred.

We must remember how serious the losses were. The convulsion set up a fire in the ruins of the immense number of collapsed houses or those shaken to their foundations, and this fire rapidly assumed the proportions of what the insurance companies call a conflagration. The American companies, without exception of consequence, and the English companies, paid up promptly, to help the sufferers, although they had an excellent fighting case over the earthquake itself. We might have learned a little of German methods from the action of Hamburg companies, who adopted the opposite policy and repudiated their liability. It might have taught us something of the German methods in the conduct of war and diplomacy, of the German conceptions of the spirit of a contract and of sportsmanship. At least after that time the fire insurance companies of Hamburg wrote little insurance in America.

<!-- PAGE:115 -->

### Sound Prediction Under Difficulties

When the stock market is taken by such a surprise there is a violent break closely akin to that of a panic. The basis of a panic, when analyzed, is essentially surprise. It cannot be said that the stock market of 1906, in the last days of April, got out of hand. But the decline had been sufficiently serious. The twenty railroad stocks which sold at 138.36 on January 22, 1906, on May 3d had declined over eighteen points; the twelve industrials then used had reacted from 103 on January 19th to 86.45 on the later date. There seems to be some sort of uniformity which obtains in breaks like this. Experience records a recovery of part of the panic break, with a subsequent and much slower decline which really tests the strength of the stock market.

In fact, *The Wall Street Journal* of July 6, 1906, called attention to this fact, in predicting a general recovery from the showing of the averages. It said:

> *"It is a uniform experience, over the years when such averages have been kept, that a panic decline is followed by a sharp rally of from 40 per cent to 60 per cent of the movement, and then by an irregular sag ultimately carrying the price to about the old low point. It seems to need this to bale out the weak holders who were helped over the panic. It could hardly be said that the break on the San Francisco disaster was exactly of the panic class, and the market in rallying recovered to 131.05 in the case of the railroad stocks, which is only 1.61 below the price at which the earthquake decline started. The rally, however, does represent about 60 per cent of the decline since January 22d, and the course of the market since has been curiously parallel to the movement observed after a panic rally. It seems fair to infer that liquidation of very much the same kind as that following a panic has been necessary."*

### Seriousness of the Disaster

At this distance of time we may easily forget how serious the San Francisco disaster was. The loss direct has been estimated at $600,000,000. The Aetna Fire Insurance Company admitted that the conflagration had cost it the savings of forty years. If that was the effect on the strongest fire insurance company in the United States, and one of the strongest in the world, how severe must have been the consequences elsewhere.

It was all very well for the shallow, half-taught optimist to say that broken windows made work for glaziers and manufacturers of glass. But it cost you something to put in a new pane, and the money you spent on it would have been spent on something else, while, as Bastiat said, you would still have your window. If that sort of reasoning were good, the quick road to prosperity would be to burn down all the cities in the United States.

We see that the railroad stocks suffered more than the industrials, and we should remember that they were in a higher class, both relatively and positively. But in a sudden and demoralizing break people sell the things for which there is some market in order to protect those for which there is no market. As *The Wall Street Journal* put it at that time: *"The first decline in a panic is scare, and the second and slower decline is the demonstration of the general shock to confidence;"* going on to say, in speaking of the market on July 2d, that the line of prices was well below the line of values and that the indications were bullish.

<!-- PAGE:116 -->

### Rally From a Break in a Bull Market

This inference proved correct, and it has been the custom, which is followed in these discussions, to consider the bull market which began in September, 1903, as actually terminating and turning to the bear side, not in January, 1906, but in December of the same year. At the time the bullish inference quoted was published the market was making a line which proved, as the analyst correctly surmised, to be one of accumulation. The forecast was soon verified, and on August 21st *The Wall Street Journal* again discussed the market from the point of view of the averages. There was a greatly active market at that time, and it remarked how absurd it was to suppose that within two hours of trading on a Saturday one single interest could possibly manipulate one million six hundred thousand shares. This is a useful confirmation, coming out of the past of fifteen years ago, of what we have already seen for ourselves in demonstrating the relative unimportance of manipulation. In that discussion *The Wall Street Journal* went on to say:

> *"We can only suppose that the long decline between January 22d and July 2d represented a somewhat extended bear swing in a bull market."*

### Average Deductions Uniformly Correct

Remember that this correct inference was drawn at the time, and not after the event. I could easily go back and show how trustworthy these deductions have been over the twenty-odd years since Dow formulated his theory. It would be absurd to say that it was possible to call the exact turn in the major swings, much less anticipate the unexpected. But these studies in the price movement did what was much more useful from the point of view of those using the barometer from day to day: they were continually right when they said of a major movement that it was still in progress, even when a deceptive secondary movement had made superficial observers bearish in a bull market or bullish in a bear market.

There is a story, probably apocryphal, of James R. Keene saying that he would be well content to be

<!-- PAGE:117 -->

right 51 per cent of the time. I don't believe he ever said it. He must have found a much larger percentage necessary. The balance in his favor would not have paid operating costs, to say nothing of keeping a racing stable. But the deductions from the evidence of the price movement have been right, as the printed record proves, much the most of the time. After searching both the record and my conscience I can find no instance of a radical misinterpretation of the meaning of the barometer. The studies based upon its use were uniformly able to anticipate what the public was thinking about business before the public knew its own thoughts. The errors, where any occurred, were mainly due to the almost impossibility of forecasting the secondary movement of the market. This is really much more difficult than the interpreting of the major swing, just as it is easier for the Weather Bureau to forecast weather for a large area than it is to say whether it will rain in New York to-morrow morning.

### Initiation of a Bear Market

Near the top of this bull market *The Wall Street Journal* uttered a caution. It pointed out, on December 15, 1906, that there had been a *"line,"* especially in the twenty active railroad stocks, and that the possibility of a break through the lower level of the line should be considered as indicating the warning of a coming decline. This forecast did not commit itself to anything more than a possible bear swing in what had been for three years a primary bull market.

<!-- PAGE:118 -->

It was altogether too early to call the actual turn. In the beginning of 1907, large railroad earnings, materialized in the case of the spectacular dividend policy announced for the Harriman roads during 1906, were set off against high money rates, which, as we soon saw, were already beginning to warn the market, and business generally, of that severe crisis brought about later in the year; when the reserve of the old national banking system virtually went to pieces, call money became practically unobtainable at unparalleled rates, and the banks resorted to clearing-house certificates for the first time since the panic of 1893.

In the month of January, 1907, the active professional traders were selling stocks. Political meddling was beginning to scare investors, and before the year was out there was what amounted to a strike of capital. The decline in stocks had already started, and it is interesting to trace the elapsed time taken to decide that a major bear swing had replaced the preceding long-continued bull movement. A decline of prices in January is always disturbing to the stock market because that is a time of year when, other things being equal, the tendency is oftenest bullish. It is a time for cheap money, and the reinvestment of the profits of the preceding year. It is a time, moreover, when it is peculiarly unpopular to talk bearish in Wall Street. The prophet of evil, as I have already frequently demonstrated, is totally without honor in that part of the country.

### Boom Times and a Falling Barometer

In the long bull market there had been an unusually large emission of new issues, and it was then that the late J. Pierpont Morgan originated the phrase about undigested securities. America loves a good phrase, and that one caught hold. Industrial earnings, and especially those of the United States Steel Corporation, continued remarkably good. The railroads were making an excellent showing of both gross and net. But the sharp decline in the averages in January made our commentator most cautious, particularly in declining to predict a rally, much less assume that nothing more than a secondary reaction had been established. It was altogether too soon to be positive about the major movement. In fact the severe decline kept everybody guessing; but it appears from the records that early in March the existence of a primary bear market was conceded and *The Wall Street Journal*, very like any other newspaper, was doing all it could to cheer up the dispirited investor with a statement of the genuinely satisfactory features.

<!-- PAGE:119 -->

### Some Bearish Influences

But the market was looking at all the facts, and the far-reaching consequences of some of them were reflected in stocks. These bear arguments were given on March 15, 1907, and they read curiously now. They were:

1. Excessive prosperity.
2. High cost of living, due largely to the effect upon prices of a great gold production.
3. Readjustment of values to the higher rates of interest.
4. Speculation in land absorbing liquid capital that might otherwise be available for commercial enterprises.
5. Roosevelt and his policy of government regulation of the corporations.
6. Anti-railroad agitation in the various states.
7. Progress of socialistic sentiment and demagogic attacks on wealth.
8. Harriman investigation of exposure of bad practices in high finance.
9. War between big financial interests.
10. Over-production of securities.
11. Effect of San Francisco earthquake.

There were other causes quoted of only momentary consequence, in which possible bear manipulation was put last. It has been said already that there never was a bear market which was not justified by the facts subsequently disclosed. Are we not entitled to say that some of these influences became permanent, to an extent which even the stock market could not possibly foresee, conceding that it is, at least theoretically, of longer and larger vision than any of us? As after events proved, the over-regulation of the railroads alone was sufficient to justify investors in protecting themselves, whatever the consequences to the stock market might be.

<!-- PAGE:120 -->

### An Abnormal Money Market

In retrospect, the year 1907 seems to me the most interesting I have ever spent in Wall Street, and perhaps the most instructive. It is full of lessons and warnings. I wish that the scope of these discussions permitted a treatment of it in greater detail. There is no better story of it for the student than that of Alexander Dana Noyes in his *Forty Years of American Finance*. He was financial editor of the *Evening Post* at that time. I remember that at the beginning of the year, when industry was booming, when railroad gross and net earnings were making about the best showing on record, when the stock market was only receding a little from three years of advance, where prices, moreover, at least on paper, had not overtaken values, he was struck, as I was, by the abnormal money market. That is the time of year when money should be cheap, and it was almost painfully tight in February. The stock market foresaw the meaning of it long before we did, as the major bear swing of 1907 showed.

### No Bigger Than a Man's Hand

There was a broker of that time, since dead, whose face comes up before me as I write. He talked in terms of Wall Street, but his illustrations were vivid and his intelligence was well above the average. He was an educated lover of music, and much more reverent than he sounded. He was speaking to me one day about a performance of Mendelssohn's *"Elijah"* that he had once heard, with the title role taken by the greatest oratorio artist of all time, the late Charles Santley. The dramatic story had appealed to my friend. He talked of the priests of Baal being *"cornered bears of the stock Elijah controlled,"* and of *"their frantic efforts to cover their shorts."* He was

<!-- PAGE:121 -->

impressed with the way Elijah had, as he expressed it, *"joshed"* them in their extremity, suggesting that their god was taking a nap or was, peradventure, *"on a journey."* There was a phrase that had stuck in his mind which describes the condition at the beginning of 1907: *"Behold, there ariseth a little cloud out of the sea, like a man's hand."* The *"great rain"* followed in the autumn of the year 1907.

Not only was the collapse in business tremendous. It developed with a suddenness which simply took our breath away. At the close of the year I was traveling on the Pennsylvania railroad with Mr. Samuel Rea, now the president and then the first vice-president of the road. The Pennsylvania carries—and carried then—a tenth of the railroad freight of the United States. Mr. Rea said that at a time when they were only a month away from the peak of their load, apparently able to count upon the crop movement and the industrial traffic, both ways, of the Pittsburgh district, business seemed to shut up like a jackknife, almost overnight. We could see the empty cars in the stub-end sidings and yards all along the system between Philadelphia and Pittsburgh, at a time of year when railroads are normally using everything but the cripples in the repair shops.

### The Deadly Hand of Politics

There had been nothing like it since the collapse of 1893, when that Congressional monument of economic ignorance and sectional folly, the Sherman Silver Purchase Act, reaped its grisly harvest in the most demoralizing and far-reaching panic we ever saw.

<!-- PAGE:122 -->

That seemed to have been a lesson to our lawgivers. The lean years which followed that panic, with the almost universal bankruptcy of the railroads and those who served them, finally put the fear of the Lord into the politicians. For ten prosperous years previous to 1907 they had quit kicking the business dog around. But in that year they had fully resumed that highly expensive sport, and before the end of the year there was a strike of capital. Every man who had anything to lose was terrified. Every man who knew anything foresaw what bureaucratic meddling and unintelligent regulation would do for the business of the country.

It seems to me, if I am not wandering from my text, that this is largely what is the matter with the country now, war or no war, and that the stock market for two years past has been foreseeing some of the further consequences of fool politics. It may also be that in the impending improvement in business, already foreshadowed by the averages and the underlying investment demand shown in bonds, the market foresees some return to sanity, even if the indications in Congress at present are anything but encouraging.