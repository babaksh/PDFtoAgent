# WATER IN THE BAROMETER

# WATER IN THE BAROMETER

<!-- PAGE:95 -->

## “WATER” IN THE BAROMETER

EVERY effort has been made to simplify these discussions. They have been offered with the most stringent exclusion of extraneous matter. In serial form they aroused much criticism and comment, some of it illuminating and helpful. But old preconceptions and prejudices still survive. One critic, whose scanty knowledge of the subject appears to have been derived from the reading of perhaps two of these articles, says:

> “How can we trust your barometer if we cannot trust the stocks which the Stock Exchange deals in? You have said nothing about overcapitalization. What about water?”

---

### Watered Labor

Water is more unpopular than ever in the United States just now. But the financial center of the United States, with the business of the country in view, is far more concerned about watered labor than watered capital. There is only one way to squeeze the water out of labor—the factory or apartment house which cost a million dollars to build and represents only $500,000 of real value. That way is by bankruptcy. Of the apartment houses that were built in New York, during a period of high wages and “ca’ canny” which set in long before the war, very few have not passed through a stage of financial reorganization, due to watered labor in construction, long before rents began to advance.

The stock market has a short and simple method of dealing with water in stocks. It exists for the purpose of squeezing that water out. The process does not involve a receivership.

The very word "water" begs the question. You may call the capitalization of an industrial flotation "water" because you do not see the potential values of a great creative organization. But with justice, and better knowledge, the late J. Pierpont Morgan might have called that capitalization **intelligently anticipated growth**. Whatever it may be—and I shall give an example from the most striking instance, the capitalization of the United States Steel Corporation—the stock market is forever adjusting prices to values. The water soon evaporates.

---
<!-- PAGE:96 -->

### Squeezing Out the Water

To recap: we are studying the stock market barometer, having established the fact of its known and orderly movements—the long primary swing, the secondary reaction or rally, and the daily fluctuation; and to do this we are taking the averages of two groups of stocks—twenty active industrials and twenty active railroads. All adjustments of the prices of these stocks individually must primarily be based upon values. For all practical purposes the Stock Exchange is an open market, and the business of such a market is to adjust conflicting estimates to a common basis, which is expressed in the price.

By manipulation, James R. Keene advanced the price of Amalgamated Copper twenty years ago to one hundred and thirty, and obviously the group of financiers which offered the stock at par originally, without success, assumed one hundred as value for it. The stock market does not make its adjustments in a day. But, over a period which seems brief in retrospect, it knocked one hundred points off the highest figure Amalgamated Copper attained in a general bull market.

This is the business of the stock market. It has to consider both basic values and prospects. At the close of a major downward movement, a primary bear market, prices will have passed below the line of values. The causes of the liquidation will have been so serious that people have been compelled to realize their holdings at less than their normal worth; less, indeed, than their book value—the worth of the company's assets, that is, irrespective of productive capacity and good will. The prices of the standard stocks will be injuriously affected by the prices of "cats and dogs" dealt in on the Curb market, many of them of such a character that any bank would refuse them as collateral in its loans. When the banks are compelled to call loans made on Stock Exchange securities, the stocks of tested worth, of properties competently and reputably managed, will be the first to suffer because it is those stocks which are pledged in bank loans. The constantly recruited Curb group is highly speculative, but trading there is always limited, and indeed safeguarded, by the large margin which is necessary to carry Curb stocks.

---
<!-- PAGE:97 -->

### Stock Profits and Income Tax

Conversely, a bull market starts with stocks much below their real value, certain to be helped in anticipation by the general improvement in the country's business which the stock market foresees and discounts. In the long advance values will be gradually overtaken, and toward the close of the advance an uninformed public, incapable of recognizing the bargains which were offering when the movement started, is buying on prospects only. Experienced traders in Wall Street say that when the elevator boy and the shoeblack are asking for bull tips on the market it is time to sell and go fishing.

When I sailed for Europe early in October, 1919, to report on financial conditions in Britain and Germany, the market was in the last sanguine stage of a long bull movement. The inflation bull argument then was most curious. It was that the people who had large profits would not sell, and could not sell, because in turning those paper profits into cash they would show such a large earning of income for the year that the tax-gatherer would take a prohibitive share of the profits. We analyzed this fallacy in the smoking saloon of the *Mauretania*, and at least some of the business men on board concluded to divide up with Uncle Sam. The argument was preposterous in itself, because it pictured the most vulnerable kind of bull account that it would be possible to conceive. It was glaringly up to be shot at, and the poorest marksman could fill it full of holes. Rough seas stove in five of the *Mauretania*'s lifeboats, and put the wireless apparatus out of commission for the last three days of that voyage. When we arrived at Cherbourg we learned that the stock market itself had begun to free the bulls of stocks from the embarrassment of paying excessive income tax. They had not much to worry about in that respect by the end of the year, for the paper profits had been rapidly extinguished.

---
<!-- PAGE:98 -->

### Well-Distributed Holdings

There is no way of permanently holding up artificial prices created by an overbought market. One great protection to the public is in widely distributed stock ownership. When a single group in Wall Street owns practically all of the stock in a property like Stutz Motor, that group can call the market price anything it chooses. It will not be the "market" price because there will be no real market. Abraham Lincoln pointed out long ago that you could not talk five legs onto a dog by renaming its tail.

All the stocks in the average have shared in the wide and healthy distribution of securities. The average holding of Pennsylvania (which has the greatest capitalization of any of the railroads in our average) or of the five and a half million shares of United States Steel common is nothing near one hundred shares for each holder. So far as the public is concerned, there is, indeed, safety in numbers.

---
<!-- PAGE:100 -->

### “Valuation” and Market Prices

To the inquirer quoted at the beginning of this article, who asks, “What about water?” we may answer, well, what about it? He cannot show us any water in the averages. We may go further and tell him that he cannot show us any water, at prices and not at the nominal par, in the whole Stock Exchange list.

For the railroads, no valuation which could be instituted by Congress and carried out by a committee of the Interstate Commerce Commission could begin to compare with the market prices of the securities themselves, taken in a normal month of a normal year, with the prices not inflated on overestimated prospects or deflated by forced liquidation, brought about largely to protect unsalable securities and warehouse receipts not associated with the railroads or the standard industrial companies in any way.

Every scrap of intelligence and knowledge available, uninfluenced in any real degree by manipulation, has been brought to bear in the adjustment of the stock market prices. Reproduction value, real estate value, franchises, right of way, good will—everything else—have been brought into the free-market estimate in a way which no valuation committee appointed by Congress could ever attain. The Interstate Commerce Commission’s valuation of a railroad has merely historical worth—if it has any. As a true estimate of the property, if the method of fixing it were commonly just, it is out of date the moment it is printed, or, indeed, months before it is printed. But the Stock Exchange price records the value from day to day, from month to month, from year to year, from bull market to bear market, from one of Jevons's cycle dates to another; and the bankers of America and any other civilized country accept that valuation and advance real money on it, without reference to the arbitrary estimate of the Interstate Commerce Commission.

---
<!-- PAGE:101 -->

### The Fetish of Watered Stock

It is astonishing to what depths of foolishness the fetish of watered stock has carried this country. The capitalization in stocks and bonds of its railroads, alleged to represent water, is not one-fifth that of the railroads of the British Islands, mile for mile. It is less per mile than that of any European country or of any government or privately owned railroad in Britain's self-governing colonies. I am not afraid to go on record with the statement that the American railroads are uneconomically undercapitalized, on their real value.

The charge of watered stock made against the listed industrial corporations is equally absurd. The stock market had far more than squeezed out the water in that capitalization at the Stock Exchange prices current in 1921. It had squeezed blood.

As this is written, United States Steel common is selling under $80 a share. But stringent analysis of an industrial corporation offering the most exhaustive figures of any like company in the world gives a book value to the common stock of $261 a share. In the twenty years of its history it has put upwards of a billion dollars into the property in new construction, and so little is this watered in the capital that this new investment out of earnings is represented in property account by only $275,000,000. The quick assets, largely cash, are over $600,000,000 alone, something like $120 a share with the whole concern scrapped. Where is the water? A common stock capital of $550,000,000 looks large, but it is only relatively large. Was not Morgan right if he called this **intelligently anticipated growth**? If his spirit could revisit the pale glimpses of the moon, surely he would be astonished at his own moderation.

And yet the distribution of the United States Steel common and preferred stocks, made in the major swing of a great bull market, was brought about largely by the most stupendous manipulation the market ever saw, under the direction of the late James R. Keene. And what was the end of that manipulation? It was to sell the common stock at fifty and the preferred stock at par. If the people who bought at those prices put the stock away after paying for it, would they have anything to regret even at the low market prices of August, 1921, attained after a major bear swing of unusually long duration?

---
<!-- PAGE:102 -->

### Buying on Values

Probably some one will charge me with writing a bull argument about Steel common, because I set this simple illustration before the public. There again we have the inveterate prejudice against Wall Street.

---
<!-- PAGE:104 -->

*Figure No. 8 — A COMPARISON OF THE MOST ACTIVE*

---
<!-- PAGE:105 -->

*Figure CK—UNITED STATES STEEL COMMON*

---
<!-- PAGE:107 -->

The facts I have stated are of record, accessible to anybody, perfectly well known to some of the people at least who were selling Steel common in 1921. But they were selling the stock because they needed the money, at a time when most of us needed money. When the Rothschild of the days of Waterloo, a week before the result of that battle was known, was buying British consols at fifty-four, a friend asked him how he could buy with such confidence on an outlook so uncertain. He said that if the outlook were certain consols would not be selling at fifty-four. He knew that with that uncertainty they must necessarily be selling below their value. Everybody needed money at the same time, and he was one of the few people who had any.

I suppose no one will ever know how Russell Sage did it, but he could lay his hands upon more real money in a panic than anybody in Wall Street. He believed in quick and liquid assets, short-time paper maturing all the time, call loans and deposits—everything which could be turned into cash, not to hoard but to buy freely when people who had lost sight of values were selling.

---
<!-- PAGE:108 -->

### A Story of Russell Sage

All sorts of stories are told of Russell Sage and his extraordinary frugality. That is not exactly the word I would use; nor would I call it miserliness, for he was anything but a miser. I remember the last time I ever saw him, when I was a young reporter, or at least a younger reporter. I was trying to find out something about a railroad property in which he was dominant with another financier of nation-wide notoriety, or reputation. Lying is a word which is seldom used (or needed) in Wall Street, and it would be better to say that the other financier had given me information calculated to let me deceive myself if I was not exceptionally wide-awake.

With the idea, therefore, of seeing if Mr. Sage's terminological inexactitude would differ from his comrade's, with enough significance to enable me to deduce something from the points upon which the two fairy tales did not agree, I went over to see Sage, who was always accessible to the newspaper men.

He greeted me in the most friendly way, as indeed he did anybody whose visit had nothing to do with money. I put my question and he rapidly changed the subject. He said: "Do you know anything about suspenders?" I was exasperated, but I replied modestly that I did not know any more about them than any other wearer. "What do you think of these?" said Uncle Russell, handing me over a pair certainly inferior to those worn by reporters, who are not, or certainly were not at that time, given to undue extravagance in such an article of attire. "What about them?" I asked. "Well, what do you think of them?" said Sage; "I gave thirty-five cents for those." Perhaps I was a little vindictive, having failed to secure even the poor information I had come to seek. I said: "You were robbed. You can get better in Hester Street for a quarter." Sage looked at me doubtfully. "I don't believe it," he said. But he was really troubled. It was not the difference of ten cents, and I would not have sworn to the Hester Street quotation. It was the principle of the thing. His judgment of values had been impugned.

---
<!-- PAGE:109 -->

### Values and Averages

And there you have it. The things in which Russell Sage dealt had value. He had to know those values, and it was by knowing them when they had ceased to be apparent to other people that he died worth more than $70,000,000.

The stock market barometer shows present and prospective values. It is necessary in reading it to judge whether a long movement has carried the average prices below that line or above it. In looking back over the various analyses of the stock market as a guide to general business, published in *The Wall Street Journal* since Charles H. Dow died, at the end of 1902, I find a typical instance of the application of the averages which may seem remarkable to the reader, although I regard it as the merest common sense. There is no one so unpopular as the man who is always telling you that he "told you so," but the illustration is impersonal.

---
<!-- PAGE:110 -->

### A Cautious but Correct Forecast

No severer test could be taken than the interpretation of the averages in what might almost be called the transition period between a bear and a bull market. The bear market which developed from September, 1902, saw its low points in the September of the following year, and it is weeks or even months afterwards before the change in the major swing can be definitely asserted.

But on December 5, 1903, *The Wall Street Journal*, after a review of the fundamentally sound tendency of business in then recent years, said:

> “Considering the extraordinary advance in wealth of the United States during that period, considering that railroad mileage has not increased in anything like the ratio of increase in surplus earnings, and finally considering that the ratio of increase in surplus earnings available for dividends has been at all times in excess of the rise in market prices and at the present time shows a larger percentage on market price than at any time since the former boom started, the question may well be asked whether the decline in stocks has not culminated. There is at least some evidence in favor of an affirmative answer to that question.”

---
<!-- PAGE:111 -->

### A Bull Market Confirmed

It would be easy to say that such an opinion could have been given without the help of the averages, but it was given with the price movement clearly in view and at a time when there was an easy possibility that the main bear movement might be resumed. It correctly foresaw the bull market, allowing for the caution necessary in such a prediction and, indeed, for the fact that analysis of the market movement was still in its infancy.

The bull market then foreseen ran throughout 1904, and can be said to have terminated only in January, 1907. But some nine months after this editorial analysis of the business situation, judged by the averages, was written, *The Wall Street Journal* tackled the almost equally difficult question of whether the bull market then getting into full swing might be expected to continue. Remember that the advance had been running with moderate but increasing strength for twelve months, which would allow for at least some discounting in values.

On September 17, 1904, *The Wall Street Journal* said:

> “There is apparently nothing in sight to lead one to believe that railroad values are not on the whole maintaining their high position, and that as time goes on this will bring a further appreciation of prices. Much will depend on the coming winter, which will at all events bring a clear indication of the general trend of values. In the long run values make prices. It is safe to say that if present values are maintained, present prices are not on an average high enough.
>
> “It must further be remembered that the continued increase in the production of gold is a most powerful factor, which cannot fail to be felt in the future as making for higher prices of securities other than those of fixed yield.”

---
<!-- PAGE:112 -->

### A Vindication of the Theory

Note carefully that last line. We have satisfied ourselves that bonds held for fixed income decline when the cost of living rises, and more gold means that the gold dollar will buy less because gold is the world's accepted standard of value. But it stimulates speculation, and the stock market had seen this in 1904, when this was written, even if the houses with bonds to sell thought it rather "unclubby" to say anything which would disturb their business.

Of course, these quotations are far from dogmatic, because Dow's Theory was only beginning to be understood. We shall see as the years went on that the theory allowed for much more explicit statements of the market's condition and its prospects. It is sufficient to record how soon the stock market barometer proved its usefulness when Dow's sound method of reading it had been set forth.