# THE UNPUNCTURED CYCLE

# THE UNPUNCTURED CYCLE

<!-- PAGE:127 -->

## THE UNPUNCTURED CYCLE

WE have been considering in some necessary detail the record of the stock market barometer, and we shall have some further historical study to make in that interesting and little understood period between the bear market which culminated in 1910 and the outbreak of the World War. We have hitherto paid small attention to the tempting "cycle theory" of human affairs, and especially of business affairs. In an early discussion I set forth the panic dates for the eighteenth and nineteenth centuries as recorded by Jevons, together with Dow's brief account of our panics of last century. But it was essential to establish something of an irregular stock market cycle of our own, not necessarily, and hardly more than incidentally, involving a panic—for, indeed, the panic has more than once proved to be merely an interruption in the main movement of the barometer.

### Our Own Modest Cycle

We can see that we have established some sort of irregular rotation through Dow's theory of the stock market price movement—its major swing up or down; its secondary reaction or rally, as the case may be; and the daily fluctuation in prices on the Stock Exchange as reflected in the records of the averages.

<!-- PAGE:128 -->

But the theory of the longer rhythmical cycle will not down. It seems to be almost an obsession with many of my readers and critics. None of them seems to have analyzed his belief in it in any searching way. The general impression is that there is “something in” the idea; that if it is not proved true it should be true; that the world’s panic dates themselves indicate a striking degree of periodicity; that, given such periodicity in the past, we may anticipate something like it in the future; that men will always be as stupid in the conduct of their own business as they seem to have been when judged by the records of history.

### Basis of the Cycle Theory

Probably this unwillingness to analyze the panic theory arises from the fact that in the eighteenth century, according to Jevons, there were exactly ten noteworthy crises at an average of ten years apart. I am content to waive the one Jevons omitted—that of 1715, when the Scots invaded England—because there were not enough spots on the sun in that year to establish his daring theory of the relation between the two phenomena. We may note that Jevons gave 1793 and 1804–5 as crisis years, while it is of record that our own first panic of the nineteenth century was consequent upon the British capture of the city of Washington in 1814—an event which no cycle could have predicted, unless we are to assume that the cycle theory could have predicted the late war. But, counting 1814, and what Dow calls the “near approach to

<!-- PAGE:129 -->

a crisis” in 1819, there were ten American crises in the nineteenth century.

Let us see how the cyclist—if that is the correct word—approaches the subject. The ten-year interval between the British crisis of 1804–5 and our own of 1814 might stimulate him at first. And the really serious and nation wide crises of 1837 and 1857 would give him a great deal of confidence. He would recall the ten-year intervals of Jevons, and that we had up to 1837 recorded four crises of sorts, in four decades of the new century. We did not greatly share the panic in Europe in 1847, although it was sufficiently serious there to impress itself upon American memory. But when the cycle enthusiast found a real panic in 1857, he cried “Aha! We have now discovered the secret. There is a twenty-year cycle, with a big crisis at each end, and a little crisis in the middle. We may now confidently set about humoring the facts to fit this beautiful theory.”

### Misfitting Dates

On that showing there should have been another first-class panic, with nation wide consequences, in 1877. But apparently the machinery slipped a cog, for the panic came in 1873. From the devastating folly of overtrading on a greenback basis, it would have come in 1872 but for the accident that we had in that year an enormous wheat crop, which brought splendid prices in the world market because of the almost total crop failure in Russia. Here, then, was a contraction

<!-- PAGE:130 -->

of the interval between great crises. The twenty-year theory was deflated to sixteen, and it is hard to derive much consolation from the fact that the Overend-Gurney failure in London in 1866 had marked a date conveniently between the two great crises. The London panic of 1866 was accompanied by a heavy fall in prices in our Stock Exchange. In April of that year there was a corner in Michigan Southern and rampant speculation. The truthful but cautious Dow says that the relapse from this "was rather more than normal."

But the three panic years 1873, 1884 and 1893 did something to revive the confidence of the ten and twenty-year theorists. The first and the last were crises of almost world wide magnitude and equally far-reaching consequences. Our cyclists said: "That slip-up in the reduction to sixteen years for the interval between crises occurring in 1857 and 1873 was merely fortuitous, or at least we shall be able to explain it satisfactorily when we have deduced only a little more about the laws which govern these things." And the twenty-year cyclists prophesied, saying: "There are twenty years between 1873 and 1893. Our barometer is getting into shape. There will be a minor crisis round about 1903 and a major panic in 1913, or not later than 1914."

### Lost in Transit

What is the use of the theory, indeed, unless it can be made the basis for at least as much prophecy as that? But between 1893 and 1907 we have an interval

<!-- PAGE:131 -->

of fourteen years. Has the twenty-year period contracted, or the ten-year period expanded, to fourteen years? Is there any dependable periodicity about the thing? We see that there was not the slightest reason for any crisis in the years presumably anticipated by the cycle theorist—1903 or 1913. Indeed, the volume of the world's speculative business was not large enough to make a crisis in those years. It is reasonably certain that a smash cannot be brought about unless an edifice of speculation has been constructed sufficiently high to make a noise when it topples over.

What is the value of all this as a forecast for business? I cannot see that it has any. The theory has to make so many concessions—takes so much humoring, in fact—that it ceases to have more than a value for record. We see that the sweeping conclusions based upon the cycle assumption had to be changed again and again. Does much that is really useful remain? I am anything but a sceptic; but this whole method of playing the cycles looks to me absurdly like cheating yourself at solitaire. I can understand stringent rules, arbitrary rules, unreasonable rules, in any game. But my mind fails to grasp a game where you change the rules as you go along.

### Are They Equal?

And what becomes of that imposing premise that **"action and reaction are equal?"** Are they? There is little real evidence to prove the assumption, in recorded human affairs. Of course the holders of that

<!-- PAGE:132 -->

theory may respond, "Well, if they are not equal they ought to be." I cannot even see why they ought to be. Certainly, holding a Christian faith in the perfectibility of human nature, I do not see why crises should not be eliminated altogether. It is easy to see how the periods between them at least seem to have grown longer. The interval between 1893 and 1907 was fourteen years, and 1920 was no panic year.

Unless we are to force the construction of what constitutes a panic until we actually distort it, we can hardly regard the deflation liquidation of 1920 as a typical crisis. It could not begin to compare with the damaging effects of 1893, 1873, 1857, or 1837. It had none of the earmarks of a panic year. I dare say I shall believe, in five years' time, that the drastic contraction and deflation were about the best thing that could have happened to us. They should certainly discount all sorts of trouble in the future.

### A Business Pathology Needed

There must be some sort of scientific pathology of business affairs, or perhaps it might be better to call morbid psychology. I have suggested in another chapter how utterly inadequate the records of history are in the vital matter of commerce and all that contributes to it. But we are beginning to acquire a scientific knowledge of the symptoms of the diseases which afflict it. In this respect we have probably made more advance in the past quarter of a century than in all the years since Carthage sold the purple weaves

<!-- PAGE:133 -->

of Tyre to Rome. We may well hope that we are developing a scientific method of diagnosing the symptoms of business disease. There was no such method in 1893, because there were no such records as we have today.

But why need we assume that once every ten years or twenty years, or any other period, the most intelligent part of mankind loses its head and forgets all the lessons of the past? One thing is certain about a panic. It could never occur if it were foreseen. Are we not working toward a sum of knowledge and an accuracy of analysis which will, in a sufficiently safe measure, foresee all but the non-insurable risks—“the act of God and the King’s enemies?”

### The Federal Reserve Safeguard

I can see a great deal too much politics, and many defects, in the Federal Reserve banking system. But under that system it is hard to imagine a set of conditions which would force the country to resort once more to clearing-house certificates, as it did in 1907 and 1893. It would pass the wit of man to devise a perfect banking system; and what would seem perfect to one would appear utterly inadequate to another. But the progress from the old national banking system to the Federal Reserve system represents the most tremendous stride in business practice which the country has ever seen. Is not the Reserve system itself an entirely new factor for the cycle theorist to consider?

It must not be assumed for a moment that possible crises in the future may be dismissed from considera-

<!-- PAGE:134 -->

tion. On the contrary, they are certain to come. But may we not hope that, with fuller knowledge, they will be at least in part anticipated and, in their most dangerous effects, radically mitigated?

### Teaching the Teacher

If these studies have shown the man who takes an intelligent, even if not a financial interest in Wall Street, that knowledge will protect him there as it will anywhere else, the educational design has been largely accomplished. Certainly one of the desirable educative services of this series has been to show the writer how much there was about the stock market movement which he had never before formulated to himself in any useful fashion. The way to get at the essence of such a proposition is pragmatic—to live with it from day to day. The stock market problem, considered in the light of Dow's Theory, is essentially simple. It can be set forth in a thoroughly useful way, provided only that the teacher is neither a crank nor a quack, a gambler or a crook. Harvard University is performing a greatly needed service in putting out tabulations and index charts on general business conditions which are above suspicion. The compilers have not tied themselves down to dangerous assumptions. They are not lashed to an assumed "medial line" of national wealth with a constant upward tendency at the same rate of speed in good times or bad, which loses its certainty in face of the grim facts of war, and hysterically changes its course.

<!-- PAGE:135 -->

### Does the Physical Law Apply?

Such a system as that of Harvard University is not committed to the proposition that in human affairs action and reaction are equal. That is a fine-sounding phrase, but it should require incalculably more evidence than has yet been adduced to persuade us to adapt a law of physics to something so unstable and elusive as human nature itself. Among the many things which our stock market averages prove, one stands out clearly. It is that so far as the price movement is concerned action and reaction are not equal. We do not have an instance of a bull market offset in the extent of its advance by an exactly corresponding decline in a bear market. And if this is true, as it demonstrably is, about the extent of the price movement in any given major swing, it is still more true about the time consumed. We have seen that bull markets are, as a rule, of materially longer duration than bear markets. There is no automatically balancing equation there. I do not believe there is such an equation in human affairs anywhere. Certainly there is none recorded in history. I am compelled to rely upon others for tabular figure compilations of all kinds, and do not profess to have used my modest razor for the cutting of any of these tables of stone. But in all the study of figures prepared for use in my profession, I have been unable to find a balance of action and reaction.

<!-- PAGE:136 -->

### Extent and Duration Incalculable

Certainly the stock market barometer shows nothing of the kind. There is no approximation to the regularity of the pendulum, either in the arc of the swing or its velocity. We see a bear market declining forty points, a bull market advancing fifty points over more than twice the period, a bear market declining nearly sixty points, a bull market recovering forty-five points, a bear market declining less than thirty points, a major swing upward of not much more than twenty points, a bull market advancing nearly sixty points in the industrials with a simultaneous advance of less than thirty in the railroads, and a different period for each successive swing. This, in approximate figures, is the record for a quarter of a century. There is, obviously, a rough periodicity about such movements. But if we begin to twist them into some mathematically calculable, regularly recurring "cycle," the next main movement, up or down, will leave us all adrift, with nothing to hold on to but an empty theory and an empty purse.

### Sham Mysteries

I do not want to dogmatize about this, although I am trying to make what is essentially a scientifically treated subject popularly interesting, if, indeed, sermons are ever popular. One trouble of all teaching, and a moral danger to every teacher, is that the authority necessarily accorded to the instructor leads him to make something of a mystery of his trade. His

<!-- PAGE:137 -->

unconscious desire to eliminate embarrassing competition leads him to exaggeration of the difficulties to be encountered in acquiring a sound knowledge of the subject. In a brief time, as human affairs run, there will be a sort of cult amplifying and complicating an otherwise simple thesis. Every religion breeds a priesthood, where sacerdotal succession becomes more important, or at least much more jealously defended, than mere salvation. Both in the English common law and the canon law handicrafts were sometimes referred to as mysteries. The plumber who comes into your house likes you to believe that his elaborate preparations, and the general mess he makes, are evidence of the difficulty of the task he has accomplished—a difficulty you as a layman are entirely unable to measure—and a sufficient pretext for the extortionate bill he renders.

### Tipsters and Insiders

I have known some likable people connected with what are frankly stock-tipping agencies. There is a market for what they supply, and they are necessarily excellent judges of human nature. They are never bearish on the stock market. They are often successful and prosperous in a bull market, and I suppose that the savings of the fat years support them in the lean ones. They tell the unscientific speculator what he wants to know, but not what he needs to know. Sometimes the guessing is good, and always there is the suggestion that there is a mystery about reading the stock

<!-- PAGE:138 -->

market movement. If this is true of what they teach on the general market, it is still more true about individual stocks. With them "insiders" are always buying. In my experience I have known many insiders, and for every purpose of the small speculator they were far oftener wrong than right.

As a matter of fact these so-called insiders, the real men who conduct the real business of a corporation, are too busy to spend their time over the stock ticker. They are far too limited, too restricted to their particular trade, to be good judges of the turn of the market. They are normally bullish on their own property, in the respect that they believe it to be a growing concern with great possibilities. But of the fluctuations of business which will affect their stock, together with the rest in the same group or all the other railroad and industrial stocks in the same market, their view is singularly limited. It is not mere cynicism but truth to say that sufficient inside information can ruin anybody in Wall Street.

That is not only true, but it is an excellent thing that it is true. Of course the executive officers of large corporations should have a sound general knowledge of conditions outside their own sphere. They should be well instructed. They might read this book with advantage, if it only taught them to take a more objective view. But even with the basis of a general education, such as is required in a good university of the man who intends afterwards to specialize in law or surgery, their very occupation unduly affects their sense of proportion.

<!-- PAGE:139 -->

### Our Trustworthy Guide

This is why the stock market barometer is so valuable. It makes little of cycles or systems, interesting and even well-grounded inferences or common fads. It uses them all so far as they are useful, together with every other scrap of information it is possible to collect. The market movement reflects all the real knowledge available, and every day's trading sifts the wheat from the chaff. If the resultant showing of grain is poor, the market reflects the estimate of its value in lower prices. If the winnowing is good, prices advance long before the most industrious and up-to-date student of general business conditions can bushel up the residue and set it forth in his pictorial chart. Few of us can be Keplers or Newtons. But it is possible to formulate working rules which will help and protect any man in that forecast of the future which he must necessarily make every day of his life. This is what the stock market barometer does. It makes no false claims. It admits highly human and obvious limitations. But such as it is, it can honestly claim that it has a quality of forecast which no other business record yet devised has even closely approached.