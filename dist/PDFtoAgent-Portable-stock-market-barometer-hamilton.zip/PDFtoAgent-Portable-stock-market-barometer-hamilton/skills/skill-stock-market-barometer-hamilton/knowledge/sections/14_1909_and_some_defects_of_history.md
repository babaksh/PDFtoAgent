# 1909, AND SOME DEFECTS OF HISTORY

# 1909, AND SOME DEFECTS OF HISTORY

<!-- PAGE:166 -->

## 1909, AND SOME DEFECTS OF HISTORY

SINCE we have set the understanding of the stock market barometer as our goal, we are not to be discouraged by the real and fancied obstacles still remaining. We can always hearten ourselves by looking back and seeing how much we have already overcome. Perhaps the reward is in the race we run, not in the prize. This is not to say that the mere reading of this series of studies is any achievement if the reader has not, thereby, added to his mental bank balance. But if we look back we can see that we have not only established Dow's theory of the price movement, but constructed or deduced a workable barometer from it—a barometer with the invaluable quality of long distance forecast.

We should know our theory by heart. It is that the stock market has three movements—its broad swing upward or downward, extending from a year to three years; its secondary reactions or rallies, as the case may be, lasting from a few days to many weeks; and the daily fluctuation. These movements are simultaneous, much as the advancing tide shows wave recessions, although each succeeding roller comes further up the beach. Perhaps it might be permissible to say that the secondary movement suspends for a time the great primary swing, although a natural law is still in force even

<!-- PAGE:167 -->

when we counteract it. My pen would fall from my fingers to the ground or the desk, by the attraction of gravitation, and that law continues operative, if not active. In a like way of putting it, the secondary movement can be regarded as simultaneous with the major swing, which still continues to govern.

### That Unbalanced Equation

It has been necessary to refer in previous articles to business charts and records, and I would be the last to seek a quarrel with the compilers of such useful data. All I contend is that these charts and records are hardly, in a useful sense, barometers. They are hazy about the future, even where they make the assumption that they are based upon a great law of physics—that action and reaction are equal. They have still to show me that they have included all the factors of their equation. Certainly these business charts did not include the possibility of Germany winning the war in 1918. The bear market in stocks in 1917 took count of all that these tabulations ever formulated, and this overwhelming possibility besides.

It is true that we can form little conception of what may happen in the future unless we are familiar with what has happened in the past, where like causes have produced like effects. But forecast may be mistaken or premature long enough to ruin any business man, with no other guide than that. One of these business-chart authorities not long ago advocated the purchase of a certain stock, on the basis of the earnings and dividends for a period of ten years past. There was a fundamental change in conditions, aggravated by an ill-judged change in policy, and the people who bought that stock suffered severe losses. How would a present holder of such a stock as American Sugar, for instance, have fared if he had bought the common stock in 1920 on its dividend record?

### Insufficient Premises

Reasoning of that kind has too narrow a base. It lacks foresight. It is like saying that a patient will recover, irrespective of his symptoms, because he has enjoyed good health for ten years past. This is an example of reasoning from insufficient premises. No doubt the possibilities of changes in management and other things, which sometimes wreck concerns with a previously good dividend record, are averaged in the total of a recording agency's tables. But even when these things are averaged they are a record and not a barometer.

The data of the Weather Bureau are of the highest value, but they do not pretend to predict a dry summer or a mild winter. You and I know from personal experience that the weather in New York is likely to be cold in January and hot in July. We could infer that much without assistance from the Weather Bureau. That bureau can give us only an inadequately short view. It cannot tell us that there will be fine weather for our picnic the day after to-morrow. Still less can it tell the farmer that the temperature and humidity of the coming summer

<!-- PAGE:169 -->

will be such that he should plant potatoes instead of corn. It can show the records and probabilities; but the farmer must use his own judgment; while we take chances on the kind of weather that will make or mar our picnic.

### How Little the Best Man Knows

We have seen that the stock market barometer does predict. It shows us what will happen to the general volume of business many months ahead. It even goes further and warns us of the danger of international events which could upset all ordinary calculations based on the course of business as inferred from the records. It cannot be too often repeated that the stock market barometer is acting upon all the knowledge available.

I recently asked one of the greatest financiers in Wall Street, often credited, by sensation-loving journals, with the most searching knowledge of financial conditions and their influence upon coming events, what sort of percentage of the available knowledge he supposed he had. He said, "I have never worked that out. But if I had 50 per cent of all the knowledge which is reflected in the movement of stocks I am confident that I would be far better equipped than any other man in Wall Street." This was from a banker who handles the financing of great railroads and industrial corporations, whose foreign connections are of the very highest class. When he could confess this without false modesty to one he would not be foolish enough to deceive, how absurd must be the

<!-- PAGE:170 -->

assumed omniscience of the “financial octopus” the politician is so fond of parading!

### A Needless Accuracy

We have come a long way in the reading of the barometer based upon Dow’s Theory. We have seen that a “line” in the average—a succession of closing prices, over a sufficient number of days for a fair volume of trading within a narrow range—must indicate either accumulation or distribution; and that a movement of the average price out of that line, downward or upward, will confidently indicate a change in the general market direction of at least a secondary and even a primary character, which we can depend upon where either average is confirmed by the other.

We have also satisfied ourselves that the averages must confirm each other, although they may not break out of their respective lines on the same day or in the same week. It is sufficient if they take the same direction. It is by no means necessary, as experience shows, that the low or the high point of a primary movement should be made in both averages on the same day. All we assume is that the market has turned, with the two averages confirming, even although one of the averages subsequently makes a new low point or a new high point, but is not confirmed by the other. The previous lows or highs made by both averages may best be taken as representing the turn of the market.

<!-- PAGE:171 -->

This seems to be a difficulty which is still puzzling a number of people who expect an absolute mathematical accuracy from the averages, such as I would be the last to claim, if only for the reason that it is not needed. One critic believes that I am wrong in assuming that the low point of the last bear movement was in June, 1921, because the industrials made a lower point in the following August. But that lower point was not confirmed by the railroad average. Consequently, it is negligible from our point of view, although if it adds to the sum of that gentleman's certainty he will not go far wrong if he dates his upward movement from August and not from June.

### A Double Top in 1909

In the present discussion it will be useful to show the turn of the market to the bear side in 1909. This is likely to be confusing to our meticulous critics, because the railroad stocks made their high for the preceding bull movement at 134.46 in August, 1909; while the industrials made a high of 100.12 at the end of the following September, 100.50 early in October, and 100.53, the highest of the year, at the beginning of November. The last high, taken with that preceding, is an example of what is called a **double top**. It is by no means infallible, but is often useful; and experience has shown that when the market makes a double top or a double bottom in the averages there is strong reason for suspecting that the rise or decline is over.

If, however, I say that a bull market saw its

<!-- PAGE:172 -->

top in August, 1909, and that the bear market set in from that date, somebody will tell me that the bear movement cannot be said to have set in until the beginning of November. What does it matter? If we combine the condition exhibited then with what we have learned from a study of the line of distribution or accumulation, we shall see that distribution preceding an important downward turn, possibly secondary but proving to be primary in this case, had been in progress and had established its inevitable consequences, at any rate before the completion of the first week's trading of November, 1909.

### Bulls of Stocks Well Warned

That seems to me about as adequate a barometrical indication as we dare expect from a gauge which has to take into consideration all the fallibility of human nature itself. Never was the bull of stocks given such repeated chances as in 1909 to take profits at the top, or a few points below it.

In a previous discussion I have said that the bull market which originated in December, 1907, was actually almost unpopular. The previous bear market had predicted an era of corporation baiting, originated by President Roosevelt, who could never have foreseen the absurd lengths to which his animadversions upon "malefactors of great wealth" would be carried, or the devastating implications which would be drawn by people much more ignorant and far less sincere than himself.

The bull market of 1908–9 did not please a number

<!-- PAGE:173 -->

of highly respectable and competent critics.

### To Criticize a Critic

I have appreciated and recommended elsewhere *Forty Years of American Finance*, by Alexander D. Noyes. His review appears to have been carried only to the beginning of 1909, to judge by his concluding paragraph. He seems to reprehend the bull market then in progress. He certainly failed to see that it would continue in force up to August, so far as the railroads were concerned, up to November as shown by the industrial average, and that, at the end of the year 1909, the railroads would be no lower than one hundred and thirty on December 31st, as against one hundred and thirty-four in the middle of August, and the industrials a bare point away from the top.

Mr. Noyes says, in speaking of the bull market, with what can fairly be called a somewhat unsuccessful essay in prophecy:

“The end of this singular demonstration came with the opening of 1909, when facts were suddenly recognized, when prices for steel and other commodities came down, and when the Stock Exchange demonstrations ended. With the closing of the year 1908, this history may properly close; for it marked the ending of a chapter.”

But we have seen, from the record of the averages, that the chapter was not closed so summarily as Mr. Noyes assumed. We may say, for convenience, that the bull market had spent its force in August, 1909—or in November, as we choose to look at it. But the

<!-- PAGE:174 -->

bear market which foresaw the next period of depression did not begin to "hit on all cylinders" until January, 1910. Here again we see a profound and able observer influenced by accepting a record for a barometer.

### A Record Too Brief

To a student of history—and the writer modestly claims to be something of the kind himself—it is source of unceasing regret that there is relatively so little real history to study. Our table of averages is only truly effective for rather over a quarter of a century. When we say that the twenty active railroad stocks must confirm the twenty industrials it seems to me that this implies, at least in part, that less than forty stocks do not give a sufficiently inclusive picture of the market.

I might, in some subsequent discussion, offer a partial and incomplete record of the years from 1860 to 1880, with an average high and low, month by month, of fifteen miscellaneous stocks. I may as well say now that I do not think that it has any conclusive teaching value; or that if it had been kept contemporaneously with the events of that time, and not compiled years after, it would have given business anything like the thoroughly trustworthy indications which we can read in the more perfect double-average barometer of to-day.

### How History Records the Wrong Things

But my criticism of history goes much further than the mere records of which we are treating. It is that

<!-- PAGE:175 -->

all available history, as far back as we can trace—from Egypt and the supposed cradle of the race in Asia Minor—records the wrong things. It tells us all about the dynasties of the Pharaohs, and nothing about those productive middle-class brains of management which made those dynasties rich—gave them a real people to rule over. We know that there were rulers and wars, slaves and industrial workers enjoying different degrees of freedom. We know now that, so far from labor creating everything—the preposterous major premise of Karl Marx—labor creates only a fraction of the sum of human wealth compared with the product of brains. Of the “people” of the past, in the sense that the Bolshevist demagogue uses the word, we know a good deal.

Professor Thorold Rogers, of Oxford, many years ago compiled a tabulation of wages in England, from the time of the Tudors. But history seems to give something of the bottom and a great deal too much of the top. It tells us nothing, or next to nothing, of the middle class which must be the directing brain force of a nation with any commerce whatever.

### Where Are the Business Records?

What do we really know about the Carthaginians? They were the greatest trading nation of their time. We might well afford to sacrifice the detailed accounts of the campaigns of Hannibal, to throw away most of what we know about the second Punic War, to scrap nearly all that part of history, in exchange for

<!-- PAGE:176 -->

only one year's accounting of a typical Carthaginian merchant engaged in foreign trade. We would have more practical knowledge, applicable to the problems of to-day, from that single merchant's books of the year 250 B.C. than we can get from the *Decline and Fall of the Roman Empire*, and all it incidentally says about Carthage, to say nothing of the practical conduct of commerce in those days.

How did that merchant do his business? He dealt in tin from Cornwall and dyestuffs from Tyre. He had correspondents all over the known world, which then extended from Britain in the west to India in the east. Did he, or could he, for the tin or dyestuffs he received, pay exclusively in coined gold or silver? He may well have exchanged one of his commodities for another, or something else for both. How did he pay? How did he settle his balances? Did he have bills of exchange? I am inclined to think that he did, whatever form they may have taken, although no papyrus or parchment has survived. But history does not tell us the one thing we want to know.

How did the Carthaginians adjust their international trade balances? They necessarily had them. The merchants of Joppa or Sidon or Alexandria kept books, or their equivalent. They had a record of what they imported from Carthage and what they exported there and elsewhere. Rome owed Carthage balances in account, in triangular transactions which must have required some knowledge of double entry, with more or less regular exchange quotations to balance one

<!-- PAGE:177 -->

national coinage against another. What does history tell us about all this? Absolutely nothing. And yet that knowledge would be of infinitely greater value to us, would save us more mistakes, than Xenophon's deathless story of the retreat of the ten thousand.

### Who Financed Xerxes?

Heaven forbid that we should lose the inspiring lesson of Thermopylae. We have seen, in the Great War, that men are still capable of rising to the heroism of the fated three hundred. But what of the contractors who fed and clothed and armed the "five million men" in the army of the victorious Xerxes? "The mountains look on Marathon—and Marathon looks on the sea," and they may continue looking at each other, until the crack of doom, without telling us the cost of the ship's stores consumed in the fleet which transported the defeated Persians.

"You have the Pyrrhic dance as yet, where is the Pyrrhic phalanx gone?" We could dispense with the dance if we knew how the Pyrrhic phalanx got its necessary three square meals a day, and from whence its food was imported. I am far from endorsing the Henry Ford criticism of history—it is not "bunk"; but what would we not give for a trustworthy analysis of the economic consequences of Diocletian's price-fixing edicts, in the year 301?

Where did the Greeks buy their naval stores? How were they assembled? How was the account settled? Was it in coined money, or in a draft written on parch-

<!-- PAGE:178 -->

ment, transferring one merchant's debt to another in order to balance the books of a third? All this is left out of classical history, and is sadly lacking in modern history. It was not until the middle of the nineteenth century that Green wrote, not a history of the kings of England, but *A Short History of The English People*. It was all too short; and the most important part of the English people was loftily minimized—that respectable but inarticulate element which goes about attending to its own business and manages to "keep out of the papers." No one would belittle the record of the events which led up to the signing of Magna Charta. But if I am not greatly interested in King John, I want to know much more than history records about those useful mercantile and financial figures personified by Walter Scott in Isaac of York. The tortured Jew's extracted tooth outweighs, in real historical value, the sceptre of the Plantagenet king.

### What of the Banking in the Middle Ages?

The more we search the work of the earlier historians, the more we are astonished at their inability to see a thing so self-evident, for they were almost invariably drawn from the class they failed to chronicle, except where it touched politics. Froude devotes chapters of a volume of his history to the divorce of Catherine of Aragon. He tells us nothing of value about the financial transactions involved in such a simple matter as the collection and payment of Queen

<!-- PAGE:179 -->

Catherine's dowry to Henry VIII. I have heard experienced newspaper men say, "The most interesting news never gets into the papers." There is a good deal of cynical truth in that remark, and certainly the most instructive historical facts seldom get into the histories.

That is why the diary of Samuel Pepys, not written for publication, tells us more of the real things we want to know than anything which has ever been written, contemporaneously and since, about the period of the Restoration. It is almost from that date that we begin to get some familiar idea of what banking was like, and how it was conducted in the great city of London two and a half centuries ago.

Our knowledge, so far as available records are concerned, hardly, in any real sense, antedates the incorporation of the Bank of England, at the end of the seventeenth century. The records of commerce and banking of the earlier financiers are almost hopelessly wanting. There must have been such records arising out of the colonial expansion of Holland, Spain and Portugal or, working back through the years, in the trade of the Genoese and the Venetians. But these highly respectable historians seemed to think that the birth of a king's bastard was more important than the opening of an avenue of trade, with the creation of the financial machinery necessary for its development.

### How New Is Credit?

I am credibly informed that banking, and even branch banking, has been in use in China for at least

<!-- PAGE:180 -->

two thousand years, with drafts, credits and the usual banking machinery, if in a much simplified form. It must also be admitted that the great structure of to-day's credit is essentially modern. But it would be absurd to assume that it is all modern, merely because we know so little about history. The trading of Carthage, Genoa and Venice was largely barter. But we may be sure that it was not all barter. Not only the Church canon law but the Bible itself and like works have many allusions to the sin of usury. But usury meant interest, and interest meant credit, just as coinage meant exchange. It was not all pawn-broking; nor was the banking of the Middle Ages. There is some evidence that the same people both received and paid interest. The merchant, then as now, probably had a good deal more practical sense than the theologian, and certainly a clearer idea of the line between legitimate interest and usury. The trouble is that historians, up to a late date, have been influenced by the ecclesiastical attitude toward money lending. They are exasperatingly dogmatic on the things they admit they don't know.

I am inclined to suspect that it was not the early Middle Ages that were "dark" but only the historians. I am even disposed to agree with my friend Dr. James J. Walsh that, in point of real civilization and attainment, both artistic and literary, the thirteenth century in Europe compares favorably with our own. And even he has been unable to elicit anything of real usefulness about the mechanics of commerce.

And if this is the sum of our knowledge of the his-

<!-- PAGE:181 -->

### Socialism's False Assumption

tory of the most vital part of human affairs, the history of the men who paid the taxes and the men who made the taxes possible; the history of those who took the bare product of labor and fructified it tenfold—how difficult is it for us to gather together enough particulars to frame a trustworthy generalization from the wholly modern tabulation of the records of trade, industry and finance!

There has recently been published a book by H. G. Wells, *The Outline of History*, which at least has had the excellent effect of persuading a number of people to read history who have done little serious reading in the course of their lives. But that “outline” is devoted to proving a fallacious assumption—that men are groping their way, rather blindly, in the direction of international socialism. Is there one single record in all the inadequate volumes of history, upon which Mr. Wells and we ourselves necessarily depend, which indicates anything of the kind? Everything points to the development of the efficient individual. There is nothing in the Wells inference which does not ignore the factor of management in production, dominant now and dominant always, from the time when man learned to save something out of his harvest, to keep himself and others through the coming winter, and exchange for what he could not produce.

### A Sound and Conservative Forecast

With regard to the use of the barometer in the turn of the market in 1909, *The Wall Street Journal* on

<!-- PAGE:182 -->

September 11th, a month after the railroads had recorded their high, said:

“The movement of the average on Thursday’s break was one which has often marked the commencement of a downward swing. The indication as yet is not very authoritative, but whatever we may think about a resumption of the bull movement, ‘now that all the bad news is out,’ the averages undoubtedly look more bearish than they have done in a long period.

“Pessimism has never been the policy of this paper, but it published an earnest plea for conservatism when the market was at the top. Nothing has occurred since which has not emphasized the position taken.”

From that time forward, although the market, as we have seen, was remarkably firm, showing only modified secondary downward swings practically up to the end of the year, *The Wall Street Journal* continued to draw lessons of warning from the averages. On October 28th it said, after pointing out the extent of the rally necessary to re-establish the old bull market:

“There is no pretense here to pass an opinion upon the market from any other point of view than a purely technical one, based upon the experience of the price movements as shown in the average record of many years, but the depression in the barometer, here evidenced, is well worthy of the consideration of thoughtful traders.”

### Growing Effectiveness of the Barometer

Remarking how widely the idea of a bull market in 1910 was then held *The Wall Street Journal* was

<!-- PAGE:183 -->

unpopularly bearish on December 18, 1909, although both averages were within a very few points of the top. It is interesting to note that one of the bear arguments (other than that of the averages) discussed at that time was the high cost of living! On December 28th, any idea of a January boom—a movement always talked of at the beginning of the year—was rather cruelly discouraged.

It would be easy to multiply examples. It is sufficient here to show, before taking up the discussion of the four years of somewhat indecisive market movements which preceded the war, how faithfully the stock market barometer, twelve years ago, was already serving its purpose.