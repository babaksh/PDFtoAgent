# A STUDY IN MANIPULATION—1900—1

# A STUDY IN MANIPULATION—1900—1

<!-- PAGE:235 -->
## A STUDY IN MANIPULATION—1900-1

IT has been shown in previous discussions how relatively unimportant stock market manipulation is. But history presents some striking instances of manipulation, and much was possible in the Wall Street of two decades back which would not be feasible or tolerated to-day. It would not, for instance, be within the bounds of possibility to manipulate either the Steel stocks or Amalgamated Copper for distribution to-day as they were undoubtedly manipulated by James R. Keene twenty-one years ago. These two stocks are merely offered for example, and it is not to be assumed that I am placing them on a parity. There was an arrogant impudence about the distribution of Amalgamated Copper which makes me hot all over, even now. I remember that I criticized it, with all the freedom the law (and Charles H. Dow) allowed, at the time it was in progress.

### Conceived in Sin

The Amalgamated Copper Company was conceived in sin and born under similar auspices. It was offered for subscription with a capital of $75,000,000 early in 1899, and the subscription books closed on May 4th of that year. A number of "newspapers," of a kind

<!-- PAGE:236 -->
now happily defunct, reported that the stock had been "five times oversubscribed!" It did not sound probable, with the stock selling at a heavy discount in less than a month. The general stock market was on the down grade then. It did not turn until the summer of the following year. Of all the contemporary comments on that disreputable exploit those of the Boston News Bureau, which flatly refused to be humbugged, were about the most vitriolic. Here is one of them, published less than a month after the fivefold "oversubscription." On June 1, 1899, the Boston News Bureau said:

> The drop in Amalgamated Copper stock which was the feature of the trading in outside securities yesterday, was particularly appropriate at this time when the general railway list is on the down grade. Many shrewd observers in Wall Street contend that the formation of the Amalgamated Copper Company was the red flag which warned conservative investors and speculators away from the security market; that a blind pool calling for a capital of $75,000,000 should be oversubscribed five times was an indication to the better element of speculators that the public lost its head and the crash would not be far distant.
>
> One of the worst features of the whole case is that the National City Bank, which is the largest institution of its kind in this country, should have stood sponsor for such a transaction, etc., etc.

### Amalgamated Copper

It will be seen that, in spite of all the flubdub circulated about "oversubscription," the flotation had been a failure. The Boston News Bureau continued to comment upon "The Amalgamated Fiasco," "Promises

<!-- PAGE:237 -->
and Predictions Against Realities," "The Humor and Pathos of Copper Promises," in an acridly humorous vein. In the same month of June there were rumors that control of the Anaconda company had been purchased by the organizers of Amalgamated Copper, for something like $45 a share, though it was quoted at $70 a share by the time Amalgamated was floated, and was said to be going into the new Amalgamated company at $100 a share. The same Boston article points out that the $75,000,000 capital of Amalgamated Copper should have been sufficient to pay for the entire capital of the constituent companies, although only a control, presumably 51 per cent, was declared to have been acquired. The whole transaction was so raw that in the better Wall Street of to-day it seems almost unbelievable.

### Keene's Part in Distribution

In the latter part of 1904, three years after the manipulated distribution of the stock by James R. Keene had taken place, that eminent operator wrote a letter, which became public, in which he admitted that he distributed, "for the account of Henry H. Rogers and associates," $22,000,000 of Amalgamated Copper (two hundred and twenty thousand shares) at prices ranging from ninety to ninety-six. In that letter he indicated the period of distribution with sufficient clearness. In the following January I published, in *The Wall Street Journal*, an analysis of what he had done, as shown by the recorded sales, under the title

<!-- PAGE:238 -->
of "A Study in Manipulation." That analysis did not deal with the ethical question. You cannot say much about the ethics of people who seem to have none. By taking the sales of Amalgamated Copper stock, as recorded on the ticker, together with the names of the brokers executing orders as reported from the Stock Exchange, and by comparing periods of activity it seemed possible to dot Mr. Keene's "i's" and cross his "t's."

It had the result of making me some enemies in Wall Street, although, to do James R. Keene justice, I do not think he was one of them. I have said before that we were never intimate. But he made opportunities to see me at various times after that analysis was published, and nothing I could say seemed to convince him that I had not had some illicit access to his books. As he put it, "Somebody must have leaked." The Wall Street of that time, and the nature of his own business, made Keene habitually suspicious. His mentality was incomplete in the respect that he found it hard to believe a simple truth where it depended upon the unsupported word of anybody. Really great men, and some children, know when to believe—and whom. Keene was not a great man.

### A Difference Between Steel and Copper

Leaving all questions of ethics apart, there was probably nothing more ably done in its day than the distribution of Amalgamated Copper in the stock market. Keene's handling of United States Steel common and preferred will remain an example of consummate generalship. But in that instance he had the enormous advantage of a public which wanted the stock he had to sell. It is not true that there was much real "water" in the capitalization of Steel. What was called watered capital was only intelligently anticipated growth. United States Steel was floated in 1901, and three years afterwards was showing a well-established surplus of 4.9 per cent on the common stock sold to the public at fifty, which surplus had been more than doubled by 1905. In an earlier article I have pointed out the genuine book value of the stock now.

But Amalgamated Copper was an utterly different proposition. As a work of art the distribution, compared with that of Steel, bears about the relation of a Meissonier to one of the heroic battle pictures of De Neuville. Keene, in his subsequent statement, said that he was reluctant to take the matter in hand. It was not that he had to create a market, as in the case of United States Steel common and preferred; he had to begin his distribution in a market which others had done their stupid best to spoil.

### Earlier Manipulation

On analysis of the sales, the first significant period seems to be that between December 3, 1900, and about the middle of January, 1901. Taking advantage of the general bull movement which set in shortly before the second election of McKinley, such members of the

<!-- PAGE:239 -->
public as had really subscribed for Amalgamated Copper originally were unloading on the promoters of the enterprise. Certain "court circulars" of the time were talking boldly of "inside buying." They were right for once. Insiders were buying because they could not help themselves. They were "accumulating," much against their will, to judge from the downward movement of the stock. With a knowledge of the backs of the cards as well as the faces, the "Standard Oil crowd" which hatched the company could not conceal their crude and clumsy methods. We may here recapitulate the movements and total sales during this period:

- Opening price December 3, 1900, was 96
- Sales from December 3d to December 13th were 160,000
- The fluctuation in that period was from 96 to 90 $ \frac{1}{4} $
- Sales from December 14, 1900, to January 11, 1901, were 295,000
- The fluctuation in that period was from 89 $ \frac{3}{4} $ to 96
- With all this stimulation the closing price on January 11, 1901, was only 91 $ \frac{1}{8} $

### Keene's First Appearance

Keene's first appearance seems to have been made then, and he was much too clever not to see that it would be necessary to break the market for the stock before he put it to a level which would attract the speculative public. The next record is:

- Opening price January 12, 1901: 91
- Sales from January 12th to January 19th: 70,000
- Fluctuation in that period from: 92 $ \frac{1}{4} $ to 90 $ \frac{1}{4} $
- Closing price January 19th: 90 $ \frac{1}{2} $

Sales from January 20th to January 26th: 88,000

- Fluctuation in that period from: 92 to 83 $ \frac{3}{4} $
- Closing price January 26th: 89

This closing price of January 26th is a tribute to Keene's ability. It was a much more real price than the ninety-six momentarily established by the fatuous "insiders" in the previous December.

<!-- PAGE:240 -->

The beginning of Keene's operations is characteristic. There were transactions averaging from twenty thousand to thirty thousand shares daily in the third week of January, 1901, when, on the 20th of the month, the price was hammered to eighty-six, fluctuated between 83 $ \frac{3}{4} $ and 89 on the following day, and tended to settle down stolidly at 88 $ \frac{1}{4} $ on the day after. The gossip obtainable at the time was beneath contempt from a news point of view, but was well calculated to stimulate the avarice of the public. Everything tended to show that, if Keene was in the market at all, he was raiding the stock for a turn on the bear side. It is not venturing too far to say that he had previously taken no trouble to cover up his tracks, in order to create exactly that impression.

### What a Major Bull Swing Made Possible

But the McKinley boom in the broadening market was well under way. Stocks were in that great swing, so violently interrupted, but not terminated, by the Northern Pacific corner and panic of the following May. Nothing could have suited Keene better than to have it believed that he was short of a "Standard Oil stock." He admits to having sold all the stock of the Rogers pool, at prices from ninety to ninety-six, shortly before the advance to one hundred and twenty-eight. That advance did not take place until the middle of the following April, but early in March the stock was already selling well above par. I assumed, when writing in 1905, that Keene meant that the $22,000,000 of stock was not credited to Rogers and his friends at one average price, but perhaps in a series of large blocks of stock averaging from ninety to ninety-six, after allowing for the cost of manipulation. Some of it was, of course, sold much higher, but we have already seen that some of it was sold below eighty-four.

### Keene's Second Stage

Keene was not the man to press the market when it was going his way, and there followed a period where the stock was judiciously allowed to take care of itself, with occasional stimulus to cultivate bullish sentiment. Transactions were in relatively light volume. In the next period the extreme fluctuation was less than five points, but it is noteworthy that the higher figure was the prevailing price when we see Keene's hand again:

- Sales January 26th to February 23d: 110,000
- Fluctuation in that period: 92 $ \frac{3}{8} $ to 87 $ \frac{3}{4} $

<!-- PAGE:241 -->

In this quiet period of a month he may have sold some real stock but certainly never forced it on the market. It is difficult to say how many shares he actually dealt in that he might distribute so large a quantity. It was possibly ultimately three times the stock he had to sell. In the early stages he was employing brokers on both sides of the market, even if they did not know that they were executing matched orders. That was, and is, against the Stock Exchange rules, and we can afford, at this distance of time, to give them the benefit of the doubt. As the market improved, manipulation of that kind probably grew less, and of course as the public took hold it disappeared altogether.

### Keene's Final Distribution

What may be called the third movement shows the final distribution of the stock:

| Opening price February 28th | 92 $ \frac{3}{8} $ |
| --- | --- |
| Sales February 28th to April 3d | 780,000 |
| Fluctuation in that period from | 92 to 103 $ \frac{3}{4} $ |
| Closing price April 3d | 100 $ \frac{3}{8} $ |

It is in this period that Keene probably distributed the bulk of his two hundred and twenty thousand shares. He admitted that much to me, and was never satisfied with my answer to his question as to how I knew.

It is one of the discreditable facts of that period that throughout this trading Amalgamated Copper was practically on an 8 per cent basis. It was declar-

<!-- PAGE:242 -->
ing 1 $ \frac{1}{2} $ per cent quarterly, with a half per cent extra; and its directors, with that extraordinary fatuity for which the public ultimately paid, were convinced that they could hold up the world price of the metal indefinitely. One of the items of gossip in the early part of the Keene movement was to the effect that the decline of the metal in London, then and now the world's free market for copper, had at last been checked effectually. It was not so. But it was as near the truth as any of the rumors of that curious time. It was some years before the competing copper magnate, Augustus Heinze, reached a settlement with the Amalgamated Copper people, but such a settlement was among the rumors then exploited, and one of the principal bull arguments.

### The Public's Own Boom

As a net result of the manipulation here detailed Keene had, in the first fortnight of April, 1901, created a market for the stock which may well have surprised himself. It was at least twice as broad as it had been in February or March, with daily transactions amounting to two hundred and fourteen thousand shares in one case, and to almost as much on several other days during that month. It should be compared with the record, during Keene's activities, of seventy-seven thousand shares on March 6th, with an extreme fluctuation of nearly three points.

It may be taken that the subsequent trading showed all obstacles removed from the stock's pathway to the top:

<!-- PAGE:243 -->

- Sales from April 4th to April 16th: 1,275,000
- Advance in price from: 101 $ \frac{1}{2} $ to 128 $ \frac{1}{2} $

The stock of the Rogers pool had been marketed and, indeed, greedily eaten up in the enthusiasm of a general bull market.

### Their Own Gold Brick

It is a humiliating exhibit in the indictment of human nature that the "insiders" who had called in Keene seem actually to have begun to believe in their own gold brick. It is of record that Henry H. Rogers, quite in the manner of the man who has "heard something from a friend of his who knows an insider," informed Keene that "the stock was going to advance; that he had received letters from parties who were going to buy, and that he suggested Mr. Keene should join in the movement." It is needless to say that the net was vainly spread in the sight of that wary old bird. But the stock certainly advanced some twenty points beyond the price at which it was selling when Keene had finished his distribution.

It is also significant, in the study of an incident which is not at all likely to recur, that, in the later trading, houses which felt flattered in those days to be called "Keene brokers" were much more conspicuous than in the earlier time when the real Keene trading was in progress. Mr. Keene’s name, to judge by the gossip current at the time, was only mentioned when he had safely completed his selling. What happened subsequently would be interesting to know, but there is not the same evidence to go upon.

<!-- PAGE:244 -->

### Petroleum and Swelled Head

There is no "Standard Oil crowd" now. The millionaires who comprised that group were new to the possession of great wealth. They believed themselves invincible, up to the time of the issue of Amalgamated Copper. They made many mistakes, then and after, but as time went on they learned sense and got out of the stock market. They were so overwhelmingly right about petroleum, and particularly Standard Oil, that they could afford to risk enormous losses in other directions. Some day some one will unkindly tell the story of young Mr. John D. Rockefeller, and his venture in "Little Leather." Only a young man with a really well-to-do father could afford to spend so much on his education. There is good reason to suppose that his expensive post-graduate course in the school of experience had permanent and even admirable effect.

I have told, in earlier discussions, how heartily wrong Henry H. Rogers could be, and how his pride of opinion laid all the blame upon the ignorant stock market, which, in the last showdown, is always right. When he died in 1908 he was worth $50,000,000, and it is possible that his estate would have shown twice that amount had he lived another two years. Some of his work was good, and calculated to endure. The Virginian Railroad was the best built road, in its original construction, ever undertaken and completed in the United States. It almost broke the heart of its godfather that, with his financial backing and personal wealth, he was compelled to borrow money in

<!-- PAGE:245 -->
1907 for his pet railroad, on terms equal to 7 per cent with his personal guaranty. Even there he miscalculated the meaning of the stock market. It was saying, in the most explicit way, that H. H. Rogers was lucky to get money on any terms whatever. Money of that kind during the panic year may be said to have commanded anything the lender chose to ask.

### Lessons from the Incident

In this detailed examination of a notorious essay in manipulation there are some important lessons on the nature and quality of our barometer. Remember that Amalgamated Copper was in the Unlisted Department of the Stock Exchange, which is now abolished. It was, as the Boston News Bureau said at the time, a blind pool, in every sense of the term. Nothing like it could occur under the present listing requirements. I do not believe that anything of the kind would be possible in the Curb Market's new Exchange. Modern methods of publicity are so much better than those of twenty years ago that a movement of such a nature would not last for a week before it met the active and effective opposition of the banks. No financial clique, like that which constituted the Standard Oil group, is likely to acquire in the future the unwholesome power which was exercised at the time we have had under review. But the best of all protections is the greatly enlightened public opinion. Information on financial matters is now incalculably better than it ever was before. The cure for corruption is publicity. There is no such sanitary agent as full daylight. People are no longer deceived by the mystery talk which was peddled as news two decades ago. The infallibility of the "insider" has been utterly exploded. The stock market barometer, based upon Dow's theory of the triple simultaneous movement of the market, has increased in dependability as the years have gone by. Certainly it is in no real danger from manipulation, and on that topic I have something further to add.

<!-- PAGE:246 -->

### A Shift of Bad Reporting

Manipulation in the stock market is reported twenty times for once it occurs. It is the inefficient reporter's method of accounting for a stock market movement which he has not taken the trouble to understand. Collection of news in Wall Street is difficult, but not impossible. It requires a higher average of intelligence than news collection anywhere else, and, if it is done properly, entails unremitting hard work. Unremitting hard workers are not much commoner in the newspaper business than elsewhere. The financial reporter is tempted by the fact that he can take refuge in technical terms not understood or correctly appreciated by his employers. Except in such a responsible news agency as the Dow-Jones service, whose very existence depends upon the integrity of what it gathers and sells, financial reporting is apt to become perfunctory, although it is improving.

### Always a Reason, and Always News

This is a matter which particularly interests me because some of my earliest work in Wall Street was

<!-- PAGE:247 -->
writing the stock market paragraphs for the Dow Jones news service. The aim was to get, as far as possible, a reason, if only a tentative reason, for all individual and general fluctuations in the market. Mere generalities were not accepted, and I could tell many stories, ranging from pathos to wild absurdity, of the gathering of news which might be stale in half an hour's time. Such news was, of course, of the highest value to the active brokerage and banking houses, serving as it did to sustain interest in the market. They all had customers whose appetite for such news was insatiable. Even at an interval of twenty years I am humbled by the crudity of some of the reasons I had to give, especially as I was evolving a method out of nothing. But at least it was genuine news collecting, and not guessing. I look back on nothing in my life with greater pleasure than the friendly expressions of regret I received from the active houses in Wall Street when I relinquished that nerve-racking task to take up the editorship of *The Wall Street Journal*. Almost necessarily, a reporter's rewards are those of the tinker's donkey—"more kicks than ha' pence." He has, for compensation, the most interesting work in the world—if he likes to make it so.

Here is a chief reason why the part of the manipulation has been so absurdly exaggerated in the public mind. Every movement in the stock market has a valid explanation. To get at that explanation involves much intelligent research, with a comparison of the carefully sifted expressions of the people concerned in the actual market movement—those who executed the

<!-- PAGE:248 -->
orders on the floor, and, preferably, those who gave them. The research can be carried back to the original source of the orders and the news can be traced further, to the reasons for buying or selling stocks, and the particular stocks involved.

### Honest News Protects the Public

Wall Street has a number of maxims more or less of the nature of what is called "dope." One of these is, "There is no news in a bull market." It is not true, except with too many qualifications to justify a general rule. There is news, and plenty of it, in any market if the reporter will only get out and get it. If he is content to turn out perfunctory paragraphic comments on the market for the evening newspapers, or even for the morning press; content to warm over items which he finds in the financial news "slips," he will take refuge in such expressions as "manipulation," "traders selling," "Standard Oil buying," and all the other fudge which some newspaper proprietors still accept as news. Wall Street is the financial news center of the world. News collection there has steadily and greatly improved in my time, but the field is simply inexhaustible.