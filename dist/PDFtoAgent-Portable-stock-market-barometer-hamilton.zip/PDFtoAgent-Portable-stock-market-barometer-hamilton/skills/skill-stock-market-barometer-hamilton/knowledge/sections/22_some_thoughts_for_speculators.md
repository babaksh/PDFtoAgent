# SOME THOUGHTS FOR SPECULATORS

# SOME THOUGHTS FOR SPECULATORS

<!-- PAGE:276 -->

## SOME THOUGHTS FOR SPECULATORS

MANY years ago one of the Southern states, which need not be otherwise identified, had a law which prohibited the playing of games of chance where any stake was involved. It need hardly be said that a law so foolish was "more honored in the breach than the observance." The sheriff of one of the smaller towns, however, determined to enforce the law and captured a party of young men playing euchre in a barn. Courts were not overburdened with formalities in those days. It was not considered out of the way, or a departure from dignity, when counsel for the prisoners, while admitting that his "unfortunate clients" had been playing euchre, submitted that it was not a game of chance. As the court and the gentlemen of the jury habitually played the game themselves, the contention was received with incredulity. Nothing daunted, however, the counsel for the defense said: "If your honor will allow me to demonstrate the game to the jury for a short time I am sure I can convince them that euchre is not a game of chance."

### Not a Game of Chance

This seemed eminently fair, and the jury and the lawyer were accordingly locked up together. In a short time various members of the jury sent out to borrow a little change from their friends. After an hour or so of "demonstration," the jury returned to court with the unanimous verdict that euchre was not a game of chance.

These articles would not be complete if I did not say something about speculation and, incidentally, give some practical counsel to the speculator. Speculation necessarily involves a large element of chance. It is the speculator himself who too often makes it a sheer gamble. I do not know what the Southern lawyer in the story did to convince the jury of the certainties underlying the game of euchre. But certainly, if the amateur is to come into Wall Street and "speculate" with the stupidity he so frequently exhibits, the professionals there can show him that his kind of speculation is not a game of chance, and they will not have to cheat to do so.

### Real Protection in the Barometer

It cannot too often be said that Dow's theory of the stock market movement is not a "system" for beating the market—a get-rich-quick scheme which converts the Wall Street district into a sort of Tom Tiddler's ground, where any man with a few dollars for margin can pick up gold and silver. But if the intelligent speculator of to-day (who in many cases is the intelligent investor of to-morrow) cannot find means of protecting himself in the stock market by an earnest study of the stock market barometer, then

<!-- PAGE:277 -->

these chapters have, in that respect, failed. He has already gained something tangible if he has correctly understood the major movement. If he comes into Wall Street on a mere tip from somebody he trusts about a stock of which he never heard before, without ascertaining whether the general market is in an upward or a downward major swing, he stands an excellent chance of losing all he brings in the way of margin, without a fair "run for his money." But if he has learned what the market movement means and appreciates the opportunity given to him in the dulness after a typical reaction in a bull market, he stands more than an even chance of making a profit. That profit will depend on a number of considerations which, apparently, do not enter into the minds of many people who come to Wall Street only to lose money, spending the rest of their lives denouncing the Stock Exchange as a gambling hell.

### Speculation and Gambling

To these people all stocks look alike. But they are not alike. So far as well-protected speculation is concerned, there is all the difference in the world between such a stock as United States Steel common, with a well-established market—a stock well distributed and widely held—and the latest motor or oil proposition floated on the Curb for the purpose of distribution. The latter may be good, but it is at least untested, not only as regards the business the new company purposes doing, but in the market aspect of its stock.

<!-- PAGE:278 -->

### Selecting a Stock

Let us suppose, then, that the outsider has considered the character of the major movement and tendency of the stock market. His next business is to select his stock. Here again the amateur, who wants quick action for his money, will not take the trouble to inform himself properly upon the stock in which he purposes to risk his small capital.

It is a good standing rule that in a stock for which no permanent market has been created—a new flotation or one which is still notoriously, by majority holdings, in control of the people who dictate the policies of the corporation—the small speculator should not trade on margin at all. This is, of course, a counsel of perfection, but at least he should make it a rule to take only a small risk in such a venture and to buy only what he can in some way finance himself if necessary.

By the time a stock is listed in the Stock Exchange there is generally a dependable market for it at most times although here the danger of too much ownership in few hands, as in the case of Stutz Motor, still exists. Such stocks are good to let alone; and only where the nature of the speculator's own business gives him access to special information should he embark his money in stocks of such a character, and even then his margin should be of the most ample kind.

### On the Matter of Margin

This brings us to the question of margins. A complete misunderstanding of what constitutes a sufficient

<!-- PAGE:279 -->

margin is responsible for many needless losses in Wall Street. Brokers are looking for business, and they tell the tyro that ten points margin is good enough if he can guarantee the firm that amount against fluctuations. This would mean $1000 on one hundred shares of stock at par. That margin is not enough, or nearly enough. Writing twenty-one years ago, Charles H. Dow pointed out that "the man who buys a hundred shares on a 10 per cent margin, and stops his loss at 2 per cent, has lost (with commissions) nearly one-quarter of his capital." Obviously it does not take long to wipe him out. Dow was ultra-cautious, but he was not wide of the mark when he said that if such a man had begun with ten-share lots he would have been able to see a substantial loss and yet have averaged his purchases to yield him an ultimate profit, granting he was correct in his first surmise that the stock was selling much below its value. Certainly a trader with $1000, and no more, has no business to start with a hundred shares of stock unless it be something at a very low price. There was a time when Steel common could have been bought below $10 a share.

### Little Traders and Large

Another delusion of the small trader is that he should buy part of the quantity he contemplates, adding to his holdings on each point of decline until he completes the amount he thinks he can carry. But why not buy it all at the last price? If he proposes to

<!-- PAGE:280 -->

buy one hundred shares in twenty-share lots, and expects that there will be a decline of five points in the market, he is really contradicting the assumption upon which he originally decided to trade. He has not considered all the facts of the case. If the stock can go down five points the purchase is not so good a one as he supposed. It is quite true that great operators, like Jay Gould, did buy stock in that way. But they were not trading on margin, except in the respect that they financed their stocks mostly through their own banks. And they were buying upon considerations which would seem hopelessly remote to the small speculator who wishes to test his judgment in Wall Street. Such a man as Jay Gould, moreover, could himself give value to the things he purchased. He might well start to buy into a company during the course of a major bear swing, knowing that he could not get all the stock he wanted in a bull market.

The small speculator cannot afford to take any such view, unless he purposes to devote such exclusive attention to stock trading as he would give to any other business. There are plenty of people who do that, and I have in previous discussions given instances of their success. But we are talking now of the man who speculates on his judgment while interested in some other business. There is no reason why a speculator of this class should not have more than an even-money chance in the market if he would only bring a little common sense to bear. But if he will listen to the first casual friend who tells him to "buy a hundred shares of A. O. T., and ask no questions," and risks

<!-- PAGE:281 -->

his only thousand dollars in doing so, he cannot complain if he loses. He is a gambler and not a speculator. He would have much more fun if he took his dollars to the races. He would have a healthy day in the open air and find the racehorse a much more amusing spectacle than the ticker.

### A Quotation from Dow

In an editorial published in *The Wall Street Journal* on July 11, 1901, Charles H. Dow said:

> "If people with either large or small capital would look upon trading in stocks as an attempt to get 12 per cent per annum on their money instead of 50 per cent weekly, they would come out a good deal better in the long run. Everybody knows this in its application to his private business, but the man who is prudent and careful in carrying on a store, a factory or a real estate business, seems to think that totally different methods should be employed in dealing in stocks. Nothing is further from the truth."

In the same article Dow went on to say that the speculator can avoid tying himself up in a financial knot at the outset by keeping his transactions down to a limit which, compared with his capital, leaves his judgment clear and affords ample ability to cut loss after loss short; to double up; to switch to some other stock, and generally to act easily and fearlessly instead of under the constraint which comes from a knowledge that his margin of safety is so small as to leave no room for anything except a few anxious gasps before the account is closed.

<!-- PAGE:282 -->

This is as good sense now as on the day it was written. The speculator who comes into Wall Street must learn to take losses, and take them quickly. I have said before that more money has been lost in Wall Street from sheer pride of opinion than from any other single cause. If you buy a stock and find that it is falling rapidly, you have not considered all the facts of the case. You cannot consider them impartially so long as you are under the terror of losing all your capital. You cannot take a clear, unbiased view unless you get out and look at the thing objectively. When you are tied up in a losing speculation you are in the position of the man lost in the forest who cannot see the wood for the trees.

### Avoiding Inactive Stocks

Readers will remember the story I told of the young man who refused a partnership offered to him by Jay Gould because, in executing Gould's orders on the floor of the Stock Exchange, Gould seemed to him to make nothing but losses. He was not broad enough to see that these unsuccessful attempts were merely testing purchases, and that Gould probably employed some other broker when he was quite sure that he had caught the turn of the market. Here is where the purchase of a stock only occasionally active becomes so dangerous. The broker may be able to carry it very well to-day, although inactive stocks are not looked upon with favor in bank loans.

But the broker himself does not know whether he

<!-- PAGE:283 -->

can carry the stock so conveniently to-morrow. The peculiar circumstances which started the movement in that stock may be fully discounted in a few days' active trading, and the event will be a market without a single transaction for days together, where the seller is obliged to make concessions to find a buyer—generally a professional, who charges all the traffic will bear for such a service. Such a stock should not be carried on margin at all. But the man whose business is in some intimate connection with the steel trade or the textile industry may well take hold of Steel common or Bethlehem Steel or American Woolen, feeling that there is a permanent market if not always an active one.

### A Word for the Consolidated Exchange

I have many friends in the New York Stock Exchange, but I have also friends elsewhere in Wall Street. The odd-lot brokers, of whom there are fewer than ten firms specializing in that way, make the market in lots of less than a hundred shares. But the Consolidated Stock Exchange makes a regular market for those small quantities all the time. It is in every way a reputable institution, whose members are open to the same scrutiny the speculator ought to apply to any broker he employs. Our small amateur trader can do his business just as well on the Consolidated Exchange, provided he chooses really active stocks. Such stocks are “seasoned” and thoroughly well distributed, and this is not true of those which make up

<!-- PAGE:284 -->

the list of the Curb Association. I am not saying one word against the latter, but the securities in which it deals are seldom popular in bank loans, and I should have the strongest suspicions of a Curb house which professed to trade for its customers indiscriminately on a 10 per cent margin.

By all means get the idea of such a margin out of your head. The margin should be as good as you can make it. If you are engaged in business or living upon an income from investments with people dependent upon you, your losses in speculation should be limited to an amount which will not cause you serious compunction. It is probably heterodox to say so, but there is common sense in the proposition that gambling begins where we risk what we cannot really afford to gain something we have not earned.

### A Glance at Short Selling

How can the stock market barometer help the speculator? In many ways. He cannot expect any stock, except under most unusual circumstances, to advance profitably against the general current of the market. He must be most unusually well informed, an almost instinctive reader of the market, if he can speculate successfully on the occasional rallies which take place in a major downward swing. I am saying little about short selling. The man who tries short selling in a bull market is merely guessing at the secondary reactions, and unless he is a trader on the floor or devoting all his attention to the business of speculation,

<!-- PAGE:285 -->

he is certain to lose his money. I am not discussing the morality of short selling, because I do not believe the moral question enters into speculation at all, provided it does not degenerate into gambling with what is, in effect, other people's money. In every market in the world there is necessarily a great deal of short selling. The tourist in San Francisco whose stocks are locked up in his safe deposit box in New York cannot afford to miss his market by waiting until he returns across the continent. If he sells he is short of the market, and a borrower of stocks until he can make his delivery good. But on the law of averages, far more money has been made on the bull side than has ever been made on the bear side, if only for the reason that bull markets are generally much longer in their duration than bear markets. Short selling is an operation which may well be left to the professional, especially by the man who is only a student of the market learning the rules of the game.

### Buying on Reactions

No knowledge of the stock market barometer will enable any of us to call the absolute turn from a bear market to a bull market. There may be weeks of narrow fluctuations before a definite trend is established, as we have seen in our previous studies of the market movement. All of these indecisive fluctuations eat up the speculator's capital, in broker's commissions and interest, to say nothing of the market turn. But when once the major bull swing is established the successful purchase of stocks for a rise becomes a feasible proposition. If on the completion of his purchase a stock reacts, carried down by a similar reversal of movement in the general market, the speculator should take his loss without hesitation and wait for that inevitable period of dulness which develops after a secondary reaction in a major bull swing.

Here again he may buy his stock, and instead of purchasing on the way down, on the fallacious assumption I exposed earlier in this article, he may well add to his holdings as the market rises. Each advance adds to his margin of safety, and, provided he does not "pyramid" too much, and conceding that his holdings are not overextended so that his own account would be a tempting object of attack, the speculator may well, if he protects himself with "stop-loss" orders, make profits much more substantial than he at first expected. We hear a great deal about people who lost money in Wall Street but very little about those who made substantial profits there. The latter, as a class, are inarticulate, in my experience; and a man seldom cares to ascribe his prosperity to successful speculation. He prefers to call it judicious investment. There is little difference between a purchase of a house on mortgage and a purchase of stocks on margin, provided the purchaser can meet his contracts. In these great uplifting times, when everybody is minding everybody else's affairs, I am still disposed to say that it is nobody's business how our speculator carries his stocks so long as he does so out of his own resources, which include his borrowing credit at the bank.

<!-- PAGE:286 -->

### Ways of Losing Money

There is another class of speculator, all too common, who loses money by forgetting why he went into the market in the first place. Knowing me personally, he asks me my opinion of Atchison common. I tell him what the road's prospects are, what the earned margin may be over and above the dividend, and the general railroad outlook in that part of the country. He concludes that Atchison common (here chosen merely for example) is cheap, and buys himself some of it. If he would protect his broker with ample margin, or pay for the stock outright, and ignore fluctuations, he would probably make money.

But he listens to every bit of gossip, particularly stories of "traders selling," "Congressional investigation," "threatened strikes," "crop failures," and all the rest of it. He forgets that the market has made allowance for everything of the kind in the broad estimate of the prospective value of the stock. He becomes nervous on a minor fluctuation, takes a loss and decides never to ask my opinion again. At least I wish he would so decide; but, unfortunately, he does not. He comes to me again to see if I cannot say something to upset what he calls his judgment, based, this time, upon the opinion of somebody else.

### Another Way of Losing Money

Take another easy way of losing money in Wall Street. The speculator is informed, correctly, of a coming quick movement, perhaps covering four points

<!-- PAGE:287 -->

in a particular stock. He notices that the stock has been active, without paying much attention to the fact that a point and a half of the expected four points is already shown in the advance of the price. After some hesitation he buys, when the movement is almost completed. He sees a small profit, and then the stock becomes dull. The special movement is over. The attention of the professionals is turned to some other security, and his own stock sags with the market or eats its head off in interest. But he is still fatuously holding on instead of realizing that he has missed his opportunity and has had what, if he would look at it sensibly, is really a cheap and most instructive lesson.

Here again he forgets why he originally bought the stock, just as he did when he purchased on permanent value. If the special movement he anticipated fails to materialize he should take his loss, or his disappointingly small profit, and wait for another chance. But the trouble with most of the speculators of my acquaintance is that they lack not only memory but the virtue of patience. They must be dabbling all the time; and sooner or later they get tied up with an account, extended to their full resources, which seems to have run aground, with the general current of the market swinging past it.

### "Where do the Gentiles Get It?"

It is a common mistake to suppose that the reputable broker makes his profits out of what his customer

<!-- PAGE:288 -->

loses. The broker stays in business out of the commissions that his customers pay. He not only wants them to make money, but he does everything he can to help them do so, or, at the worst, to prevent them from losing money. It is only the bucket shop which wants a new customer every day, to fleece thoroughly before the market closes. All the reputable brokers of my acquaintance are proud to point to customers who have been employing them for many years, in good times and bad, extending in at least two instances I can recall, to nearly half a century.

In writing this I have necessarily outlined a patient, intelligent and level-headed speculator—in fact, a man of exceptional coolness and poise. But that is the kind of speculator for whom I am writing. I am certainly not drumming up business for the Stock Exchange. These stories of the continual losses of the outside public in Wall Street always remind me of the young Jew who said to his wealthy parent: “Father, where do the gentiles get all the money that we take away from them?” Where does the public get all this money which Wall Street is supposed to take from it in speculation? Is the broker’s commission a sort of middleman’s profit taken out of the whole business of the country? To a certain extent it is; but not to anything like the extent the people who do not love Wall Street assume. Wall Street is the great reservoir for small, trickling streams of capital. Great corporations would be impossible if there were not a free market for the interchange of their securities. The free market is in itself an element of value. If we

<!-- PAGE:289 -->

could imagine two securities of exactly equal merit in every respect, the one with the free market would inevitably, and most properly, sell anything from five to ten points above the other. It is exactly this free market that Wall Street provides.

### A Final Thought

This brings me to the conclusion of my discussions of the stock market barometer. I would not have it on my conscience that I had encouraged any weakling to gamble, or had expedited, by a day, the inevitable parting of a fool from his money. At least in that respect every man is a free agent. In spite of all sorts of personally regulatory legislation, he has still that much freedom allowed to him. We can imagine laws which would make speculation impossible, even if, as they certainly would, they paralyzed the business of the United States. But we cannot imagine any law which would compel a man to trade in Wall Street if he did not choose to do so. All I have tried to do here is to show him how he can protect himself, and at least feel that not only has he had a fair run for his money but that he has earned the prize at the end of the run.