# SOME CONCLUSIONS—1910—14

# SOME CONCLUSIONS—1910—14

<!-- PAGE:251 -->

## SOME CONCLUSIONS—1910—14

WE are nearing the end of our discussions of *The Stock Market Barometer*. From readers of *Barron's* during their serial publication I gathered that this series of papers had been illuminating and widely interesting. It certainly instructed the writer of them, for he did not realize, when the series began, how much could be profitably said upon the subject of Dow's theory of the price movement. It has led us to an analysis of some pretentious theories of what are called "cycles"; to an examination of historical authorities which has shown us how much history could tell us if the records were intelligently compiled, and how little we know of the past, when the importance of commerce in national and world development was so little understood or appreciated. We have reached also a fair and dependable estimate, not only of what the stock market barometer does, but of its limitations. We know, now at least, that it is not a method of beating the speculative market—not an advertised system of stock trading, guaranteed against loss.

### Speculation's Prediction Value

So far from limiting the usefulness of the barometer, this really expands that usefulness further than

<!-- PAGE:252 -->

could have been expected when we started to analyze the triple movement of the market—its major swing upward or downward; its secondary reaction or rally; and the never-ceasing ebb and flow of the daily fluctuation. At least we have evolved something of real value to the man whose business is sufficiently extended to make it necessary to foresee the general current of trade. In the chart of the Harvard Committee on Economic Research, for the years from 1903 to 1914 inclusive, the line of speculation is shown as preceding the lines of banking and business. This is a calculation correctly extracted after the event, and such a chart, because of its extreme conservatism and the numerous adjustments made in its construction, will never reach the barometrical value of the stock market averages as recorded from day to day, when considered in the light of Dow's theory of the triple market movement.

### A Prophet Who Knows When to Stop

Those who make a living by giving tips on the stock market are active and conspicuous when the market itself shows similar activity. In dull times they are depressing folk to listen to unless you have a patient sense of humor. In those quiet years between the culmination of the bear market of 1910 and the outbreak of the Great War one of them often deplored to me his inability to predict market movements in a market which has ceased to show profitable fluctuations. But our barometer has nothing to take back

<!-- PAGE:253 -->

or regret. It is almost the only prophet of to-day who stops talking when he has nothing to say. From the studies in the price movement published from time to time in *The Wall Street Journal* I have offered evidence that the bear market in stocks of 1910 was clearly foreseen in the latter part of 1909. The market took a turn for the better after June, 1910.

Although the recovery was slow and hesitating the general trend was upward. There was a secondary reaction of recognizable dimensions about midsummer, 1911. The top of the main movement, however, was in the latter part of 1912, and what is most interesting about the four years before the war is the relatively small extent of any of the fluctuations. The bear market from the latter part of 1909 until the middle of 1910 was well defined, but in both averages was of barely half the extent of the preceding bear market in the panic year of 1907. The following bull market, if it attains quite that dignity, for it was anything but a boom, showed scarcely a third of the range of the preceding bull market which held from the autumn of 1907 to near the end of 1909. Altogether, in these instructive years, we can see a general dwindling movement. Examination of business records for those years will show that there was a corresponding slowing up of activity in trade, not amounting to depression but rather to a dull level of business; not without the improvement to be expected from the country's natural growth; but in no way conspicuous, or strong enough to stimulate any large volume of speculation.

<!-- PAGE:254 -->

### Predicting Small as well as Large Movements

Here again we see another valuable function of our barometer. The major movements do, in this sense, forecast the extent and almost the duration of the coming improvement, or the depth, and even the severity, of the impending business depression. Our discussions of selected periods covered in our twenty-five-year chart have made this sufficiently clear, as anyone can see for himself by comparing the price-movement analyses in previous articles with the subsequent developments in trade. It may be broadly said that business became dull in 1910 and that it did not recover its activity, in any sense greatly worth anticipating in the speculative market, until the boom created by the war.

Here is a period, then, which seems to raise a difficulty for the compilers of business charts, where a certain rhythm is postulated as a normal condition of business. Action and reaction can hardly be called equal in these instructive years, unless it may be the action and reaction of the pendulum of a clock which is running down. Perhaps that is not a bad simile of what took place before the war. It may be said that the demand for war material of all kinds wound up our business clock when it seemed to be slowing down. This is anything but accurate; but it gives a pictorial idea which is useful if not too rigidly applied.

But from the top of the stock market in 1909 we could plot what might be termed, with some show of justice, a bear market lasting nearly five years. It

<!-- PAGE:255 -->

could be called, with a little latitude, a plausible instance of that five-year major swing which Charles H. Dow so hastily assumed when he first formulated his theory. There had unquestionably been over-rapid development of the country's resources, and possibly of its railroad resources, which had culminated in the panic of 1907. We may, I think, cautiously infer that the effects of such major panics as that are not all dissipated by the subsequent and logical stock market rally; as, for instance, that recovery which culminated in 1909. We see that the business of readjustment took much longer.

### Where the Cycle Becomes Useful

Here is a case where the "panic-cycle" theory becomes useful (and it has its proper place), even if it is altogether too vague for helpful application to daily affairs. It is immensely interesting historically, and teaches real lessons when seen in its true perspective. After the panic of 1873 there was some stock market rally, but a subsequent general dwindling of business, under entirely different conditions to those existing to-day but sufficiently like the period we are now discussing to afford a useful parallel. It might almost be said that it was not until the resumption of specie payments (1879) was well in sight that the business of the country picked up, going on to that broader development which was checked by the less severe panic of 1884.

In the same way, the panic of 1893 was followed

<!-- PAGE:256 -->

by a period of depression much longer than that occupied in the break in stocks, although there were narrowing fluctuations up and down which, if charted, would look strikingly like those of the years following the strong stock market rally culminating in 1909. Here we have a uniformity which suggests at least similar laws, governing a movement broader than that of even the major swing which we have been able to deduce by the application of Dow's theory of the stock market movement. We can at least see that it is not a task of months but of years to restore confidence where it has once been successfully assailed.

### Contracting Volume and Its Bearing

It has been pointed out already that business in stocks is always far lighter in a bear market than in a bull market. Our twenty-five-year chart, recording as it does the monthly average of daily stock trading, tells us that speculative business, in the years 1911 to 1914 inclusive, was very little if any better in volume than in the four years preceding the re-election of McKinley. The later period, here under our consideration, was followed by the war boom, an event which upset all calculations. The Harvard Committee on Economic Research does not even chart that period, representing as it does a set of world conditions as abnormal as an earthquake or some such natural phenomenon.

And since the war, and the culmination of what may be called the deflation bear market in June-August, 1921, the volume of business has shown a marked contraction. We are experiencing one of the slowest and least spectacular bull movements of which we have any authentic record. Of the fact of the bull market, anticipated in more than one of these articles when published serially, there can be no manner of doubt. The recovery had extended in April, 1922, to twenty-nine points in the industrials and rather more than two-thirds as much in the railroads, with typical secondary movements. In a strong primary swing the secondary movement is correspondingly vigorous. It is noteworthy that neither the upward major swing nor the secondary movement of 1922 has shown a virility which is, as yet, prophetic of a boom in business, as distinguished from a conservative recovery. The barometer is saying that some recovery is due, but that it will come slowly and will take more than the usual time to establish itself. The prediction is rather of a bull market which will not carry prices to new high records, to put it mildly, than a spectacular movement which foreshadows a large and adventurous development of our industrial resources.

<!-- PAGE:257 -->

### Throttling the Railroads

Readers of **Chapter XVIII**, in which the broad downward movement of railroad stocks over a period of sixteen years was considered, will easily recognize why the extreme conservatism of the stock market at present, even on its recovery, is justified. In our barometer at least, the twenty active railroad stocks represent one-half of our speculative material and record. Our railroads represent the largest single investment of capital in this country, exclusive of farming. The status of these railroads is anything but reassuring. There is nothing to show that more vexatious regulation may not still further restrict their wealth-creating capacity.

We have falsely and foolishly assumed, through our legislators, that 6 per cent is the very maximum of earnings which should be permitted to a railroad stockholder; while he is to take the risk of anything less, down to a receivership. Obviously capital will never go into the development of transportation on any such terms as this. But we cannot establish such utterly discouraging conditions for one-half of the speculative field without injuriously affecting the other half. Who can foresee what politics may not bring forth if we are running into that populistic condition which marked the middle nineties? We are regulating capital out of public utilities of all kinds. Who is to say that this interference with the earning power of capital will not be extended to the great industrial corporations?

<!-- PAGE:258 -->

### Politics in Industry

This is no idle surmise. It has been so extended. It certainly has not been so exercised with any gain to the public. But the action of the Department of Justice against the United States Steel Corporation (now abandoned) shows what can be done if the dangerous theories of the demagogue are to be forced upon business. It is all very well to say that the tendency of modern production is toward concentration, and that commodities will ultimately be cheaper under one management, like that of the Steel Corporation, than under the score or more separate enterprises comprised in that great and beneficent organization. But if the politician's assumption that mere size is in itself an offense is accepted, as it has undoubtedly been accepted in responsible quarters in the past, we may well look upon the course of business in the next half-decade with serious misgiving.

### Mr. Taft's Inherited Policies

It must have been in 1909 or early in 1910 that I saw President Taft at the White House. I pointed out to him how the unrelenting hostility toward the railroads, backed up as it had been by the Administration itself, was paralyzing railroad development, and how our regulatory bodies were adding to the business handicap. Mr. Taft was sympathetic, but cautious. He contended that we could no longer expect the rapid growth of the past, based though it had been upon speculative hope made true by great endeavor. But he said that he was inclined to believe that this was necessarily the price which must be paid for the security of the public through the regulation of these great corporations. This was the "policy" he inherited from Roosevelt, and yet it did not satisfy the Progressives in 1912! It was not a long interview, and that was the end of it. When Mr. Taft, with

<!-- PAGE:259 -->

his unimpeachable honesty, could take that view, what was to be expected of all the little politicians, in the state legislatures and the state regulatory bodies, who were paying off old grudges against the railroads, regardless of the cost to the public?

### Our Voluntary Fetters

What is the worth of these voluntary fetters we have assumed? Is it contended that railroad service has been improved by all this meddling? There is not a dining car to-day which gives meals as good as those provided by Harvey for the Atchison twenty years ago. The "standard railroad meal," established by Mr. McAdoo, is recalled like a nightmare by its victims. The railroads have not recovered the old level of service. Both the Pennsylvania and the New York Central once were able to cut the time between New York and Chicago to sixteen hours. But that time has now lengthened to twenty and twenty-two hours. Are the cars any more comfortable than they were? Are the railroad servants any more civil and obliging? When the railroads could discharge an employee for not keeping a car clean without risking an interminable inquiry before the Labor Board, the cars were kept clean. But we have legislated and regulated the spirit of service out of the railroads. Only in a half-hearted way are they competing in making their own route more attractive than that of their neighbors. What inducement is there for the railroads to spend capital in developing such attractions?

<!-- PAGE:260 -->

Congress has said that they will be robbed of any return from so wise an investment if it exceeds a purely arbitrary figure of 6 per cent—one which makes no real provision for growth out of the earnings.

### A True Psychological Condition

We are not wandering from the point. We are tracing one of the causes of the most significant movement shown in our averages. You cannot hit the railroads without hitting everything else, because the manufacturers of railroad supplies, as represented in the imposing list of the Railway Business Association, constitute a part of our national manufacturing industry so large that it swings all industry with it. If there is one word which has grown wearisome, from constant use and misuse in the era of quackery from which we are only slowly emerging, that word is “psychology.” But here is a true psychological condition. We have lost trust in ourselves. We have meddled so disastrously with the law of supply and demand that we cannot bring ourselves to the radical step of letting it alone.

You cannot have real freedom in a country where you have no freedom in business. There is no tyranny so hard, because none so stupid, as that of bureaucracy. Take a single illustration: President Rea of the Pennsylvania, not so long ago, asked me how many reports I supposed his railroad made to departments in Washington, principally the Interstate Commerce Commission, in a single year? Knowing how ample that rail-

<!-- PAGE:261 -->

road's reports are, I said that it might be safe to take five hundred a year, as all that were really needed, and multiply that figure by twenty; and ventured, on that basis, an estimate of ten thousand reports for a single year. Mr. Rea laughed ruefully. He said, "Last year we made one hundred and fourteen thousand reports for our lines east of Pittsburgh alone!"

### A Reform or a Revolution?

And that was for part of one railroad! Multiply that by all the railroads in the country and see what bureaucratic red tape can do in tying up a great utility's service and impairing its efficiency. We have just begun, thanks to General Dawes, to import a little common sense into Washington business methods. But manifestly he has only scratched the surface. The reform which is needed almost amounts to a revolution, for we are to remember that the Department of Commerce and the Department of Labor, to name only two, are making their demands for more light and more figures, more stationery and more wasted time, upon the general business of the country.

### One Handicap and Its Consequences

It is a self-imposed handicap. We have only ourselves to thank. Look at what I have recorded of President Taft's acceptance of the position twelve years ago. Who is to take the Old Man of the Sea off Sinbad's shoulders? How can we expect a general

<!-- PAGE:262 -->

boom in business, or a restoration of the railroads to their old conditions of vigor and growth, so long as the politician can inflict such handicaps as these? We are all hit by it. It hits the farmer in Nebraska, who is burning corn because it works out cheaper per ton than coal. It is hitting our foreign trade. Ours are the largest coal resources in the world, but Great Britain is actually landing coal in this country. She has already supplanted us where we were able, through the war, to build up foreign trade. The attitude of Congress toward business is not merely a development of the insane prejudice against the railroads. It amounts, when analyzed, to the bolshevist idea of fettering success—of making large individual wealth impossible. Enterprise will be attacked in the legislatures, not because there is a speculative danger but because, in the development of the country, some individuals may grow rich. You cannot keep those individuals poor without keeping the country poor. Are we to try again the experiment which was made during the second Cleveland administration? Is that era of Populism and depression, of entire lack of confidence or trust in ourselves, what we shall run into when the present bull market culminates and begins to give signals on the bear side?