# MANIPULATION AND PROFESSIONAL TRADING

# MANIPULATION AND PROFESSIONAL TRADING

<!-- PAGE:68 -->

## MANIPULATION AND PROFESSIONAL TRADING

Readers of preceding chapters may well pause here to take count of how much we have been able to infer, and how much of our inference we have been able to prove, starting on the sound basis of Dow's theory of the stock market. We have satisfied ourselves that he was right when he said that there are in progress three definite movements in the market—the major swing, upwards or downwards; its occasional suspension by a secondary rally or reaction, as the case may be; and the incalculable, and for our purposes largely negligible, daily fluctuation. We can satisfy ourselves from examples that a period of trading within a narrow range—what we have called a “line”—gaining significance as the number of trading days increases, can only mean accumulation or distribution, and that the subsequent price movement shows whether the market has become bare of stocks or saturated with an oversupply.

But we have been able to go further than this. From the preceding article alone we see that every major swing is justified by the subsequent condition of the country's general business. It has neither needed nor received manipulation. The market consequently has

<!-- PAGE:69 -->

often seemed to run counter to business conditions, but only for the reason which represents its greatest usefulness. It is then fulfilling its true function of prediction. It is telling us not what business is to-day but what the future course of business will be. News known is news discounted. What everybody knows has ceased to be a market factor, except in the rare instance of a panic, when the stock market is confessedly taken by surprise.

When these articles appeared in serial form in *Barron's*, the national financial weekly, I included the following inference, based upon the reading of our barometer, on September 18, 1921, the date when the quoted paragraph was written. It appeared on November 5, 1921. It was no guess, but a scientific deduction from sound premises, and correctly announced the change in the main direction of the market.

> “There is a pertinent instance and test in the action of the current market. I have been challenged to offer proof of the prediction value of the stock market barometer. With the demoralized condition of European finance, the disaster to the cotton crop, the uncertainties produced by deflation, the unprincipled opportunism of our lawmakers and tax-imposers, all the aftermath of war inflation—unemployment, uneconomic wages in coal mining and railroading—with all these things overhanging the business of the country at the present moment, the stock market has acted as if there were better things in sight. It has been saying that the bear market which set in at the end of October and the beginning of November, 1919, saw its low point on June 20, 1921, at 64.90 for the twenty industrials and 65.52 for the twenty railroad stocks.”

<!-- PAGE:70 -->

### A Contemporary Example

At the beginning of the last week of August, 1921, it looked as if the bear market might be resumed by the establishment of new low points in both averages. But remembering that the averages must confirm each other, *The Wall Street Journal* said, on August 25th:

> "So far as the averages are concerned, they are far from encouraging to the bull, but they do not yet jointly indicate a definite resumption of the main bear movement."

The railroad stocks were forming a "line" at that time, and after a technical break of a fraction of a point through on the lower side it was resumed, and no new low point, indicating a definite resumption of the main bear movement, was given. On September 21st, after a remarkable continuance of the line of probable accumulation in the railroad stocks and a confirmatory rally in the industrials, *The Wall Street Journal*'s "Study in the Price Movement" said:

> "It is beside the point to say that we are facing a hard winter. The stock market is meaningless if it does not look beyond such contingencies. It seems to be forecasting a solid foundation for better general business in the spring. It may well be that the stage for a primary bull market is being set."

By that time both the industrials and the railroads had well-developed lines of presumed accumulation, and the former had significantly made a higher point than that of the previous rally. *The Wall Street Journal*'s analysis of October 4th said:

> "By the well-tried methods of reading the stock market averages, only a decline of eight points in the industrial average,

<!-- PAGE:71 -->

and nine points in the railroads, or below the low figures of the main bear movement recorded June 20th, would indicate a resumption of that movement. On the other hand, the railroad stocks alone at present figures would need to advance less than a point to record the repeated new high for both averages which would indicate a primary bull market. The industrials have already recorded that point, and both averages have shown a remarkably clear and distinct line of accumulation which is likely at any time to disclose a market bereft of its floating supply of stocks."

In the last paragraph of this closely reasoned analysis it was said:

> "Prices are low because all these bearish factors our critics adduce have been discounted in the prices. When the market is taken by surprise there is a panic, and history records how seldom it is taken by surprise. To-day all the bear factors are known, serious as they admittedly are. But the stock market is not trading on what is common knowledge to-day but upon the sum of expert knowledge applied to conditions as they can be foreseen many months ahead."

### Henry H. Rogers and His Critics

Here is the application of our theory, and the reader can judge from the subsequent course of the market the value of the stock market barometer. He can even make the same analysis for himself, given the same major premise and carefully tested reasoning from it.

The professional speculator might well encourage the general belief that he is invulnerable and invincible, even if an ignorant public assumes that the cards are stacked against itself and that the professional knows

<!-- PAGE:72 -->

their backs as well as their faces. Many years ago the late Henry H. Rogers, who was not talking for publication, said to me: "The sensational newspapers, which are always attacking John D. Rockefeller and his associates for their wealth, have put millions into the treasury of the Standard Oil Company. You and I know that we are not omniscient or all-powerful. But, by editorial innuendo and suggestion in cartoons, the people who hold us up to popular envy and hate have created exactly that impression. When everybody who may have to do business with us assumes in advance that we can dictate our own terms, we have an invaluable business asset." The same agitation brought about the dissolution of the Standard Oil into its thirty-three constituent companies. That operation trebled the value of Standard Oil shares, and, incidentally, the price of gasoline. Perhaps these newspaper proprietors were holders of the stock. That was before the era of the Ford car, however, and they may have assumed that it was a public service to make the rich owner of a motor car pay more for his gasoline.

### A Speculator's Reasoning

Assumption of an unfair advantage for the professional is absolutely baseless. The reasoning of a professional like Jesse Livermore is merely the reasoning presented in this and preceding articles, backed by a study of general conditions. He said on October 3, 1921, that he had been buying, and, giving him the credence of ordinary courtesy for such a voluntary

<!-- PAGE:73 -->

statement, it is clear that he was trying to shape in his own mind what the investing and speculating public would think at a date as far ahead as he could see.

This is not manipulation. These speculators are not creating any false market or deceptive appearance of activity to lure the public into the game, like the "barker" outside a Midway show. On October 3d Jesse Livermore was quoted in the columns of *Barron's* as saying that "all market movements are based on sound reasoning. Unless a man can anticipate future events his ability to speculate successfully is limited." And he went on to add: "Speculation is a business. It is neither guesswork nor a gamble. It is hard work and plenty of it."

### Dow's Clear Definition

Let us compare this with the words of Charles H. Dow in *The Wall Street Journal* twenty years before. In the editorial of July 20, 1901, he said:

> "The market is not like a balloon plunging hither and thither in the wind. As a whole, it represents a serious, well-considered effort on the part of farsighted and well-informed men to adjust prices to such values as exist or which are expected to exist in the not too remote future. The thought with great operators is not whether a price can be advanced, but whether the value of property which they propose to buy will lead investors and speculators six months hence to take stock at figures from ten to twenty points above present prices."

Observe how the none too deftly expressed thought of Livermore parallels the more perfectly shaped definition of the detached and dispassionate Dow. Ber-

<!-- PAGE:74 -->

nard M. Baruch, after the war, gave evidence before a Congressional committee as to a market operation by which he had largely profited. He showed in the simplest manner that he had merely analyzed a known cause and foreseen clearly its probable market effect. He showed, what nobody who knows him would question, that he had no "inside information," so called, and that no employee in a Washington department had sold the secrets of his office. Wall Street holds such secrets as of little value. They may give an unfair advantage so far as individual stocks are concerned, but they could be entirely neglected with imperceptible loss, even if the secret were not generally as worthless as the seller of it.

### A Good Loser—

What is there that was done by James R. Keene or Jay Gould, by Addison Cammack or other great market figure of the past, which could not have been done, in the fairest way, by men of equal brains and intelligence, willing to pay the price of arduous study for the knowledge necessary to success? What is there that Jesse Livermore or Bernard M. Baruch do which is open to criticism? They pay the seller his price, but they do not accept stock sold "with a string to it." The vendor thinks his reasons for selling as good as theirs for buying what he sells. If he were a jobber in the woolen trade, selling his investment in American Woolen stock, or a banker selling United States Steel common on the devastating foreign competition which he thinks he foresees, he would consider his own

<!-- PAGE:75 -->

sources of information better than those of the speculators. They take the same risks that he does. They are often wrong, but they do not whimper about it. I have known many operators of this kind, and I never heard them whine when they lost, or boast greatly when they won.

### —and a Bad One

But the little gambler who takes the gutter view of Wall Street pits his wits against trained minds, not merely those of the speculators and the professional traders on the floor of the Stock Exchange, but the minds of men whose business requires them to study business conditions. This kind of gambler is a bad loser, and is often highly articulate. He, or those dependent upon him, is lucky if he receives such a lesson at his first venture that he confines his future relation with Wall Street to denouncing it as a gambling hell. It would be all that if the stock market were made by him or people like him. To the everlasting credit of the country, we may confidently assume that it is not.

### Refusing a Partnership With Jay Gould

Charles H. Dow, who knew Jay Gould well and enjoyed his confidence as much as any newspaper man of the time, largely because of his incorruptible independence, says in one of his editorials that Gould based his position in the stock market primarily on values. He tested that market with purchases of sufficient stock to show whether there was a public

<!-- PAGE:76 -->

response—whether he had correctly foreseen the public appreciation of values which he thought he had recognized. If the response was not what he expected he would not hesitate to take loss after loss of a point or so, in order to reconsider his position from a detached point of view. Some years ago there was a pathetic derelict in New Street, one of the unlovely fringe of any speculative market, who could truthfully say that he had once been offered a partnership by Jay Gould. I have missed his face in recent years, but not a great many years ago he was a promising young member of the Stock Exchange. His execution of orders on the floor was remarkably good. It is a difficult and exacting task. It requires about that combination of instantaneous judgment and action which would mark a star player in big-league baseball.

To this broker a number of Jay Gould's orders were entrusted. No broker, it is needless to say, saw all of them. Gould was so pleased with the way his business was done that he sent for the young man and offered him a limited partnership. To Mr. Gould's surprise, it was refused. The broker actually said: "Mr. Gould, I have executed a great many of your orders and you seem to me to make more losses than profits. That is not a business I want to share." He could not see that his vision was restricted to only one side of Gould's many-sided activities. Opportunity knocked at his door—tried to kick it in—but the young man showed that he could do only one thing well. His administrative judgment would have been worthless, as indeed it afterwards proved, for he drifted out of

<!-- PAGE:77 -->

the Stock Exchange into New Street and from there, I suppose, into oblivion. Truly, many are called but few are chosen.

### An Intelligent Trader

Rare talent of any kind commands great rewards for the reason that it is rare. The amateur who regards the market as a gamble starts wrong. He holds on when he is losing and takes small profits, to his continuing regret, when the market is going his way. The speculators he envies, those he charges with cogging the dice and marking the cards, exactly reverse his process. However strong their conviction may be they run quickly when the market does not agree with them or justify the inferences they have drawn. They may be, as Gould often was, too far ahead of the market. One of the most intelligent men I ever met in Wall Street, not long dead, was a former teacher and a fine classical scholar, whose hobby was collecting rare coins but whose business was speculation. He saved no market turns or broker's commissions by partnership in a Stock Exchange house. He was just a speculator, sitting before a customers' board or near a stock ticker. And yet that man, by judgment, study, nerve tempered by caution and, above all, a readiness to see his error quickly, never made less than $30,000 a year; dying at a good age, leaving a comfortable fortune and a collection of rare coins which brought excellent prices.

He would select his stocks on analyzed value and study the market movement. He would buy with con-

<!-- PAGE:78 -->

fidence but always well within his means. He would take a two-point loss on a thousand shares of stock without hesitation if the market did not move his way. When that discouragement happened he said that he could not form a correct judgment unless he got out and took an objective view. He had originally about the capital which would have been necessary to pay for the education of a doctor or a lawyer, or to start them in business. He gave his undivided but by no means selfish attention to what he had made his business. He was always long of stocks early in a bull market, and in its last stages he generally made a trip to Europe to add to his collection of coins. He was no solitary instance. I could name others like him. But I am not advising any man to speculate, even if he has the moral stamina to comply with the same exacting requirements. If you have a business that you like, one which keeps you comfortably with a margin for the unforeseen, why speculate in stocks? I don't.

### The Dial of the Boiler

Some intelligent and many irrelevant questions have been put since these discussions began, and one of them, which has something of both qualities, disputes the economic necessity for the professional speculator. I am not to be drawn into a discussion of academic economics and still less into one of abstract ethical questions. I am describing the stock market barometer as it is and the great and useful service it performs. It is necessary, therefore, to explain its by no means com-

<!-- PAGE:79 -->

plicated machinery. It is neither as simple as the crude three-foot tube with its column of mercury nor so complex as the highly perfected aneroid instrument. The question whether I would be willing myself to discharge the functions of a professional speculator is beside the point. We do not need to go back to the formal logic of the Greeks twenty-four centuries ago to know that there can be no argument on matters of taste.

Every bit as important as production is distribution, and distribution of capital is the greatest function of Wall Street. The professional speculator is no more superfluous than the pressure gauge of the steam-heating plant in your cellar. Wall Street is the great financial power house of the country, and it is indispensably necessary to know when the steam pressure is becoming more than the boilers can stand. It is important here to avoid getting our metaphors mixed, but the safety valve will occur to anybody. The stock market is all that and more; and the professional speculator, however ignoble or material his motives may be, is a useful and highly dependable part of that machinery. That he may grow rich in the process is neither here nor there, unless we are to adopt the bolshevist doctrine that personal wealth is wicked. There is another doctrine, held by many who would resent the epithet of bolshevism, which is in any country much more dangerous. It holds wealth, with the power it brings, as a thing for envy and not for emulation; that if we cannot legislate everybody rich it is demonstrably possible to legislate everybody poor. One short way

<!-- PAGE:80 -->