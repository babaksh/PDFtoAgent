import json
import math
from typing import Any, Dict, List, Optional


def _mean(values: List[float]) -> float:
    return sum(values) / float(len(values)) if values else 0.0


def _correlation(a: List[float], b: List[float]) -> float:
    n = len(a)
    if n < 2:
        return 0.0
    ma = _mean(a)
    mb = _mean(b)
    cov = sum((a[i] - ma) * (b[i] - mb) for i in range(n))
    va = sum((a[i] - ma) ** 2 for i in range(n))
    vb = sum((b[i] - mb) ** 2 for i in range(n))
    if va <= 0.0 or vb <= 0.0:
        return 0.0
    return cov / math.sqrt(va * vb)


def _swings(series: List[float], min_reversal_pct: float) -> List[Dict[str, Any]]:
    swings: List[Dict[str, Any]] = []
    n = len(series)
    if n < 2:
        return swings
    reversal = min_reversal_pct
    pivot = 0
    direction = 0
    ext_idx = 0
    for i in range(1, n):
        price = series[i]
        if direction == 0:
            if series[pivot] and price >= series[pivot] * (1.0 + reversal):
                direction = 1
                ext_idx = i
            elif series[pivot] and price <= series[pivot] * (1.0 - reversal):
                direction = -1
                ext_idx = i
            continue
        if direction > 0:
            if price > series[ext_idx]:
                ext_idx = i
            elif price <= series[ext_idx] * (1.0 - reversal):
                swings.append(_make_swing(series, pivot, ext_idx, "up"))
                pivot = ext_idx
                direction = -1
                ext_idx = i
        else:
            if price < series[ext_idx]:
                ext_idx = i
            elif price >= series[ext_idx] * (1.0 + reversal):
                swings.append(_make_swing(series, pivot, ext_idx, "down"))
                pivot = ext_idx
                direction = 1
                ext_idx = i
    if ext_idx > pivot:
        swings.append(
            _make_swing(series, pivot, ext_idx, "up" if direction > 0 else "down")
        )
    return swings


def _make_swing(
    series: List[float], start_idx: int, end_idx: int, direction: str
) -> Dict[str, Any]:
    start = series[start_idx]
    end = series[end_idx]
    return {
        "start_idx": start_idx,
        "end_idx": end_idx,
        "direction": direction,
        "length_periods": end_idx - start_idx,
        "change_pct": (end - start) / start if start else 0.0,
    }


def _classify_movements(
    series: List[float], periods_per_year: float, min_primary_months: float,
    min_secondary_months: float, min_reversal_pct: float,
) -> Dict[str, Any]:
    swings = _swings(series, min_reversal_pct)
    months_per_period = 12.0 / periods_per_year if periods_per_year else 0.0
    counts = {"primary": 0, "secondary": 0, "daily": 0}
    labelled: List[Dict[str, Any]] = []
    for swing in swings:
        months = swing["length_periods"] * months_per_period
        swing["months"] = months
        if months >= min_primary_months:
            kind = "primary"
        elif months >= min_secondary_months:
            kind = "secondary"
        else:
            kind = "daily"
        swing["movement"] = kind
        counts[kind] += 1
        labelled.append(swing)

    daily_range = 0.0
    if len(series) > 1:
        ratios = []
        for i in range(1, len(series)):
            if series[i - 1]:
                ratios.append(abs(series[i] - series[i - 1]) / series[i - 1])
        daily_range = max(ratios) if ratios else 0.0

    has_primary = counts["primary"] >= 1
    has_secondary = counts["secondary"] >= 1
    has_daily = daily_range > 0.0 or counts["daily"] >= 1

    return {
        "num_swings": len(swings),
        "movement_counts": counts,
        "has_primary": has_primary,
        "has_secondary": has_secondary,
        "has_daily": has_daily,
        "three_movements_present": has_primary and has_secondary and has_daily,
        "longest_swing_months": (
            max([s["months"] for s in labelled]) if labelled else 0.0
        ),
        "daily_fluctuation_pct": daily_range,
        "swings": labelled,
    }


async def foreign_list_representative_group_average_check(
    groups: List[Dict],
    domestic_average: Optional[List[float]] = None,
    periods_per_year: float = 12.0,
    min_primary_months: float = 9.0,
    min_secondary_months: float = 1.0,
    min_reversal_pct: float = 0.05,
    min_correlation: float = 0.7,
    min_sign_agreement: float = 0.6,
    verbose: bool = True,
) -> str:
    """Compile representative group averages from a non-US securities list, show that
    they exhibit the same primary, secondary and daily movements, and test whether a
    group average corroborates the domestic benchmark.

    Use when you hold price series drawn from a foreign list -- British railroads,
    London industrials, Kaffir/South African gold mines -- and want to know whether
    Dow's law transfers to that market: pass each representative group as
    {"name": ..., "series": [...] } (one series per constituent, all the same length)
    and optionally the domestic average to corroborate against. The tool averages each
    group across its constituents, breaks the group average into swings, labels each
    swing primary / secondary / daily by its duration (the chapter's own taxonomy:
    primary swings run from less than a year to three years or more, secondary
    reactions or rallies interrupt them, daily fluctuation is always present), and then
    tests each group average against the domestic average on the overlapping window.

    Extends average_corroboration_check (chCYCLES AND STOCK MARKET RECORDS): that tool
    compares two given averages; this one adds the prior step of CONSTRUCTING the
    representative group averages from a foreign securities list and the three-movement
    exhibition, so corroboration is sought between a constructed foreign group average
    and the domestic average rather than between two given averages.

    Inputs: groups (list of {"name", "series": [ [prices per constituent] ]} or
    {"name", "prices": [prices]} ), domestic_average (the domestic benchmark series,
    optional), periods_per_year (12 monthly, 252 daily),     min_primary_months (9 = the
    chapter's "from less than a year"), min_secondary_months (1), min_reversal_pct (5%,
    the swing filter), min_correlation and
    min_sign_agreement (corroboration cutoffs).
    Do NOT use this to test a market's reaction to a single event -- for that use
    manipulation_shock_deflection_test.
    """
    provenance = {
        "source_grounded": [
            "compile two or more representative groups from a foreign securities list",
            "exhibit the primary, secondary and daily movements of each group average",
            "primary swings extend from less than a year to three years or more",
            "a foreign average (e.g. British railroads) may confirm the domestic average",
            "the law would be equally true of London, Paris or Berlin",
        ],
        "model_extrapolated": [
            "min_primary_months default of 9 months from 'less than a year to three years or more'",
            "min_secondary_months default of 1 month",
            "min_reversal_pct default of 5% as the swing segmentation filter",
            "equal-weighted arithmetic mean across constituents as the group average",
            "corroboration cutoffs: min_correlation=0.7, min_sign_agreement=0.6",
            "swing segmentation by consecutive direction changes",
        ],
    }

    def payload(result: Dict[str, Any]) -> str:
        return json.dumps(
            {"result": result, "error": None, "metadata": {"provenance": provenance}}
        )

    try:
        ppy = 12.0 if periods_per_year is None else float(periods_per_year)
        if ppy <= 0:
            ppy = 12.0
        min_prim = (
            9.0 if min_primary_months is None else float(min_primary_months)
        )
        min_sec = 1.0 if min_secondary_months is None else float(min_secondary_months)
        min_rev = 0.05 if min_reversal_pct is None else float(min_reversal_pct)
        min_corr = 0.7 if min_correlation is None else float(min_correlation)
        min_sign = 0.6 if min_sign_agreement is None else float(min_sign_agreement)

        domestic: List[float] = []
        if domestic_average:
            domestic = [float(v) for v in domestic_average if v is not None]

        group_reports: List[Dict[str, Any]] = []
        for position, group in enumerate(groups or []):
            if not isinstance(group, dict):
                continue
            name = group.get("name", "group_%d" % position)
            constituents: List[List[float]] = []
            raw = group.get("constituents")
            if raw is None:
                raw = group.get("series")
            if isinstance(raw, dict):
                raw = list(raw.values())
            if raw:
                for item in raw:
                    if isinstance(item, dict):
                        prices = item.get("prices")
                        if prices is None:
                            prices = item.get("series")
                        if prices:
                            constituents.append([float(v) for v in prices])
                    elif isinstance(item, (list, tuple)):
                        constituents.append([float(v) for v in item])
                    else:
                        constituents.append([float(item)])
            if not constituents:
                prices = group.get("prices")
                if prices:
                    constituents.append([float(v) for v in prices])

            if not constituents:
                report: Dict[str, Any] = {
                    "name": name,
                    "num_constituents": 0,
                    "length": 0,
                    "movement_counts": {"primary": 0, "secondary": 0, "daily": 0},
                    "has_primary": False,
                    "has_secondary": False,
                    "has_daily": False,
                    "three_movements_present": False,
                    "corroborates_domestic": False,
                    "verdict": "unmeasurable",
                    "reason": "No price series were supplied for this group.",
                }
                group_reports.append(report)
                continue

            length = min(len(c) for c in constituents)
            if length == 0:
                report = {
                    "name": name,
                    "num_constituents": len(constituents),
                    "length": 0,
                    "movement_counts": {"primary": 0, "secondary": 0, "daily": 0},
                    "has_primary": False,
                    "has_secondary": False,
                    "has_daily": False,
                    "three_movements_present": False,
                    "corroborates_domestic": False,
                    "verdict": "unmeasurable",
                    "reason": "This group has no usable observations.",
                }
                group_reports.append(report)
                continue

            average = [_mean([c[i] for c in constituents]) for i in range(length)]
            movements = _classify_movements(average, ppy, min_prim, min_sec, min_rev)

            report = {
                "name": name,
                "num_constituents": len(constituents),
                "length": length,
                "movement_counts": movements["movement_counts"],
                "has_primary": movements["has_primary"],
                "has_secondary": movements["has_secondary"],
                "has_daily": movements["has_daily"],
                "three_movements_present": movements["three_movements_present"],
                "longest_swing_months": movements["longest_swing_months"],
                "daily_fluctuation_pct": movements["daily_fluctuation_pct"],
            }

            overlap = min(length, len(domestic)) if domestic else 0
            if overlap >= 2:
                foreign_tail = average[length - overlap :]
                domestic_tail = domestic[len(domestic) - overlap :]
                f_rets = [
                    (foreign_tail[i] - foreign_tail[i - 1]) / foreign_tail[i - 1]
                    for i in range(1, overlap)
                    if foreign_tail[i - 1]
                ]
                d_rets = [
                    (domestic_tail[i] - domestic_tail[i - 1]) / domestic_tail[i - 1]
                    for i in range(1, overlap)
                    if domestic_tail[i - 1]
                ]
                m = min(len(f_rets), len(d_rets))
                if m >= 2:
                    f_rets = f_rets[-m:]
                    d_rets = d_rets[-m:]
                    corr = _correlation(f_rets, d_rets)
                    agreement = (
                        sum(
                            1
                            for i in range(m)
                            if (f_rets[i] > 0 and d_rets[i] > 0)
                            or (f_rets[i] < 0 and d_rets[i] < 0)
                            or (f_rets[i] == 0 and d_rets[i] == 0)
                        )
                        / float(m)
                    )
                else:
                    corr = 0.0
                    agreement = 0.0
                corroborates = (
                    corr >= min_corr
                    and agreement >= min_sign
                    and movements["three_movements_present"]
                )
                report.update(
                    {
                        "correlation": corr,
                        "sign_agreement": agreement,
                        "overlap_periods": overlap,
                        "corroborates_domestic": corroborates,
                        "verdict": "corroborated" if corroborates else "not_corroborated",
                        "reason": (
                            "Group average of %d constituents shows primary, secondary and daily "
                            "movements and agrees with the domestic average (correlation %.4g, sign "
                            "agreement %.4g), so Dow's law transfers to this market and the foreign "
                            "average confirms our own."
                            % (len(constituents), corr, agreement)
                            if corroborates
                            else "Group average of %d constituents does not meet the corroboration bar "
                            "(three movements present: %s; correlation %.4g against %.4g; sign "
                            "agreement %.4g against %.4g)."
                            % (
                                len(constituents),
                                movements["three_movements_present"],
                                corr,
                                min_corr,
                                agreement,
                                min_sign,
                            )
                        ),
                    }
                )
            else:
                report.update(
                    {
                        "correlation": None,
                        "sign_agreement": None,
                        "overlap_periods": overlap,
                        "corroborates_domestic": False,
                        "verdict": "no_benchmark",
                        "reason": (
                            "No domestic average of usable length was supplied, so corroboration is "
                            "unmeasured; only the three-movement exhibition was performed."
                            if not domestic
                            else "The group average and the domestic average do not overlap on at "
                            "least two periods, so corroboration cannot be measured."
                        ),
                    }
                )

            if verbose:
                report["group_average"] = average
                report["swings"] = movements["swings"]
            group_reports.append(report)

        if not group_reports:
            return payload(
                {
                    "num_groups": 0,
                    "groups": [],
                    "all_groups_show_three_movements": False,
                    "corroborating_groups": [],
                    "dow_law_transfers": False,
                    "verdict": "unmeasurable",
                    "reason": "No representative groups were supplied, so no foreign group average can be compiled.",
                }
            )

        all_three = all(g["three_movements_present"] for g in group_reports)
        corroborating = [
            g["name"] for g in group_reports if g["corroborates_domestic"]
        ]
        transfers = all_three and len(corroborating) >= 1

        if not group_reports:
            verdict = "unmeasurable"
        elif not all_three:
            verdict = "three_movements_not_shown"
        elif not domestic:
            verdict = "three_movements_shown_benchmark_absent"
        elif not corroborating:
            verdict = "not_corroborated"
        else:
            verdict = "corroborated"

        result: Dict[str, Any] = {
            "num_groups": len(group_reports),
            "all_groups_show_three_movements": all_three,
            "corroborating_groups": corroborating,
            "dow_law_transfers": transfers,
            "verdict": verdict,
            "reason": (
                "All %d compiled group averages exhibit primary, secondary and daily movements and %d "
                "of them corroborate the domestic average, so Dow's law transfers to this foreign market."
                % (len(group_reports), len(corroborating))
                if transfers
                else "Dow's law is not established for this list: all-groups-three-movements=%s, "
                "corroborating groups=%d of %d."
                % (all_three, len(corroborating), len(group_reports))
            ),
            "groups": group_reports,
        }
        if not verbose:
            result["groups"] = [
                {
                    k: v
                    for k, v in g.items()
                    if k not in ("group_average", "swings")
                }
                for g in group_reports
            ]
        return payload(result)
    except Exception as exc:  # noqa: BLE001 - contract requires a JSON error payload
        return json.dumps(
            {
                "result": None,
                "error": "%s: %s" % (type(exc).__name__, exc),
                "metadata": {"provenance": provenance},
            }
        )