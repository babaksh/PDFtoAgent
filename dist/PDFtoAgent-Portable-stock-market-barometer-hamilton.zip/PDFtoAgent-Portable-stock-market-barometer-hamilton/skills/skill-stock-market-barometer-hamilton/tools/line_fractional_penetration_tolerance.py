import json
from typing import List, Optional


async def line_fractional_penetration_tolerance(
    prices: List[float],
    line_low: float,
    line_high: Optional[float] = None,
    tolerance_points: float = 1.0,
    verbose: bool = True,
) -> str:
    """Judge whether a dip through the lower side of a Dow-theory 'line' is only a technical break.

    Use when an average has been making a line (a narrow trading range) and has dipped BELOW the
    line's lower side, and you must decide whether that dip invalidates the line. This chapter
    states the tolerance: a penetration of 'a fraction of a point' through the lower side is a
    mere technical break which leaves the line intact, and the line is then resumed -- no new low
    point is given and the bear movement is NOT resumed. Only a DECISIVE penetration beyond that
    fraction ends the line and establishes a new low point.

    Inputs: prices (the average's price path covering the dip through the lower side),
    line_low (the lower side of the trading-range line), line_high (optional upper side, echoed
    back and used to test whether the average returned inside the range), and tolerance_points
    (the 'fraction of a point'; default 1.0, i.e. anything under a full point).

    Do NOT use this to DETECT the line itself -- call line_formation_breakout (chCYCLES AND
    STOCK MARKET RECORDS) first, then feed its lower bound in here. Do NOT use it for an upside
    breakout through the upper side; this rule is stated for the lower side only.
    Depends on: line_formation_breakout (chCYCLES AND STOCK MARKET RECORDS) -- this tool supplies
    the missing tolerance that tool lacks.
    """

    try:
        series = [float(p) for p in (prices or []) if p is not None]
        low_side = 0.0 if line_low is None else float(line_low)
        high_side = None if line_high is None else float(line_high)
        tol = 1.0 if tolerance_points is None else float(tolerance_points)
        if tol < 0.0:
            tol = 0.0

        if not series:
            result = {
                "verdict": "no_penetration",
                "reason": "No price data supplied: no dip through the lower side of the line is observed, so the line stands undisturbed.",
                "penetration_points": 0.0,
                "tolerance_points": tol,
                "decisive": False,
                "line_intact": True,
                "line_resumed": False,
                "new_low_made": False,
                "periods": 0,
            }
            return json.dumps({
                "result": result,
                "error": None,
                "metadata": {"provenance": {
                    "source_grounded": [
                        "a penetration of a fraction of a point through the lower side is a technical break",
                        "the line is then resumed and no new low point is given",
                        "a decisive penetration ends the line",
                    ],
                    "model_extrapolated": [
                        "numeric value of 'a fraction of a point' set to tolerance_points=1.0",
                        "no_penetration reading returned for an empty series",
                    ],
                }},
            })

        min_price = min(series)
        trough_index = series.index(min_price)
        penetration = max(0.0, low_side - min_price)

        # decisive penetration: beyond the stated fraction of a point
        decisive = bool(penetration > tol)

        # resumption: after the trough the average gets back to (or above) the lower side
        after = series[trough_index + 1:]
        resumed = bool(after and any(p >= low_side for p in after))
        if resumed:
            resumed_after_periods = next(i + 1 for i, p in enumerate(after) if p >= low_side)
        else:
            resumed_after_periods = None

        last_price = series[-1]
        back_inside = bool(
            last_price >= low_side and (high_side is None or last_price <= high_side)
        )

        if penetration <= 0.0:
            verdict = "no_penetration"
            reason = (
                "The average never traded through the lower side of the line: the line is intact "
                "and no break, technical or decisive, has occurred."
            )
        elif decisive:
            verdict = "line_ended"
            reason = (
                "The penetration of %s points exceeds the fraction-of-a-point tolerance of %s "
                "points: this is a decisive penetration, the line is ended and a new low point is "
                "established." % (_fmt(penetration), _fmt(tol))
            )
        else:
            verdict = "technical_break_line_intact"
            reason = (
                "The penetration of %s points is no more than a fraction of a point (tolerance %s "
                "points): a technical break only, which does not invalidate the line. %s"
                % (
                    _fmt(penetration),
                    _fmt(tol),
                    "The line was resumed, so no new low point was given."
                    if resumed
                    else "The line has not yet been resumed; the break stands as technical until it is.",
                )
            )

        line_intact = bool(not decisive)
        new_low_made = bool(decisive)

        compact = {
            "verdict": verdict,
            "penetration_points": penetration,
            "tolerance_points": tol,
            "decisive": decisive,
            "line_intact": line_intact,
            "line_resumed": resumed,
            "new_low_made": new_low_made,
        }
        if not verbose:
            result = compact
        else:
            result = dict(compact)
            result.update({
                "reason": reason,
                "line_lower_side": low_side,
                "line_upper_side": high_side,
                "lowest_price_seen": min_price,
                "trough_index": trough_index,
                "last_price": last_price,
                "resumed_after_periods": resumed_after_periods,
                "back_inside_line": back_inside,
                "periods_examined": len(series),
                "tolerance_headroom_points": max(0.0, tol - penetration),
            })

        return json.dumps({
            "result": result,
            "error": None,
            "metadata": {"provenance": {
                "source_grounded": [
                    "a penetration of a fraction of a point through the lower side is a technical break",
                    "the line is then resumed and no new low point is given",
                    "only a decisive penetration beyond that fraction ends the line",
                ],
                "model_extrapolated": [
                    "numeric value of 'a fraction of a point' set to tolerance_points=1.0",
                    "resumption tested as any close back at or above the lower side after the trough",
                    "verdict label set: no_penetration / technical_break_line_intact / line_ended",
                    "no_penetration reading returned for an empty series",
                ],
            }},
        })
    except Exception as exc:  # pragma: no cover - defensive
        return json.dumps({
            "result": None,
            "error": "line_fractional_penetration_tolerance failed: %s" % exc,
            "metadata": {"provenance": {
                "source_grounded": [],
                "model_extrapolated": ["error-handling path"],
            }},
        })


def _fmt(x: Optional[float]) -> str:
    return "n/a" if x is None else ("%.2f" % x)