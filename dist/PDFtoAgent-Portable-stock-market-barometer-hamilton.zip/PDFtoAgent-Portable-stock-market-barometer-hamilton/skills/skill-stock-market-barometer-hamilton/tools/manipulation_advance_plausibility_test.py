"""Grade whether an alleged manipulation is plausible given the primary trend."""

import json
from typing import Any, Dict, List, Optional


def _normalize_direction(value: Any) -> Optional[str]:
    """Three-way read of a direction label: 'up', 'down', or None when the label
    carries no direction (absent, empty or unrecognised)."""
    text = str(value if value is not None else "").strip().lower()
    if text in ("down", "d", "bear", "bearish", "fall", "falling", "decline", "declining", "negative", "-1", "-"):
        return "down"
    if text in ("up", "u", "bull", "bullish", "rise", "rising", "advance", "advancing", "positive", "1", "+"):
        return "up"
    return None


async def manipulation_advance_plausibility_test(
    prices: List[float],
    intended_direction: Optional[str] = None,
    primary_trend: Optional[str] = None,
    min_primary_move_pct: float = 10.0,
    verbose: bool = True,
) -> str:
    """Classify the stated primary trend of the averages (bull or bear) and grade
    whether an alleged manipulation of a given intended direction is plausible there.

    Use when someone alleges that a move in a stock or group was engineered -- a
    pool, a corner, a raid -- and you want this chapter's test applied: read the
    primary trend of the averages from the price path (or take it as stated), take
    the direction the alleged manipulation was intended to produce, and grade the
    claim. The chapter's rules: "Manipulation for the advance is impossible in a
    primary bear market"; the few great instances of designed manipulation "occurred
    in a primary bull market, necessarily so because the market sees more than the
    manipulator"; and "manipulation in a falling market is practically non-existent".

    Inputs: prices -- the averages over the period in question (the data that says
    what the primary trend was); intended_direction -- "up" for a manipulation for
    the advance, "down" for a bear raid (omit or pass an unknown label and the tool
    reports intended_direction='none' with an indeterminate grade rather than
    assuming a direction); primary_trend -- optional "up"/"down" override when the
    caller has already classified the trend.

    Extends manipulation_shock_deflection_test (chWALL STREET OF THE MOVIES): that
    tool asks whether an event merely deflected the price path; this one adds the
    primary-trend-state gate and the intended direction of the move, and grades
    plausibility of the manipulation claim itself.

    Do NOT use to test whether a bear swing was justified by later events, and do
    NOT use for secondary reactions inside a primary rise (use
    secondary_swing_duration_asymmetry_test).
    """
    try:
        prices = [float(p) for p in (prices or []) if p is not None]
        intended = _normalize_direction(intended_direction)
        min_primary_move_pct = 10.0 if min_primary_move_pct is None else float(min_primary_move_pct)

        n = len(prices)
        result: Dict[str, Any] = {
            "n_periods": n,
            "net_change_pct": None,
            "primary_trend": "none",
            "trend_source": "prices",
            "intended_direction": intended if intended is not None else "none",
            "classification": "indeterminate",
            "plausible": False,
            "advance_impossible": False,
            "designed_manipulation_case": False,
            "reason": "No price path supplied, so the primary trend cannot be read.",
        }

        if n == 0:
            return json.dumps({
                "result": result,
                "error": None,
                "metadata": {"provenance": {
                    "source_grounded": [],
                    "model_extrapolated": ["empty-input neutral reading"],
                }},
            })

        first = prices[0]
        last = prices[-1]
        if first != 0.0:
            net_pct = (last - first) / abs(first) * 100.0
        else:
            net_pct = 0.0
        result["net_change_pct"] = net_pct

        if net_pct > 0.0:
            measured = "up" if abs(net_pct) >= min_primary_move_pct else "none"
        elif net_pct < 0.0:
            measured = "down" if abs(net_pct) >= min_primary_move_pct else "none"
        else:
            measured = "none"

        stated = _normalize_direction(primary_trend)
        if stated in ("up", "down"):
            trend = stated
            result["trend_source"] = "stated"
        else:
            trend = measured
            result["trend_source"] = "measured from prices"
        result["primary_trend"] = trend
        result["measured_trend"] = measured
        result["stated_trend"] = stated if stated else None

        if trend == "none":
            result["classification"] = "indeterminate"
            result["reason"] = (
                "The averages show no primary movement (net change %.2f%% over %d periods, "
                "below the %.2f%% required), so this chapter's manipulation rules, which are "
                "conditional on a primary bull or bear market, cannot be applied."
                % (net_pct, n, min_primary_move_pct)
            )
        elif intended is None:
            result["classification"] = "indeterminate"
            result["reason"] = (
                "No direction was given for the alleged manipulation (intended_direction is "
                "neither 'up' for a manipulation for the advance nor 'down' for a bear raid), so "
                "the chapter's rules, which are conditional on that direction, cannot be applied."
            )
        elif trend == "down" and intended == "up":
            result["classification"] = "impossible"
            result["plausible"] = False
            result["advance_impossible"] = True
            result["reason"] = (
                "The averages are in a primary BEAR market (net change %.2f%% over %d periods), "
                "and manipulation for the advance is impossible in a primary bear market: the "
                "market sees more than the manipulator and is bigger than the manipulation."
                % (net_pct, n)
            )
        elif trend == "down" and intended == "down":
            result["classification"] = "practically_nonexistent"
            result["plausible"] = False
            result["reason"] = (
                "The averages are falling (net change %.2f%% over %d periods). Manipulation in a "
                "falling market is practically non-existent: the bear trader carries his own "
                "letter of marque and fights for his own hand, and a major bear swing has always "
                "been amply justified by future events." % (net_pct, n)
            )
        elif trend == "up" and intended == "up":
            result["classification"] = "designed_manipulation_possible"
            result["plausible"] = True
            result["designed_manipulation_case"] = True
            result["reason"] = (
                "The averages are in a primary BULL market (net change %.2f%% over %d periods). "
                "This is the only state in which the chapter allows great designed manipulation "
                "for the advance -- necessarily so, because the market sees more than the "
                "manipulator, who merely foresees values he hopes the public will appreciate "
                "later -- so the allegation is plausible but the market remains bigger than it."
                % (net_pct, n)
            )
        else:
            result["classification"] = "not_the_chapter_case"
            result["plausible"] = False
            result["reason"] = (
                "The averages are rising (net change %.2f%% over %d periods) but the alleged "
                "manipulation was for the DECLINE. The chapter's few great instances of designed "
                "manipulation all occurred in a primary bull market for the advance, and the "
                "market is bigger than any manipulation; a designed bear operation inside a rising "
                "primary average is not the case the chapter admits." % (net_pct, n)
            )

        if verbose:
            result["thresholds"] = {"min_primary_move_pct": min_primary_move_pct}

        return json.dumps({
            "result": result,
            "error": None,
            "metadata": {
                "provenance": {
                    "source_grounded": [
                        "manipulation for the advance is impossible in a primary bear market",
                        "great designed manipulations occurred in a primary bull market",
                        "the market sees more than the manipulator",
                        "manipulation in a falling market is practically non-existent",
                        "the bear trader fights for his own hand",
                        "the manipulator only foresees values the public will appreciate later",
                    ],
                    "model_extrapolated": [
                        "min_primary_move_pct=10 to read a primary bull/bear trend from net change",
                        "grade labels: impossible / practically_nonexistent / designed_manipulation_possible / not_the_chapter_case / indeterminate",
                        "flat-market 'none' reading when net change is below the threshold",
                        "primary_trend override accepted ahead of the measured trend",
                        "unknown/absent intended_direction -> 'none' + indeterminate, never defaulted to 'up'",
                    ],
                }
            },
        })
    except Exception as exc:  # noqa: BLE001
        return json.dumps({
            "result": None,
            "error": "manipulation_advance_plausibility_test failed: %s" % exc,
            "metadata": {
                "provenance": {
                    "source_grounded": [],
                    "model_extrapolated": ["error handling path"],
                }
            },
        })