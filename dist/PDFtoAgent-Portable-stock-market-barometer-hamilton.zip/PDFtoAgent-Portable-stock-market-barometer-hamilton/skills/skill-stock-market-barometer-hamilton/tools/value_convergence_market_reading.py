import json
from typing import List, Optional


async def value_convergence_market_reading(
    present_price: float,
    expected_value_horizon_months: float = 3.0,
    expected_value: Optional[float] = None,
    price_path: Optional[List[float]] = None,
    target_premium_points: float = 10.0,
    max_premium_points: float = 20.0,
    verbose: bool = True,
) -> str:
    """Read the market from the standpoint of values, as Dow says is the best way.

    Dow, editorial of July 20, 1901: "The best way of reading the market is to
    read from the standpoint of values. The market is not like a balloon
    plunging hither and thither in the wind. As a whole, it represents a
    serious, well-considered effort on the part of far-sighted and
    well-informed men to adjust prices to such values as exist or which are
    expected to exist in the not too remote future. The thought with great
    operators is not whether a price can be advanced, but whether the value of
    property which they propose to buy will lead investors and speculators six
    months hence to take stock at figures from ten to twenty points above
    present prices. In reading the market, therefore, the main point is to
    discover what a stock can be expected to be worth three months hence and
    then to see whether manipulators or investors are advancing the price of
    that stock toward those figures."

    Use when you have formed (or been given) the value a stock can be expected
    to be worth at the horizon -- three to six months hence -- and want to know
    whether the present price and its recent path are advancing toward that
    value, and whether the gap is of the ten-to-twenty-point order great
    operators work with.

    Do NOT use to compute the expected value itself; the chapter says only that
    it must be "discovered" from values and never says how. Pass it in as
    `expected_value`. Do NOT use for the three-eighths reaction rule -- that is
    `three_eighths_secondary_reaction_rule`.
    """
    provenance = {
        "source_grounded": [
            "read the market from the standpoint of values, not as a balloon in the wind",
            "discover what a stock can be expected to be worth three months hence",
            "then see whether manipulators or investors are advancing the price toward those figures",
            "great operators work with figures ten to twenty points above present prices",
            "the question is whether value will lead investors to take stock, not whether the price can be advanced",
            "the market adjusts prices to values expected to exist in the not too remote future (six months hence)",
        ],
        "model_extrapolated": [
            "expected_value must be supplied by the caller; the chapter gives no way to compute it",
            "target_premium_points = 10.0 and max_premium_points = 20.0 as the order of magnitude great operators work with",
            "convergence measured as the share of the gap to expected value closed over the supplied price path",
            "advance_toward_value graded against the path's net move and the gap closed",
            "horizon default 3.0 months with the chapter's 6-month variant accepted",
        ],
    }
    try:
        price = 0.0 if present_price is None else float(present_price)
        horizon = 3.0 if expected_value_horizon_months is None else float(expected_value_horizon_months)
        target = 10.0 if target_premium_points is None else float(target_premium_points)
        maxprem = 20.0 if max_premium_points is None else float(max_premium_points)
        path = [0.0 if p is None else float(p) for p in (price_path or [])]

        value = None if expected_value is None else float(expected_value)
        gap_points = None
        gap_pct = None
        if value is not None:
            gap_points = value - price
            if price != 0.0:
                gap_pct = gap_points / price * 100.0

        path_start = path[0] if path else price
        path_move = path[-1] - path_start if path else 0.0
        if path_move > 0.0:
            path_direction = "up"
        elif path_move < 0.0:
            path_direction = "down"
        else:
            path_direction = "none"

        gap_closed_share = None
        if value is not None and path and gap_points is not None and gap_points != 0.0:
            gap_closed_share = (path[-1] - path_start) / gap_points

        if value is None:
            verdict = "no_value_supplied"
            advancing_toward_value = None
            reason = ("No expected value was supplied. The main point of reading the market is "
                      "to discover what the stock can be expected to be worth at the horizon "
                      "and then see whether the price is being advanced toward those figures; "
                      "the chapter gives no way to compute that value, so it must be passed in.")
        else:
            if gap_points == 0.0:
                advancing_toward_value = None
                verdict = "price_at_value"
                reason = ("The present price %.2f already equals the expected value %.2f at %.1f "
                          "months; there is no gap for manipulators or investors to advance the "
                          "price across." % (price, value, horizon))
            elif gap_points > 0.0:
                if path_direction == "up" and (gap_closed_share or 0.0) > 0.0:
                    advancing_toward_value = True
                elif path_direction == "none":
                    advancing_toward_value = None
                else:
                    advancing_toward_value = False
            elif gap_points < 0.0:
                if path_direction == "down":
                    advancing_toward_value = True
                elif path_direction == "none":
                    advancing_toward_value = None
                else:
                    advancing_toward_value = False
            else:
                advancing_toward_value = True

            if advancing_toward_value is True:
                verdict = "price_advancing_toward_value"
                reason = ("Value %.2f at %.1f months lies %.2f points %s the present price %.2f, "
                          "and the recent path has moved in that direction (%.2f points), so "
                          "manipulators or investors are advancing the price toward those figures."
                          % (value, horizon, abs(gap_points),
                             "above" if gap_points > 0.0 else "below", price, path_move))
            elif advancing_toward_value is False:
                verdict = "price_moving_away_from_value"
                reason = ("Value %.2f at %.1f months lies %.2f points %s the present price %.2f, "
                          "but the recent path has moved %.2f points the other way: the price is "
                          "not being advanced toward those figures."
                          % (value, horizon, abs(gap_points),
                             "above" if gap_points > 0.0 else "below", price, path_move))


        if value is None:
            premium_order = None
        elif gap_points >= maxprem:
            premium_order = "above_the_ten_to_twenty_point_scale"
        elif gap_points >= target:
            premium_order = "within_the_ten_to_twenty_point_scale"
        elif gap_points > 0.0:
            premium_order = "below_the_ten_to_twenty_point_scale"
        elif gap_points == 0.0:
            premium_order = "no_premium"
        else:
            premium_order = "price_above_value"

        result = {
            "verdict": verdict,
            "reason": reason,
            "present_price": price,
            "expected_value": value,
            "horizon_months": horizon,
            "value_gap_points": gap_points,
            "value_gap_pct": gap_pct,
            "path_move_points": path_move,
            "path_direction": path_direction,
            "gap_closed_share": gap_closed_share,
            "advancing_toward_value": (advancing_toward_value
                                       if value is not None else None),
            "premium_order": premium_order,
        }
        if verbose:
            result["target_premium_points"] = target
            result["max_premium_points"] = maxprem
            result["price_path_length"] = len(path)
            result["params"] = {
                "expected_value_horizon_months": horizon,
                "target_premium_points": target,
                "max_premium_points": maxprem,
            }
            result["note"] = ("The thought with great operators is not whether a price can be "
                              "advanced, but whether the value of the property will lead "
                              "investors and speculators to take stock at figures from ten to "
                              "twenty points above present prices.")
        return json.dumps({"result": result, "error": None,
                           "metadata": {"provenance": provenance}})
    except Exception as exc:
        return json.dumps({"result": None, "error": str(exc),
                           "metadata": {"provenance": provenance}})