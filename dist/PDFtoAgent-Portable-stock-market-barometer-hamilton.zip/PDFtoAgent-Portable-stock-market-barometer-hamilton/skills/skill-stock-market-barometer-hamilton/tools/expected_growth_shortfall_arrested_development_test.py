import json
from typing import List, Optional


async def expected_growth_shortfall_arrested_development_test(
    levels: List[float],
    level_years: List[float],
    actual_increment: float,
    basis: str = "percent",
    projected_increment: Optional[float] = None,
    min_shortfall_fraction: Optional[float] = None,
    verbose: bool = True,
) -> str:
    """Project the increment a series SHOULD have shown over its next full decade
    from its own prior decadal growth, then grade the actual increment as normal
    growth or as arrested development.

    Use when you have a series measured contemporaneously at successive ten-year
    intervals -- the chapter's railroad mileage taken with each decennial census
    (1880, 1890, 1900, 1910) -- plus the increment the NEXT decade actually
    delivered (the 1910-1920 increase of "less than fifteen thousand miles").
    The tool projects the expected increment from the last completed decade and
    compares.

    Two projection bases, both measures of "the same growth again":
      - "percent" (default): apply the last decade's PERCENTAGE gain to the
        closing level -- 240,830 miles in 1910 at nearly 25 per cent over 1900
        projects about 60,000 more miles.
      - "absolute": repeat the last decade's absolute increment -- about
        48,000 more miles.
      - "max": the larger of the two, i.e. "an increase of as much as ninety
        thousand miles" is the ceiling the chapter uses; supply
        min_shortfall_fraction to grade against that ceiling explicitly.

    Grading: the actual increment over the expected increment is the
    `realised_fraction`. The chapter calls its case "not one-sixth" of the
    expected increase and labels it "the irreducible minimum, just enough to
    keep the railroads alive" -- so the default cutoff is one sixth: at or below
    it the reading is "arrested_development_at_irreducible_minimum"; above it,
    "normal_growth".

    Do NOT use this for a single isolated increment with no prior history (there
    is nothing to project from), and do NOT use it to test a price decline --
    call `secular_decline_exceeding_major_swings_test` for that.

    Args:
        levels: The series measured at each benchmark date, chronological
            (e.g. [93000.0, 163000.0, 193000.0, 240830.0] for 1880-1910 mileage).
        level_years: Decimal year of each level (e.g. [1880, 1890, 1900, 1910]).
        actual_increment: The increment the following decade ACTUALLY delivered.
        basis: "percent", "absolute" or "max" -- which prior-decade growth measure
            to project with.
        min_shortfall_fraction: Fraction of the expected increment below which the
            grade is arrested development (default 1/6, the chapter's own figure).
        verbose: False returns the compact grade; True adds the growth history,
            the components of the projection and the thresholds.

    Returns:
        JSON string {"result": {...}, "error": ..., "metadata": {...}} where
        result.classification is "normal_growth" or
        "arrested_development_at_irreducible_minimum".
    """
    try:
        levels_in = [float(v) for v in (levels or []) if v is not None]
        years_in = [float(y) for y in (level_years or []) if y is not None]
        actual = 0.0 if actual_increment is None else float(actual_increment)
        override = (
            None if projected_increment is None else float(projected_increment)
        )
        basis_key = str(basis or "percent").strip().lower()
        if basis_key not in ("percent", "absolute", "max"):
            basis_key = "percent"
        cutoff = (
            1.0 / 6.0 if min_shortfall_fraction is None else float(min_shortfall_fraction)
        )
        if cutoff < 0:
            cutoff = 0.0

        if len(levels_in) < 2:
            return json.dumps(
                {
                    "result": {
                        "classification": "insufficient_history",
                        "reason": "At least two benchmark levels are needed to derive "
                        "a prior decade of growth; %d supplied." % len(levels_in),
                        "actual_increment": actual,
                        "expected_increment": None,
                        "realised_fraction": None,
                        "shortfall_miles": None,
                        "arrested_development": False,
                    },
                    "error": None,
                    "metadata": {
                        "provenance": {
                            "source_grounded": [
                                "increment projected from the prior decadal growth of the same series",
                                "actual increment compared with the projected increment",
                                "grade of arrested development at the irreducible minimum",
                            ],
                            "model_extrapolated": [
                                "insufficient-history reading when fewer than two levels are supplied"
                            ],
                        }
                    },
                }
            )

        history = []
        for i in range(1, len(levels_in)):
            prev = levels_in[i - 1]
            increment = levels_in[i] - prev
            pct = (increment / prev * 100.0) if prev != 0 else 0.0
            span = (
                years_in[i] - years_in[i - 1]
                if len(years_in) == len(levels_in)
                else 10.0
            )
            history.append(
                {
                    "from_year": years_in[i - 1] if len(years_in) == len(levels_in) else None,
                    "to_year": years_in[i] if len(years_in) == len(levels_in) else None,
                    "from_level": prev,
                    "to_level": levels_in[i],
                    "increment": increment,
                    "growth_pct": pct,
                    "span_years": span,
                }
            )

        last = history[-1]
        last_level = levels_in[-1]
        span_years = last["span_years"] if last["span_years"] else 10.0

        projected_absolute = last["increment"] * (10.0 / span_years)
        projected_percent = last_level * (
            (((1.0 + (last["growth_pct"] / 100.0)) ** (10.0 / span_years)) - 1.0)
        ) if (1.0 + last["growth_pct"] / 100.0) > 0 else 0.0

        if basis_key == "absolute":
            expected = projected_absolute
        elif basis_key == "percent":
            expected = projected_percent
        else:
            expected = max(projected_absolute, projected_percent)

        if override is not None:
            expected = override

        if expected == 0:
            realised_fraction = None
            arrested = False
            classification = "no_expected_growth"
            reason = (
                "The prior decade showed no growth, so there is no increment to "
                "project and no shortfall to grade."
            )
        else:
            realised_fraction = actual / expected
            arrested = bool(realised_fraction <= cutoff)
            classification = (
                "arrested_development_at_irreducible_minimum"
                if arrested
                else "normal_growth"
            )
            if arrested:
                reason = (
                    "The projected increase was %.2f and the actual increase %.2f, "
                    "a realised fraction of %.4f at or below the %.4f cutoff: the "
                    "series has been held to the irreducible minimum, just enough "
                    "to keep it alive."
                    % (expected, actual, realised_fraction, cutoff)
                )
            else:
                reason = (
                    "The projected increase was %.2f and the actual increase %.2f, "
                    "a realised fraction of %.4f above the %.4f cutoff: growth "
                    "continued at the rate the prior decade justified."
                    % (expected, actual, realised_fraction, cutoff)
                )

        shortfall = expected - actual if expected is not None else None

        result = {
            "classification": classification,
            "reason": reason,
            "arrested_development": arrested,
            "expected_increment": expected,
            "actual_increment": actual,
            "shortfall": shortfall,
            "realised_fraction": realised_fraction,
            "shortfall_cutoff": cutoff,
            "basis": basis_key,
            "last_decade_growth_pct": last["growth_pct"],
            "last_decade_increment": last["increment"],
        }

        if verbose:
            result["growth_history"] = history
            result["projection_components"] = {
                "terminal_level": last_level,
                "absolute_repeat": projected_absolute,
                "percent_repeat": projected_percent,
            }
            result["params"] = {
                "basis": basis_key,
                "min_shortfall_fraction": cutoff,
                "span_years": span_years,
            }

        return json.dumps(
            {
                "result": result,
                "error": None,
                "metadata": {
                    "provenance": {
                        "source_grounded": [
                            "mileage taken contemporaneously with each ten-year census",
                            "1910 mileage 240830, up nearly 25 per cent since 1900 and more than double 1880",
                            "projected continuing increase of as much as ninety thousand miles",
                            "actual increase less than fifteen thousand miles",
                            "not one-sixth of the expected increase",
                            "irreducible minimum, just enough to keep the railroads alive",
                        ],
                        "model_extrapolated": [
                            "projection basis (percent / absolute / max) for repeating the prior decade's growth",
                            "default cutoff of one sixth, taken from the chapter's own grading fraction",
                            "compounding of the decadal growth rate when the interval is not exactly ten years",
                            "insufficient-history reading below two benchmark levels",
                        ],
                    }
                },
            }
        )
    except Exception as exc:  # pragma: no cover - defensive
        return json.dumps(
            {
                "result": None,
                "error": str(exc),
                "metadata": {
                    "provenance": {
                        "source_grounded": [],
                        "model_extrapolated": [],
                    }
                },
            }
        )