"""Detect a stock only occasionally active, and rule that it must not be carried on margin."""

import json
import math
from typing import List, Optional

_PROVENANCE = {
    "source_grounded": [
        "the danger of the purchase of a stock only occasionally active",
        "the peculiar circumstances may be fully discounted in a few days' active trading",
        "the event will be a market without a single transaction for days together",
        "the seller is obliged to make concessions to find a buyer, generally a professional",
        "such a stock should not be carried on margin at all",
        "exception: the man whose own business is in intimate connection with the trade may well take hold, feeling that there is a permanent market if not always an active one",
    ],
    "model_extrapolated": [
        "inactivity threshold of 3 consecutive sessions without a transaction",
        "minimum shares per session that counts as a transaction",
        "the dry-spell test applied to the trailing part of the record and to the longest run",
        "encoding of the business-connection exception as a boolean",
    ],
}


def _num(value, default):
    if value is None:
        return float(default)
    try:
        out = float(value)
    except (TypeError, ValueError):
        return float(default)
    if math.isnan(out) or math.isinf(out):
        return float(default)
    return out


def _longest_dry_runs(flags):
    longest = 0
    run = 0
    for dry in flags:
        if dry:
            run += 1
            if run > longest:
                longest = run
        else:
            run = 0
    trailing = 0
    for dry in reversed(flags):
        if dry:
            trailing += 1
        else:
            break
    return longest, trailing


async def inactive_stock_margin_carry_exclusion(
    daily_volume: Optional[List[float]] = None,
    days_without_transaction: Optional[List[float]] = None,
    min_shares_for_transaction: float = 0.0,
    max_days_without_transaction: float = 3.0,
    sessions_since_special_circumstances: Optional[float] = None,
    business_connection_to_the_trade: bool = False,
    verbose: bool = True,
) -> str:
    """Detect a stock that is only occasionally active -- liable to go days together
    without a single transaction once its special circumstances are discounted -- and
    rule that it must not be carried on margin.

    Use when you hold, or are about to carry, a position in a stock whose activity you
    can measure: pass its daily volume (shares traded per session) or, if you only have
    the record in that form, the counts of consecutive days without a transaction. The
    chapter's picture is a stock that trades actively for a few days while its peculiar
    circumstances are being discounted and then goes days without a single transaction,
    so that the seller must make concessions to a professional to find a buyer. Such a
    stock should not be carried on margin at all.

    There is one stated exception: the man whose own business is in some intimate
    connection with the trade (the steel trade, the textile industry) may well take
    hold, feeling that there is a permanent market if not always an active one.

    Do NOT use this to decide whether a stock with no permanent market, a new flotation
    or majority control may be margined at all -- that is
    speculative_stock_marketability_margin_screen. Do NOT use it to size the lot once
    the stock is cleared -- call margin_capital_loss_exposure_test.

    Returns the detection (occasionally active or not), the longest and trailing dry
    spells, and the carry-on-margin verdict.
    """
    floor = max(_num(min_shares_for_transaction, 0.0), 0.0)
    max_dry = max(_num(max_days_without_transaction, 3.0), 0.0)

    volumes = []
    if daily_volume:
        for v in daily_volume:
            try:
                volumes.append(float(v))
            except (TypeError, ValueError):
                volumes.append(0.0)

    dry_runs = []
    if days_without_transaction:
        for d in days_without_transaction:
            try:
                dry_runs.append(max(float(d), 0.0))
            except (TypeError, ValueError):
                dry_runs.append(0.0)

    window = None
    if sessions_since_special_circumstances is not None:
        window = int(max(_num(sessions_since_special_circumstances, 0.0), 0.0))

    def _slice(seq):
        if window is not None and window > 0:
            return list(seq[-window:])
        return list(seq)

    if volumes:
        flags = [v <= floor for v in _slice(volumes)]
        sessions = len(flags)
        active_sessions = sum(1 for f in flags if not f)
        longest_run, trailing_run = _longest_dry_runs(flags)
        longest_from_runs = None
    elif dry_runs:
        runs = _slice(dry_runs)
        flags = [d > 0 for d in runs]
        sessions = len(runs)
        active_sessions = sum(1 for f in flags if not f)
        longest_from_runs = max(runs) if runs else 0.0
        trailing_run = 0.0
        for d in reversed(runs):
            if d > 0:
                trailing_run = d
            else:
                break
        longest_run = longest_from_runs
    else:
        flags = []
        sessions = 0
        active_sessions = 0
        longest_run = 0
        trailing_run = 0
        longest_from_runs = None

    longest_dry = float(max(longest_run if longest_run else 0, longest_from_runs or 0))
    trailing_dry = float(trailing_run or 0)

    if sessions == 0:
        occasionally_active = False
        verdict = "no_record"
        carry_allowed = True
        reason = "No activity record was supplied, so no dry spell can be detected."
        active_share_pct = None
    else:
        active_share_pct = 100.0 * active_sessions / sessions
        dry_spell_now = trailing_dry >= max_dry
        dry_spell_record = longest_dry >= max_dry
        occasionally_active = bool(dry_spell_now or dry_spell_record)
        if occasionally_active:
            if business_connection_to_the_trade:
                verdict = "business_connection_exception"
                carry_allowed = True
                reason = (
                    "The record shows %.4g consecutive sessions without a transaction (record "
                    "run) with %.4g at the end of it, past the %.4g-session bound, so the stock "
                    "is only occasionally active. But the speculator's own business is in "
                    "intimate connection with the trade, so he may take hold of it, feeling "
                    "that there is a permanent market if not always an active one."
                    % (longest_dry, trailing_dry, max_dry)
                )
            else:
                verdict = "do_not_carry_on_margin"
                carry_allowed = False
                reason = (
                    "The stock is only occasionally active: %.4g consecutive sessions without a "
                    "transaction in the record and %.4g at the end of it, past the %.4g-session "
                    "bound. Once the peculiar circumstances behind the movement are discounted "
                    "in a few days' active trading, the market goes days without a single "
                    "transaction and the seller must make concessions to a professional. Such a "
                    "stock should not be carried on margin at all."
                    % (longest_dry, trailing_dry, max_dry)
                )
        else:
            verdict = "may_carry_on_margin"
            carry_allowed = True
            reason = (
                "No dry spell reaches the %.4g-session bound: the longest run without a "
                "transaction is %.4g sessions and the trailing run %.4g. The stock is not "
                "shown to be only occasionally active."
                % (max_dry, longest_dry, trailing_dry)
            )

    result = {
        "sessions": sessions,
        "active_sessions": active_sessions,
        "active_session_share_pct": active_share_pct,
        "longest_days_without_transaction": longest_dry,
        "trailing_days_without_transaction": trailing_dry,
        "max_days_without_transaction": max_dry,
        "occasionally_active": occasionally_active,
        "business_connection_to_the_trade": bool(business_connection_to_the_trade),
        "carry_on_margin_allowed": carry_allowed,
        "verdict": verdict,
    }

    if verbose:
        result["min_shares_for_transaction"] = floor
        result["sessions_since_special_circumstances"] = (
            None if sessions_since_special_circumstances is None
            else _num(sessions_since_special_circumstances, 0.0)
        )
        result["dry_flags"] = [bool(f) for f in flags]
        result["reason"] = reason

    return json.dumps({"result": result, "error": None, "metadata": {"provenance": _PROVENANCE}})