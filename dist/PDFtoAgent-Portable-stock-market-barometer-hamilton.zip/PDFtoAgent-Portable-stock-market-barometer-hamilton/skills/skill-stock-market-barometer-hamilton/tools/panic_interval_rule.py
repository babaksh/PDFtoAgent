import json
from typing import List, Optional


def _floats(values: Optional[List[float]]) -> List[float]:
    if not values:
        return []
    out = []
    for v in values:
        try:
            out.append(float(v))
        except (TypeError, ValueError):
            continue
    return out


def _lengthening(intervals: List[float]) -> Optional[float]:
    """Least-squares slope of interval length against interval order (years per interval)."""
    m = len(intervals)
    if m < 2:
        return None
    mx = (m - 1) / 2.0
    my = sum(intervals) / m
    denom = sum((i - mx) ** 2 for i in range(m))
    if denom <= 0:
        return None
    return sum((i - mx) * (intervals[i] - my) for i in range(m)) / denom


async def panic_interval_rule(
    panic_years: List[float],
    min_interval_years: float = 10.0,
    max_interval_years: float = 14.0,
    as_of_year: Optional[float] = None,
    verbose: bool = True,
) -> str:
    """Measure the intervals between panic dates and forecast the next panic window.

    Use when you have a chronology of panic years (the chapter's own: 1837, 1857, 1866,
    1873, 1884, 1893, 1907) and you want to judge the observed spacing against the stated
    variable interval of ten to fourteen years, test whether the intervals are tending to
    grow longer, and project when the next panic falls due. Intervals inside the band keep
    the forecast straightforward; intervals outside it are flagged as irregular (the
    chapter itself hesitates over the deflation year of 1920).

    Do NOT use this to classify a market movement or a trading range -- call
    dow_three_movement_classification or line_formation_breakout. Do NOT use it on a
    single panic date; at least two dates are needed to measure even one interval.

    Parameters: panic_years (panic dates, in years, in chronological order),
    min_interval_years (short end of the stated band, 10), max_interval_years (long end,
    14), as_of_year (the year from which 'next' is judged; defaults to the last panic
    date given, and if omitted the window is anchored on the last panic),
    verbose (False returns only the next-panic window and the regularity verdict).
    """
    try:
        min_interval_years = 10.0 if min_interval_years is None else float(min_interval_years)
        max_interval_years = 14.0 if max_interval_years is None else float(max_interval_years)
        if max_interval_years < min_interval_years:
            min_interval_years, max_interval_years = max_interval_years, min_interval_years

        years = sorted(_floats(panic_years))

        provenance = {
            "source_grounded": [
                "panics show a variable interval from ten to fourteen years",
                "the intervals are apparently tending to grow longer",
            ],
            "model_extrapolated": [
                "tendency to lengthen measured as a least-squares slope of interval against interval order",
                "lengthening slope shifts the projected window later by one slope-step",
                "projection anchored on the last panic date when as_of_year is omitted",
                "borderline dates outside the band are reported as irregular rather than dropped",
            ],
        }
        meta = {
            "provenance": provenance,
            "parameters": {
                "min_interval_years": min_interval_years,
                "max_interval_years": max_interval_years,
                "as_of_year": as_of_year,
            },
            "dates_supplied": len(years),
        }

        if len(years) < 2:
            result = {
                "intervals": [],
                "regularity": "insufficient_data",
                "next_window_start": None,
                "next_window_end": None,
                "reason": "at least two panic dates are needed to measure an interval; got %d" % len(years),
            }
            return json.dumps({"result": result, "error": None, "metadata": meta})

        intervals = [years[i + 1] - years[i] for i in range(len(years) - 1)]
        in_band = [iv for iv in intervals if min_interval_years <= iv <= max_interval_years]
        irregular = [
            {"after_year": years[i], "before_year": years[i + 1], "interval_years": intervals[i]}
            for i in range(len(intervals))
            if not (min_interval_years <= intervals[i] <= max_interval_years)
        ]

        mean_interval = sum(intervals) / len(intervals)
        slope = _lengthening(intervals)
        lengthening = slope is not None and slope > 0.0

        if len(in_band) == len(intervals):
            regularity = "regular"
            reason = "every observed interval lies inside the stated %g-%g year band" % (
                min_interval_years, max_interval_years)
        elif in_band:
            regularity = "mixed"
            reason = ("%d of %d intervals lie inside the %g-%g year band; the rest are irregular and should be "
                      "treated as the variable, borderline cases the chapter itself hesitates over"
                      % (len(in_band), len(intervals), min_interval_years, max_interval_years))
        else:
            regularity = "irregular"
            reason = ("no observed interval lies inside the %g-%g year band; the chronology does not follow the "
                      "stated spacing" % (min_interval_years, max_interval_years))

        if lengthening:
            reason += ("; the intervals are tending to grow longer, so the projection is shifted later by %.2f "
                       "years" % slope)
        elif slope is not None:
            reason += "; the intervals show no tendency to lengthen"

        last_panic = years[-1]
        anchor = last_panic
        if as_of_year is not None:
            try:
                anchor = float(as_of_year)
            except (TypeError, ValueError):
                anchor = last_panic

        drift = slope if (lengthening and slope is not None) else 0.0
        base = max(anchor, last_panic)
        window_start = base + min_interval_years + drift
        window_end = base + max_interval_years + drift

        overdue = anchor is not None and anchor > window_end

        result = {
            "intervals": intervals,
            "mean_interval_years": mean_interval,
            "lengthening_slope_years_per_interval": slope,
            "intervals_lengthening": lengthening,
            "intervals_in_band": len(in_band),
            "intervals_total": len(intervals),
            "regularity": regularity,
            "next_window_start": window_start,
            "next_window_end": window_end,
            "elapsed_since_last_panic": anchor - last_panic,
            "overdue": overdue,
            "reason": reason,
        }

        if verbose:
            result["panic_years_used"] = years
            result["band"] = {
                "min_interval_years": min_interval_years,
                "max_interval_years": max_interval_years,
            }
            result["irregular_intervals"] = irregular
            result["anchor_year"] = anchor
            result["longest_interval_years"] = max(intervals)
            result["shortest_interval_years"] = min(intervals)

        return json.dumps({"result": result, "error": None, "metadata": meta})
    except Exception as exc:
        return json.dumps({"result": None, "error": str(exc), "metadata": {}})