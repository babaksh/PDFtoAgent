import json
from typing import List, Optional


async def average_vs_value_line_position_classifier(
    industrials: List[float],
    railroads: List[float],
    present_value_line: Optional[float] = None,
    prospective_value_line: Optional[float] = None,
    value_line: Optional[float] = None,
    band_pct: float = 5.0,
    require_agreement: bool = True,
    verbose: bool = True,
) -> str:
    """Read the barometer from the standpoint of values: is the average below or above the value line?

    Use when you have the two averages the barometer is built from -- the twenty
    active industrials and the twenty active railroads -- over a long movement,
    together with an estimate of the line of present and prospective values
    expressed in the same average points, and you want the chapter's own reading:
    "It is necessary in reading it to judge whether a long movement has carried
    the average prices below that line or above it."

    Pass the value line either as `value_line` if you already have one figure, or
    as `present_value_line` and `prospective_value_line` separately -- the
    chapter insists the barometer shows present AND prospective values, so when
    both are given the line is taken as the mean of the two.

    Returns a classification (`below_the_line`, `above_the_line`,
    `at_the_line`, `divergent`, `unmeasurable`) plus a short reason, the
    position of each average separately, and how far the movement carried it.

    Extends `value_convergence_market_reading` (ch04): that tool reads ONE
    stock's present price against an expected value at a three-to-six-month
    horizon; this one moves the comparison to the level of the averages over a
    whole long movement and requires prospective as well as present value.

    Do NOT use it to read a single stock against its book value (that is
    `water_in_capitalization_test`), and do NOT use it to classify the movement
    itself as bull or bear (that is `bull_bear_higher_high_lower_low_test`).
    """
    provenance = {
        "source_grounded": [
            "the barometer shows present and prospective values",
            "in reading it, judge whether a long movement has carried the average prices below that line or above it",
            "the averages are of two groups: twenty active industrials and twenty active railroads",
            "at the close of a major downward movement prices will have passed below the line of values",
            "a bull market starts with stocks much below their real value; in the long advance values are gradually overtaken",
            "toward the close of the advance an uninformed public is buying on prospects only",
        ],
        "model_extrapolated": [
            "the line taken as the mean of present and prospective value when both are supplied",
            "band_pct = 5.0 (a reading within 5% of the line is 'at the line', not above or below)",
            "require_agreement = True (both averages must agree before a joint position is named)",
            "the long movement taken as the supplied series: start-to-end change plus the end level against the line",
            "verdict ladder: below_the_line / above_the_line / at_the_line / divergent / unmeasurable",
            "three-way position test so a flat or exactly-on-the-line average is never folded onto up or down",
        ],
    }
    try:
        ind = [0.0 if p is None else float(p) for p in (industrials or [])]
        rr = [0.0 if p is None else float(p) for p in (railroads or [])]
        band = 5.0 if band_pct is None else float(band_pct)
        agree = True if require_agreement is None else bool(require_agreement)

        def _pos_of(deviation_pct):
            if deviation_pct is None:
                return "unmeasurable"
            if deviation_pct > band:
                return "above_the_line"
            if deviation_pct < -band:
                return "below_the_line"
            return "at_the_line"

        if value_line is not None:
            line = float(value_line)
            line_basis = "value_line_supplied"
        elif present_value_line is not None and prospective_value_line is not None:
            line = (float(present_value_line) + float(prospective_value_line)) / 2.0
            line_basis = "mean_of_present_and_prospective"
        elif prospective_value_line is not None:
            line = float(prospective_value_line)
            line_basis = "prospective_value_line_only"
        elif present_value_line is not None:
            line = float(present_value_line)
            line_basis = "present_value_line_only"
        else:
            line = None
            line_basis = "none"

        def _position(series):
            if not series or line is None:
                return None, None, None, None, None
            current = series[-1]
            start = series[0]
            move_points = current - start
            if move_points > 0.0:
                direction = "up"
            elif move_points < 0.0:
                direction = "down"
            else:
                direction = "none"
            deviation_pct = None
            if line != 0.0:
                deviation_pct = (current / line - 1.0) * 100.0
            pos = _pos_of(deviation_pct)
            move_pct = None
            if start > 0.0:
                move_pct = move_points / start * 100.0
            return current, direction, deviation_pct, pos, move_pct

        ind_current, ind_dir, ind_dev, ind_pos, ind_move = _position(ind)
        rr_current, rr_dir, rr_dev, rr_pos, rr_move = _position(rr)

        available = [p for p in (ind_pos, rr_pos) if p is not None and p != "unmeasurable"]

        if line is None:
            verdict = "unmeasurable"
            reason = ("No line of present and prospective values was supplied. The chapter's reading "
                      "is a comparison of the averages against that line; pass value_line, or "
                      "present_value_line and prospective_value_line, in the same points as the "
                      "averages.")
        elif not available:
            verdict = "unmeasurable"
            reason = ("Neither average supplied a usable level: an empty series carries no price, and "
                      "a zero value line admits no percentage deviation, so no position can be named.")
        elif len(available) == 1:
            verdict = available[0]
            reason = ("Only one of the two averages could be read; it stands %.2f%% from the line of "
                      "present and prospective values at %.2f, which is %s. The barometer's reading "
                      "is strongest when the twenty industrials and the twenty railroads are read "
                      "together." % (ind_dev if ind_dev is not None else rr_dev, line, available[0]))
        elif ind_pos == rr_pos:
            verdict = ind_pos
            reason = ("Both averages stand %s: the industrials %.2f%% and the railroads %.2f%% from a "
                      "line of present and prospective values at %.2f, inside a %.2f%% band. "
                      % (ind_pos, ind_dev, rr_dev, line, band)
                      + ("The long movement has carried the average prices below that line, the "
                         "condition in which the chapter says a bull market starts with stocks much "
                         "below their real value."
                         if ind_pos == "below_the_line" else
                         "The long movement has carried the average prices above that line, the stage "
                         "in which values have been gradually overtaken and an uninformed public is "
                         "buying on prospects only."
                         if ind_pos == "above_the_line" else
                         "The movement has left the average prices on the line itself, so values are "
                         "neither clearly below nor clearly above the price level."))
        else:
            verdict = "divergent"
            reason = ("The two averages disagree: the industrials read %s (%.2f%% from the line of "
                      "%.2f) and the railroads read %s (%.2f%%). The chapter reads the barometer "
                      "from both groups together, so a divergent reading is not yet a verdict on the "
                      "long movement." % (ind_pos, ind_dev, line, rr_pos, rr_dev))

        if verdict == "divergent" and not agree:
            joint_dev = None
            if ind_dev is not None and rr_dev is not None:
                joint_dev = (ind_dev + rr_dev) / 2.0
            elif ind_dev is not None:
                joint_dev = ind_dev
            elif rr_dev is not None:
                joint_dev = rr_dev
            if joint_dev is None:
                verdict = "unmeasurable"
                reason = ("The two averages disagree and neither supplies a deviation from the line, "
                          "so with require_agreement set False there is still no joint position to "
                          "name.")
            else:
                verdict = _pos_of(joint_dev)
                reason = ("The two averages disagree -- industrials %s (%.2f%%), railroads %s (%.2f%%) "
                          "-- and require_agreement was set False, so the reading is made on their "
                          "combined distance of %.2f%% from the line of %.2f: %s."
                          % (ind_pos, ind_dev, rr_pos, rr_dev, joint_dev, line, verdict))
            result_joint_dev = joint_dev
        else:
            result_joint_dev = None

        result = {
            "verdict": verdict,
            "reason": reason,
            "value_line": line,
            "value_line_basis": line_basis,
            "band_pct": band,
            "industrial_position": ind_pos,
            "railroad_position": rr_pos,
            "industrial_current": ind_current,
            "railroad_current": rr_current,
            "industrial_deviation_pct": ind_dev,
            "railroad_deviation_pct": rr_dev,
            "industrial_movement_direction": (ind_dir if ind else None),
            "railroad_movement_direction": (rr_dir if rr else None),
            "industrial_move_pct": ind_move,
            "railroad_move_pct": rr_move,
            "combined_deviation_pct": result_joint_dev,
        }
        if verbose:
            result["industrial_series_length"] = len(ind)
            result["railroad_series_length"] = len(rr)
            result["params"] = {
                "band_pct": band,
                "require_agreement": agree,
            }
            result["note"] = ("The stock market barometer shows present and prospective values; in "
                              "reading it, judge whether a long movement has carried the average "
                              "prices below that line or above it.")
        return json.dumps({"result": result, "error": None,
                           "metadata": {"provenance": provenance}})
    except Exception as exc:
        return json.dumps({"result": None, "error": str(exc),
                           "metadata": {"provenance": provenance}})