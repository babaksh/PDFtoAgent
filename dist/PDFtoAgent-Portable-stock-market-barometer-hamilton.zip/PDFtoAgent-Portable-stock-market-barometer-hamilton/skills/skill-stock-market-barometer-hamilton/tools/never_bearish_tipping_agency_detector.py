import json
from typing import Dict, List, Optional


def _as_bool(v) -> Optional[bool]:
    if isinstance(v, bool):
        return v
    if v is None:
        return None
    s = str(v).strip().lower()
    if s in ("true", "yes", "y", "1", "buying", "buy"):
        return True
    if s in ("false", "no", "n", "0", "selling", "sell"):
        return False
    return None


_PROVENANCE = {
    "source_grounded": [
        "stock-tipping agencies are never bearish on the stock market",
        "with them insiders are always buying",
        "they tell the speculator what he wants to know, not what he needs to know",
        "there is always the suggestion of a mystery about reading the market movement",
    ],
    "model_extrapolated": [
        "max_bearish_share default 0.0 (never bearish)",
        "min_insider_buying_share default 0.9 for 'always buying'",
        "recognition mark scored as never-bearish AND insiders-always-buying",
        "insufficient_record verdict when no calls are supplied",
    ],
}


def _meta() -> dict:
    return {"provenance": _PROVENANCE}


async def never_bearish_tipping_agency_detector(
    market_calls: List[Dict],
    max_bearish_share: float = 0.0,
    min_insider_buying_share: float = 0.9,
    verbose: bool = True,
) -> str:
    """Classify an advisory service as a stock-tipping agency or as a genuine market reading.

    Use when you have the published market calls of an advisory service, tipster
    letter or brokerage circular -- each call carrying its stance on the general
    market (bullish / bearish / neutral) and its claim about what insiders are doing
    -- and you want to know what kind of service you are reading. The chapter's
    recognition mark is that stock-tipping agencies are never bearish on the stock
    market and always report that insiders are buying; a service that is willing to
    be bearish is reading the market instead of selling tips.

    Do NOT use to judge whether a market call was RIGHT -- pass the calls to the
    relevant barometer or confirmation tools instead; this tool only tests the
    recognition marks of the service that issued them.
    """
    try:
        max_bear = 0.0 if max_bearish_share is None else float(max_bearish_share)
        min_ins = 0.9 if min_insider_buying_share is None else float(min_insider_buying_share)

        n = 0
        n_bearish = 0
        n_bullish = 0
        n_neutral = 0
        n_unstated = 0
        insider_flags: List[bool] = []
        bearish_periods: List[str] = []
        rows = []

        for c in market_calls or []:
            if not isinstance(c, dict):
                continue
            n += 1
            stance = str(c.get("stance", c.get("call", ""))).strip().lower()
            period = c.get("period", c.get("date", c.get("label", None)))
            period_s = "" if period is None else str(period)

            insider = None
            for key in ("insiders_buying", "insider_buying", "insiders", "insiders_are_buying"):
                if key in c:
                    insider = _as_bool(c[key])
                    break
            if insider is None:
                for key in ("insider_activity", "insider_stance", "insiders_activity"):
                    if key in c:
                        insider = _as_bool(c[key])
                        break

            if stance in ("bearish", "bear", "down", "negative", "sell"):
                n_bearish += 1
                bearish_periods.append(period_s)
            elif stance in ("bullish", "bull", "up", "positive", "buy"):
                n_bullish += 1
            elif stance in ("neutral", "flat", "mixed", "none", "hold"):
                n_neutral += 1
            else:
                n_unstated += 1

            if insider is not None:
                insider_flags.append(bool(insider))

            rows.append(
                {
                    "period": period_s,
                    "stance": stance if stance else "unstated",
                    "insiders_buying": insider,
                }
            )

        bearish_share = n_bearish / n if n else 0.0
        n_insider_calls = len(insider_flags)
        n_insider_buying = sum(1 for f in insider_flags if f)
        insider_buying_share = n_insider_buying / n_insider_calls if n_insider_calls else 0.0

        never_bearish = bool(n > 0 and bearish_share <= max_bear)
        insiders_always_buying = bool(n_insider_calls > 0 and insider_buying_share >= min_ins)
        marks_matched = int(never_bearish) + int(insiders_always_buying)

        if n == 0:
            verdict = "insufficient_record"
        elif never_bearish and insiders_always_buying:
            verdict = "stock_tipping_agency"
        elif not never_bearish and not insiders_always_buying:
            verdict = "market_reading"
        else:
            verdict = "mixed_marks"

        if verdict == "insufficient_record":
            reason = "no published market calls supplied, so no recognition mark can be tested"
        elif verdict == "stock_tipping_agency":
            reason = (
                "never bearish in %d published call(s) and insiders reported buying in "
                "%.0f%% of them -> both recognition marks of a stock-tipping agency"
                % (n, insider_buying_share * 100.0)
            )
        elif verdict == "market_reading":
            reason = (
                "willing to be bearish (%d of %d calls) and does not report insiders buying "
                "%.0f%% of the time -> a market reading, not a tipping agency"
                % (n_bearish, n, insider_buying_share * 100.0)
            )
        else:
            reason = (
                "only one of the two recognition marks is matched (never bearish: %s; "
                "insiders always buying: %s) -> mixed marks"
                % (never_bearish, insiders_always_buying)
            )

        payload = {
            "n_calls": n,
            "n_bearish": n_bearish,
            "n_bullish": n_bullish,
            "n_neutral": n_neutral,
            "n_unstated": n_unstated,
            "bearish_share": bearish_share,
            "max_bearish_share": max_bear,
            "never_bearish": never_bearish,
            "n_insider_calls": n_insider_calls,
            "n_insider_buying": n_insider_buying,
            "insider_buying_share": insider_buying_share,
            "min_insider_buying_share": min_ins,
            "insiders_always_buying": insiders_always_buying,
            "recognition_marks_matched": marks_matched,
            "classification": verdict,
            "bearish_periods": bearish_periods,
            "verdict": verdict,
            "calls": rows,
            "reason": reason,
        }
        if not verbose:
            payload = {
                k: payload[k]
                for k in (
                    "n_calls",
                    "n_bearish",
                    "n_bullish",
                    "n_neutral",
                    "bearish_share",
                    "never_bearish",
                    "n_insider_calls",
                    "insider_buying_share",
                    "insiders_always_buying",
                    "recognition_marks_matched",
                    "classification",
                    "verdict",
                )
            }
        return json.dumps({"result": payload, "error": None, "metadata": _meta()})
    except Exception as exc:  # noqa: BLE001 - contract requires a reading, never a raise
        return json.dumps(
            {
                "result": {"verdict": "indeterminate", "classification": "indeterminate", "reason": str(exc)},
                "error": None,
                "metadata": _meta(),
            }
        )