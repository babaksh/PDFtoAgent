"""Bound how far a guarantied stock can advance: no more than the discounted guaranty value."""

import json
import math
from typing import Optional


def _v(x, default: float) -> float:
    try:
        if x is None:
            return float(default)
        f = float(x)
    except (TypeError, ValueError):
        return float(default)
    if math.isnan(f) or math.isinf(f):
        return float(default)
    return f


def _r(v, nd: int = 4):
    if v is None:
        return None
    try:
        f = float(v)
    except (TypeError, ValueError):
        return None
    if math.isnan(f) or math.isinf(f):
        return None
    return round(f, nd)


async def guaranty_value_discount_ceiling_test(
    observed_advance: float,
    guaranteed_annual_return: float,
    unguaranteed_income: float = 0.0,
    capitalization_rate: float = 0.06,
    guaranty_years: float = 6.0,
    pre_announcement_price: Optional[float] = None,
    verbose: bool = True,
) -> str:
    """Rule whether a guarantied stock's observed advance stays inside the ceiling the
    chapter sets: it cannot advance "more than enough to discount the estimated value of
    that guaranty".

    Use when an issue has been taken into the fixed-income class by a government (or
    equivalent) guaranty of a minimum return and you need a computable bound on how far
    its price may legitimately rise. The chapter's instance: the railroads under federal
    control, guaranteed a minimum return based on the average earnings of the three
    years ended June 30, 1917, which "had nothing to expect beyond the government
    guaranty" and so could not advance beyond discounting its estimated value. Their
    first impetuous buying on the guaranty was followed by a break.

    The ceiling is computed from the guaranty itself, in three steps:
      1. the guaranty's annual value = guaranteed_annual_return - unguaranteed_income
         (what the guaranty adds over what the holder already had; if no unguaranteed
         income is supplied the whole guaranteed return is the addition);
      2. its estimated value = that addition capitalised at capitalization_rate over
         guaranty_years (perpetuity when guaranty_years <= 0);
      3. `ceiling_advance` = that estimated value, which is the most the price may add.

    The verdict is then three-way on `observed_advance` against the ceiling: within it,
    at it, or beyond it (`excess_advance` = observed - ceiling).

    Extends `single_average_exception_government_guaranty_test` (chFORECASTING A BULL
    MARKET--1908-1909): that tool took government guaranty only as a true/false flag on
    the way to a confirmation verdict. This one turns the guaranty into a computable
    CEILING, valued off its stated earnings base.

    Do NOT use this to decide whether the issue is speculative or fixed-income (call
    speculative_vs_fixed_income_security_classifier), and do NOT use it for a
    non-guarantied issue -- with no guaranty there is no ceiling to compute.

    Args:
        observed_advance: the price advance actually recorded, in price points.
        guaranteed_annual_return: the annual return the guaranty assures, per share.
        unguaranteed_income: income per share the holder had WITHOUT the guaranty
            (the guaranty's value is only the addition); 0.0 if the guaranty covers
            the whole return.
        capitalization_rate: rate at which the guaranty's annual value is capitalised
            (the chapter's rate-making rule of 6 per cent net return is the default).
        unguaranteed_income: income per share the holder had WITHOUT the guaranty
            (the guaranty's value is only the addition); 0.0 if the guaranty covers
            the whole return.
        guaranty_years: years the guaranty is expected to run; <= 0 values it in
            perpetuity at capitalization_rate.
        pre_announcement_price: price before the guaranty; when given, the ceiling and
            the observed advance are also reported as percentages of it.
        verbose: False returns the ceiling and the verdict; True adds every intermediate
            quantity and the rule text.

    Returns:
        JSON {"result": {...}, "error": None, "metadata": {...}} with `classification`
        ("within_ceiling" / "at_ceiling" / "beyond_ceiling") and `exceeds_ceiling`.
    """
    try:
        observed = _v(observed_advance, 0.0)
        guaranteed = _v(guaranteed_annual_return, 0.0)
        unguaranteed = _v(unguaranteed_income, 0.0)
        rate = _v(capitalization_rate, 0.06)
        years = _v(guaranty_years, 6.0)
        base = None
        if pre_announcement_price is not None:
            try:
                b = float(pre_announcement_price)
                if not (math.isnan(b) or math.isinf(b)):
                    base = b
            except (TypeError, ValueError):
                base = None

        if rate <= 0.0:
            rate = 0.06

        guaranty_annual_value = guaranteed - unguaranteed

        if guaranty_annual_value <= 0.0:
            ceiling = 0.0
            basis = "guaranty adds nothing over the unguaranteed income, so it has no value to discount"
        elif years <= 0.0:
            ceiling = guaranty_annual_value / rate
            basis = ("perpetual guaranty: annual value " + format(guaranty_annual_value, ".4f")
                     + " capitalised at " + format(rate * 100.0, ".2f") + "%")
        else:
            disc = 1.0 - (1.0 + rate) ** (-years)
            ceiling = guaranty_annual_value * disc / rate
            basis = ("annual value " + format(guaranty_annual_value, ".4f")
                     + " capitalised at " + format(rate * 100.0, ".2f") + "% for "
                     + format(years, ".2f") + " years")

        excess = observed - ceiling
        denom = abs(base) if base not in (None, 0.0) else (abs(ceiling) if ceiling != 0.0 else 1.0)
        tol = abs(denom) * 1e-9
        if excess > tol:
            classification = "beyond_ceiling"
            exceeds = True
        elif excess < -tol:
            classification = "within_ceiling"
            exceeds = False
        else:
            classification = "at_ceiling"
            exceeds = False

        if classification == "beyond_ceiling":
            reason = ("The advance of " + format(observed, ".4f")
                      + " points exceeds the ceiling of " + format(ceiling, ".4f")
                      + " points -- the estimated value of the guaranty -- by "
                      + format(excess, ".4f")
                      + ". The chapter's rule is that a guarantied stock cannot advance "
                        "more than enough to discount the estimated value of the guaranty, "
                        "so the excess is unsupported and the chapter expects a break.")
        elif classification == "at_ceiling":
            reason = ("The advance of " + format(observed, ".4f")
                      + " points exactly discounts the estimated value of the guaranty ("
                      + format(ceiling, ".4f")
                      + " points): the stock has gone as far as the guaranty can justify "
                        "and no further.")
        else:
            reason = ("The advance of " + format(observed, ".4f")
                      + " points is within the ceiling of " + format(ceiling, ".4f")
                      + " points, leaving " + format(-excess, ".4f")
                      + " points of the guaranty's estimated value still undiscounted.")

        result = {
            "classification": classification,
            "exceeds_ceiling": exceeds,
            "reason": reason,
            "observed_advance": _r(observed),
            "ceiling_advance": _r(ceiling),
            "excess_advance": _r(excess),
            "guaranty_annual_value": _r(guaranty_annual_value),
            "capitalization_rate": _r(rate, 6),
            "guaranty_years": _r(years),
            "valuation_basis": basis,
        }

        if base is not None:
            result["observed_advance_pct"] = _r(
                observed / abs(base) * 100.0 if base != 0.0 else None)
            result["ceiling_advance_pct"] = _r(
                ceiling / abs(base) * 100.0 if base != 0.0 else None)

        if verbose:
            result["detail"] = {
                "guaranteed_annual_return": _r(guaranteed),
                "unguaranteed_income": _r(unguaranteed),
                "pre_announcement_price": _r(base),
                "rule_quote": ("They could not advance in any market, bull or bear, more "
                               "than enough to discount the estimated value of that "
                               "guaranty."),
            }

        return json.dumps({
            "result": result,
            "error": None,
            "metadata": {
                "provenance": {
                    "source_grounded": [
                        "a guarantied stock cannot advance more than enough to discount the estimated value of the guaranty",
                        "government guaranty of a minimum return based on the average earnings of the three years ended June 30, 1917",
                        "the 6 per cent net return as a rule of rate-making",
                        "the break followed the first impetuous buying on government guaranty",
                    ],
                    "model_extrapolated": [
                        "guaranty value = guaranteed return less unguaranteed income",
                        "capitalisation rate default of 6% and guaranty horizon default of 6 years",
                        "finite-horizon annuity discounting, perpetuity when guaranty_years <= 0",
                        "equality band of 1e-9 relative for the at-ceiling reading",
                    ],
                }
            },
        })
    except Exception as exc:
        return json.dumps({
            "result": {
                "classification": "insufficient_data",
                "exceeds_ceiling": False,
                "reason": "Could not compute the guaranty ceiling: " + str(exc),
            },
            "error": None,
            "metadata": {
                "provenance": {
                    "source_grounded": [
                        "a guarantied stock cannot advance more than enough to discount the estimated value of the guaranty",
                    ],
                    "model_extrapolated": ["boundary reading on unusable input"],
                }
            },
        })