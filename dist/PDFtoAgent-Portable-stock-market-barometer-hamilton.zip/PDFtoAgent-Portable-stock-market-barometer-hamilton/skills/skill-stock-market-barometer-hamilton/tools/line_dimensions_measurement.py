import json
import math
from typing import List, Optional


def _as_float(value, default: float) -> float:
    try:
        if value is None:
            return float(default)
        return float(value)
    except (TypeError, ValueError):
        return float(default)


def _clean(values) -> List[float]:
    out: List[float] = []
    for v in values or []:
        try:
            f = float(v)
        except (TypeError, ValueError):
            continue
        if math.isnan(f) or math.isinf(f):
            continue
        out.append(f)
    return out


def _clip_index(value, n: int, default: int) -> int:
    try:
        idx = int(value) if value is not None else default
    except (TypeError, ValueError):
        idx = default
    return max(0, min(idx, n - 1))


async def line_dimensions_measurement(
    industrials: Optional[List[float]] = None,
    railroads: Optional[List[float]] = None,
    start_index: Optional[int] = None,
    end_index: Optional[int] = None,
    max_range_points: float = 5.0,
    min_trading_days: int = 10,
    max_outside_prints: int = 1,
    verbose: bool = True,
) -> str:
    """Measure a candidate congestion period in both averages for breadth in points and duration in trading days, and rule whether it is a genuine Dow-theory 'line'.

    Use when the two averages have been moving sideways and you must say whether the
    congestion is really a "line" -- the chapter answers "the questions as to the
    dimensions or breadth of a line" by measuring exactly two things in each average
    separately: the extreme range in POINTS and the length in TRADING DAYS. In the
    chapter's own worked case the line "had actually extended over sixty-six trading
    days in the industrials and seventy-one in the railroads", and "three points was the
    extreme range in the industrials and four points that in the more stable railroad
    stocks". A line "may be prolonged indefinitely" in theory, so duration has a floor,
    not a ceiling; and no inference of value can be drawn from a single day's trading.

    Extends: line_formation_breakout (chCYCLES AND STOCK MARKET RECORDS), which detects
    and classifies the resolution of a line but never scores its dimensions. This tool
    gives the line explicit, separately-measured dimensions: extreme range in points per
    average and length in trading days per average.

    Inputs: `industrials` and `railroads`, the two daily closing averages over the
    candidate period (give at least one; give both for the two-average reading the
    barometer requires), optionally bounded by `start_index` / `end_index`.
    `max_range_points` is the widest extreme range still counted as a line,
    `min_trading_days` the shortest congestion still counted as a line, and
    `max_outside_prints` how many single-day prints outside the band are tolerated
    without destroying the measurement (the chapter's own line survived one, the
    railroads' print at 100 on June 25th).

    Do NOT use this to classify how the congestion resolved -- use
    line_formation_breakout. Do NOT use it to rule on a single-day penetration of the
    band -- use line_warning_retraction_rule.
    """
    try:
        ind = _clean(industrials)
        rr = _clean(railroads)
        max_pts = _as_float(max_range_points, 5.0)
        if max_pts < 0.0:
            max_pts = 0.0
        try:
            min_days = int(min_trading_days) if min_trading_days is not None else 10
        except (TypeError, ValueError):
            min_days = 10
        if min_days < 0:
            min_days = 0
        try:
            outside_limit = int(max_outside_prints) if max_outside_prints is not None else 1
        except (TypeError, ValueError):
            outside_limit = 1
        if outside_limit < 0:
            outside_limit = 0

        def _respond(result):
            return json.dumps({
                "result": result,
                "error": None,
                "metadata": {
                    "tool": "line_dimensions_measurement",
                    "provenance": {
                        "source_grounded": [
                            "a line is measured by its dimensions or breadth",
                            "extreme range measured in points",
                            "length measured in trading days",
                            "each average measured separately and read to check and confirm the other",
                            "in theory a line may be prolonged indefinitely",
                            "no inference of value can be drawn from a single day's trading",
                            "worked case: 3 points and 66 trading days in the industrials",
                            "worked case: 4 points and 71 trading days in the railroads",
                        ],
                        "model_extrapolated": [
                            "max_range_points default of 5 points as the widest band still a line",
                            "min_trading_days default of 10 as the duration floor",
                            "max_outside_prints default of 1 tolerated single-day print outside the band",
                            "band boundaries taken from the interior prints after excluding tolerated outliers",
                        ],
                    },
                },
            })

        def _measure(series, start, end):
            if not series:
                return None
            s = max(0, min(start, len(series) - 1))
            e = max(0, min(end, len(series) - 1))
            if e < s:
                s, e = e, s
            window = series[s:e + 1]
            if not window:
                return None
            lo = min(window)
            hi = max(window)
            ordered = sorted(window)
            keep = max(1, len(window) - outside_limit)
            best_start = 0
            best_width = None
            for i in range(0, len(window) - keep + 1):
                width = ordered[i + keep - 1] - ordered[i]
                if best_width is None or width < best_width:
                    best_width = width
                    best_start = i
            band_low = ordered[best_start]
            band_high = ordered[best_start + keep - 1]
            outside = [p for p in window if p < band_low or p > band_high]
            return {
                "trading_days": len(window),
                "extreme_range_points": hi - lo,
                "band_low": band_low,
                "band_high": band_high,
                "band_range_points": band_high - band_low,
                "extreme_high": hi,
                "extreme_low": lo,
                "outside_prints": len(outside),
                "outside_print_values": outside,
                "mean_price": sum(window) / float(len(window)),
            }

        def _rule(measurement, name):
            if measurement is None:
                return None
            days_ok = measurement["trading_days"] >= min_days
            range_ok = measurement["extreme_range_points"] <= max_pts
            prints_ok = measurement["outside_prints"] <= outside_limit
            qualifies = days_ok and range_ok and prints_ok
            if not days_ok:
                reason = (
                    "the congestion ran only %d trading days against a floor of %d, and no inference "
                    "of value can be drawn from so short a period" % (measurement["trading_days"], min_days)
                )
            elif not range_ok:
                reason = (
                    "the extreme range of %.2f points is wider than the %.2f point band that bounds a "
                    "line" % (measurement["extreme_range_points"], max_pts)
                )
            elif not prints_ok:
                reason = (
                    "%d prints fell outside the band of %.2f-%.2f against a tolerance of %d, so the "
                    "congestion is not contained" % (
                        measurement["outside_prints"], measurement["band_low"],
                        measurement["band_high"], outside_limit,
                    )
                )
            else:
                reason = (
                    "the congestion spans %.2f points between %.2f and %.2f over %d trading days, "
                    "within the %.2f point band and the %d day floor, so it measures as a line"
                    % (
                        measurement["extreme_range_points"], measurement["band_low"],
                        measurement["band_high"], measurement["trading_days"], max_pts, min_days,
                    )
                )
            row = dict(measurement)
            row["average"] = name
            row["duration_ok"] = days_ok
            row["range_ok"] = range_ok
            row["prints_ok"] = prints_ok
            row["qualifies_as_line"] = qualifies
            row["reason"] = reason
            return row

        supplied = [s for s in (ind, rr) if s]
        if not supplied:
            return _respond({
                "is_line": False,
                "classification": "no_evidence",
                "averages_measured": 0,
                "start_index": None,
                "end_index": None,
                "industrials": None,
                "railroads": None,
                "reason": "no averages were supplied, so no congestion period can be measured",
            })

        lengths = [len(s) for s in supplied]
        n_ref = max(lengths)
        start = _clip_index(start_index, n_ref, 0)
        end = _clip_index(end_index, n_ref, n_ref - 1)
        if end < start:
            start, end = end, start

        ind_row = _rule(_measure(ind, start, end), "industrials") if ind else None
        rr_row = _rule(_measure(rr, start, end), "railroads") if rr else None

        rows = [r for r in (ind_row, rr_row) if r is not None]
        measured = len(rows)
        qualifying = [r for r in rows if r["qualifies_as_line"]]

        if measured == 2:
            both = len(qualifying) == 2
            if both:
                classification = "line_confirmed_by_both_averages"
                reason = (
                    "both averages measure as a line: the industrials %.2f points over %d trading days "
                    "and the railroads %.2f points over %d trading days, so the two averages check and "
                    "confirm each other"
                    % (
                        ind_row["extreme_range_points"], ind_row["trading_days"],
                        rr_row["extreme_range_points"], rr_row["trading_days"],
                    )
                )
            elif len(qualifying) == 1:
                classification = "line_in_one_average_only"
                ok = qualifying[0]
                bad = rr_row if ok is ind_row else ind_row
                reason = (
                    "only the %s average measures as a line (%.2f points over %d trading days); the %s "
                    "does not, so the line is unconfirmed: %s"
                    % (ok["average"], ok["extreme_range_points"], ok["trading_days"],
                       bad["average"], bad["reason"])
                )
            else:
                classification = "not_a_line"
                reason = (
                    "neither average measures as a line: %s; %s"
                    % (ind_row["reason"], rr_row["reason"])
                )
        else:
            only = rows[0]
            both = only["qualifies_as_line"]
            classification = (
                "line_in_one_average_only" if both else "not_a_line"
            )
            reason = (
                "only the %s average was supplied, so the line cannot be confirmed by a second "
                "average; on its own dimensions: %s" % (only["average"], only["reason"])
            )

        result = {
            "start_index": start,
            "end_index": end,
            "is_line": bool(both) if measured == 2 else bool(qualifying),
            "classification": classification,
            "averages_measured": measured,
            "industrials": ind_row,
            "railroads": rr_row,
            "reason": reason,
        }

        if verbose:
            result["thresholds"] = {
                "max_range_points": max_pts,
                "min_trading_days": min_days,
                "max_outside_prints": outside_limit,
            }
            result["rule"] = (
                "a line is measured by its dimensions: the extreme range in points and the length in "
                "trading days, taken in each average separately; it may be prolonged indefinitely, so "
                "only the duration floor and the breadth band bound it"
            )
            if ind:
                result["industrial_series"] = ind[start:end + 1]
            if rr:
                result["railroad_series"] = rr[start:end + 1]

        return _respond(result)
    except Exception as exc:  # pragma: no cover - defensive
        return json.dumps({
            "result": None,
            "error": str(exc),
            "metadata": {
                "tool": "line_dimensions_measurement",
                "provenance": {
                    "source_grounded": ["a line is measured by range in points and length in trading days"],
                    "model_extrapolated": ["max_range_points default", "min_trading_days default"],
                },
            },
        })