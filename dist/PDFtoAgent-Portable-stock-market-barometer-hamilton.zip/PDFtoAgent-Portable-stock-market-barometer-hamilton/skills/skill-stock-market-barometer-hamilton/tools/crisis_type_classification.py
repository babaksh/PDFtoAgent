import json
from typing import Any, Dict, List


async def crisis_type_classification(
    bank_suspensions: int = 0,
    commodity_price_change_pct: float = 0.0,
    real_estate_price_change_pct: float = 0.0,
    bank_circulation_change_pct: float = 0.0,
    specie_change_pct: float = 0.0,
    stock_price_change_pct: float = 0.0,
    business_failures: int = 0,
    credit_collapsed: bool = False,
    depression_severity: float = 0.0,
    min_bank_suspensions: int = 2,
    commodity_collapse_pct: float = 15.0,
    circulation_contraction_pct: float = 15.0,
    specie_loss_pct: float = 10.0,
    stock_smash_pct: float = 15.0,
    commercial_failure_threshold: int = 50,
    near_approach_severity: float = 5.0,
    verbose: bool = True,
) -> str:
    """Classify a financial disturbance into one of Charles H. Dow's named kinds.

    Use when you have ONE crisis episode described by its measurable attributes
    (number of bank suspensions, commodity and real-estate price change,
    contraction of bank circulation, specie loss, stock-price change, number of
    business failures, whether credit collapsed, how serious the resulting
    depression was on a 0-10 scale) and you want Dow's own label for it.

    The five kinds come straight from Dow's own account of the American crises:
      * "commercial_panic" -- banks suspend payments, credit collapses,
        commodity and real-estate prices fall, a great number of failures
        (1837, 1857, 1873, 1893);
      * "stock_exchange_panic_only" -- a Stock Exchange smash that is NOT a
        commercial crisis (1884);
      * "money_panic" -- driven by a tremendous contraction of bank circulation,
        "purely a money panic as far as its causes were concerned" (1819);
      * "near_approach_to_a_crisis" -- contraction of bank circulation causing a
        serious fall in commodity and real-estate prices, but falling short of a
        real panic (1819);
      * "interruption_to_progress_rather_than_reversal" -- lower prices and some
        money stringency, but "the situation did not become very serious"
        (1826).

    Returns the kind, a severity class, whether the Stock Exchange was involved,
    and a short reason naming the attributes that drove the call.

    Do NOT use this to name the CAUSE of a crisis (war, deficient crops, specie
    too small relative to loans, currency-standard uncertainty ...) -- call
    `crisis_cause_attribution`. Do NOT use it to grade how far a FOREIGN crisis
    transmitted here -- call `foreign_crisis_transmission_assessment`.

    Depends on: nothing from earlier chapters; it is the crisis-side companion
    of `panic_interval_rule` (chCYCLES AND STOCK MARKET RECORDS).
    """
    try:
        bank_suspensions = 0 if bank_suspensions is None else int(bank_suspensions)
        business_failures = 0 if business_failures is None else int(business_failures)
        commodity_price_change_pct = 0.0 if commodity_price_change_pct is None else float(commodity_price_change_pct)
        real_estate_price_change_pct = 0.0 if real_estate_price_change_pct is None else float(real_estate_price_change_pct)
        bank_circulation_change_pct = 0.0 if bank_circulation_change_pct is None else float(bank_circulation_change_pct)
        specie_change_pct = 0.0 if specie_change_pct is None else float(specie_change_pct)
        stock_price_change_pct = 0.0 if stock_price_change_pct is None else float(stock_price_change_pct)
        depression_severity = 0.0 if depression_severity is None else float(depression_severity)
        min_bank_suspensions = 2 if min_bank_suspensions is None else int(min_bank_suspensions)
        commodity_collapse_pct = 15.0 if commodity_collapse_pct is None else float(commodity_collapse_pct)
        circulation_contraction_pct = 15.0 if circulation_contraction_pct is None else float(circulation_contraction_pct)
        specie_loss_pct = 10.0 if specie_loss_pct is None else float(specie_loss_pct)
        stock_smash_pct = 15.0 if stock_smash_pct is None else float(stock_smash_pct)
        commercial_failure_threshold = 50 if commercial_failure_threshold is None else int(commercial_failure_threshold)
        near_approach_severity = 5.0 if near_approach_severity is None else float(near_approach_severity)
        credit_collapsed = bool(credit_collapsed)

        commodity_collapse = commodity_price_change_pct <= -commodity_collapse_pct
        real_estate_collapse = real_estate_price_change_pct <= -commodity_collapse_pct
        circulation_contraction = bank_circulation_change_pct <= -circulation_contraction_pct
        specie_loss = specie_change_pct <= -specie_loss_pct
        many_failures = business_failures >= commercial_failure_threshold
        stock_smash = stock_price_change_pct <= -stock_smash_pct
        banks_suspended = bank_suspensions >= min_bank_suspensions

        business_evidence = (
            credit_collapsed or commodity_collapse or real_estate_collapse or many_failures or specie_loss
        )
        full_crisis = banks_suspended or credit_collapsed
        any_evidence = (
            bank_suspensions != 0
            or commodity_price_change_pct != 0.0
            or real_estate_price_change_pct != 0.0
            or bank_circulation_change_pct != 0.0
            or specie_change_pct != 0.0
            or stock_price_change_pct != 0.0
            or business_failures != 0
            or credit_collapsed
            or depression_severity != 0.0
        )

        drivers: List[str] = []
        if banks_suspended:
            drivers.append("%d bank suspension(s) (>= %d)" % (bank_suspensions, min_bank_suspensions))
        if credit_collapsed:
            drivers.append("credit collapsed")
        if commodity_collapse:
            drivers.append("commodities %.1f%%" % commodity_price_change_pct)
        if real_estate_collapse:
            drivers.append("real estate %.1f%%" % real_estate_price_change_pct)
        if many_failures:
            drivers.append("%d failures (>= %d)" % (business_failures, commercial_failure_threshold))
        if specie_loss:
            drivers.append("specie %.1f%%" % specie_change_pct)
        driver_text = "; ".join(drivers) if drivers else "no bank suspensions, no credit collapse"

        if not any_evidence:
            kind = "no_disturbance_identified"
            severity_class = "none"
            reason = (
                "No disturbance: every attribute supplied is at its neutral value (no suspensions, no price "
                "change, no failures, no credit collapse), so there is nothing to classify."
            )
        elif full_crisis and business_evidence:
            kind = "commercial_panic"
            severity_class = "full_crisis"
            reason = (
                "Commercial panic: the disturbance reached general business as well as the banks -- "
                + driver_text
                + (", with the Stock Exchange down %.1f%%" % stock_price_change_pct if stock_smash else "")
                + "."
            )
        elif full_crisis and stock_smash:
            kind = "stock_exchange_panic_only"
            severity_class = "stock_exchange_panic"
            reason = (
                "Stock Exchange panic only: prices fell %.1f%% on the Exchange and banks/credit were hit "
                "(%s), but there was no commercial-crisis evidence -- no commodity or real-estate collapse "
                "of %.1f%% and %d failures against a threshold of %d."
                % (
                    stock_price_change_pct,
                    driver_text,
                    commodity_collapse_pct,
                    business_failures,
                    commercial_failure_threshold,
                )
            )
        elif full_crisis:
            kind = "commercial_panic"
            severity_class = "full_crisis"
            reason = (
                "Commercial panic: %s, with no measured collapse of commodities, real estate, credit or "
                "failures on the evidence supplied." % driver_text
            )
        elif circulation_contraction and (
            commodity_collapse or real_estate_collapse or depression_severity >= near_approach_severity
        ):
            kind = "near_approach_to_a_crisis"
            severity_class = "near_approach_to_a_crisis"
            reason = (
                "Near approach to a crisis: bank circulation contracted %.1f%% (threshold %.1f%%) causing a "
                "serious fall in prices (%s), yet banks did not suspend and credit did not collapse -- "
                "'purely a money panic as far as its causes were concerned'."
                % (bank_circulation_change_pct, circulation_contraction_pct, driver_text or "depression severity %.1f" % depression_severity)
            )
        elif circulation_contraction:
            kind = "money_panic"
            severity_class = "money_panic"
            reason = (
                "Money panic: bank circulation contracted %.1f%% (threshold %.1f%%) without bank suspensions, "
                "credit collapse or a serious fall in commodity and real-estate prices."
                % (bank_circulation_change_pct, circulation_contraction_pct)
            )
        elif business_evidence:
            kind = "near_approach_to_a_crisis"
            severity_class = "near_approach_to_a_crisis"
            reason = (
                "Near approach to a crisis: %s, but banks did not suspend and credit did not collapse."
                % driver_text
            )
        elif stock_smash:
            kind = "stock_exchange_panic_only"
            severity_class = "stock_exchange_panic"
            reason = (
                "Stock Exchange panic only: prices fell %.1f%% (threshold %.1f%%) with no bank suspensions, "
                "no credit collapse, no contraction of bank circulation and no commodity or real-estate "
                "collapse -- a Stock Exchange smash but not a commercial crisis."
                % (stock_price_change_pct, stock_smash_pct)
            )
        elif depression_severity >= near_approach_severity:
            kind = "near_approach_to_a_crisis"
            severity_class = "near_approach_to_a_crisis"
            reason = (
                "Near approach to a crisis: depression severity %.1f reaches the near-approach level of %.1f, "
                "but banks did not suspend, credit did not collapse and bank circulation did not contract by "
                "%.1f%%." % (depression_severity, near_approach_severity, circulation_contraction_pct)
            )
        else:
            kind = "interruption_to_progress_rather_than_reversal"
            severity_class = "interruption_to_progress_rather_than_reversal"
            reason = (
                "Interruption to progress rather than a reversal of conditions: prices were lower (stocks "
                "%.1f%%, commodities %.1f%%, circulation %.1f%%) and depression severity %.1f is below the "
                "near-approach level of %.1f, with no bank suspensions and no credit collapse -- 'the "
                "situation did not become very serious'."
                % (
                    stock_price_change_pct,
                    commodity_price_change_pct,
                    bank_circulation_change_pct,
                    depression_severity,
                    near_approach_severity,
                )
            )

        result: Dict[str, Any] = {
            "kind": kind,
            "severity_class": severity_class,
            "stock_exchange_involved": bool(stock_smash),
            "is_full_crisis": bool(full_crisis),
            "reason": reason,
        }
        if verbose:
            result["evidence"] = {
                "bank_suspensions": bank_suspensions,
                "banks_suspended": banks_suspended,
                "credit_collapsed": credit_collapsed,
                "commodity_collapse": commodity_collapse,
                "real_estate_collapse": real_estate_collapse,
                "circulation_contraction": circulation_contraction,
                "specie_loss": specie_loss,
                "many_failures": many_failures,
                "stock_smash": stock_smash,
                "depression_severity": depression_severity,
                "purely_money_panic_causes": bool(circulation_contraction and not full_crisis),
                "business_evidence": bool(business_evidence),
            }
            result["thresholds"] = {
                "min_bank_suspensions": min_bank_suspensions,
                "commodity_collapse_pct": commodity_collapse_pct,
                "circulation_contraction_pct": circulation_contraction_pct,
                "specie_loss_pct": specie_loss_pct,
                "stock_smash_pct": stock_smash_pct,
                "commercial_failure_threshold": commercial_failure_threshold,
                "near_approach_severity": near_approach_severity,
            }
        return json.dumps({
            "result": result,
            "error": None,
            "metadata": {"provenance": {
                "source_grounded": [
                    "commercial panic: banks suspend payments, credit collapses, commodity and real-estate prices fall, great number of failures",
                    "stock-exchange smash but not a commercial crisis (1884)",
                    "money panic: contraction of bank circulation causing a serious fall in commodity and real-estate prices",
                    "near approach to a crisis (1819)",
                    "interruption to progress rather than a reversal of conditions (1826)",
                    "serious loss in specie as a crisis attribute",
                ],
                "model_extrapolated": [
                    "numeric thresholds: 2 bank suspensions, 15% commodity/real-estate collapse, 15% circulation contraction, 10% specie loss, 15% stock smash, 50 failures, severity 5/10",
                    "depression_severity 0-10 scale invented to separate a near approach from 'not very serious'",
                    "specie loss counted as commercial-crisis business evidence",
                    "single-label precedence order between overlapping kinds (money panic vs near approach)",
                    "label no_disturbance_identified for an all-neutral attribute set",
                ],
            }},
        })
    except Exception as exc:  # pragma: no cover - defensive
        return json.dumps({
            "result": None,
            "error": "%s: %s" % (type(exc).__name__, exc),
            "metadata": {"provenance": {
                "source_grounded": [],
                "model_extrapolated": ["error path only"],
            }},
        })