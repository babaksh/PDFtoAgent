import json
from typing import List, Optional


async def single_stock_average_impact_dilution(
    surprise_move_points: float,
    group_size: int = 20,
    average_before: Optional[float] = None,
    recovery_series: Optional[List[float]] = None,
    direction: str = "up",
    negligible_threshold_points: float = 0.5,
    recovery_window_periods: int = 5,
    recovered_share_pct: float = 50.0,
    verbose: bool = True,
) -> str:
    """Compute how far a surprise move in ONE constituent stock shifts its 20-stock group average, and rule whether the shift is negligible noise or evidence of a broad business change.

    Use when a single stock in an average does something unexpected (an
    unexpected dividend passed, increased or omitted) and you need to know how
    much of that surprise actually shows up in the group average: the chapter's
    rule is that the move is spread over the whole group, so a ten-point
    surprise in one of twenty stocks moves the average only half a point. Feed
    in the surprise in points, the number of stocks in the group, the average
    before the event, and (optionally) the average's subsequent path in
    `recovery_series` to test the chapter's second half: a move that presages
    no broad business change is "almost instantly recovered".

    Do NOT use this to judge a move that hit several stocks at once (that is a
    breadth question -- call manipulation_scope_by_movement_classifier), and do
    NOT use it to price execution friction (call
    market_turn_effective_execution_price or
    round_trip_friction_quick_turn_test).

    Args:
        surprise_move_points: size of the surprise move in the single stock, in
            price points (the chapter's worked case is 10.0 points).
        group_size: number of stocks in the group average (default 20, the
            chapter's twenty railroad / twenty industrial stocks).
        average_before: the group average just before the surprise, in points.
            Supply it when you want the after-average and the recovery test.
        recovery_series: the group average's path AFTER the surprise, oldest
            first. Used to measure how many periods the impact takes to be
            given back.
        direction: "up" or "down" -- sign of the surprise move.
        negligible_threshold_points: impact on the average at or below which the
            move counts as negligible noise when no recovery path is supplied
            (default 0.5, the chapter's own worked half point).
        recovery_window_periods: number of periods within which a give-back
            counts as "almost instantly recovered" (default 5).
        recovered_share_pct: share of the impact that must be given back for the
            move to count as recovered (default 50.0 = half of it).
        verbose: False returns the compact ruling; True adds the full breakdown.

    Returns:
        JSON string with result/error/metadata. Result holds the diluted impact
        on the average, the average before and after, the recovery measurement
        (or null when no path was supplied) and the verdict --
        "negligible_noise" or "broad_business_change".
    """
    try:
        gs = group_size if isinstance(group_size, int) and group_size > 0 else 20
        move = float(surprise_move_points) if surprise_move_points is not None else 0.0
        if direction == "down":
            signed_move = -abs(move)
        elif direction == "up":
            signed_move = abs(move)
        else:
            signed_move = move

        impact_points = signed_move / float(gs)
        diluted_over = gs - 1

        base = float(average_before) if average_before is not None else None
        after = (base + impact_points) if base is not None else None

        recovery_periods = None
        recovery_measured = False
        recovered = None
        if (
            base is not None
            and recovery_series
            and len(recovery_series) > 0
            and abs(impact_points) > 0.0
        ):
            recovery_measured = True
            give_back_needed = abs(impact_points) * (
                float(recovered_share_pct) / 100.0
            )
            for idx, value in enumerate(recovery_series):
                if abs(float(value) - base) <= give_back_needed:
                    recovery_periods = idx + 1
                    break
            recovered = recovery_periods is not None

        window = (
            int(recovery_window_periods)
            if recovery_window_periods is not None and int(recovery_window_periods) > 0
            else 1
        )
        if recovery_measured:
            if recovered and recovery_periods <= window:
                verdict = "negligible_noise"
                reason = (
                    "Impact of %.4f point(s) on a %d-stock average was given back "
                    "within %d period(s) (chapter's window %d): noise, no broad "
                    "business change." % (impact_points, gs, recovery_periods, window)
                )
            else:
                verdict = "broad_business_change"
                reason = (
                    "Impact of %.4f point(s) on a %d-stock average was not given back "
                    "within %d period(s): the dividend action presages a broad "
                    "general change in business conditions."
                    % (impact_points, gs, window)
                )
        else:
            threshold = (
                float(negligible_threshold_points)
                if negligible_threshold_points is not None
                else 0.5
            )
            if abs(impact_points) <= threshold:
                verdict = "negligible_noise"
                reason = (
                    "A %.4f point move in one stock dilutes to %.4f point(s) over %d "
                    "stocks (spread over the other %d), at or below the %.4f point "
                    "negligible threshold."
                    % (signed_move, impact_points, gs, diluted_over, threshold)
                )
            else:
                verdict = "broad_business_change"
                reason = (
                    "A %.4f point move in one stock dilutes to %.4f point(s) over %d "
                    "stocks, above the %.4f point negligible threshold: too large to "
                    "be a single-stock surprise."
                    % (signed_move, impact_points, gs, threshold)
                )

        if base is not None and abs(base) > 0.0:
            impact_pct = impact_points / base * 100.0
        else:
            impact_pct = None

        result = {
            "surprise_move_points": signed_move,
            "group_size": gs,
            "diluted_over_stocks": diluted_over,
            "average_impact_points": impact_points,
            "average_impact_pct": impact_pct,
            "average_before": base,
            "average_after": after,
            "recovery_measured": recovery_measured,
            "verdict": verdict,
        }
        if verbose:
            result["recovery_periods"] = recovery_periods
            result["recovery_window_periods"] = window
            result["recovered_share_pct"] = float(recovered_share_pct)
            result["negligible_threshold_points"] = (
                float(negligible_threshold_points)
                if negligible_threshold_points is not None
                else 0.5
            )
            result["reason"] = reason
        return json.dumps(
            {
                "result": result,
                "error": None,
                "metadata": {
                    "provenance": {
                        "source_grounded": [
                            "twenty-stock group average as the divisor",
                            "ten-point surprise in one stock makes half a point difference in the average",
                            "negligible when spread over the other nineteen stocks of the same group",
                            "almost instantly recovered if no broad general change in business conditions",
                        ],
                        "model_extrapolated": [
                            "negligible threshold of 0.5 average point",
                            "recovery window of 5 periods for almost instantly",
                            "give-back share of 50% defining recovered",
                            "group_size fallback to 20 when unsupplied or non-positive",
                        ],
                    }
                },
            }
        )
    except Exception as exc:
        return json.dumps(
            {
                "result": None,
                "error": str(exc),
                "metadata": {
                    "provenance": {
                        "source_grounded": [
                            "twenty-stock group average as the divisor",
                            "ten-point surprise in one stock makes half a point difference in the average",
                        ],
                        "model_extrapolated": [
                            "negligible threshold of 0.5 average point",
                            "recovery window of 5 periods for almost instantly",
                        ],
                    }
                },
            }
        )