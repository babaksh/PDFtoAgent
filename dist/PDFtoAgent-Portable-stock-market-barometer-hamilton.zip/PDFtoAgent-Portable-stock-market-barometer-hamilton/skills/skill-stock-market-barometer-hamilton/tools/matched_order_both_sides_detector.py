"""Detect the matched-order stage of a manipulation from broker sides.

Use when you have the brokers reported as executing orders in a stock, with
the side each house worked (buy or sell) over the same period, and you want to
know whether houses are appearing on both sides of the market at once --
executing offsetting orders they may not know are matched. The chapter calls
this the earliest and clumsiest phase of a campaign, and against Stock
Exchange rules.

Inputs: brokers as a list of dicts (broker, buy_shares, sell_shares) or
separate buy/sell broker lists; one call covers one period. Do NOT use this
to date the campaign stage by stage -- call
manipulation_operation_reconstruction_from_tape. Do NOT use it to name the
taxonomy stage -- call manipulated_distribution_stage_taxonomy.
"""

import json
from typing import Any, Dict, List, Optional


async def matched_order_both_sides_detector(
    brokers: Optional[List[Dict]] = None,
    brokers_buy: Optional[List[str]] = None,
    brokers_sell: Optional[List[str]] = None,
    buy_shares: Optional[List[float]] = None,
    sell_shares: Optional[List[float]] = None,
    min_both_sided_brokers: int = 1,
    min_offset_share: float = 0.5,
    verbose: bool = True,
) -> str:
    """Detect brokers working both sides of a stock in one period."""

    def _f(v: Any, default: float = 0.0) -> float:
        try:
            if v is None:
                return default
            return float(v)
        except (TypeError, ValueError):
            return default

    try:
        min_both_sided_brokers = int(_f(min_both_sided_brokers, 1.0))
        if min_both_sided_brokers < 1:
            min_both_sided_brokers = 1
        min_offset_share = _f(min_offset_share, 0.5)

        rows: List[Dict[str, Any]] = []
        for i, b in enumerate(brokers or []):
            if isinstance(b, dict):
                name = str(b.get("broker") or b.get("name") or ("broker_%d" % (i + 1)))
                buy = _f(b.get("buy_shares", b.get("bought")))
                sell = _f(b.get("sell_shares", b.get("sold")))
            else:
                name = str(b)
                buy = _f(buy_shares[i]) if buy_shares and i < len(buy_shares) else 0.0
                sell = _f(sell_shares[i]) if sell_shares and i < len(sell_shares) else 0.0
            rows.append({"broker": name, "buy_shares": buy, "sell_shares": sell})

        if not rows:
            bl = [str(b) for b in (brokers_buy or [])]
            sl = [str(b) for b in (brokers_sell or [])]
            names: List[str] = []
            for nm in bl + sl:
                if nm not in names:
                    names.append(nm)
            for nm in names:
                rows.append({
                    "broker": nm,
                    "buy_shares": 1.0 if nm in bl else 0.0,
                    "sell_shares": 1.0 if nm in sl else 0.0,
                })

        both: List[Dict[str, Any]] = []
        for r in rows:
            buy = r["buy_shares"]
            sell = r["sell_shares"]
            on_buy = buy > 0.0
            on_sell = sell > 0.0
            if not (on_buy and on_sell):
                continue
            gross = buy + sell
            offset = min(buy, sell)
            offset_share = (offset / gross) if gross > 0 else 0.0
            both.append({
                "broker": r["broker"],
                "buy_shares": buy,
                "sell_shares": sell,
                "offsetting_shares": offset,
                "net_shares": buy - sell,
                "offset_share_of_own_trading": round(offset_share, 4),
                "matched": bool(offset_share >= min_offset_share),
            })

        total_buy = sum(r["buy_shares"] for r in rows)
        total_sell = sum(r["sell_shares"] for r in rows)
        offset_shares = sum(b["offsetting_shares"] for b in both)
        gross = total_buy + total_sell
        offset_pct = (offset_shares / gross * 100.0) if gross > 0 else 0.0
        buy_only = [r["broker"] for r in rows if r["buy_shares"] > 0 and r["sell_shares"] == 0]
        sell_only = [r["broker"] for r in rows if r["sell_shares"] > 0 and r["buy_shares"] == 0]
        inactive = [r["broker"] for r in rows if r["buy_shares"] == 0 and r["sell_shares"] == 0]

        n_both = len(both)
        detected = bool(n_both >= min_both_sided_brokers)
        if detected:
            phase = "early_clumsy_matched_order_phase"
            reason = ("%d house(s) worked both sides of the stock in the same period, "
                      "offsetting %.0f shares (%.2f%% of all trading)"
                      % (n_both, offset_shares, offset_pct))
        else:
            phase = "no_matched_order_evidence"
            reason = ("fewer than %d broker(s) appear on both sides in this period"
                      % min_both_sided_brokers)

        result: Dict[str, Any] = {
            "matched_orders_detected": detected,
            "phase": phase,
            "reason": reason,
            "both_sided_brokers": [b["broker"] for b in both],
            "matched_brokers": [b["broker"] for b in both if b["matched"]],
            "both_sided_broker_count": n_both,
            "broker_count": len(rows),
            "total_buy_shares": round(total_buy, 4),
            "total_sell_shares": round(total_sell, 4),
            "offsetting_shares": round(offset_shares, 4),
            "offset_share_of_all_trading_pct": round(offset_pct, 4),
            "buy_only_brokers": buy_only,
            "sell_only_brokers": sell_only,
        }
        if verbose:
            result["broker_detail"] = both
            result["thresholds"] = {
                "min_both_sided_brokers": min_both_sided_brokers,
                "min_offset_share": min_offset_share,
            }
            if inactive:
                result["brokers_with_no_recorded_trading"] = inactive

        return json.dumps({
            "result": result,
            "error": None,
            "metadata": {"provenance": {
                "source_grounded": [
                    "brokers employed on both sides of the market in the early stages",
                    "brokers may not know they are executing matched orders",
                    "matched orders are against Stock Exchange rules",
                    "matched-order trading is the earliest and clumsiest phase",
                    "the practice grows less as the market improves and vanishes as the public takes hold",
                ],
                "model_extrapolated": [
                    "minimum of 1 both-sided broker to flag the phase",
                    "offsetting share measured as min(buy, sell) over the house's gross trading",
                    "0.5 offset share for labelling a house's trading as matched",
                    "one call covers one period; the period window is the caller's split",
                ],
            }},
        })
    except Exception as exc:  # pragma: no cover - defensive
        return json.dumps({
            "result": None,
            "error": "%s: %s" % (type(exc).__name__, exc),
            "metadata": {"provenance": {
                "source_grounded": [],
                "model_extrapolated": [],
            }},
        })