"""Reconstruct a named operator's manipulation campaign from the tape.

Use when you have a stock's recorded sales split into periods (or dated
stages) together with the brokers reported as executing the orders, and you
want the period-by-period comparison the chapter performed on Amalgamated
Copper: sales volume, price range, net price change and broker identity,
compared period against period, so activity can be attributed to a named
operator and dated stage by stage.

Inputs: periods (one dict per period: label/start/end, opening_price,
closing_price, period_high, period_low, sales_shares, days, brokers or
brokers_buy/brokers_sell), operator_brokers (the houses known to act for the
operator), distribution_block_shares (the block the operator had to sell).
Do NOT use this to NAME the stage of each period -- call
manipulated_distribution_stage_taxonomy for that. Do NOT use it to test
whether brokers traded both sides -- call matched_order_both_sides_detector.

Depends on: book_method_line_manipulation_detector (DOW'S THEORY, APPLIED TO
SPECULATION) -- this adds the broker identity of the executing houses and the
per-period sales totals, so activity is attributed to a named operator's
campaign and dated stage by stage rather than read as a line in one stock's
book.
"""

import json
from typing import Any, Dict, List, Optional


async def manipulation_operation_reconstruction_from_tape(
    periods: List[Dict],
    operator_brokers: Optional[List[str]] = None,
    distribution_block_shares: Optional[float] = None,
    heavy_rate_multiple: float = 1.25,
    light_rate_multiple: float = 0.75,
    verbose: bool = True,
) -> str:
    """Reconstruct an operator's campaign from recorded sales and brokers.

    Returns per-period sales/range/broker comparison plus a campaign summary.
    """

    def _f(v: Any, default: float = 0.0) -> float:
        try:
            if v is None:
                return default
            return float(v)
        except (TypeError, ValueError):
            return default

    def _median(xs: List[float]) -> float:
        s = sorted(xs)
        m = len(s)
        if m == 0:
            return 0.0
        if m % 2 == 1:
            return s[m // 2]
        return 0.5 * (s[m // 2 - 1] + s[m // 2])

    def _dir(x: float, tol: float = 1e-12) -> str:
        if x > tol:
            return "up"
        if x < -tol:
            return "down"
        return "flat"

    try:
        heavy_rate_multiple = _f(heavy_rate_multiple, 1.25)
        light_rate_multiple = _f(light_rate_multiple, 0.75)
        op_set = {str(b) for b in (operator_brokers or []) if b is not None}
        block = None
        if distribution_block_shares is not None:
            block = _f(distribution_block_shares, 0.0)

        raw = list(periods or [])

        parsed: List[Dict[str, Any]] = []
        for i, p in enumerate(raw):
            if not isinstance(p, dict):
                continue
            label = str(p.get("label") or p.get("period") or ("period_%d" % (i + 1)))
            sales = _f(p.get("sales_shares", p.get("sales")))
            opening = _f(p.get("opening_price", p.get("open")))
            closing = _f(p.get("closing_price", p.get("close")))
            high = _f(p.get("period_high", p.get("high")))
            low = _f(p.get("period_low", p.get("low")))
            if high == 0.0 and low == 0.0:
                high = max(opening, closing)
                low = min(opening, closing)
            if high < low:
                high, low = low, high
            days = int(_f(p.get("days"), 0.0))
            brokers: List[str] = []
            for b in (p.get("brokers") or []):
                brokers.append(str(b))
            if not brokers:
                for b in list(p.get("brokers_buy") or []) + list(p.get("brokers_sell") or []):
                    brokers.append(str(b))
            seen = set()
            brokers = [b for b in brokers if not (b in seen or seen.add(b))]
            parsed.append({
                "label": label,
                "start": p.get("start"),
                "end": p.get("end"),
                "sales_shares": sales,
                "days": days,
                "rate": sales / float(days) if days > 0 else sales,
                "opening_price": opening,
                "closing_price": closing,
                "period_high": high,
                "period_low": low,
                "brokers": brokers,
            })

        total_sales = sum(r["sales_shares"] for r in parsed)
        n = len(parsed)
        base_rate = _median([r["rate"] for r in parsed]) if n else 0.0

        rows: List[Dict[str, Any]] = []
        prev_brokers: List[str] = []
        prev_rate = 0.0
        for r in parsed:
            brokers = r["brokers"]
            rate = r["rate"]
            rng = r["period_high"] - r["period_low"]
            net = r["closing_price"] - r["opening_price"]
            net_pct = (net / r["opening_price"] * 100.0) if r["opening_price"] else 0.0
            share_pct = (r["sales_shares"] / total_sales * 100.0) if total_sales else 0.0
            vs_mean = (rate / base_rate) if base_rate > 0 else 0.0
            vs_prev = (rate / prev_rate) if prev_rate > 0 else None
            if base_rate <= 0:
                activity = "no_recorded_sales"
            elif rate >= base_rate * heavy_rate_multiple:
                activity = "heavy"
            elif rate <= base_rate * light_rate_multiple:
                activity = "light"
            else:
                activity = "moderate"
            new_brokers = [b for b in brokers if b not in prev_brokers]
            carried = [b for b in brokers if b in prev_brokers]
            op_present = [b for b in brokers if b in op_set]
            op_share = (float(len(op_present)) / float(len(brokers))) if brokers else 0.0
            rows.append({
                "label": r["label"],
                "start": r["start"],
                "end": r["end"],
                "sales_shares": r["sales_shares"],
                "sales_share_pct": round(share_pct, 4),
                "daily_sales_rate": round(rate, 4),
                "sales_vs_campaign_average": round(vs_mean, 4),
                "sales_vs_previous_period": (round(vs_prev, 4) if vs_prev is not None else None),
                "opening_price": r["opening_price"],
                "closing_price": r["closing_price"],
                "period_high": r["period_high"],
                "period_low": r["period_low"],
                "range_points": round(rng, 4),
                "net_price_change": round(net, 4),
                "net_price_change_pct": round(net_pct, 4),
                "net_price_direction": _dir(net),
                "activity_class": activity,
                "broker_count": len(brokers),
                "new_brokers": new_brokers,
                "carried_over_brokers": carried,
                "operator_brokers_present": op_present,
                "operator_broker_share": round(op_share, 4),
                "brokers": brokers,
            })
            prev_brokers = brokers
            prev_rate = rate

        heaviest = max(parsed, key=lambda r: r["sales_shares"])["label"] if parsed else None
        quietest = min(parsed, key=lambda r: r["sales_shares"])["label"] if parsed else None
        first_op = None
        for r in rows:
            if r["operator_brokers_present"]:
                first_op = r["label"]
                break
        all_brokers: List[str] = []
        for r in parsed:
            for b in r["brokers"]:
                if b not in all_brokers:
                    all_brokers.append(b)
        in_every = [b for b in all_brokers if all(b in r["brokers"] for r in parsed)] if parsed else []

        ratio = None
        consistent = None
        if block is not None and block > 0:
            ratio = total_sales / block
            consistent = bool(ratio >= 1.0)

        summary = {
            "period_count": n,
            "total_sales_shares": round(total_sales, 4),
            "heaviest_period": heaviest,
            "quietest_period": quietest,
            "campaign_high": (max(r["period_high"] for r in parsed) if parsed else None),
            "campaign_low": (min(r["period_low"] for r in parsed) if parsed else None),
            "operator_first_appearance": first_op,
            "brokers_seen": all_brokers,
            "brokers_in_every_period": in_every,
            "distribution_block_shares": (round(block, 4) if block is not None else None),
            "sales_multiple_of_block": (round(ratio, 4) if ratio is not None else None),
            "consistent_with_block_distribution": consistent,
        }

        compact_rows = [
            {
                "label": r["label"],
                "sales_shares": r["sales_shares"],
                "sales_share_pct": r["sales_share_pct"],
                "range_points": r["range_points"],
                "net_price_change": r["net_price_change"],
                "net_price_direction": r["net_price_direction"],
                "activity_class": r["activity_class"],
                "operator_brokers_present": r["operator_brokers_present"],
            }
            for r in rows
        ]

        result: Dict[str, Any] = {
            "period_count": n,
            "rows": rows if verbose else compact_rows,
            "summary": summary,
        }
        if verbose:
            result["broker_sequence"] = [
                {
                    "label": r["label"],
                    "brokers": r["brokers"],
                    "new_brokers": r["new_brokers"],
                    "carried_over_brokers": r["carried_over_brokers"],
                    "operator_brokers_present": r["operator_brokers_present"],
                }
                for r in rows
            ]
            result["comparison_basis"] = {
                "heavy_rate_multiple_of_campaign_median": heavy_rate_multiple,
                "light_rate_multiple_of_campaign_median": light_rate_multiple,
                "compared_on": ["sales_shares", "price_range", "net_price_change", "broker_identity"],
            }

        return json.dumps({
            "result": result,
            "error": None,
            "metadata": {"provenance": {
                "source_grounded": [
                    "sales recorded on the ticker as the primary input",
                    "brokers executing orders as reported from the Stock Exchange",
                    "comparison of periods of activity",
                    "per-period sales totals, price fluctuation range and closing price",
                ],
                "model_extrapolated": [
                    "heavy/light activity cutoffs of 1.25x and 0.75x the campaign median daily rate",
                    "daily sales rate used when period days are supplied",
                    "operator_broker_share measured as brokers present divided by brokers seen",
                    "block-distribution consistency taken at total sales >= block",
                ],
            }},
        })
    except Exception as exc:  # pragma: no cover - defensive
        return json.dumps({
            "result": None,
            "error": "%s: %s" % (type(exc).__name__, exc),
            "metadata": {"provenance": {
                "source_grounded": [],
                "model_extrapolated": [],
            }},
        })