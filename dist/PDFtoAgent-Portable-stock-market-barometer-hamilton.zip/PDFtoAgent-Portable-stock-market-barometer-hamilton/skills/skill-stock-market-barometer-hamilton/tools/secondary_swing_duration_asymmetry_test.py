"""Test the time asymmetry of secondary reactions inside a primary rising average."""

import json
from typing import Any, Dict, List, Optional


def _zigzag(prices: List[float], min_move_pct: float) -> List[int]:
    """Return indices of alternating pivots whose reversal exceeds min_move_pct."""
    n = len(prices)
    if n < 3:
        return []
    pivots = [0]
    ext = prices[0]
    ext_i = 0
    direction = 0
    for i in range(1, n):
        price = prices[i]
        if ext == 0.0:
            continue
        change = (price - ext) / abs(ext) * 100.0
        if direction >= 0:
            if price > ext:
                ext = price
                ext_i = i
            elif change <= -min_move_pct:
                if ext_i != pivots[-1]:
                    pivots.append(ext_i)
                ext = price
                ext_i = i
                direction = -1
        else:
            if price < ext:
                ext = price
                ext_i = i
            elif change >= min_move_pct:
                pivots.append(ext_i)
                ext = price
                ext_i = i
                direction = 1
    if pivots[-1] != ext_i:
        pivots.append(ext_i)
    if pivots[-1] != n - 1:
        pivots.append(n - 1)
    return pivots


async def secondary_swing_duration_asymmetry_test(
    prices: List[float],
    periods: Optional[List[str]] = None,
    min_move_pct: float = 5.0,
    min_primary_rise_pct: float = 10.0,
    min_decline_pct: float = 5.0,
    min_recovery_ratio: float = 1.0,
    verbose: bool = True,
) -> str:
    """Measure each secondary decline and its subsequent recovery inside a primary
    rising average, and report whether declines are short and sharp while the halting
    recovery consumes the longer time.

    Use when you have the price path of an average over a period you believe is a
    primary RISE, and you want this chapter's time-dimension test on its secondary
    reactions: "secondary downward swings in a primary rising average are short and
    sharp, with a halting recovery consuming a longer time than the decline". The
    tool builds the swing sequence (pivots separated by at least min_move_pct), takes
    every decline leg and the recovery leg that follows it, compares the two
    durations, and returns a verdict per swing and overall.

    Extends three_eighths_secondary_reaction_rule (chDOW'S THEORY, APPLIED TO
    SPECULATION): that tool scores a reaction's MAGNITUDE against the three-eighths
    ratio; this one adds the TIME dimension -- short sharp decline versus a slower,
    halting recovery that takes longer.

    Do NOT use for the major swings themselves (use major_swing_duration_ratio), and
    do NOT use it inside a primary decline, where the chapter makes no such claim.
    """
    try:
        prices = [float(p) for p in (prices or []) if p is not None]
        min_move_pct = 5.0 if min_move_pct is None else float(min_move_pct)
        min_primary_rise_pct = 10.0 if min_primary_rise_pct is None else float(min_primary_rise_pct)
        min_decline_pct = 5.0 if min_decline_pct is None else float(min_decline_pct)
        min_recovery_ratio = 1.0 if min_recovery_ratio is None else float(min_recovery_ratio)

        n = len(prices)
        result: Dict[str, Any] = {
            "n_periods": n,
            "net_change_pct": None,
            "primary_rising": False,
            "n_secondary_swings": 0,
            "n_asymmetric_swings": 0,
            "asymmetry_share": None,
            "mean_decline_periods": None,
            "mean_recovery_periods": None,
            "mean_recovery_to_decline_ratio": None,
            "verdict": False,
            "reason": "No price path supplied, so no secondary swing can be measured.",
        }
        if n == 0:
            return json.dumps({
                "result": result,
                "error": None,
                "metadata": {"provenance": {
                    "source_grounded": [],
                    "model_extrapolated": ["empty-input neutral reading"],
                }},
            })

        first = prices[0]
        last = prices[-1]
        net_pct = (last - first) / abs(first) * 100.0 if first != 0.0 else 0.0
        result["net_change_pct"] = net_pct
        result["primary_rising"] = bool(first != 0.0 and net_pct >= min_primary_rise_pct and n >= 3)

        pivots = _zigzag(prices, min_move_pct)
        swings: List[Dict[str, Any]] = []

        for k in range(len(pivots) - 2):
            i0, i1, i2 = pivots[k], pivots[k + 1], pivots[k + 2]
            start_price = prices[i0]
            low_price = prices[i1]
            end_price = prices[i2]
            if low_price >= start_price or end_price <= low_price:
                continue
            if start_price == 0.0:
                continue
            decline_periods = i1 - i0
            recovery_periods = i2 - i1
            decline_pct = (low_price - start_price) / abs(start_price) * 100.0
            recovery_pct = (end_price - low_price) / abs(low_price) * 100.0
            if decline_periods <= 0 or recovery_periods <= 0:
                continue
            ratio = float(recovery_periods) / float(decline_periods)
            sharp = bool(abs(decline_pct) >= min_decline_pct)
            asymmetric = bool(ratio >= min_recovery_ratio)
            swings.append({
                "decline_start_index": i0,
                "trough_index": i1,
                "recovery_end_index": i2,
                "decline_start_label": periods[i0] if periods and i0 < len(periods) else None,
                "trough_label": periods[i1] if periods and i1 < len(periods) else None,
                "recovery_end_label": periods[i2] if periods and i2 < len(periods) else None,
                "decline_periods": decline_periods,
                "recovery_periods": recovery_periods,
                "decline_pct": decline_pct,
                "recovery_pct": recovery_pct,
                "recovery_to_decline_ratio": ratio,
                "decline_is_sharp": sharp,
                "recovery_longer_than_decline": asymmetric,
                "asymmetric": bool(sharp and asymmetric),
            })

        result["n_secondary_swings"] = len(swings)
        if swings:
            declines = [s["decline_periods"] for s in swings]
            recoveries = [s["recovery_periods"] for s in swings]
            ratios = [s["recovery_to_decline_ratio"] for s in swings]
            asym = [s for s in swings if s["asymmetric"]]
            result["mean_decline_periods"] = sum(declines) / float(len(declines))
            result["mean_recovery_periods"] = sum(recoveries) / float(len(recoveries))
            result["mean_recovery_to_decline_ratio"] = sum(ratios) / float(len(ratios))
            result["n_asymmetric_swings"] = len(asym)
            result["asymmetry_share"] = float(len(asym)) / float(len(swings))
            result["verdict"] = bool(result["primary_rising"] and asym and result["asymmetry_share"] >= 0.5)

            if not result["primary_rising"]:
                result["reason"] = (
                    "The average does not show a primary rise over the window (net change "
                    "%.2f%% against the %.2f%% required), so this chapter's rule about "
                    "secondary swings inside a primary rising average does not apply."
                    % (net_pct, min_primary_rise_pct)
                )
            elif result["verdict"]:
                result["reason"] = (
                    "Inside a primary rise of %.2f%%, %d of %d secondary swings are short and "
                    "sharp with a longer halting recovery: mean decline %.2f periods against a "
                    "mean recovery of %.2f periods (ratio %.2f)." % (
                        net_pct, len(asym), len(swings), result["mean_decline_periods"],
                        result["mean_recovery_periods"], result["mean_recovery_to_decline_ratio"],
                    )
                )
            else:
                result["reason"] = (
                    "Only %d of %d secondary swings show the short-sharp-decline / longer-halting-"
                    "recovery pattern (mean decline %.2f periods, mean recovery %.2f periods, "
                    "ratio %.2f), so the chapter's time asymmetry is not confirmed here." % (
                        len(asym), len(swings), result["mean_decline_periods"],
                        result["mean_recovery_periods"], result["mean_recovery_to_decline_ratio"],
                    )
                )
        else:
            reason = (
                "The average shows a primary rise of %.2f%% but the path contains no completed "
                "decline-and-recovery swing at the %.2f%% reversal threshold, so no time "
                "asymmetry is measurable." % (net_pct, min_move_pct)
                if result["primary_rising"] else
                "The path contains no completed decline-and-recovery swing at the %.2f%% "
                "reversal threshold and shows no primary rise (net change %.2f%%), so no time "
                "asymmetry is measurable." % (min_move_pct, net_pct)
            )
            result["reason"] = reason

        if verbose:
            result["swings"] = swings
            result["thresholds"] = {
                "min_move_pct": min_move_pct,
                "min_primary_rise_pct": min_primary_rise_pct,
                "min_decline_pct": min_decline_pct,
                "min_recovery_ratio": min_recovery_ratio,
            }

        return json.dumps({
            "result": result,
            "error": None,
            "metadata": {
                "provenance": {
                    "source_grounded": [
                        "secondary downward swings in a primary rising average are short and sharp",
                        "a halting recovery consuming a longer time than the decline",
                        "bear market normally appreciably shorter than a bull market, as these reactions are",
                    ],
                    "model_extrapolated": [
                        "min_move_pct=5 zigzag to delimit a secondary swing",
                        "min_primary_rise_pct=10 test for a primary rising average",
                        "min_decline_pct=5 for 'short and sharp'",
                        "min_recovery_ratio=1.0 for the recovery taking longer",
                        "asymmetry_share >= 0.5 for the overall verdict",
                    ],
                }
            },
        })
    except Exception as exc:  # noqa: BLE001
        return json.dumps({
            "result": None,
            "error": "secondary_swing_duration_asymmetry_test failed: %s" % exc,
            "metadata": {
                "provenance": {
                    "source_grounded": [],
                    "model_extrapolated": ["error handling path"],
                }
            },
        })