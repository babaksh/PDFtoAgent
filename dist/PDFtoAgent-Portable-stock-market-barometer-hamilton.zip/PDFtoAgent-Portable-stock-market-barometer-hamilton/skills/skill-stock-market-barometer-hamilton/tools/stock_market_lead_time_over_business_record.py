import json
from typing import Any, Dict, List, Optional


def _get(d: Dict[str, Any], *names: str, default: Any = None) -> Any:
    for n in names:
        if isinstance(d, dict) and n in d and d[n] is not None:
            return d[n]
    return default


def _f(v: Any, default: Optional[float] = None) -> Optional[float]:
    try:
        if v is None:
            return default
        return float(v)
    except (TypeError, ValueError):
        return default


def _norm_dir(v: Any) -> str:
    s = str(v or "").strip().lower()
    if s in ("bull", "up", "rise", "rising", "advance"):
        return "bull"
    if s in ("bear", "down", "fall", "falling", "decline"):
        return "bear"
    return s


def _norm_kind(v: Any) -> str:
    s = str(v or "").strip().lower()
    if s in ("depression", "below", "contraction", "black_below"):
        return "depression"
    if s in ("expansion", "above", "prosperity", "black_above"):
        return "expansion"
    return s


async def stock_market_lead_time_over_business_record(
    market_swings: List[Dict[str, Any]],
    business_areas: List[Dict[str, Any]],
    min_lead_months: float = 0.0,
    min_forecast_share: float = 1.0,
    verbose: bool = True,
) -> str:
    """Measure how far ahead stock-market primary swings led dated business-condition areas.

    Use when you have (a) dated primary market swings -- each with a direction
    (bull/bear) and decimal start/end years -- and (b) dated fundamental business
    areas (expansion or depression) with decimal start/end years, and you want to
    test the chapter's claim that the stock market barometer predicted each
    business area months before the business record itself showed it. For every
    business area the tool pairs it with the primary swing of the matching
    direction (a depression area pairs with a bear swing, an expansion area with
    a bull swing), measures the lead in months from the market turning point to
    the start of the business area, and grades the pair forecast / coincident /
    lagged.

    Do NOT use this to date a swing from a price path (call
    primary_movement_termination_rule), and do NOT use it to grade the shape of a
    business area (call babson_area_depth_duration_balance_test).

    Depends on: primary_movement_termination_rule (chMAJOR MARKET SWINGS) can
    supply the dated swings consumed here.
    """
    try:
        swings_in = list(market_swings) if market_swings else []
        areas_in = list(business_areas) if business_areas else []

        min_lead = 0.0 if min_lead_months is None else float(min_lead_months)
        min_share = 1.0 if min_forecast_share is None else float(min_forecast_share)

        swings = []
        for i, s in enumerate(swings_in):
            if not isinstance(s, dict):
                continue
            st = _f(_get(s, "start_year", "start", "begin_year"))
            en = _f(_get(s, "end_year", "end", "end"))
            if st is None:
                continue
            swings.append({
                "label": str(_get(s, "label", "name", default="swing_%d" % (i + 1))),
                "direction": _norm_dir(_get(s, "direction", "trend", "kind")),
                "start_year": st,
                "end_year": en,
            })

        rows: List[Dict[str, Any]] = []
        leads: List[float] = []
        matched = 0
        forecast = 0

        for j, a in enumerate(areas_in):
            if not isinstance(a, dict):
                continue
            kind = _norm_kind(_get(a, "kind", "type", "area_kind"))
            a_start = _f(_get(a, "start_year", "start", "begin_year"))
            a_end = _f(_get(a, "end_year", "end"))
            label = str(_get(a, "label", "name", default="area_%d" % (j + 1)))

            wanted = "bear" if kind == "depression" else ("bull" if kind == "expansion" else None)
            cands = [s for s in swings if (wanted is None or s["direction"] == wanted)]

            best = None
            behind = [s for s in cands if a_start is not None and s["start_year"] <= a_start]
            if behind:
                best = max(behind, key=lambda s: s["start_year"])
                matched_source = "preceding_swing"
            elif cands:
                best = min(cands, key=lambda s: s["start_year"])
                matched_source = "following_swing"
            else:
                matched_source = "no_matching_swing"

            if best is None or a_start is None:
                rows.append({
                    "area_label": label,
                    "area_kind": kind or "unknown",
                    "area_start_year": a_start,
                    "area_end_year": a_end,
                    "swing_label": None,
                    "swing_direction": wanted,
                    "swing_start_year": None,
                    "swing_end_year": None,
                    "lead_months": None,
                    "horizon_months": None,
                    "match": matched_source,
                    "grade": "unmatched",
                    "forecast": False,
                })
                continue

            lead = (a_start - best["start_year"]) * 12.0
            horizon = None if a_end is None else (a_end - best["start_year"]) * 12.0
            if lead > min_lead:
                grade = "forecast"
            elif lead < 0.0:
                grade = "lagged"
            else:
                grade = "coincident"
            is_fc = grade == "forecast"
            matched += 1
            if is_fc:
                forecast += 1
                leads.append(lead)
            rows.append({
                "area_label": label,
                "area_kind": kind or "unknown",
                "area_start_year": a_start,
                "area_end_year": a_end,
                "swing_label": best["label"],
                "swing_direction": best["direction"],
                "swing_start_year": best["start_year"],
                "swing_end_year": best["end_year"],
                "lead_months": lead,
                "horizon_months": horizon,
                "match": matched_source,
                "grade": grade,
                "forecast": is_fc,
            })

        tested = len([r for r in rows])
        share = (float(forecast) / float(tested)) if tested else 0.0
        mean_lead = (sum(leads) / float(len(leads))) if leads else (0.0 if tested else None)
        max_lead = max(leads) if leads else (0.0 if tested else None)
        verdict = bool(tested) and share >= min_share - 1e-12
        if not tested:
            reason = "no business areas supplied; no lead time can be measured"
        elif matched == 0:
            reason = "no primary swing of matching direction could be paired with any business area"
        elif verdict:
            reason = "the market turning point led %d of %d business areas by a mean of %.1f months" % (
                forecast, tested, mean_lead if mean_lead is not None else 0.0)
        else:
            reason = "only %d of %d business areas were led by the market (share %.2f < required %.2f)" % (
                forecast, tested, share, min_share)

        result: Dict[str, Any] = {
            "areas_tested": tested,
            "areas_matched": matched,
            "areas_forecast": forecast,
            "forecast_share": share,
            "mean_lead_months": mean_lead,
            "max_lead_months": max_lead,
            "min_lead_months_required": min_lead,
            "min_forecast_share_required": min_share,
            "verdict": verdict,
            "reason": reason,
        }
        if verbose:
            result["rows"] = rows
            result["swings_supplied"] = len(swings)

        return json.dumps({
            "result": result,
            "error": None,
            "metadata": {"provenance": {
                "source_grounded": [
                    "bear swing Sept 1902 - Sept 1903 preceded the 1903-1904 depression area",
                    "bear swing Jan 1907 - early Dec 1907 (11 months) preceded the 1908 depression area",
                    "bull swing Dec 1907 - Aug 1909 preceded the 1908-1909 expansion area",
                    "barometer predicts business areas months ahead; Babson chart is a record",
                ],
                "model_extrapolated": [
                    "min_lead_months default 0.0: any positive lead counts as a forecast",
                    "min_forecast_share default 1.0 (chapter: the market predicted each area)",
                    "pairing rule: nearest preceding swing of matching direction, else nearest following swing",
                    "decimal-year convention (fraction of year) for all dates",
                ],
            }},
        })
    except Exception as exc:  # noqa: BLE001
        return json.dumps({
            "result": None,
            "error": "stock_market_lead_time_over_business_record failed: %s" % exc,
            "metadata": {"provenance": {
                "source_grounded": [],
                "model_extrapolated": ["error path"],
            }},
        })