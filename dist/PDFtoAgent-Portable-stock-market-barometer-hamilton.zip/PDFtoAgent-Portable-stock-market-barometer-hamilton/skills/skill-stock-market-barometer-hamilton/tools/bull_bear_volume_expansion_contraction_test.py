"""Classify a swing as bull or bear from how traded volume behaves against price.

The chapter's statement: "the volume of trading is always larger in a bull
market than in a bear market. It expands as prices go up and contracts as they
decline" -- uniformly true of major bull swings, but "subject to great
modification in the secondary movements", because "a sharp reaction in a bull
market will often stimulate the volume of business" (the May 1901 Northern
Pacific panic, when average monthly sales exceeded 1,800,000 shares a day).
"""

import json
import math
from typing import List, Optional


def _clean(values) -> List[float]:
    if not values:
        return []
    out = []
    for v in values:
        try:
            f = float(v)
        except (TypeError, ValueError):
            continue
        if math.isnan(f) or math.isinf(f):
            continue
        out.append(f)
    return out


def _mean(xs: List[float]):
    return sum(xs) / len(xs) if xs else 0.0


def _max_drawdown_pct(prices: List[float]) -> float:
    peak = prices[0]
    worst = 0.0
    for p in prices:
        if p > peak:
            peak = p
        denom = abs(peak) if peak != 0.0 else 1.0
        drop = (peak - p) / denom * 100.0
        if drop > worst:
            worst = drop
    return worst


async def bull_bear_volume_expansion_contraction_test(
    prices: List[float],
    volumes: List[float],
    sharp_reaction_pct: float = 5.0,
    expansion_tolerance_pct: float = 10.0,
    verbose: bool = True,
) -> str:
    """Classify a swing bull or bear by whether volume expands on rises and contracts on declines.

    Use when you have a price series AND the matching traded volume (recorded
    sales) over the same periods and want the chapter's volume confirmation of
    the swing's character: in a bull market volume expands as prices advance and
    contracts as they decline; the reverse holds in a bear market. The tool also
    applies the chapter's named exception -- a sharp reaction inside a bull
    market often stimulates volume instead -- so a decline on heavy volume is
    not automatically read as bear.

    Do NOT use this without a volume series: price alone cannot answer it. Do
    NOT use it to judge the daily fluctuation; the rule is stated for swings.

    Args:
        prices: price (or average) series, oldest first.
        volumes: traded volume / recorded sales for the same periods.
        sharp_reaction_pct: percent peak-to-trough decline that counts as a "sharp reaction".
        expansion_tolerance_pct: percent by which one side's mean volume must exceed the other to count.
        verbose: False returns the compact verdict; True adds the per-period detail.

    Returns:
        JSON {"result": {...}, "error": None, "metadata": {...}} with
        `classification` plus a short `reason`.
    """
    try:
        sharp_reaction_pct = 5.0 if sharp_reaction_pct is None else float(sharp_reaction_pct)
        expansion_tolerance_pct = (
            10.0 if expansion_tolerance_pct is None else float(expansion_tolerance_pct)
        )

        px = _clean(prices)
        vol = _clean(volumes)
        n = min(len(px), len(vol))
        px = px[:n]
        vol = vol[:n]

        if n < 2:
            return json.dumps({
                "result": {
                    "classification": "insufficient_data",
                    "reason": "At least two paired price and volume observations are needed; "
                              "no swing character can be read.",
                    "periods_compared": n,
                },
                "error": None,
                "metadata": {
                    "provenance": {
                        "source_grounded": ["volume expands as prices go up and contracts as they decline"],
                        "model_extrapolated": ["insufficient-data boundary reading"],
                    }
                },
            })

        up_vols: List[float] = []
        down_vols: List[float] = []
        rows = []
        for i in range(1, n):
            delta = px[i] - px[i - 1]
            if delta > 0.0:
                up_vols.append(vol[i])
                rows.append({"index": i, "price_change": "up", "volume": vol[i]})
            elif delta < 0.0:
                down_vols.append(vol[i])
                rows.append({"index": i, "price_change": "down", "volume": vol[i]})
            else:
                rows.append({"index": i, "price_change": "flat", "volume": vol[i]})

        mean_up = _mean(up_vols)
        mean_down = _mean(down_vols)
        tol = 1.0 + abs(expansion_tolerance_pct) / 100.0

        denom = abs(px[0]) if px[0] != 0.0 else 1.0
        net_pct = (px[-1] - px[0]) / denom * 100.0
        drawdown_pct = _max_drawdown_pct(px)

        ratio = None
        if mean_down > 0.0:
            ratio = mean_up / mean_down
        elif mean_up > 0.0:
            ratio = float("inf") if mean_down == 0.0 else None

        if not up_vols and not down_vols:
            classification = "no_price_movement"
            reason = ("Prices did not move in either direction over the window, so the "
                      "volume/price rule has nothing to compare and no swing is read.")
        elif not up_vols or not down_vols:
            classification = "single_direction_only"
            reason = ("Prices moved in one direction only over the window, so there is no "
                      "opposite side against which to test contraction or expansion of volume.")
        else:
            if ratio is not None and ratio > tol:
                classification = "bull"
                reason = ("Mean volume on rising periods exceeds that on declining periods by "
                          + format((ratio - 1.0) * 100.0, ".1f")
                          + "%, so volume expands as prices go up and contracts as they decline "
                            "-- the chapter's bull reading.")
            elif ratio is not None and ratio < 1.0 / tol:
                if net_pct > 0.0 and drawdown_pct >= sharp_reaction_pct:
                    classification = "bull_sharp_reaction_exception"
                    reason = ("Volume was heaviest on the declining periods, but the window is "
                              "still net higher with a sharp reaction of "
                              + format(drawdown_pct, ".1f")
                              + "% inside it; the chapter's named exception applies -- a sharp "
                                "reaction in a bull market often stimulates business -- so this "
                                "is not read as a bear swing.")
                else:
                    classification = "bear"
                    reason = ("Mean volume on declining periods exceeds that on rising periods, "
                              "so volume expands as prices fall and contracts as they rise -- "
                              "the reverse of the bull rule, and no sharp-reaction exception "
                              "applies.")
            else:
                classification = "indeterminate"
                reason = ("Volume on rising and declining periods differs by less than the "
                          + format(abs(expansion_tolerance_pct), ".1f")
                          + "% tolerance, so the volume/price rule gives no reading.")

        result = {
            "classification": classification,
            "reason": reason,
            "net_price_change_pct": round(net_pct, 4),
            "max_drawdown_pct": round(drawdown_pct, 4),
            "up_period_volume_mean": round(mean_up, 4),
            "down_period_volume_mean": round(mean_down, 4),
            "volume_expansion_ratio": None if ratio is None or math.isinf(ratio) else round(ratio, 4),
            "up_periods": len(up_vols),
            "down_periods": len(down_vols),
        }
        if verbose:
            result["detail"] = {
                "periods_compared": n,
                "sharp_reaction_pct": sharp_reaction_pct,
                "expansion_tolerance_pct": expansion_tolerance_pct,
                "sharp_reaction_present": drawdown_pct >= sharp_reaction_pct,
                "rows": rows,
                "rule_quote": "expands as prices go up and contracts as they decline",
            }

        return json.dumps({
            "result": result,
            "error": None,
            "metadata": {
                "provenance": {
                    "source_grounded": [
                        "volume larger in a bull market than in a bear market",
                        "expands as prices go up and contracts as they decline",
                        "uniformly true of major bull swings",
                        "a sharp reaction in a bull market will often stimulate the volume of business",
                    ],
                    "model_extrapolated": [
                        "sharp reaction threshold of 5.0% peak-to-trough",
                        "expansion tolerance of 10.0% between the two volume means",
                        "comparison on same-period price change versus that period's volume",
                    ],
                }
            },
        })
    except Exception as exc:
        return json.dumps({
            "result": {
                "classification": "insufficient_data",
                "reason": "Could not evaluate the price and volume series: " + str(exc),
            },
            "error": None,
            "metadata": {
                "provenance": {
                    "source_grounded": ["expands as prices go up and contracts as they decline"],
                    "model_extrapolated": ["boundary reading on unusable input"],
                }
            },
        })