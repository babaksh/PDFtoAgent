import json
from typing import Optional


async def post_panic_readjustment_lag_test(
    panic_year: Optional[float] = None,
    stock_break_years: Optional[float] = None,
    rally_years: Optional[float] = None,
    restoration_year: Optional[float] = None,
    restoration_marker: str = "resumption of specie payments",
    swing_start_year: Optional[float] = None,
    observation_year: Optional[float] = None,
    major_swing_bound_years: Optional[float] = None,
    latitude_years: Optional[float] = None,
    much_longer_factor: Optional[float] = None,
    verbose: bool = True,
) -> str:
    """Measure the readjustment lag that follows a major panic and rule whether
    the nearly five-year major swing plotted from the post-panic top is still running.

    Use after a major panic when you know how long the break in stocks lasted and
    how long the subsequent logical rally took to culminate, and you can date the
    restoration of business and confidence by a NAMED marker (the chapter's own
    instance: it was not until the resumption of specie payments, 1879, was well
    in sight that business picked up after the panic of 1873). The test compares
    the years of readjustment against the years the market episode itself
    occupied, because the chapter infers that the effects of a major panic are
    NOT all dissipated by the subsequent logical stock market rally: "the
    business of readjustment took much longer", and it is "not a task of months
    but of years to restore confidence where it has once been successfully
    assailed."

    It then rules on Charles H. Dow's assumed five-year major swing: measured
    from the top of the stock market (`swing_start_year`, e.g. late 1909) to the
    observation year (e.g. 1914), is that swing still running within the bound
    (with a little latitude)?

    Extends: stock_market_lead_time_over_business_record (chA UNIQUE QUALITY OF
    FORECAST) -- that tool measures the market's lead over business turns; this
    one constrains the measurement to the POST-PANIC tail, where panic effects
    outlast the rally and restoration is a task of years, and tests the whole
    span against the five-year swing bound.

    Do NOT use for: ordinary (non-panic) business-cycle lead measurement, for
    dating a market turn itself, or for the day-to-day fluctuation.

    Args:
        panic_year: year of the panic (e.g. 1873.0, 1893.0, 1907.0).
        stock_break_years: duration in years of the break in stock prices.
        rally_years: duration in years of the subsequent logical rally, to its
            culmination.
        restoration_year: year business/confidence was restored per the marker;
            None leaves the readjustment lag unmeasured.
        restoration_marker: label for the restoration marker used.
        swing_start_year: year of the post-panic market TOP from which the
            five-year major swing is plotted (e.g. 1909.8).
        observation_year: year at which the swing is being judged (e.g. 1914.0).
        major_swing_bound_years: Dow's assumed major swing length (default 5.0).
        latitude_years: "a little latitude" allowed beyond the bound
            (default 0.5).
        much_longer_factor: how many times the market episode the readjustment
            must last to count as "much longer" (default 1.5).
        verbose: False returns the compact verdict and the computed years only.

    Returns:
        JSON string with keys result/error/metadata.
    """
    try:
        panic_year = 0.0 if panic_year is None else float(panic_year)
        stock_break_years = 0.0 if stock_break_years is None else abs(float(stock_break_years))
        rally_years = 0.0 if rally_years is None else abs(float(rally_years))
        bound = 5.0 if major_swing_bound_years is None else float(major_swing_bound_years)
        latitude = 0.5 if latitude_years is None else abs(float(latitude_years))
        factor = 1.5 if much_longer_factor is None else float(much_longer_factor)

        market_episode_years = stock_break_years + rally_years

        readjustment_years = None
        excess_years = None
        lag_ratio = None
        outlasts = None
        if restoration_year is not None and float(restoration_year) > panic_year:
            readjustment_years = float(restoration_year) - panic_year
            excess_years = readjustment_years - market_episode_years
            if market_episode_years > 0:
                lag_ratio = readjustment_years / market_episode_years
                outlasts = bool(lag_ratio >= factor)
            else:
                outlasts = bool(readjustment_years > 0)

        if outlasts is None:
            readjustment_verdict = "unmeasured"
        elif outlasts:
            readjustment_verdict = "outlasts_market_episode"
        else:
            readjustment_verdict = "completed_within_market_episode"

        elapsed = None
        swing_still_running = None
        if swing_start_year is not None and observation_year is not None:
            elapsed = float(observation_year) - float(swing_start_year)
            swing_still_running = bool(elapsed <= (bound + latitude))

        if swing_still_running is None:
            classification = "swing_unmeasured"
            reason = (
                "The swing was not dated: supply both the post-panic market top "
                "and the year at which the swing is judged, so the elapsed years "
                "can be tested against the five-year major swing bound."
            )
        elif swing_still_running:
            classification = "major_swing_still_running"
            reason = (
                "Plotted from the top of %s the swing had run %.2f years by %s, "
                "still within the %.1f-year major swing (with a little latitude): "
                "the readjustment from the panic of %s is not over, and "
                "confidence is not yet restored."
                % (swing_start_year, elapsed, observation_year, bound, panic_year)
            )
        else:
            classification = "major_swing_completed"
            reason = (
                "Plotted from the top of %s the swing had run %.2f years by %s, "
                "beyond the %.1f-year major swing plus latitude: the swing has "
                "run its course and the readjustment is no longer the live "
                "forecast."
                % (swing_start_year, elapsed, observation_year, bound)
            )

        if readjustment_verdict == "outlasts_market_episode":
            reason += (
                " The readjustment (%.2f years, to %s) is much longer than the "
                "%0.2f years occupied by the break and its logical rally, so the "
                "effects of the panic were not dissipated by the rally."
                % (readjustment_years, restoration_marker, market_episode_years)
            )
        elif readjustment_verdict == "completed_within_market_episode":
            reason += (
                " The readjustment (%.2f years, to %s) did not greatly exceed the "
                "%0.2f years occupied by the break and its logical rally."
                % (readjustment_years, restoration_marker, market_episode_years)
            )
        else:
            reason += (
                " No named restoration marker was supplied, so the length of the "
                "readjustment is left unmeasured rather than assumed."
            )

        result = {
            "classification": classification,
            "reason": reason,
            "readjustment_verdict": readjustment_verdict,
            "readjustment_outlasts_market_episode": outlasts,
            "panic_year": panic_year,
            "stock_break_years": stock_break_years,
            "rally_years": rally_years,
            "market_episode_years": market_episode_years,
            "readjustment_years": readjustment_years,
            "readjustment_excess_years": excess_years,
            "lag_over_market_episode": lag_ratio,
            "swing_elapsed_years": elapsed,
            "swing_still_running": swing_still_running,
            "restoration_marker": restoration_marker,
        }
        if verbose:
            result["major_swing_bound_years"] = bound
            result["latitude_years"] = latitude
            result["much_longer_factor"] = factor
            result["restoration_year"] = (
                None if restoration_year is None else float(restoration_year)
            )
        else:
            result = {
                k: result[k]
                for k in (
                    "classification",
                    "reason",
                    "readjustment_verdict",
                    "readjustment_outlasts_market_episode",
                    "market_episode_years",
                    "readjustment_years",
                    "readjustment_excess_years",
                    "lag_over_market_episode",
                    "swing_elapsed_years",
                    "swing_still_running",
                )
            }

        return json.dumps({
            "result": result,
            "error": None,
            "metadata": {"provenance": {
                "source_grounded": [
                    "effects of a major panic are not dissipated by the subsequent logical stock market rally",
                    "the business of readjustment took much longer",
                    "panic of 1873: not until the resumption of specie payments (1879) was well in sight did business pick up",
                    "panic of 1893 followed by depression much longer than the break in stocks",
                    "not a task of months but of years to restore confidence once assailed",
                    "five-year major swing assumed by Charles H. Dow, with a little latitude",
                    "1909 top to the outbreak of the war: nearly five years",
                ],
                "model_extrapolated": [
                    "major_swing_bound_years default 5.0",
                    "latitude_years default 0.5 for 'a little latitude'",
                    "much_longer_factor default 1.5 for 'much longer than the break in stocks'",
                    "readjustment measured from panic_year to the named restoration year",
                    "unmeasured (None) readings instead of a guessed verdict when inputs are missing",
                ],
            }},
        })
    except Exception as exc:  # pragma: no cover - defensive
        return json.dumps({
            "result": None,
            "error": "post_panic_readjustment_lag_test failed: %s" % exc,
            "metadata": {"provenance": {
                "source_grounded": [],
                "model_extrapolated": ["defensive error wrapper"],
            }},
        })