import json
from typing import List, Optional


async def railroad_capitalization_per_mile_comparison(
    stocks_and_bonds_capitalization: float,
    miles: float,
    peers: Optional[List[dict]] = None,
    five_times_threshold: bool = True,
    lowest_is_undercapitalized: bool = True,
    verbose: bool = True,
) -> str:
    """Test the aggregate charge of watered stock by capitalization per mile, ranked against peers.

    Use when you have a railroad system's capitalization in stocks and bonds and
    its mileage, plus a peer set of other systems or countries with the same two
    figures, and you want the chapter's verdict on the charge that American
    railroad capitalization is water.

    The chapter states the comparison outright: "The capitalization in stocks and
    bonds of its railroads, alleged to represent water, is not one-fifth that of
    the railroads of the British Islands, mile for mile. It is less per mile than
    that of any European country or of any government or privately owned railroad
    in Britain's self-governing colonies. I am not afraid to go on record with
    the statement that the American railroads are uneconomically
    undercapitalized, on their real value."

    Returns capitalization per mile for the subject system, the peer ranking, the
    ratio to the highest and lowest peers, whether the one-fifth (five-times)
    charge is falsified, and the undercapitalization verdict.

    Do NOT use it to test water in a single industrial capitalization (that is
    `water_in_capitalization_test`), and do NOT use it to decide whether a
    quoted price is a real market price (that is
    `ownership_distribution_real_market_test`).
    """
    provenance = {
        "source_grounded": [
            "the capitalization in stocks and bonds of its railroads, alleged to represent water",
            "not one-fifth that of the railroads of the British Islands, mile for mile",
            "less per mile than that of any European country or of any government or privately owned railroad in Britain's self-governing colonies",
            "the American railroads are uneconomically undercapitalized, on their real value",
            "the comparison is made mile for mile",
            "the fetish of watered stock has carried this country to astonishing depths of foolishness",
        ],
        "model_extrapolated": [
            "capitalization taken at the stated (par / book) amount of stocks and bonds, not at market value",
            "per-mile capitalization computed as stocks_and_bonds_capitalization / miles for each system",
            "five_times_threshold = True (the chapter's 'not one-fifth of' relation is tested as: the highest peer per mile at least 5x the subject per mile discharges the charge of water)",
            "lowest_is_undercapitalized = True (the subject is ruled undercapitalized when its per-mile figure ranks lowest in the supplied peer set)",
            "peer entries read as dicts with 'label', 'capitalization' and 'miles'; alternative keys 'stocks_and_bonds' and 'mileage' accepted",
            "verdict ladder: undercapitalized_on_real_value / water_charge_not_sustained / not_lowest / unmeasurable",
            "mileage taken as given (route or track miles not distinguished by the chapter)",
        ],
    }
    try:
        cap = 0.0 if stocks_and_bonds_capitalization is None else float(stocks_and_bonds_capitalization)
        mi = 0.0 if miles is None else float(miles)
        five = True if five_times_threshold is None else bool(five_times_threshold)
        lowest = True if lowest_is_undercapitalized is None else bool(lowest_is_undercapitalized)

        subject_per_mile = None
        if mi > 0.0:
            subject_per_mile = cap / mi

        rows = []
        for j, peer in enumerate(peers or []):
            if not isinstance(peer, dict):
                continue
            label = peer.get("label") or peer.get("name") or ("peer_%d" % j)
            p_cap = peer.get("capitalization")
            if p_cap is None:
                p_cap = peer.get("stocks_and_bonds")
            p_mi = peer.get("miles")
            if p_mi is None:
                p_mi = peer.get("mileage")
            p_cap = 0.0 if p_cap is None else float(p_cap)
            p_mi = 0.0 if p_mi is None else float(p_mi)
            p_per_mile = None
            if p_mi > 0.0:
                p_per_mile = p_cap / p_mi
            rows.append({
                "label": label,
                "capitalization": p_cap,
                "miles": p_mi,
                "capitalization_per_mile": p_per_mile,
                "ratio_to_subject": (None if (p_per_mile is None or subject_per_mile in (None, 0.0))
                                     else p_per_mile / subject_per_mile),
            })

        comparable = [r for r in rows if r["capitalization_per_mile"] is not None]
        ranked = sorted(comparable, key=lambda r: r["capitalization_per_mile"])
        for i, r in enumerate(ranked):
            r["rank"] = i + 1

        lowest_peer = ranked[0] if ranked else None
        highest_peer = ranked[-1] if ranked else None

        five_times_discharged = None
        if five and highest_peer is not None and subject_per_mile not in (None, 0.0):
            five_times_discharged = highest_peer["capitalization_per_mile"] >= subject_per_mile * 5.0

        subject_is_lowest = None
        if lowest and comparable and subject_per_mile is not None:
            subject_is_lowest = subject_per_mile < lowest_peer["capitalization_per_mile"]

        if subject_per_mile is None:
            verdict = "unmeasurable"
            reason = ("The subject mileage is %.2f, so no capitalization per mile can be formed. The "
                      "chapter's test is a mile-for-mile comparison; supply a positive mileage." % mi)
        elif not comparable:
            verdict = "unmeasurable"
            reason = ("No peer supplied a usable per-mile figure, so the ranking the chapter relies on "
                      "cannot be made. Supply peers as dicts with capitalization and miles.")
        elif subject_is_lowest:
            verdict = "undercapitalized_on_real_value"
            reason = ("The subject system carries %.2f of stocks and bonds per mile against a lowest "
                      "peer of %.2f (%s) and a highest of %.2f (%s), a ratio of %.2f to the highest. "
                      "Its capitalization per mile is the lowest in the comparison, so on the "
                      "chapter's own statement the system is uneconomically undercapitalized on its "
                      "real value -- the charge of water is not sustained."
                      % (subject_per_mile, lowest_peer["capitalization_per_mile"],
                         lowest_peer["label"], highest_peer["capitalization_per_mile"],
                         highest_peer["label"],
                         highest_peer["ratio_to_subject"] if highest_peer["ratio_to_subject"] is not None else 0.0))
        elif five_times_discharged is True:
            verdict = "water_charge_not_sustained"
            reason = ("The subject is not the lowest in the comparison, but the highest peer, %s at "
                      "%.2f per mile, is at least five times its %.2f per mile (ratio %.2f): the "
                      "chapter's 'not one-fifth of' relation holds against the most heavily "
                      "capitalized system, so the charge of watered stock is not sustained here."
                      % (highest_peer["label"], highest_peer["capitalization_per_mile"],
                         subject_per_mile, highest_peer["ratio_to_subject"]))
        else:
            verdict = "not_lowest"
            reason = ("The subject system carries %.2f of stocks and bonds per mile, above the lowest "
                      "peer %s at %.2f per mile, and the highest peer %s at %.2f is not five times it "
                      "(ratio %.2f). The chapter's undercapitalization verdict rests on being lowest "
                      "mile for mile, and its one-fifth comparison does not hold either, so the "
                      "charge of water is left standing."
                      % (subject_per_mile, lowest_peer["label"],
                         lowest_peer["capitalization_per_mile"], highest_peer["label"],
                         highest_peer["capitalization_per_mile"],
                         highest_peer["ratio_to_subject"] if highest_peer["ratio_to_subject"] is not None else 0.0))

        result = {
            "verdict": verdict,
            "reason": reason,
            "capitalization": cap,
            "miles": mi,
            "capitalization_per_mile": subject_per_mile,
            "peers_compared": len(comparable),
            "lowest_peer_label": (lowest_peer["label"] if lowest_peer is not None else None),
            "lowest_peer_per_mile": (lowest_peer["capitalization_per_mile"] if lowest_peer is not None else None),
            "highest_peer_label": (highest_peer["label"] if highest_peer is not None else None),
            "highest_peer_per_mile": (highest_peer["capitalization_per_mile"] if highest_peer is not None else None),
            "highest_peer_ratio_to_subject": (highest_peer["ratio_to_subject"] if highest_peer is not None else None),
            "subject_ranked_lowest": subject_is_lowest,
            "five_times_charge_discharged": five_times_discharged,
        }
        if verbose:
            result["ranking"] = ranked
            result["params"] = {
                "five_times_threshold": five,
                "lowest_is_undercapitalized": lowest,
            }
            result["note"] = ("The capitalization in stocks and bonds of the American railroads is not "
                              "one-fifth that of the railroads of the British Islands, mile for mile.")
        return json.dumps({"result": result, "error": None,
                           "metadata": {"provenance": provenance}})
    except Exception as exc:
        return json.dumps({"result": None, "error": str(exc),
                           "metadata": {"provenance": provenance}})