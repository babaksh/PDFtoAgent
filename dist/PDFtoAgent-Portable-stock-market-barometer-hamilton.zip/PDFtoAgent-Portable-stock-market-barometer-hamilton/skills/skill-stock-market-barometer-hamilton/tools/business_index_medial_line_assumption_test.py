import json
from typing import List, Optional


def _mean(xs: List[float]) -> float:
    return sum(xs) / len(xs) if xs else 0.0


def _ols_slope(x: List[float], y: List[float]) -> float:
    n = len(x)
    if n < 2:
        return 0.0
    mx = _mean(x)
    my = _mean(y)
    num = sum((x[i] - mx) * (y[i] - my) for i in range(n))
    den = sum((x[i] - mx) ** 2 for i in range(n))
    if den == 0.0:
        return 0.0
    return num / den


_PROVENANCE = {
    "source_grounded": [
        "assumed medial line of national wealth with a constant upward tendency at the same rate of speed in good times or bad",
        "that tendency loses its certainty in face of the grim facts of war",
        "and hysterically changes its course",
        "the chapter rejects tying a general-business index to that dangerous assumption",
    ],
    "model_extrapolated": [
        "rejection thresholds max_trend_rate_change_pct=25.0 and max_segment_rate_change_pct=25.0",
        "rate measured as the OLS slope of the index against its own year axis",
        "record split into three equal segments to detect a course change away from the named dislocation",
        "default dislocation_year 1914.0 (the outbreak of the World War the chapter names)",
        "one-sided records read as insufficient_record rather than an error",
        "a record with no movement at all has no tendency, so it reads flat_record with "
        "constant_rate_confirmed=False rather than confirming a rising medial line",
    ],
}


def _meta() -> dict:
    return {"provenance": _PROVENANCE}


def _empty_payload(reason: str) -> dict:
    return {
        "n_observations": 0,
        "direction": "none",
        "dislocation_year": None,
        "n_pre": 0,
        "n_post": 0,
        "trend_rate_pre": 0.0,
        "trend_rate_post": 0.0,
        "trend_rate_change_pct": 0.0,
        "segment_rate_change_pct": 0.0,
        "trend_revised": False,
        "constant_rate_confirmed": False,
        "medial_line_assumption_rejected": False,
        "verdict": "insufficient_record",
        "segment_rates": [],
        "years": [],
        "index_values": [],
        "reason": reason,
    }


async def business_index_medial_line_assumption_test(
    index_values: List[float],
    years: Optional[List[float]] = None,
    dislocation_year: float = 1914.0,
    max_trend_rate_change_pct: float = 25.0,
    max_segment_rate_change_pct: float = 25.0,
    verbose: bool = True,
) -> str:
    """Test a general-business index for the rejected 'medial line' assumption.

    Use when you have a general-business index or index chart (a Harvard-style index of
    general business conditions, a national wealth or production index) with its years,
    and want to know whether it is lashed to an assumed medial line of national wealth
    rising at a constant rate of speed in good times or bad. The tool fits the trend
    rate before a major dislocation and after it, checks the rate across the whole
    record for a change of course, and rules whether the constant-rate assumption
    survived or had to be revised.

    Do NOT use for stock-market averages or for reading the barometer against a value
    line -- call average_vs_value_line_position_classifier (chWATER IN THE BAROMETER)
    instead; that tool reads price against value, this one tests the trend assumption
    built into a general-business index.
    """
    try:
        vals: List[float] = []
        for v in index_values or []:
            if v is None:
                continue
            vals.append(float(v))
        n = len(vals)
        if n == 0:
            return json.dumps(
                {
                    "result": _empty_payload(
                        "no index values supplied, so the medial line cannot be tested"
                    ),
                    "error": None,
                    "metadata": _meta(),
                }
            )

        if years and len(years) == n:
            ys = [float(y) for y in years]
        else:
            ys = [float(i) for i in range(n)]

        try:
            dy = float(dislocation_year)
        except (TypeError, ValueError):
            dy = ys[-1]
        max_rate = 25.0 if max_trend_rate_change_pct is None else float(max_trend_rate_change_pct)
        max_seg = 25.0 if max_segment_rate_change_pct is None else float(max_segment_rate_change_pct)

        pairs = sorted(zip(ys, vals))
        ys = [p[0] for p in pairs]
        vals = [p[1] for p in pairs]

        pre_idx = [i for i, y in enumerate(ys) if y < dy]
        post_idx = [i for i, y in enumerate(ys) if y >= dy]
        n_pre = len(pre_idx)
        n_post = len(post_idx)

        rate_pre = _ols_slope([ys[i] for i in pre_idx], [vals[i] for i in pre_idx])
        rate_post = _ols_slope([ys[i] for i in post_idx], [vals[i] for i in post_idx])

        pre_measured = n_pre >= 2
        post_measured = n_post >= 2
        if not pre_measured or not post_measured:
            rate_change_pct = 0.0
        elif rate_pre != 0.0:
            rate_change_pct = abs(rate_post - rate_pre) / abs(rate_pre) * 100.0
        else:
            rate_change_pct = 0.0 if rate_post == 0.0 else 100.0

        seg_rates: List[float] = []
        n_seg = max(1, min(3, n // 2))
        for s in range(n_seg):
            lo = s * n // n_seg
            hi = (s + 1) * n // n_seg
            if hi - lo >= 2:
                seg_rates.append(_ols_slope(ys[lo:hi], vals[lo:hi]))
        if len(seg_rates) >= 2:
            spread = max(seg_rates) - min(seg_rates)
            denom = abs(_mean(seg_rates))
            if denom == 0.0:
                segment_rate_change_pct = 0.0 if spread == 0.0 else 100.0
            else:
                segment_rate_change_pct = spread / denom * 100.0
        else:
            segment_rate_change_pct = 0.0

        trend_revised = bool(
            (pre_measured and post_measured and rate_change_pct > max_rate)
            or segment_rate_change_pct > max_seg
        )

        if not pre_measured or not post_measured:
            if len(seg_rates) >= 2:
                constant_rate_confirmed = not trend_revised
                if trend_revised:
                    verdict = "medial_line_assumption_rejected"
                    reason = (
                        "the dislocation at %g leaves fewer than two observations on one side, "
                        "so the rate is judged across the record instead: it swung %.1f%% between "
                        "segments -> the constant medial line is not supported"
                        % (dy, segment_rate_change_pct)
                    )
                else:
                    verdict = "medial_line_assumption_holds"
                    reason = (
                        "the dislocation at %g leaves fewer than two observations on one side, "
                        "so the rate is judged across the record instead: it held within %.1f%% "
                        "between segments -> a constant medial line is consistent with this record"
                        % (dy, segment_rate_change_pct)
                    )
            else:
                verdict = "insufficient_record"
                constant_rate_confirmed = False
                reason = (
                    "too few observations to fit a trend rate either side of the dislocation at "
                    "%g or across the record" % dy
                )
        elif trend_revised:
            verdict = "medial_line_assumption_rejected"
            constant_rate_confirmed = False
            reason = (
                "the assumed constant rate did not survive: rate moved %.1f%% (%.3f before the "
                "dislocation against %.3f after) and swung %.1f%% across the record -> the "
                "medial line is a dangerous assumption the chart is lashed to"
                % (rate_change_pct, rate_pre, rate_post, segment_rate_change_pct)
            )
        else:
            verdict = "medial_line_assumption_holds"
            constant_rate_confirmed = True
            reason = (
                "the rate of rise held at %.3f before and %.3f after the dislocation (%.1f%% "
                "change, %.1f%% across the record) -> a constant medial line is consistent "
                "with this record" % (rate_pre, rate_post, rate_change_pct, segment_rate_change_pct)
            )

        net_change = vals[-1] - vals[0]
        if net_change > 0.0:
            direction = "up"
        elif net_change < 0.0:
            direction = "down"
        else:
            direction = "none"

        span = max(vals) - min(vals)
        year_span = max(ys) - min(ys)
        if span <= 0.0 and verdict != "insufficient_record":
            direction = "none"
            verdict = "flat_record"
            constant_rate_confirmed = False
            trend_revised = False
            reason = (
                "the index never moves over %d observations (level %.3f throughout), so it has "
                "no tendency at all: nothing here rises at a constant rate of speed, and the "
                "medial line assumption is neither confirmed nor rejected by this record"
                % (n, vals[0])
            )
        elif year_span <= 0.0 and verdict != "insufficient_record":
            verdict = "insufficient_record"
            constant_rate_confirmed = False
            trend_revised = False
            reason = (
                "every observation carries the same year stamp, so no rate of speed per unit of "
                "time can be fitted and the medial line cannot be tested"
            )

        payload = {
            "n_observations": n,
            "direction": direction,
            "dislocation_year": dy,
            "n_pre": n_pre,
            "n_post": n_post,
            "trend_rate_pre": rate_pre,
            "trend_rate_post": rate_post,
            "trend_rate_change_pct": rate_change_pct,
            "max_trend_rate_change_pct": max_rate,
            "segment_rate_change_pct": segment_rate_change_pct,
            "max_segment_rate_change_pct": max_seg,
            "segment_rates": seg_rates,
            "trend_revised": trend_revised,
            "constant_rate_confirmed": constant_rate_confirmed,
            "medial_line_assumption_rejected": trend_revised,
            "verdict": verdict,
            "years": ys,
            "index_values": vals,
            "reason": reason,
        }
        if not verbose:
            payload = {
                k: payload[k]
                for k in (
                    "n_observations",
                    "direction",
                    "dislocation_year",
                    "n_pre",
                    "n_post",
                    "trend_rate_pre",
                    "trend_rate_post",
                    "trend_rate_change_pct",
                    "segment_rate_change_pct",
                    "trend_revised",
                    "constant_rate_confirmed",
                    "medial_line_assumption_rejected",
                    "verdict",
                )
            }
        return json.dumps({"result": payload, "error": None, "metadata": _meta()})
    except Exception as exc:  # noqa: BLE001 - contract requires a reading, never a raise
        payload = _empty_payload(str(exc))
        payload["verdict"] = "indeterminate"
        return json.dumps({"result": payload, "error": None, "metadata": _meta()})