import json
import math
from typing import List, Optional


def _as_float(value, default: float) -> float:
    try:
        if value is None:
            return float(default)
        return float(value)
    except (TypeError, ValueError):
        return float(default)


async def unconfirmed_single_average_turn_date_tolerance(
    turn_date: Optional[float] = None,
    turn_index: Optional[int] = None,
    turn_price: Optional[float] = None,
    unconfirmed_date: Optional[float] = None,
    unconfirmed_index: Optional[int] = None,
    unconfirmed_price: Optional[float] = None,
    kind: str = "low",
    tolerance_intervals: Optional[float] = None,
    verbose: bool = True,
) -> str:
    """Decide whether a later extreme scored by ONE average alone re-dates an established market turning point.

    Use when a turning point has been dated from both averages and one average alone
    later scores a new extreme -- the chapter's own standing example is the low of the
    bear market dated June 1921 against the new low scored by the industrials alone in
    the following August. The chapter rules the difference immaterial: the established
    turning date stands, and the reader who prefers to treat the averages as
    confirming each other by a different convention is allowed that much latitude.

    Extends: average_corroboration_check (chCYCLES AND STOCK MARKET RECORDS), which
    asked only whether two averages corroborate each other within a lag. This tool adds
    the rule that a new extreme made by one average alone within a short interval of an
    established turn is immaterial and does NOT re-date it, plus the latitude the
    reader may allow.

    Inputs: the established turn (`turn_date` or `turn_index`, with `turn_price`) and
    the later single-average extreme (`unconfirmed_date` or `unconfirmed_index`, with
    `unconfirmed_price`). `kind` is 'low' or 'high'. `tolerance_intervals` is the
    short interval within which the chapter treats the difference as immaterial
    (default 3.0 periods).

    Do NOT use this to test whether two averages corroborate a move -- use
    average_corroboration_check. Do NOT use it when the later extreme was made by BOTH
    averages, in which case the turn genuinely moves.
    """
    try:
        kind_norm = str(kind or "low").strip().lower()
        is_high = kind_norm.startswith("high") or kind_norm in ("top", "peak")
        kind_label = "high" if is_high else "low"
        tol = _as_float(tolerance_intervals, 3.0)
        if tol < 0.0:
            tol = 0.0

        def _respond(result):
            return json.dumps({
                "result": result,
                "error": None,
                "metadata": {
                    "tool": "unconfirmed_single_average_turn_date_tolerance",
                    "provenance": {
                        "source_grounded": [
                            "averages must confirm each other",
                            "a later new extreme by one average alone is immaterial",
                            "the established turning date is allowed to stand",
                            "the reader may allow himself that much latitude",
                            "chapter example: June 1921 low vs the industrials-alone August low",
                        ],
                        "model_extrapolated": [
                            "tolerance_intervals default of 3.0 periods for a 'short interval'",
                            "immateriality graded by both interval and price difference",
                            "unconfirmed_by_default treats a missing corroborating average as unconfirmed",
                        ],
                    },
                },
            })

        if turn_date is None and turn_index is None:
            return _respond({
                "kind": kind_label,
                "classification": "no_evidence",
                "re_dates_turn": False,
                "reason": "no established turning point was supplied",
            })

        t_date = _as_float(turn_date, float(turn_index if turn_index is not None else 0))
        u_date = None
        if unconfirmed_date is not None or unconfirmed_index is not None:
            u_date = _as_float(
                unconfirmed_date,
                float(unconfirmed_index if unconfirmed_index is not None else t_date),
            )

        t_price = None if turn_price is None else _as_float(turn_price, 0.0)
        u_price = None if unconfirmed_price is None else _as_float(unconfirmed_price, 0.0)

        if u_date is None:
            result = {
                "kind": kind_label,
                "turn_date": t_date,
                "turn_price": t_price,
                "unconfirmed_date": None,
                "interval": None,
                "classification": "no_evidence",
                "re_dates_turn": False,
                "reason": (
                    "no later single-average extreme was supplied, so the established turning "
                    "date of %.2f stands unchallenged" % t_date
                ),
            }
            if verbose:
                result["rule"] = (
                    "a later new extreme by one average alone is immaterial and does not re-date "
                    "the established turn"
                )
            return _respond(result)

        interval = u_date - t_date
        gap = math.fabs(interval)

        price_difference = None
        price_beyond = None
        if t_price is not None and u_price is not None:
            if is_high:
                price_beyond = u_price - t_price
            else:
                price_beyond = t_price - u_price
            price_difference = math.fabs(price_beyond)

        within_tolerance = bool(gap <= tol)
        is_new_extreme = bool(price_beyond is not None and price_beyond > 0.0)

        if not is_new_extreme and price_beyond is not None:
            classification = "no_new_extreme"
            re_dates = False
            reason = (
                "the later figure of %.2f does not exceed the established %s of %.2f, so there is "
                "nothing to re-date" % (u_price or 0.0, kind_label, t_price or 0.0)
            )
        elif within_tolerance:
            classification = "immaterial_difference"
            re_dates = False
            reason = (
                "the new %s of %.2f scored by one average alone falls only %.2f periods from the "
                "established turn of %.2f, inside the %.2f-period tolerance; the difference is "
                "immaterial and the turning date stands"
                % (kind_label, u_price or 0.0, gap, t_date, tol)
            )
        else:
            classification = "material_difference"
            re_dates = False
            reason = (
                "the new %s of %.2f scored by one average alone falls %.2f periods beyond the "
                "established turn, outside the %.2f-period tolerance; it is unconfirmed by the "
                "second average, so the chapter still lets the turning date stand rather than "
                "re-dating it, though the reader may allow himself that much latitude"
                % (kind_label, u_price or 0.0, gap, tol)
            )

        result = {
            "kind": kind_label,
            "turn_date": t_date,
            "turn_price": t_price,
            "unconfirmed_date": u_date,
            "unconfirmed_price": u_price,
            "interval": interval,
            "abs_interval": gap,
            "tolerance_intervals": tol,
            "within_tolerance": within_tolerance,
            "new_extreme_scored": is_new_extreme if price_beyond is not None else None,
            "price_points_beyond_turn": price_beyond,
            "abs_price_difference": price_difference,
            "re_dates_turn": re_dates,
            "turn_date_stands": not re_dates,
            "classification": classification,
            "reason": reason,
        }
        if verbose:
            result["rule"] = (
                "the averages must confirm each other, but a later new extreme made by one "
                "average alone is immaterial: the established turning date stands"
            )
            result["latitude_allowed"] = (
                "the reader may, if he prefers, treat the later single-average extreme as the "
                "turn; the chapter sees no material difference"
            )

        return _respond(result)
    except Exception as exc:  # pragma: no cover - defensive
        return json.dumps({
            "result": None,
            "error": str(exc),
            "metadata": {
                "tool": "unconfirmed_single_average_turn_date_tolerance",
                "provenance": {
                    "source_grounded": ["averages must confirm each other"],
                    "model_extrapolated": ["tolerance_intervals default"],
                },
            },
        })