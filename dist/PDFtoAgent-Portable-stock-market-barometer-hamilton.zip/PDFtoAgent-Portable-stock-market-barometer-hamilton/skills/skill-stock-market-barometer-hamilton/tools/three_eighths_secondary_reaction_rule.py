import json
from typing import Optional


def _direction(x: float) -> str:
    if x > 0.0:
        return "up"
    if x < 0.0:
        return "down"
    return "none"


async def three_eighths_secondary_reaction_rule(
    primary_start_price: float,
    primary_end_price: float,
    observed_reaction_points: Optional[float] = None,
    observed_reaction_price: Optional[float] = None,
    reaction_ratio: float = 0.375,
    reliability_reference_points: float = 8.0,
    verbose: bool = True,
) -> str:
    """Apply Dow's law of action and reaction to a completed primary move.

    Computes the minimum secondary reaction Dow expects in the opposite
    direction -- at least three-eighths of the primary movement -- and the
    price level that reaction would reach. Passing an observed reaction
    (either in points or as the price it carried the stock to) tests whether
    the realised reaction satisfied the three-eighths rule.

    Use when you have a completed primary advance or decline (start and end
    price) and want the expected size of the reaction against it, or want to
    grade whether an observed relapse was large enough to trade. Dow: "If a
    stock advances ten points, it is very likely to have a relapse of four
    points or more ... A rise of twenty points will not infrequently bring a
    decline of eight points or more."

    Do NOT use to forecast WHERE a primary move will end -- the chapter says
    the length of a primary movement cannot be told in advance. Do NOT use
    for the day-to-day movement or for a two-week-to-a-month short swing;
    those are the first and second of Dow's three movements.

    Parameters mirror the chapter: primary_start_price / primary_end_price
    delimit the primary movement; reaction_ratio is Dow's three-eighths;
    reliability_reference_points is the reaction size (8 points, Dow's
    twenty-point example) at which trading the reaction is taken as fully
    reliable, since "the further it goes, the greater the reaction when it
    comes, hence the more certainty."
    """
    provenance = {
        "source_grounded": [
            "secondary reaction >= three-eighths of the primary movement",
            "ten-point advance -> relapse of four points or more",
            "twenty-point advance -> decline of eight points or more",
            "reliability of trading the reaction rises with the length of the primary move",
            "length of a primary movement cannot be told in advance",
        ],
        "model_extrapolated": [
            "reliability_reference_points = 8.0 (Dow's twenty-point case) as the full-reliability scale point",
            "reliability grade boundaries (0.4 moderate, 0.75 high)",
            "linear interpolation of reliability between 0 and the reference reaction",
            "rule is applied to a caller-delimited primary move; the chapter gives no delimiter",
        ],
    }
    try:
        start = 0.0 if primary_start_price is None else float(primary_start_price)
        end = 0.0 if primary_end_price is None else float(primary_end_price)
        ratio = 0.375 if reaction_ratio is None else float(reaction_ratio)
        ref = 8.0 if reliability_reference_points is None else float(reliability_reference_points)
        if ref <= 0.0:
            ref = 8.0

        move = end - start
        direction = _direction(move)
        magnitude = abs(move)
        min_reaction_points = ratio * magnitude

        if direction == "up":
            expected_reaction_price = end - min_reaction_points
        elif direction == "down":
            expected_reaction_price = end + min_reaction_points
        else:
            expected_reaction_price = end

        reliability = 0.0
        if direction != "none" and ref > 0.0:
            reliability = min(1.0, min_reaction_points / ref)
        if direction == "none":
            reliability_grade = "none"
        elif reliability >= 0.75:
            reliability_grade = "high"
        elif reliability >= 0.4:
            reliability_grade = "moderate"
        else:
            reliability_grade = "low"

        observed_points = None
        if observed_reaction_points is not None:
            observed_points = abs(float(observed_reaction_points))
        elif observed_reaction_price is not None:
            observed_points = abs(float(observed_reaction_price) - end)

        observed_ratio = None
        satisfies_rule = None
        reading = "no_reaction_supplied"
        if observed_points is not None:
            if magnitude > 0.0:
                observed_ratio = observed_points / magnitude
                satisfies_rule = observed_points >= min_reaction_points
                if satisfies_rule:
                    reading = "reaction_of_at_least_three_eighths_realised"
                else:
                    reading = "reaction_short_of_three_eighths"
            else:
                reading = "no_primary_movement_to_react_against"

        result = {
            "direction": direction,
            "primary_move_points": magnitude,
            "min_reaction_points": min_reaction_points,
            "expected_reaction_price": expected_reaction_price,
            "reliability_score": reliability,
            "reliability_grade": reliability_grade,
            "observed_reaction_points": observed_points,
            "observed_reaction_ratio": observed_ratio,
            "satisfies_three_eighths_rule": satisfies_rule,
            "reading": reading,
        }
        if verbose:
            result["primary_start_price"] = start
            result["primary_end_price"] = end
            result["reaction_ratio"] = ratio
            result["worked_examples"] = {
                "ten_point_advance": {
                    "primary_move_points": 10.0,
                    "min_reaction_points": ratio * 10.0,
                    "chapter_says": "relapse of four points or more",
                },
                "twenty_point_advance": {
                    "primary_move_points": 20.0,
                    "min_reaction_points": ratio * 20.0,
                    "chapter_says": "decline of eight points or more",
                },
            }
            result["note"] = (
                "The further the primary move goes, the greater the reaction when it "
                "comes, hence the more certainty of trading that reaction successfully; "
                "the length of the primary movement itself cannot be told in advance."
            )
        return json.dumps({"result": result, "error": None,
                           "metadata": {"provenance": provenance}})
    except Exception as exc:
        return json.dumps({"result": None, "error": str(exc),
                           "metadata": {"provenance": provenance}})