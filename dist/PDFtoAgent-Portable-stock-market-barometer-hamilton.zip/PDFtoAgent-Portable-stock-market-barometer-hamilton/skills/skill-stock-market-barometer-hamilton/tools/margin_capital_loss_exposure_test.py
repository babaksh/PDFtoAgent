"""Margin and stop-loss exposure against the speculator's capital (Dow's 1901 rule)."""

import json
import math
from typing import Optional

_PROVENANCE = {
    "source_grounded": [
        "Dow: 100 shares on a 10 per cent margin",
        "stop the loss at 2 per cent",
        "loss with commissions is nearly one-quarter of capital",
        "ten-share lots instead of a hundred-share lot",
        "$1000 on one hundred shares at par",
        "a trader with $1000 has no business to start with a hundred shares",
    ],
    "model_extrapolated": [
        "commission of an eighth per cent each way (from the chapter's mechanics discussions)",
        "survivability cutoff of 10 per cent of capital consumed by one stopped loss",
        "minimum of 10 successive stopped losses before exhaustion",
        "optional interest charge on the position",
        "max_survivable_shares solved from the same per-share loss",
    ],
}


def _num(value, default):
    if value is None:
        return float(default)
    try:
        out = float(value)
    except (TypeError, ValueError):
        return float(default)
    if math.isnan(out) or math.isinf(out):
        return float(default)
    return out


async def margin_capital_loss_exposure_test(
    capital: float,
    shares: float = 100.0,
    price_per_share: float = 100.0,
    margin_pct: float = 10.0,
    stop_loss_pct: float = 2.0,
    commission_pct_each_way: float = 0.125,
    interest_pct_of_position: float = 0.0,
    alternative_shares: Optional[float] = None,
    max_capital_fraction_pct: float = 10.0,
    min_surviving_stops: float = 10.0,
    verbose: bool = True,
) -> str:
    """Compute how much of the speculator's capital ONE stopped-out loss consumes at
    a given margin percentage and lot size, and rule whether that combination is
    survivable.

    Use when you are sizing a margin purchase: you know the capital at risk, the
    price, the lot size, the margin the broker demands, and how far away the
    stop-loss order sits. The tool reproduces Charles H. Dow's own worked example
    (a hundred shares at par on a 10 per cent margin, stopped out at 2 per cent,
    loses with commissions nearly a quarter of a $1000 capital) and then answers
    the question Dow asks: does the lot size leave the trader able to cut loss
    after loss, or does it wipe him out in a few stops?

    Do NOT use this to decide WHICH stock to trade or whether the stock may be
    carried on margin at all -- for a stock with no permanent market, a new
    flotation or majority control, call speculative_stock_marketability_margin_screen;
    for a stock that goes days without a transaction, call
    inactive_stock_margin_carry_exclusion. Do NOT use it to grade a profit target --
    call speculative_return_expectation_gate.

    Returns the loss in dollars, the fraction of capital it consumes, how many
    successive such losses exhaust the capital, the largest survivable lot, and a
    survivable / not-survivable verdict.
    """
    capital = _num(capital, 0.0)
    shares = max(_num(shares, 0.0), 0.0)
    price = max(_num(price_per_share, 0.0), 0.0)
    margin_pct = max(_num(margin_pct, 10.0), 0.0)
    stop_pct = max(_num(stop_loss_pct, 2.0), 0.0)
    comm_pct = max(_num(commission_pct_each_way, 0.125), 0.0)
    interest_pct = max(_num(interest_pct_of_position, 0.0), 0.0)
    cap_fraction = max(_num(max_capital_fraction_pct, 10.0), 0.0)
    min_stops = max(_num(min_surviving_stops, 10.0), 0.0)

    def exposure_for(lot_shares, lot_price):
        value = lot_shares * lot_price
        posted = value * margin_pct / 100.0
        stop_dollars = value * stop_pct / 100.0
        commissions = value * 2.0 * comm_pct / 100.0
        interest = value * interest_pct / 100.0
        total = stop_dollars + commissions + interest
        fraction = (100.0 * total / capital) if capital > 0 else None
        stops = (capital / total) if (total > 0 and capital > 0) else None
        return {
            "shares": lot_shares,
            "position_value": value,
            "margin_posted": posted,
            "stop_loss_dollars": stop_dollars,
            "commission_dollars": commissions,
            "interest_dollars": interest,
            "total_loss_dollars": total,
            "fraction_of_capital_pct": fraction,
            "successive_stops_to_exhaustion": stops,
        }

    lot = exposure_for(shares, price)

    per_share_loss = price * (stop_pct / 100.0 + 2.0 * comm_pct / 100.0 + interest_pct / 100.0)
    if per_share_loss > 0 and capital > 0:
        max_shares = math.floor(capital * cap_fraction / 100.0 / per_share_loss)
    else:
        max_shares = 0.0 if per_share_loss > 0 else None

    margin_posted = lot["margin_posted"]
    margin_within_capital = margin_posted <= capital
    fraction = lot["fraction_of_capital_pct"]
    stops = lot["successive_stops_to_exhaustion"]

    if shares <= 0 or price <= 0:
        survivable = True
        verdict = "no_exposure"
        reason = "No shares or no price: there is no capital at risk in a stop-out."
    elif not margin_within_capital:
        survivable = False
        verdict = "not_survivable"
        reason = (
            "The margin demanded ($%.2f) exceeds the whole capital ($%.2f); the lot "
            "cannot even be carried to the stop." % (margin_posted, capital)
        )
    else:
        within_fraction = (fraction is not None) and (fraction <= cap_fraction)
        enough_stops = (stops is None) or (stops >= min_stops)
        survivable = bool(within_fraction and enough_stops)
        if survivable:
            verdict = "survivable"
            reason = (
                "One stopped-out loss takes %.4g%% of capital, inside the %.4g%% limit, "
                "and the capital stands %.4g such losses."
                % (fraction if fraction is not None else 0.0, cap_fraction, stops if stops else float("inf"))
            )
        else:
            verdict = "not_survivable"
            reason = (
                "One stopped-out loss takes %.4g%% of capital and only %.4g such losses "
                "remain before the account is wiped out; Dow's own case loses nearly a "
                "quarter of the capital in a single stop."
                % (fraction if fraction is not None else 0.0, stops if stops else 0.0)
            )

    alternative = None
    if alternative_shares is not None:
        alt = max(_num(alternative_shares, 0.0), 0.0)
        alternative = exposure_for(alt, price)
        alt_fraction = alternative["fraction_of_capital_pct"]
        alt_stops = alternative["successive_stops_to_exhaustion"]
        alternative["survivable"] = bool(
            alt_fraction is not None
            and alt_fraction <= cap_fraction
            and ((alt_stops is None) or (alt_stops >= min_stops))
        )

    result = {
        "shares": shares,
        "price_per_share": price,
        "position_value": lot["position_value"],
        "margin_pct": margin_pct,
        "margin_posted": margin_posted,
        "capital": capital,
        "margin_within_capital": margin_within_capital,
        "stop_loss_pct": stop_pct,
        "total_loss_dollars": lot["total_loss_dollars"],
        "fraction_of_capital_pct": fraction,
        "successive_stops_to_exhaustion": stops,
        "max_survivable_shares": max_shares,
        "survivable": survivable,
        "verdict": verdict,
    }

    if verbose:
        result["loss_breakdown"] = {
            "stop_loss_dollars": lot["stop_loss_dollars"],
            "commission_dollars": lot["commission_dollars"],
            "interest_dollars": lot["interest_dollars"],
        }
        result["dow_reference"] = {
            "dow_fraction_of_capital_pct": 22.5,
            "dow_lot_shares": 100.0,
            "dow_alternative_lot_shares": 10.0,
        }
        result["alternative_lot"] = alternative
        result["reason"] = reason

    return json.dumps({"result": result, "error": None, "metadata": {"provenance": _PROVENANCE}})