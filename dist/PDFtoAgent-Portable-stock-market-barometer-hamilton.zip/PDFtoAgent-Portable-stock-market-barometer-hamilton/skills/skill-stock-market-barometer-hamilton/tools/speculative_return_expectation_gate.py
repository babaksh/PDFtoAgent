"""Annualise a stated profit target and rule it a sane speculative objective or a gambler's expectation."""

import json
import math

_PROVENANCE = {
    "source_grounded": [
        "Dow: an attempt to get 12 per cent per annum on their money",
        "Dow: instead of 50 per cent weekly",
        "the consequence: they would come out a good deal better in the long run",
        "everybody knows this in its application to his private business; totally different methods should not be employed in dealing in stocks",
        "no knowledge of the barometer will enable any of us to call the absolute turn",
    ],
    "model_extrapolated": [
        "annualisation by simple scaling of the horizon (weeks = 52 per year, months = 12, days = 365)",
        "tolerance band of 50 per cent above the 12 per cent benchmark",
        "gambler band at or above 50 per cent per annum",
        "compounding shown alongside simple annualisation as a separate reported figure",
    ],
}

_PERIODS_PER_YEAR = {
    "day": 365.0,
    "daily": 365.0,
    "week": 52.0,
    "weekly": 52.0,
    "month": 12.0,
    "monthly": 12.0,
    "quarter": 4.0,
    "quarterly": 4.0,
    "year": 1.0,
    "annual": 1.0,
    "annum": 1.0,
    "yearly": 1.0,
}


def _num(value, default):
    if value is None:
        return float(default)
    try:
        out = float(value)
    except (TypeError, ValueError):
        return float(default)
    if math.isnan(out) or math.isinf(out):
        return float(default)
    return out


async def speculative_return_expectation_gate(
    target_return_pct: float = 12.0,
    horizon: str = "annum",
    horizon_units: float = 1.0,
    benchmark_pct_per_annum: float = 12.0,
    tolerance_pct: float = 50.0,
    gambler_pct_per_annum: float = 50.0,
    verbose: bool = True,
) -> str:
    """Annualise the speculator's stated profit target and rule it a sane speculative
    objective or a gambler's expectation.

    Use when someone states a profit target over a stated horizon -- '50 per cent
    weekly', '4 points in a month', '12 per cent per annum' -- and you want the
    chapter's verdict on it. Charles H. Dow's rule, quoted in this chapter from The
    Wall Street Journal of July 11, 1901: if people with either large or small capital
    would look upon trading in stocks as an attempt to get 12 per cent per annum on
    their money instead of 50 per cent weekly, they would come out a good deal better
    in the long run. The same methods a man applies to a store, a factory or a real
    estate business apply to stocks.

    Do NOT use it to measure an outcome already realised, and do NOT use it to judge
    whether a particular trade's expected move has already been discounted -- that is
    anticipated_move_consumption_test. Do NOT use it to decide whether the capital can
    survive the lot -- call margin_capital_loss_exposure_test.

    Returns the annualised target, its multiple of Dow's 12 per cent benchmark, the
    classification, and the reason.
    """
    target = _num(target_return_pct, 0.0)
    units = max(_num(horizon_units, 1.0), 0.0)
    bench = _num(benchmark_pct_per_annum, 12.0)
    tol = max(_num(tolerance_pct, 50.0), 0.0)
    gambler = _num(gambler_pct_per_annum, 50.0)

    key = (horizon or "annum").strip().lower()
    per_year = _PERIODS_PER_YEAR.get(key, 1.0)

    if units <= 0:
        periods_per_year = per_year
    else:
        periods_per_year = per_year / units

    if target != 0:
        annualised = target * periods_per_year
        compounded = ((1.0 + target / 100.0) ** periods_per_year - 1.0) * 100.0
    else:
        annualised = 0.0
        compounded = 0.0

    multiple = (annualised / bench) if bench > 0 else None
    upper = bench * (1.0 + tol / 100.0)

    if annualised < 0:
        classification = "loss_expectation"
        verdict_bool = False
        reason = (
            "The annualised target is %.4g%% per annum, i.e. an expected loss. Dow's point is "
            "that trading in stocks is an attempt to get 12 per cent per annum on your money, "
            "not to give it away." % annualised
        )
    elif annualised == 0:
        classification = "no_expectation"
        verdict_bool = False
        reason = "The annualised target is zero: there is no stated objective to grade."
    elif annualised >= gambler:
        classification = "gamblers_expectation"
        verdict_bool = False
        reason = (
            "Annualised, the target is %.4g%% per annum -- %.4g times Dow's 12 per cent, and at "
            "or above the %.4g%% the chapter names as the gambler's figure. Dow wrote that if "
            "people would look upon trading in stocks as an attempt to get 12 per cent per annum "
            "on their money instead of 50 per cent weekly they would come out a good deal better "
            "in the long run." % (annualised, multiple if multiple is not None else 0.0, gambler)
        )
    elif annualised <= upper:
        classification = "sane_speculative_objective"
        verdict_bool = True
        reason = (
            "Annualised, the target is %.4g%% per annum, %.4g times Dow's 12 per cent and inside "
            "the %.4g%% tolerance band (up to %.4g%%). This is the objective Dow says the trader "
            "should set." % (annualised, multiple if multiple is not None else 0.0, tol, upper)
        )
    else:
        classification = "inflated_expectation"
        verdict_bool = False
        reason = (
            "Annualised, the target is %.4g%% per annum, %.4g times Dow's 12 per cent and above "
            "the %.4g%% tolerance band (%.4g%%), though short of the %.4g%% gambler's figure. It "
            "is not the objective Dow commends."
            % (annualised, multiple if multiple is not None else 0.0, tol, upper, gambler)
        )

    result = {
        "target_return_pct": target,
        "horizon": key,
        "horizon_units": units,
        "periods_per_year": periods_per_year,
        "annualised_target_pct": annualised,
        "compounded_target_pct": compounded,
        "dow_benchmark_pct_per_annum": bench,
        "multiple_of_dow_benchmark": multiple,
        "tolerance_pct": tol,
        "gambler_pct_per_annum": gambler,
        "classification": classification,
        "sane_objective": verdict_bool,
    }

    if verbose:
        result["dow_case"] = {
            "benchmark_pct_per_annum": 12.0,
            "gambler_target_pct": 50.0,
            "gambler_horizon": "week",
            "gambler_annualised_pct": 2600.0,
            "classification": "gamblers_expectation",
        }
        result["reason"] = reason

    return json.dumps({"result": result, "error": None, "metadata": {"provenance": _PROVENANCE}})