"""Score dated published barometer inferences against the subsequent record of both averages.

Reads a set of dated published inferences (each with a direction and a kind:
'continuation', 'duration' or 'reaction'), anchors each to the observation nearest
its date in the two average series, and measures what actually happened afterwards:
realized points in each average, and how many periods the inference stayed intact
before the averages gave back `retrace_fraction` of the move it had made.

Extends `record_for_barometer_forecast_error_test` (ch1909, AND SOME DEFECTS OF
HISTORY): that tool scores a commentator's call that a bull or bear market has
ENDED. This one scores the inferences this chapter actually published --
continuation claims ("we are still in a bull market and it should run much
further, possibly well into 1923"), duration claims, and secondary-reaction
recognitions ("after a typical secondary reaction ... resumption of the major
upward movement") -- and reports the realized points and the holding time.

Use when: you have dated published barometer inferences plus the subsequent
industrial and railroad average series and want each inference graded as borne
out or not, with the size and the staying power of the move that followed.

Do NOT use for: scoring a single end-of-market call (use
`record_for_barometer_forecast_error_test`), classifying a move as
primary/secondary/daily (use `dow_three_movement_classification`), or measuring
a line (use `line_dimensions_measurement`).
"""

import json
import math
from typing import Dict, List, Optional


def _num(value):
    """Coerce to a finite float or None (never raises)."""
    try:
        out = float(value)
    except (TypeError, ValueError):
        return None
    if math.isnan(out) or math.isinf(out):
        return None
    return out


def _clean_series(values):
    out = []
    for v in values or []:
        f = _num(v)
        if f is not None:
            out.append(f)
    return out


def _nearest_index(period_years, target):
    """Index of the observation whose date is nearest `target`."""
    if not period_years or target is None:
        return None
    best = 0
    best_d = abs(period_years[0] - target)
    for i in range(1, len(period_years)):
        d = abs(period_years[i] - target)
        if d < best_d:
            best_d = d
            best = i
    return best


def _norm_direction(raw):
    d = str(raw or "").strip().lower()
    if d in ("up", "upward", "bull", "bullish", "rise", "rising", "advance"):
        return "up"
    if d in ("down", "downward", "bear", "bearish", "fall", "falling", "decline"):
        return "down"
    return None


def _excursion(prices, start, end, direction, retrace_fraction, reaction_mode=False):
    """Measure what the average did after the inference was published.

    In `reaction_mode` the realized figure is the DEPTH of the reaction measured
    up to the first recovery of `retrace_fraction` of it, and the extreme is that
    reaction's low (high), not the most distant point in the whole record.
    """
    base = prices[start]
    n = end - start + 1
    rel = [prices[start + k] - base for k in range(n)]
    fav_rel = 0.0
    adv_rel = 0.0
    extreme_rel = 0.0
    extreme_off = 0
    held = n - 1
    if reaction_mode and direction in ("up", "down"):
        run = 0.0
        for k in range(1, n):
            adverse = -rel[k] if direction == "down" else rel[k]
            if adverse > run:
                run = adverse
                extreme_off = k
                extreme_rel = rel[k]
            if run > 0.0 and adverse <= run * (1.0 - retrace_fraction):
                held = k
                break
        fav_rel = run
        for k in range(n):
            if direction == "down":
                if rel[k] > adv_rel:
                    adv_rel = rel[k]
            else:
                if -rel[k] > adv_rel:
                    adv_rel = -rel[k]
        return {
            "favorable_points": fav_rel,
            "against_points": adv_rel,
            "extreme_index": start + extreme_off,
            "extreme_points": extreme_rel,
            "held_periods": held,
        }
    if direction == "up":
        for k in range(n):
            if rel[k] > fav_rel:
                fav_rel = rel[k]
            if rel[k] < adv_rel:
                adv_rel = rel[k]
            if rel[k] > extreme_rel:
                extreme_rel = rel[k]
                extreme_off = k
    elif direction == "down":
        for k in range(n):
            if -rel[k] > fav_rel:
                fav_rel = -rel[k]
            if rel[k] > adv_rel:
                adv_rel = rel[k]
            if rel[k] < extreme_rel:
                extreme_rel = rel[k]
                extreme_off = k
    else:
        for k in range(n):
            if rel[k] > adv_rel:
                adv_rel = rel[k]
            if -rel[k] > adv_rel:
                adv_rel = -rel[k]

    if direction in ("up", "down") and retrace_fraction > 0.0:
        run_extreme = 0.0
        for k in range(1, n):
            if direction == "up":
                if rel[k] > run_extreme:
                    run_extreme = rel[k]
                if run_extreme > 0.0 and rel[k] <= run_extreme * (1.0 - retrace_fraction):
                    held = k
                    break
            else:
                if rel[k] < run_extreme:
                    run_extreme = rel[k]
                if run_extreme < 0.0 and rel[k] >= run_extreme * (1.0 - retrace_fraction):
                    held = k
                    break

    return {
        "favorable_points": fav_rel,
        "against_points": adv_rel,
        "extreme_index": start + extreme_off,
        "extreme_points": extreme_rel,
        "held_periods": held,
    }


def _recovery_fraction(prices, start_index, trough_index, end, direction):
    """Fraction of the reaction's depth recovered afterwards, against the reaction."""
    if direction not in ("up", "down") or trough_index <= start_index or trough_index >= end:
        return None
    depth = abs(prices[trough_index] - prices[start_index])
    if depth <= 0.0:
        return None
    if direction == "down":
        recovery = max(prices[trough_index:end + 1]) - prices[trough_index]
    else:
        recovery = prices[trough_index] - min(prices[trough_index:end + 1])
    return recovery / depth


async def published_inference_outturn_verification(
    industrial_prices: List[float],
    railroad_prices: Optional[List[float]] = None,
    period_years: Optional[List[float]] = None,
    inferences: Optional[List[Dict]] = None,
    look_forward_periods: Optional[int] = None,
    min_points: float = 3.0,
    min_reaction_points: float = 3.0,
    retrace_fraction: float = 0.5,
    verbose: bool = True,
) -> str:
    """Score dated published barometer inferences against the later record of both averages.

    Use when you have dated published inferences (direction plus one of the kinds
    'continuation', 'duration', 'reaction') and the industrial and railroad
    average series that followed them, and you want each inference graded as borne
    out or not, with realized points in both averages and the number of periods it
    held. Do NOT use it to score a single end-of-market call (use
    `record_for_barometer_forecast_error_test`) or to classify a move as
    primary/secondary/daily (use `dow_three_movement_classification`).
    """
    provenance = {
        "source_grounded": [
            "bull move measured as 61+ industrial points, Aug 24 1921 to Mar 20 1923",
            "railroads 65.52 to 93.99 = 28.47 points by Sept 11 1922",
            "secondary reaction: industrials nearly 6 points, railroads over 4 points to Sept 30 1922",
            "bear recession 20 points industrials, over 17 railroads to Oct 27 1923",
            "an inference is read from both averages together",
        ],
        "model_extrapolated": [
            "borne out requires a favorable move of at least min_points (default 3.0) in every average supplied",
            "held_periods = periods until a retrace_fraction (default 0.5) give-back of the running extreme",
            "duration claims additionally tested at the observation nearest through_date",
            "reaction claims scored on magnitude alone; resumption reported separately",
            "look_forward_periods default is the rest of the record",
            "nearest-date anchoring when an inference carries no explicit index",
        ],
    }
    try:
        ind = _clean_series(industrial_prices)
        rr = _clean_series(railroad_prices)
        years = _clean_series(period_years)
        if len(years) != len(ind):
            years = []
        if len(rr) != len(ind):
            rr = []

        min_points = 3.0 if min_points is None else float(min_points)
        min_points = max(0.0, min_points)
        min_reaction_points = 3.0 if min_reaction_points is None else float(min_reaction_points)
        min_reaction_points = max(0.0, min_reaction_points)
        retrace_fraction = 0.5 if retrace_fraction is None else float(retrace_fraction)
        retrace_fraction = min(1.0, max(0.0, retrace_fraction))
        window = None
        if look_forward_periods is not None:
            w = int(look_forward_periods)
            if w > 0:
                window = w

        n = len(ind)
        rows = []
        for pos, inf in enumerate(inferences or []):
            if not isinstance(inf, dict):
                continue
            label = str(inf.get("label") or inf.get("date") or ("inference_" + str(pos)))
            direction = _norm_direction(inf.get("direction"))
            kind = str(inf.get("kind") or "continuation").strip().lower()
            if kind not in ("continuation", "duration", "reaction"):
                kind = "continuation"
            date = _num(inf.get("date"))

            start = None
            raw_index = inf.get("index")
            if raw_index is not None:
                try:
                    cand = int(raw_index)
                    if 0 <= cand < max(n, 1):
                        start = cand
                except (TypeError, ValueError):
                    start = None
            if start is None:
                start = _nearest_index(years, date)
            if n == 0:
                rows.append({
                    "label": label,
                    "date": date,
                    "kind": kind,
                    "direction": direction if direction is not None else "none",
                    "start_index": None,
                    "realized_points_industrials": 0.0,
                    "realized_points_railroads": 0.0 if rr else None,
                    "held_periods": 0,
                    "held_years": None,
                    "borne_out": False,
                    "reason": "no market record supplied; nothing to score the inference against",
                })
                continue
            if start is None or start >= n:
                start = 0
            end = n - 1
            if window is not None:
                end = min(n - 1, start + window)
            if end < start:
                end = start

            series = [("industrials", ind)]
            if rr:
                series.append(("railroads", rr))

            threshold = min_reaction_points if kind == "reaction" else min_points
            detail = {}
            for name, s in series:
                ex = _excursion(s, start, end, direction, retrace_fraction,
                                reaction_mode=(kind == "reaction"))
                detail[name] = ex

            moved_right_way = direction is not None and all(
                detail[name]["favorable_points"] > 0.0 for name, _ in series
            )
            big_enough = direction is not None and all(
                detail[name]["favorable_points"] >= threshold for name, _ in series
            )
            held_periods = min(detail[name]["held_periods"] for name, _ in series)

            through_index = None
            through_date = None
            net_at_through = {}
            intact_through = None
            if kind == "duration":
                through_date = _num(inf.get("through_date"))
                if years and through_date is not None:
                    through_index = _nearest_index(years, through_date)
                elif inf.get("through_index") is not None:
                    try:
                        cand = int(inf.get("through_index"))
                        if 0 <= cand < n:
                            through_index = cand
                    except (TypeError, ValueError):
                        through_index = None
                if through_index is not None:
                    for name, s in series:
                        delta = s[through_index] - s[start]
                        net_at_through[name] = delta if direction != "down" else -delta
                    intact_through = (start + held_periods) >= through_index

            if direction is None:
                borne_out = False
                reason = "no direction stated for the inference; nothing to score"
            elif n <= 1:
                borne_out = False
                reason = "record has no movement after the inference date; nothing to measure"
            elif all(detail[name]["favorable_points"] == 0.0 and detail[name]["against_points"] == 0.0
                     for name, _ in series):
                borne_out = False
                reason = "averages did not move at all after the inference date; no reading to score"
            elif not moved_right_way:
                borne_out = False
                worst = max(detail[name]["against_points"] for name, _ in series)
                reason = (
                    "averages moved against the inference (worst adverse move "
                    + format(worst, ".2f")
                    + " points); no favorable move followed"
                )
            elif not big_enough:
                best = min(detail[name]["favorable_points"] for name, _ in series)
                reason = (
                    "move in the inferred direction was only "
                    + format(best, ".2f")
                    + " points, below the "
                    + format(threshold, ".2f")
                    + " point test"
                )
            elif kind == "duration" and through_index is None:
                borne_out = True
                reason = (
                    "duration claim scored as a continuation: no through date could be anchored; "
                    "favorable move held "
                    + str(held_periods)
                    + " periods"
                )
            elif kind == "duration":
                bad_net = [k for k, v in net_at_through.items() if v <= 0.0]
                if bad_net:
                    borne_out = False
                    reason = (
                        "by the claimed date "
                        + (format(through_date, ".2f") if through_date is not None else "?")
                        + " the "
                        + ", ".join(bad_net)
                        + " were no longer beyond the level of the inference"
                    )
                elif not intact_through:
                    borne_out = False
                    reason = (
                        "the inference was retraced before the claimed date; it held only "
                        + str(held_periods)
                        + " periods"
                    )
                else:
                    borne_out = True
                    reason = (
                        "still favorable at the claimed date and held "
                        + str(held_periods)
                        + " periods"
                    )
            elif kind == "reaction":
                borne_out = True
                reason = (
                    "reaction of at least "
                    + format(threshold, ".2f")
                    + " points recognized in every average supplied"
                )
            else:
                borne_out = True
                reason = (
                    "favorable move realized in every average supplied and held "
                    + str(held_periods)
                    + " periods"
                )

            held_years = None
            if years:
                last = min(start + held_periods, len(years) - 1)
                if last > start:
                    held_years = years[last] - years[start]

            row = {
                "label": label,
                "date": date,
                "kind": kind,
                "direction": direction if direction is not None else "none",
                "start_index": start,
                "realized_points_industrials": detail["industrials"]["favorable_points"],
                "realized_points_railroads": detail["railroads"]["favorable_points"] if rr else None,
                "held_periods": held_periods,
                "held_years": held_years,
                "borne_out": borne_out,
                "reason": reason,
            }
            if kind == "reaction":
                resumed = {}
                for name, s in series:
                    frac = _recovery_fraction(s, start, detail[name]["extreme_index"], end, direction)
                    resumed[name] = (frac is not None and frac >= retrace_fraction) if frac is not None else None
                row["primary_resumed"] = all(v for v in resumed.values() if v is not None) if any(
                    v is not None for v in resumed.values()
                ) else None
            if kind == "duration" and net_at_through:
                row["net_points_at_through_industrials"] = net_at_through["industrials"]
                row["net_points_at_through_railroads"] = net_at_through["railroads"] if rr else None
            if verbose:
                row["detail"] = {
                    name: {
                        "favorable_points": detail[name]["favorable_points"],
                        "against_points": detail[name]["against_points"],
                        "extreme_index": detail[name]["extreme_index"],
                        "extreme_points": detail[name]["extreme_points"],
                        "held_periods": detail[name]["held_periods"],
                    }
                    for name, _ in series
                }
            rows.append(row)

        total = len(rows)
        hits = sum(1 for r in rows if r["borne_out"])
        mean_points = sum(r["realized_points_industrials"] for r in rows) / total if total else 0.0
        mean_held = sum(r["held_periods"] for r in rows) / total if total else 0.0

        result = {
            "n_inferences": total,
            "n_borne_out": hits,
            "hit_rate": (hits / total) if total else 0.0,
            "mean_realized_points_industrials": mean_points,
            "mean_held_periods": mean_held,
            "borne_out_labels": [r["label"] for r in rows if r["borne_out"]],
            "failed_labels": [r["label"] for r in rows if not r["borne_out"]],
        }
        if verbose:
            result["inferences"] = rows

        return json.dumps({"result": result, "error": None, "metadata": {"provenance": provenance}})
    except Exception as exc:  # noqa: BLE001 - contract: never raise
        return json.dumps(
            {"result": None, "error": "published_inference_outturn_verification failed: " + str(exc),
             "metadata": {"provenance": provenance}}
        )