"""Anticipation interval of a dated market turn over later resolved non-business events (1917).

Hamilton: "The bull market which was born in December of that year anticipated the
armistice by eleven months, and the failure of Germany's last tremendous drive by six
months." This tool measures, for ONE dated market turn, how many months it preceded
each of several later resolved non-business events (armistice, failure of a military
drive, treaty, election, peace), and rules whether the barometer foresaw them.

The ruling is scored on the WEAKEST LINK: "our chain of reasoning is as strong as its
weakest link", so the smallest anticipation across the supplied events is what the
verdict rests on, not the average.

Depends on: stock_market_lead_time_over_business_record (ch06, "A Unique Quality of
Forecast") -- that tool measures how far market primary swings led DATED BUSINESS-
CONDITION AREAS. This one extends the same lead measurement to discrete historical
EVENT anchors, scores one turn against several events at once, and returns a
minimum-anticipation verdict.

Use when: you have a dated market turn and one or more dated historical events that
resolved later, and want the anticipation in months plus a foresight ruling.
Do NOT use for: lead over business/chart areas (call
stock_market_lead_time_over_business_record), and do NOT use when the "event" has no
resolution date.
"""

import json
from typing import Dict, List, Optional


def _provenance():
    return {
        "source_grounded": [
            "bull market born December 1917",
            "anticipated the armistice by eleven months",
            "anticipated the failure of Germany's last drive by six months",
            "chain of reasoning is as strong as its weakest link",
        ],
        "model_extrapolated": [
            "dates supplied as decimal years and converted to months at 12 months per year",
            "min_anticipation_months default 3.0",
            "weakest-link (minimum) scoring of several anchors rather than an average",
            "unmeasurable reading when no event anchors are supplied",
        ],
    }


async def market_turn_anticipation_interval_test(
    turn_date: Optional[float] = None,
    events: Optional[List[Dict]] = None,
    min_anticipation_months: Optional[float] = 3.0,
    verbose: bool = True,
) -> str:
    """Measure how many months a dated market turn anticipated later resolved historical events.

    Use when you have a dated market turn (decimal year, e.g. 1917.92 for December
    1917) and one or more later resolved non-business events (armistice, failure of a
    military drive, treaty) each with its own decimal-year date, and want the
    anticipation in months for each plus a single foresight ruling.

    Do NOT use for lead time over business-condition or chart areas -- call
    stock_market_lead_time_over_business_record for that. Do NOT use when the events
    carry no resolution date.

    Args:
        turn_date: decimal year of the market turn (e.g. 1917.92 = December 1917).
        events: list of {"label": str, "date": float}, one per resolved event,
            dated in the same decimal-year units as turn_date.
        min_anticipation_months: months by which the turn must lead every scored
            event for the foresight verdict to hold. Because the ruling rests on the
            weakest link, this is a requirement on EVERY supplied event at once.
        verbose: False returns the compact ruling; True adds per-event rows and reason.
    """
    need_months = 3.0 if min_anticipation_months is None else float(min_anticipation_months)

    if turn_date is None:
        return json.dumps({
            "result": {
                "verdict": "unmeasurable",
                "reason": "no market turn date supplied, so no anticipation can be measured",
                "weakest_link_months": None,
                "n_events": 0,
            },
            "error": None,
            "metadata": {"provenance": _provenance()},
        })

    turn = float(turn_date)
    rows = []
    for i, ev in enumerate(events or []):
        if not isinstance(ev, dict):
            continue
        label = ev.get("label", "event_%d" % i)
        date = ev.get("date", ev.get("event_date"))
        if date is None:
            continue
        months = (float(date) - turn) * 12.0
        rows.append({
            "label": label,
            "event_date": float(date),
            "anticipation_months": months,
            "anticipated": bool(months >= need_months),
        })

    n_events = len(rows)
    if n_events == 0:
        return json.dumps({
            "result": {
                "verdict": "unmeasurable",
                "reason": "no dated event anchors supplied, so no anticipation can be measured",
                "weakest_link_months": None,
                "n_events": 0,
            },
            "error": None,
            "metadata": {"provenance": _provenance()},
        })

    weakest = min(r["anticipation_months"] for r in rows)
    anticipated_n = sum(1 for r in rows if r["anticipated"])
    share = anticipated_n / n_events

    if weakest >= need_months:
        verdict = "foresaw"
        reason = (
            "the turn led every one of %d resolved event(s) by at least %.2f months; "
            "weakest link %.2f months"
            % (n_events, need_months, weakest)
        )
    elif weakest < 0.0:
        verdict = "did_not_foresee"
        reason = (
            "the turn followed at least one of the events (weakest link %.2f months), "
            "so it anticipated nothing" % weakest
        )
    else:
        verdict = "did_not_foresee"
        reason = (
            "only %d of %d events were anticipated by at least %.2f months "
            "(share %.2f); the weakest link was %.2f months"
            % (anticipated_n, n_events, need_months, share, weakest)
        )

    result = {
        "verdict": verdict,
        "weakest_link_months": weakest,
        "anticipated_events": anticipated_n,
        "n_events": n_events,
        "anticipated_share": share,
    }
    if verbose:
        result["events"] = rows
        result["turn_date"] = turn
        result["reason"] = reason
        result["inputs"] = {"min_anticipation_months": need_months}
    return json.dumps({
        "result": result,
        "error": None,
        "metadata": {"provenance": _provenance()},
    })