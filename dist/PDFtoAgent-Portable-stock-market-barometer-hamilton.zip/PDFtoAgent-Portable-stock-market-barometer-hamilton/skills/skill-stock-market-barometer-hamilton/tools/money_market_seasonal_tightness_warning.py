"""Flag an abnormal money market: tight money in the season it should be cheapest.

Implements the warning this chapter records for the beginning of 1907: industry
was booming, railroad gross and net earnings were the best on record, the stock
market was only receding a little from three years of advance, and prices had
not overtaken values - yet "when industry was booming ... he was struck, as I
was, by the abnormal money market. That is the time of year when money should
be cheap, and it was almost painfully tight in February. The stock market
foresaw the meaning of it long before we did, as the major bear swing of 1907
showed."

Use this when you have a record of money rates (call money or equivalent)
labelled by month, and you want to know whether money is abnormally tight
right now - i.e. tight in the season of the year when it should be cheapest -
which the chapter treats as the leading bear warning the stock market discounts
before business men or the record do.

Do NOT use this to compare two averages (use `average_corroboration_check` or
`forced_liquidation_marketable_first_test`), and do NOT use it to measure how
far the stock market led the business record once the turn has happened (use
`stock_market_lead_time_over_business_record`, chA UNIQUE QUALITY OF FORECAST).
"""

import json
from typing import List, Optional

try:
    import numpy as _np  # noqa: F401  (optional; stdlib path is sufficient)
except ImportError:  # pragma: no cover
    _np = None


def _mean(xs: List[float]) -> Optional[float]:
    return sum(xs) / float(len(xs)) if xs else None


def _norm_months(months: Optional[List[int]], n: int) -> List[int]:
    out = []
    if months:
        for m in months[:n]:
            try:
                mi = int(m)
            except (TypeError, ValueError):
                mi = 1
            out.append(1 if mi < 1 else (12 if mi > 12 else mi))
    while len(out) < n:
        out.append((len(out) % 12) + 1)
    return out[:n]


def _norm_years(years: Optional[List[float]], months: List[int]) -> List[float]:
    """Year index per observation: explicit years, else a counter that steps on
    each January (or whenever the month sequence turns back)."""
    n = len(months)
    if years:
        out = []
        for y in years[:n]:
            try:
                out.append(float(y))
            except (TypeError, ValueError):
                out.append(0.0)
        while len(out) < n:
            out.append(out[-1] if out else 0.0)
        return out[:n]
    out = []
    y = 0.0
    prev = None
    for m in months:
        if prev is not None and m <= prev:
            y += 1.0
        out.append(y)
        prev = m
    return out


def _pct_or_points(cur: float, base: float):
    """Return (pct_difference, point_difference) with no division by zero."""
    if base > 0.0:
        return (cur - base) / base * 100.0, cur - base
    return None, cur - base


async def money_market_seasonal_tightness_warning(
    rates: List[float],
    months: Optional[List[int]] = None,
    years: Optional[List[float]] = None,
    cheap_season_months: Optional[List[int]] = None,
    min_premium_pct: float = 25.0,
    verbose: bool = True,
) -> str:
    """Warn when money is painfully tight in the season it should be cheapest.

    Use when you hold a record of money rates (call money or equivalent) and
    want the barometer's leading bear warning: is money abnormally tight, and
    is it tight in that part of the year when it should be cheapest? The
    chapter treats that condition - not earnings, not the averages - as what
    the stock market discounted ahead of business men and the record.

    Args:
        rates: Money-rate observations, in per cent, in date order (e.g. call
            money rate month by month).
        months: Month number (1-12) for each rate observation. When omitted the
            months are cycled 1..12 from January.
        years: Year (or any increasing year label) for each observation. When
            omitted a year counter that steps at each January is used.
        cheap_season_months: The months of the year when money should be
            cheapest. Defaults to [1, 2] - the beginning of the year, which is
            the season the chapter names (January-February 1907).
        min_premium_pct: How far above the usual level of that cheap season, in
            per cent, counts as "painfully tight" (25.0).
        verbose: True returns the full reading plus the seasonal table; False
            returns the compact warning only.

    Returns:
        JSON with result/error/metadata. `result.classification` is one of
        abnormal_money_market_tight_in_cheap_season,
        money_tight_outside_cheap_season, money_not_abnormally_tight,
        insufficient_history, insufficient_data.
    """
    provenance = {
        "source_grounded": [
            "time of year when money should be cheap",
            "money almost painfully tight in February 1907",
            "abnormal money market while industry was booming",
            "stock market foresaw it before business men or the record",
            "January-February: cheap money and reinvestment of prior year profits",
        ],
        "model_extrapolated": [
            "cheap_season_months default [1, 2] (beginning of the year)",
            "min_premium_pct = 25.0 for 'painfully tight'",
            "current reading = latest cheap-season observation in the record",
            "prior years only, so the norm never includes the reading being judged",
        ],
    }

    try:
        series = [float(r) for r in (rates or [])]
    except (TypeError, ValueError):
        series = []
    n = len(series)
    mons = _norm_months(months, n)
    yrs = _norm_years(years, mons)

    if cheap_season_months:
        cheap = set()
        for m in cheap_season_months:
            try:
                mi = int(m)
            except (TypeError, ValueError):
                continue
            if 1 <= mi <= 12:
                cheap.add(mi)
    else:
        cheap = {1, 2}
    if not cheap:
        cheap = {1, 2}

    min_premium_pct = 25.0 if min_premium_pct is None else float(min_premium_pct)

    compact_head = {
        "cheap_season_months": sorted(cheap),
        "min_premium_pct": min_premium_pct,
    }

    if n < 1:
        out = dict(compact_head)
        out.update({
            "classification": "insufficient_data",
            "warning": False,
            "current_rate": None,
            "current_month": None,
            "in_cheap_season": None,
            "seasonal_norm_rate": None,
            "rest_of_year_norm_rate": None,
            "premium_vs_seasonal_norm_pct": None,
            "premium_vs_seasonal_norm_points": None,
            "no_seasonal_easing": None,
            "tightness": None,
            "reason": "No money-rate observations supplied; an abnormal money "
                      "market cannot be read from an empty record.",
        })
        return json.dumps({
            "result": out,
            "error": None,
            "metadata": {"provenance": provenance, "n_observations": 0},
        })

    cur_idx = None
    for i in range(n - 1, -1, -1):
        if mons[i] in cheap:
            cur_idx = i
            break
    if cur_idx is None:
        cur_idx = n - 1
    cur_rate = series[cur_idx]
    cur_month = mons[cur_idx]
    cur_year = yrs[cur_idx]
    in_cheap = cur_month in cheap

    prior_cheap = [series[i] for i in range(cur_idx) if mons[i] in cheap]
    prior_other = [series[i] for i in range(cur_idx) if mons[i] not in cheap]

    seasonal_norm = _mean(prior_cheap)
    other_norm = _mean(prior_other)
    reference = seasonal_norm if seasonal_norm is not None else other_norm

    pct = None
    pts = None
    tightness = "unmeasurable"
    if reference is not None:
        pct, pts = _pct_or_points(cur_rate, reference)
        if pts > 0.0:
            tightness = "tighter"
        elif pts < 0.0:
            tightness = "easier"
        else:
            tightness = "unchanged"

    no_easing = None
    if other_norm is not None:
        no_easing = bool(cur_rate >= other_norm)

    premium_trigger = bool(pct is not None and pct >= min_premium_pct) or bool(
        pct is None and pts is not None and pts > 0.0
    )
    warning = bool(in_cheap and (premium_trigger or bool(no_easing)))

    if reference is None:
        classification = "insufficient_history"
        reason = (
            "Only %d prior observation(s) before the current reading of %.2f per "
            "cent; the record does not yet show what money normally costs in this "
            "season, so no abnormal-money-market warning can be measured."
            % (cur_idx, cur_rate)
        )
    elif not in_cheap:
        classification = "money_tight_outside_cheap_season"
        reason = (
            "The latest observation is month %d, outside the cheap season %s. "
            "Money at %.2f per cent versus a norm of %.2f per cent is %s, but the "
            "chapter's warning is specifically tight money in the season when it "
            "should be cheapest." % (cur_month, sorted(cheap), cur_rate, reference, tightness)
        )
    elif warning:
        classification = "abnormal_money_market_tight_in_cheap_season"
        reason = (
            "Money is %.2f per cent in month %d, the season when it should be "
            "cheapest, against a seasonal norm of %.2f per cent (%+.1f per cent). "
            "That is the abnormal money market the chapter names: painfully tight "
            "in the cheap season while earnings and business are still good - the "
            "leading bear warning the stock market discounts before business men or "
            "the record do." % (cur_rate, cur_month, reference,
                                pct if pct is not None else 0.0)
        )
        if no_easing:
            reason += (" Money is not even cheaper than the rest of the year "
                       "(norm %.2f per cent): there is no seasonal easing at all."
                       % other_norm)
    else:
        classification = "money_not_abnormally_tight"
        reason = (
            "Money at %.2f per cent in month %d is %s versus the seasonal norm of "
            "%.2f per cent (%+.1f per cent), within the %.0f per cent premium the "
            "tool treats as painfully tight; money is behaving as it should in the "
            "cheap season." % (cur_rate, cur_month, tightness, reference,
                               pct if pct is not None else 0.0, min_premium_pct)
        )

    out = dict(compact_head)
    out.update({
        "classification": classification,
        "warning": warning,
        "current_rate": cur_rate,
        "current_month": cur_month,
        "current_year": cur_year,
        "in_cheap_season": in_cheap,
        "seasonal_norm_rate": seasonal_norm,
        "rest_of_year_norm_rate": other_norm,
        "reference_norm_rate": reference,
        "premium_vs_seasonal_norm_pct": pct,
        "premium_vs_seasonal_norm_points": pts,
        "no_seasonal_easing": no_easing,
        "tightness": tightness,
        "reason": reason,
    })

    if verbose:
        rows = [{"index": i, "year": yrs[i], "month": mons[i], "rate": series[i],
                 "cheap_season": mons[i] in cheap} for i in range(n)]
        out["observations"] = rows
        out["prior_cheap_season_observations"] = len(prior_cheap)
        out["prior_rest_of_year_observations"] = len(prior_other)

    return json.dumps({
        "result": out,
        "error": None,
        "metadata": {"provenance": provenance, "n_observations": n},
    })