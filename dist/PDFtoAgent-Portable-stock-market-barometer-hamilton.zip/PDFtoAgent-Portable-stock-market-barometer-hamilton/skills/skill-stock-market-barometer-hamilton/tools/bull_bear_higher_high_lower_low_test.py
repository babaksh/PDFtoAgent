import json
from typing import List, Optional


def _pivots(prices: List[float], window: int):
    n = len(prices)
    if n < 3:
        return [], []
    highs = []
    lows = []
    for i in range(n):
        lo = max(0, i - window)
        hi = min(n - 1, i + window)
        seg = prices[lo:hi + 1]
        v = prices[i]
        ties = sum(1 for x in seg if x == v)
        if ties == 1 and v == max(seg) and v > min(seg):
            highs.append((i, v))
        if ties == 1 and v == min(seg) and v < max(seg):
            lows.append((i, v))
    return highs, lows


def _alternate(highs, lows):
    points = sorted([(i, v, "H") for i, v in highs] + [(i, v, "L") for i, v in lows])
    kept = []
    for p in points:
        if kept and kept[-1][2] == p[2]:
            last = kept[-1]
            if (p[2] == "H" and p[1] > last[1]) or (p[2] == "L" and p[1] < last[1]):
                kept[-1] = p
        else:
            kept.append(p)
    return ([p for p in kept if p[2] == "H"], [p for p in kept if p[2] == "L"])


async def bull_bear_higher_high_lower_low_test(
    prices: List[float],
    swing_window: int = 5,
    min_break_pct: float = 3.0,
    secondary_max_periods: int = 21,
    verbose: bool = True,
) -> str:
    """Classify a market as bull or bear by Dow's own definition of market state.

    Dow, editorial of January 4, 1902: "It is a bull period as long as the
    average of one high point exceeds that of previous high points. It is a
    bear period when the low point becomes lower than the previous low points.
    It is often difficult to judge whether the end of an advance has come
    because the movement of prices is that which would occur if the main
    tendency had changed. Yet, it may only be an unusually pronounced
    secondary movement."

    Use when you have a price series (a market average or a single active
    stock) and want the bull/bear reading derived from the series itself --
    this tool identifies the swing high and low points and applies Dow's
    comparison, returning the classification plus a short reason.

    Do NOT use to sort a move into day-to-day / short swing / main movement by
    DURATION -- that is `dow_three_movement_classification` (chCYCLES AND STOCK
    MARKET RECORDS), which takes the primary trend as an input. This tool
    decides the state from the highs and lows and flags the stated ambiguity
    that a move resembling a change of main tendency may be only a pronounced
    secondary movement.
    """
    provenance = {
        "source_grounded": [
            "bull test: the average at one high point exceeds that of previous high points",
            "bear test: the low point becomes lower than the previous low points",
            "ambiguity: a move resembling a change of main tendency may be only an unusually pronounced secondary movement",
            "secondary movement runs from two weeks to a month or more",
        ],
        "model_extrapolated": [
            "swing_window = 5 periods for identifying a swing high or low point",
            "min_break_pct = 3.0 as the margin needed before the state change is treated as unambiguous",
            "secondary_max_periods = 21 (about a month of daily data) as the secondary-movement duration bound",
            "previous highs/lows summarised by their arithmetic mean, per Dow's 'average of ... previous high points'",
            "strictness flags: whether every successive high (low) is above (below) the one before",
        ],
    }
    try:
        series = [0.0 if p is None else float(p) for p in (prices or [])]
        window = 5 if swing_window is None else int(swing_window)
        if window < 1:
            window = 1
        min_break = 3.0 if min_break_pct is None else float(min_break_pct)
        sec_max = 21 if secondary_max_periods is None else int(secondary_max_periods)

        raw_highs, raw_lows = _pivots(series, window)
        highs, lows = _alternate(raw_highs, raw_lows)
        high_pts = [(i, v) for i, v, _ in highs]
        low_pts = [(i, v) for i, v, _ in lows]
        high_vals = [v for _, v in high_pts]
        low_vals = [v for _, v in low_pts]

        latest_high = None
        latest_low = None
        prev_highs_avg = None
        prev_lows_avg = None
        high_break_pct = None
        low_break_pct = None
        successive_higher_highs = None
        successive_lower_lows = None

        if len(high_vals) >= 2:
            latest_high = high_vals[-1]
            prev_highs_avg = sum(high_vals[:-1]) / float(len(high_vals) - 1)
            if prev_highs_avg > 0.0:
                high_break_pct = (latest_high - prev_highs_avg) / prev_highs_avg * 100.0
            successive_higher_highs = all(high_vals[k] > high_vals[k - 1]
                                          for k in range(1, len(high_vals)))
        if len(low_vals) >= 2:
            latest_low = low_vals[-1]
            prev_lows_avg = sum(low_vals[:-1]) / float(len(low_vals) - 1)
            if prev_lows_avg > 0.0:
                low_break_pct = (latest_low - prev_lows_avg) / prev_lows_avg * 100.0
            successive_lower_lows = all(low_vals[k] < low_vals[k - 1]
                                        for k in range(1, len(low_vals)))

        bull_signal = high_break_pct is not None and high_break_pct > 0.0
        bear_signal = low_break_pct is not None and low_break_pct < 0.0

        flat = bool(series) and max(series) == min(series)

        if not series:
            classification = "none"
            reason = "No prices were supplied, so no high or low point can be compared."
        elif flat:
            classification = "none"
            reason = ("The series is flat: no high point exceeds a previous high and no low "
                      "point undercuts a previous low, so Dow's test gives neither a bull "
                      "nor a bear reading.")
        elif len(high_vals) < 2 and len(low_vals) < 2:
            classification = "unconfirmed"
            reason = ("Fewer than two swing highs and two swing lows were formed, so no "
                      "high point can be compared with previous highs nor any low with "
                      "previous lows; the state is unconfirmed.")
        elif bull_signal and bear_signal:
            classification = "unconfirmed"
            reason = ("The latest high point exceeds the previous highs while the latest low "
                      "point also undercuts the previous lows; Dow's two tests conflict, so "
                      "the state cannot be declared.")
        elif bull_signal:
            classification = "bull"
            reason = ("The latest high point %.2f exceeds the average of the previous high "
                      "points %.2f, so by Dow's definition the period is bull."
                      % (latest_high, prev_highs_avg))
        elif bear_signal:
            classification = "bear"
            reason = ("The latest low point %.2f is below the average of the previous low "
                      "points %.2f, so by Dow's definition the period is bear."
                      % (latest_low, prev_lows_avg))
        else:
            classification = "unconfirmed"
            reason = ("The latest high point does not exceed the previous highs and the "
                      "latest low point does not undercut the previous lows; neither of "
                      "Dow's tests is satisfied, so the state is unconfirmed.")

        ambiguity_flag = False
        ambiguity_reason = None
        move_periods = 0
        if high_pts or low_pts:
            idxs = sorted([i for i, _ in high_pts] + [i for i, _ in low_pts])
            move_periods = idxs[-1] - idxs[0]
        if classification in ("bull", "bear"):
            margin = abs(high_break_pct) if classification == "bull" else abs(low_break_pct)
            weak_margin = margin is not None and margin < min_break
            short_move = move_periods <= sec_max
            if weak_margin or short_move:
                ambiguity_flag = True
                which = []
                if weak_margin:
                    which.append("the break is only %.2f%% against a %.2f%% minimum"
                                 % (margin, min_break))
                if short_move:
                    which.append("the move spans %d periods, inside the two-weeks-to-a-month "
                                 "range of a secondary movement" % move_periods)
                ambiguity_reason = ("It is difficult to judge whether the end of an advance "
                                    "has come, because the movement of prices is that which "
                                    "would occur if the main tendency had changed, yet it may "
                                    "only be an unusually pronounced secondary movement: "
                                    + "; ".join(which) + ".")

        result = {
            "classification": classification,
            "reason": reason,
            "ambiguity_flag": ambiguity_flag,
            "successive_higher_highs": successive_higher_highs,
            "successive_lower_lows": successive_lower_lows,
            "num_swing_highs": len(high_vals),
            "num_swing_lows": len(low_vals),
            "latest_high": latest_high,
            "latest_low": latest_low,
            "previous_highs_average": prev_highs_avg,
            "previous_lows_average": prev_lows_avg,
            "high_break_pct": high_break_pct,
            "low_break_pct": low_break_pct,
            "move_periods": move_periods,
        }
        if verbose:
            result["ambiguity_reason"] = ambiguity_reason
            result["swing_highs"] = [{"index": i, "price": v} for i, v in high_pts]
            result["swing_lows"] = [{"index": i, "price": v} for i, v in low_pts]
            result["params"] = {
                "swing_window": window,
                "min_break_pct": min_break,
                "secondary_max_periods": sec_max,
            }
        return json.dumps({"result": result, "error": None,
                           "metadata": {"provenance": provenance}})
    except Exception as exc:
        return json.dumps({"result": None, "error": str(exc),
                           "metadata": {"provenance": provenance}})