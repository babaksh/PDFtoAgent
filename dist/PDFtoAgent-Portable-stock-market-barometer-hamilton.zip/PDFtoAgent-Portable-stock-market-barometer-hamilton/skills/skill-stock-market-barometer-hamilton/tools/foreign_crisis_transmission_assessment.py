import json
from typing import Any, Dict, List, Optional


async def foreign_crisis_transmission_assessment(
    foreign_crisis_year: float,
    domestic_series: List[float],
    series_years: Optional[List[float]] = None,
    series_start_year: Optional[float] = None,
    breadstuff_exports: float = 0.0,
    gold_discovery_year: Optional[float] = None,
    max_lag_years: float = 5.0,
    heavy_fall_pct: float = 15.0,
    minimal_fall_pct: float = 2.0,
    offset_threshold: float = 0.5,
    breadstuff_large_level: float = 5.0,
    verbose: bool = True,
) -> str:
    """Grade how far a foreign crisis transmitted into domestic prices, and the lag.

    Use when you know the year of a FOREIGN panic and you have a domestic price
    or business series covering the years around it, and you want Dow's own
    reading of what that foreign crisis did here:

      * "heavy_price_fall" -- the foreign panic "was followed by heavy fall in
        prices in the Stock Exchange here" (the London panic of 1866);
      * "little_and_neutralized" -- the panic "exerted but little influence in
        this country" because its effects "were neutralized somewhat by large
        exports of breadstuffs and later by the discovery of gold" (1847, gold
        1848-9); or the European crisis of 1825 which led to "lower prices and
        some money stringency in 1826", "more in the nature of an interruption
        to progress than a reversal of conditions";
      * "no_transmission" -- the domestic series shows no material fall after
        the foreign date.

    Pass the domestic series as annual values (`domestic_series`) with the years
    given either explicitly (`series_years`, same length) or as a start year
    (`series_start_year`). Pass any offsetting domestic factors: `breadstuff_exports`
    on a 0-10 scale (10 = the large exports of breadstuffs of the late 1840s) and
    `gold_discovery_year` (a gold discovery inside the post-crisis window, e.g.
    1849). Returns the grade, the measured peak-to-trough fall inside the window,
    the trough year and the lag in years between the foreign event and the
    domestic effect.

    Do NOT use this to name the KIND of disturbance (commercial panic, money
    panic, Stock Exchange smash) -- call `crisis_type_classification`. Do NOT use
    it to attribute a crisis to a cause -- call `crisis_cause_attribution` (its
    grade can be fed back in there as `foreign_crisis_severity` /
    `foreign_crisis_years_before`).

    Depends on: nothing from earlier chapters.
    """
    try:
        foreign_crisis_year = 0.0 if foreign_crisis_year is None else float(foreign_crisis_year)
        max_lag_years = 5.0 if max_lag_years is None else float(max_lag_years)
        heavy_fall_pct = 15.0 if heavy_fall_pct is None else float(heavy_fall_pct)
        minimal_fall_pct = 2.0 if minimal_fall_pct is None else float(minimal_fall_pct)
        offset_threshold = 0.5 if offset_threshold is None else float(offset_threshold)
        breadstuff_large_level = 5.0 if breadstuff_large_level is None else float(breadstuff_large_level)
        breadstuff_exports = 0.0 if breadstuff_exports is None else float(breadstuff_exports)

        values = [float(v) for v in (domestic_series or []) if v is not None]
        n = len(values)
        if n == 0:
            return json.dumps({
                "result": {
                    "foreign_crisis_year": foreign_crisis_year,
                    "grade": "no_transmission",
                    "fall_pct": 0.0,
                    "lag_years": None,
                    "trough_year": None,
                    "baseline_value": None,
                    "trough_value": None,
                    "offsetting_score": 0.0,
                    "neutralized": False,
                    "reason": "Empty domestic series: no domestic price or business data was supplied, so no transmission can be measured. The reading is no_transmission with error null.",
                },
                "error": None,
                "metadata": {"provenance": {
                    "source_grounded": [
                        "foreign panic followed by heavy fall in prices in the Stock Exchange here (1866)",
                        "panic exerted but little influence in this country (1847)",
                        "effects neutralized somewhat by large exports of breadstuffs and later by the discovery of gold (1848-9)",
                        "European crisis of 1825 caused diminished demand for American products and led to lower prices and some money stringency in 1826",
                    ],
                    "model_extrapolated": [
                        "empty-series boundary reading returned as no_transmission rather than an error",
                    ],
                }},
            })

        if series_years and len(series_years) == n:
            years = [float(y) for y in series_years]
        elif series_years and len(series_years) > n:
            years = [float(y) for y in series_years[:n]]
        else:
            start = 0.0 if series_start_year is None else float(series_start_year)
            years = [start + float(i) for i in range(n)]

        baseline_idx = min(range(n), key=lambda i: abs(years[i] - foreign_crisis_year))
        baseline_year = years[baseline_idx]
        baseline = values[baseline_idx]

        window_end = foreign_crisis_year + max_lag_years
        window = [(i, years[i], values[i]) for i in range(n) if foreign_crisis_year <= years[i] <= window_end]
        if not window:
            window = [(baseline_idx, baseline_year, baseline)]
        trough_idx, trough_year, trough = min(window, key=lambda row: row[2])

        fall_pct = 0.0
        if baseline > 0.0:
            fall_pct = (trough - baseline) / baseline * 100.0
        elif baseline < 0.0:
            fall_pct = (baseline - trough) / abs(baseline) * 100.0

        lag_years = trough_year - foreign_crisis_year

        breadstuff_component = min(1.0, max(0.0, breadstuff_exports) / breadstuff_large_level) if breadstuff_large_level > 0.0 else 0.0
        gold_component = (
            1.0
            if gold_discovery_year is not None
            and foreign_crisis_year <= float(gold_discovery_year) <= window_end
            else 0.0
        )
        offsetting_score = 0.5 * breadstuff_component + 0.5 * gold_component

        if fall_pct <= -heavy_fall_pct:
            grade = "heavy_price_fall"
        elif fall_pct <= -minimal_fall_pct:
            grade = "little_and_neutralized"
        else:
            grade = "no_transmission"

        downgraded = False
        if grade == "heavy_price_fall" and offsetting_score >= offset_threshold:
            grade = "little_and_neutralized"
            downgraded = True

        if grade == "heavy_price_fall":
            reason = (
                "Heavy price fall: the domestic series fell %.1f%% from %.2f in %.2f to %.2f in %.2f, %d year(s) "
                "after the foreign crisis of %.0f -- the foreign panic was followed by a heavy fall in prices "
                "here." % (fall_pct, baseline, baseline_year, trough, trough_year, lag_years, foreign_crisis_year)
            )
        elif grade == "little_and_neutralized":
            if downgraded:
                reason = (
                    "Little influence, and neutralized: the measured fall of %.1f%% was heavy enough to matter, "
                    "but offsetting domestic factors (breadstuff exports %.1f of %d, gold discovery %s) score "
                    "%.2f against the offset level of %.2f -- the effects were neutralized somewhat, as in 1847."
                    % (
                        fall_pct,
                        breadstuff_exports,
                        breadstuff_large_level,
                        "in %.0f" % float(gold_discovery_year) if gold_discovery_year is not None else "none",
                        offsetting_score,
                        offset_threshold,
                    )
                )
            else:
                reason = (
                    "But little influence: the domestic series fell %.1f%% (below the %.1f%% heavy-fall mark) "
                    "reaching its low in %.2f, %d year(s) after the foreign crisis of %.0f -- lower prices and "
                    "some stringency, more in the nature of an interruption to progress than a reversal."
                    % (fall_pct, heavy_fall_pct, trough_year, lag_years, foreign_crisis_year)
                )
        else:
            reason = (
                "No transmission: the domestic series moved %.1f%% from %.2f in %.2f to its low of %.2f in %.2f "
                "within %d year(s) of the foreign crisis of %.0f -- no material fall (threshold %.1f%%)."
                % (fall_pct, baseline, baseline_year, trough, trough_year, max_lag_years, foreign_crisis_year, minimal_fall_pct)
            )

        result: Dict[str, Any] = {
            "foreign_crisis_year": foreign_crisis_year,
            "grade": grade,
            "fall_pct": fall_pct,
            "lag_years": lag_years,
            "trough_year": trough_year,
            "baseline_value": baseline,
            "trough_value": trough,
            "offsetting_score": offsetting_score,
            "neutralized": downgraded,
            "reason": reason,
        }
        if verbose:
            result["series"] = [{"year": years[i], "value": values[i]} for i in range(n)]
            result["window"] = [{"year": y, "value": v} for _, y, v in window]
            result["components"] = {
                "breadstuff_component": breadstuff_component,
                "gold_component": gold_component,
                "gold_discovery_year": gold_discovery_year,
                "baseline_year": baseline_year,
                "window_end_year": window_end,
            }
            result["thresholds"] = {
                "max_lag_years": max_lag_years,
                "heavy_fall_pct": heavy_fall_pct,
                "minimal_fall_pct": minimal_fall_pct,
                "offset_threshold": offset_threshold,
                "breadstuff_large_level": breadstuff_large_level,
            }
        return json.dumps({
            "result": result,
            "error": None,
            "metadata": {"provenance": {
                "source_grounded": [
                    "foreign panic followed by heavy fall in prices in the Stock Exchange here (1866)",
                    "panic exerted but little influence in this country (1847)",
                    "effects neutralized somewhat by large exports of breadstuffs and later by the discovery of gold (1848-9)",
                    "European crisis of 1825 caused diminished demand for American products and led to lower prices and some money stringency in 1826",
                    "interruption to progress rather than a reversal of conditions (1826)",
                ],
                "model_extrapolated": [
                    "numeric thresholds: 15% heavy fall, 2% minimal fall, 5-year post-crisis window, 0-10 breadstuff scale with 5 = large, 0.5 offset level",
                    "offsetting score = 0.5 breadstuff + 0.5 gold discovery inside the window, and the one-step downgrade of a heavy fall to little_and_neutralized",
                    "baseline taken as the series value at the year nearest the foreign crisis; trough as the minimum inside the window",
                    "boundary readings for an empty series, a single-element series and a flat series returned as no_transmission rather than an error",
                ],
            }},
        })
    except Exception as exc:  # pragma: no cover - defensive
        return json.dumps({
            "result": None,
            "error": "%s: %s" % (type(exc).__name__, exc),
            "metadata": {"provenance": {
                "source_grounded": [],
                "model_extrapolated": ["error path only"],
            }},
        })