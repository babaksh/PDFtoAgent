import json
import math
from typing import List, Optional


def _as_float(value, default: float) -> float:
    try:
        if value is None:
            return float(default)
        return float(value)
    except (TypeError, ValueError):
        return float(default)


def _sign(points: float) -> str:
    if points > 0.0:
        return "up"
    if points < 0.0:
        return "down"
    return "none"


async def dull_market_no_sell_maxim_test(
    prices: Optional[List[float]] = None,
    activity: Optional[List[float]] = None,
    primary_direction: str = "bull",
    lookback_periods: Optional[int] = None,
    dull_activity_share: float = 0.6,
    min_sharply_pct: float = 3.0,
    verbose: bool = True,
) -> str:
    """Apply Wall Street's maxim 'Never sell a dull market' with the chapter's stated qualification.

    Use when a market has become dull (trading activity shrunk well inside its recent
    range) and you must decide whether the maxim 'Never sell a dull market' governs the
    case. The chapter qualifies it: it holds when a bull market has reacted and become
    dull -- hold. It is bad advice in a major bear swing, because the market then
    becomes dull after a sharp rally, and experienced traders accordingly put out their
    shorts again.

    Inputs: `prices` is the chronological price path, `activity` is a parallel series of
    trading activity (volume, transactions, or any comparable activity measure),
    `primary_direction` is 'bull' or 'bear', and `lookback_periods` sets how much of
    the recent record defines the activity norm (defaults to the whole record).

    Do NOT use this to classify the market's primary direction -- supply
    `primary_direction` or use bull_bear_higher_high_lower_low_test. Do NOT use it
    where no activity series exists: dullness is a property of trading, and the chapter
    calls the market dull by contrast with the activity that preceded it.
    """
    try:
        prices_in = [_as_float(p, float("nan")) for p in (prices or [])]
        activity_in = [_as_float(a, float("nan")) for a in (activity or [])]
        series = [p for p in prices_in if not math.isnan(p)]
        acts = [a for a in activity_in if not math.isnan(a)]

        trend = str(primary_direction or "bull").strip().lower()
        is_bear = trend.startswith("bear") or trend in ("down", "decline")
        label = "bear" if is_bear else "bull"
        share = _as_float(dull_activity_share, 0.6)
        sharply_pct = _as_float(min_sharply_pct, 3.0)

        def _respond(result):
            return json.dumps({
                "result": result,
                "error": None,
                "metadata": {
                    "tool": "dull_market_no_sell_maxim_test",
                    "provenance": {
                        "source_grounded": [
                            "maxim 'Never sell a dull market'",
                            "holds when a bull market has reacted and become dull",
                            "bad advice in a major bear swing",
                            "in a bear swing the market becomes dull after a sharp rally",
                            "experienced traders put out their shorts again",
                        ],
                        "model_extrapolated": [
                            "dullness measured as average activity below a share of the lookback norm",
                            "dull_activity_share default of 0.6",
                            "min_sharply_pct default of 3 percent to judge a preceding sharp rally",
                            "action stated as hold, go_short_again, or no_evidence",
                        ],
                    },
                },
            })

        if not series:
            return _respond({
                "primary_direction": label,
                "is_dull": False,
                "action": "no_evidence",
                "classification": "no_evidence",
                "reason": "no prices were supplied, so the maxim cannot be applied",
            })

        n = len(series)
        lb = None if lookback_periods is None else int(lookback_periods)
        if lb is None or lb <= 0:
            lb = max(1, int(math.ceil(n / 3.0)))
        lb = max(1, min(lb, n))

        recent = series[n - lb:]
        recent_high = max(recent)
        recent_low = min(recent)
        recent_mean = sum(recent) / float(len(recent))
        recent_range_pct = (
            (recent_high - recent_low) / recent_mean * 100.0 if recent_mean else 0.0
        )

        if acts:
            m = min(len(acts), n)
            acts = acts[-m:]
            tail = max(1, min(lb, len(acts)))
            norm = sum(acts) / float(len(acts)) if len(acts) else 0.0
            recent_activity = sum(acts[-tail:]) / float(tail)
            is_dull = bool(recent_activity < norm * share)
            activity_ratio = (recent_activity / norm) if norm else None
        else:
            norm = None
            recent_activity = None
            activity_ratio = None
            is_dull = False

        move_points = series[-1] - series[0]
        move_pct = (move_points / series[0] * 100.0) if series[0] else 0.0
        move_direction = _sign(move_points)

        preceding = series[: n - lb + 1] if n - lb + 1 >= 1 else series[:1]
        preceding_pct = 0.0
        if preceding and preceding[0]:
            swings = [((p - preceding[0]) / preceding[0] * 100.0) for p in preceding]
            preceding_pct = (max(swings) if is_bear else min(swings))
        sharp = bool(math.fabs(preceding_pct) >= sharply_pct)

        if not acts:
            classification = "cannot_judge_dullness"
            action = "no_evidence"
            reason = (
                "no activity series was supplied, so dullness cannot be measured; the maxim turns "
                "on dullness, not on price alone"
            )
        elif not is_dull:
            classification = "not_a_dull_market"
            action = "maxim_does_not_apply"
            reason = (
                "recent average activity of %.2f stands at %.2f of the %.2f norm, above the %.2f "
                "dullness share, so this is not a dull market and the maxim does not govern the case"
                % (recent_activity or 0.0, activity_ratio or 0.0, norm or 0.0, share)
            )
        elif is_bear:
            classification = "bear_swing_dull_after_sharp_rally"
            action = "go_short_again"
            reason = (
                "a major bear swing has become dull%s; the maxim is bad advice here, for the "
                "market becomes dull after a sharp rally and experienced traders accordingly put "
                "out their shorts again"
                % (" after a sharp rally of %.2f percent" % preceding_pct if sharp else "")
            )
        else:
            classification = "bull_market_reacted_into_dullness"
            action = "hold"
            reason = (
                "a bull market has reacted into dullness (recent activity at %.2f of the norm); "
                "the maxim 'Never sell a dull market' holds and the intelligent amateur is on all "
                "fours with the professional here" % (activity_ratio or 0.0)
            )

        result = {
            "primary_direction": label,
            "lookback_periods": lb,
            "recent_price_mean": recent_mean,
            "recent_range_pct": recent_range_pct,
            "activity_norm": norm,
            "recent_activity": recent_activity,
            "activity_ratio": activity_ratio,
            "dull_activity_share": share,
            "is_dull": bool(is_dull),
            "move_points": move_points,
            "move_pct": move_pct,
            "move_direction": move_direction,
            "preceding_move_pct": preceding_pct,
            "preceding_move_was_sharp": sharp,
            "maxim_applies": bool(is_dull and not is_bear),
            "action": action,
            "classification": classification,
            "reason": reason,
        }
        if verbose:
            result["prices"] = series
            result["activity"] = acts
            result["thresholds"] = {
                "dull_activity_share": share,
                "min_sharply_pct": sharply_pct,
            }
            result["rule"] = (
                "Never sell a dull market -- but hold only where a bull market has reacted into "
                "dullness; in a major bear swing, where the market becomes dull after a sharp "
                "rally, put out the shorts again"
            )

        return _respond(result)
    except Exception as exc:  # pragma: no cover - defensive
        return json.dumps({
            "result": None,
            "error": str(exc),
            "metadata": {
                "tool": "dull_market_no_sell_maxim_test",
                "provenance": {
                    "source_grounded": ["Never sell a dull market"],
                    "model_extrapolated": ["dullness threshold"],
                },
            },
        })