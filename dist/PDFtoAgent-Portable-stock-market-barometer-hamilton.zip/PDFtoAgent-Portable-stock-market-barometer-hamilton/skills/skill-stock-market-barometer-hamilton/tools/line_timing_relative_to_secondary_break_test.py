import json
import math
from typing import List, Optional


def _as_float(value, default: float) -> float:
    try:
        if value is None:
            return float(default)
        return float(value)
    except (TypeError, ValueError):
        return float(default)


def _sign(points: float) -> str:
    if points > 0.0:
        return "up"
    if points < 0.0:
        return "down"
    return "none"


async def line_timing_relative_to_secondary_break_test(
    prices: Optional[List[float]] = None,
    line_start_index: Optional[int] = None,
    line_end_index: Optional[int] = None,
    secondary_move_index: Optional[int] = None,
    direction: str = "bull",
    origin_price: Optional[float] = None,
    max_band_pct: float = 5.0,
    verbose: bool = True,
) -> str:
    """Date a line in the averages against a secondary break or rally and read it as a predictor or as a re-entry signal.

    Use when the averages have made a line (a narrow horizontal trading range) and you
    must say whether that line came before or after the secondary break or rally, and
    therefore what it is worth. The chapter answers the question 'Do the averages
    predict a secondary reaction in any dependable way?' by observing that experience
    shows the line occurs generally NOT before but AFTER a secondary break or rally.
    The line is therefore most useful to the speculator who has previously sold and
    wants to get into the market again: a bull indication after a line of accumulation
    points the way to a new figure higher than that from which the secondary decline
    took its origin, and such a new top is conclusive evidence that the bull movement
    had been resumed.

    Extends: line_formation_breakout (chCYCLES AND STOCK MARKET RECORDS), which detects
    and classifies a line's resolution but does not date the line against a secondary
    move. This tool adds the sequencing verdict from experience (line generally after,
    not before) and the use that follows from it.

    Inputs: `prices` (chronological path of an average), the line's index bounds
    `line_start_index` / `line_end_index`, the index of the secondary break or rally
    `secondary_move_index`, the primary `direction` ('bull' or 'bear'), and optionally
    `origin_price`, the figure from which the secondary move took its origin.

    Do NOT use this merely to detect whether a line exists -- use
    line_formation_breakout. Do NOT use it to test resumption when no line is involved
    -- use secondary_decline_origin_new_high_resumption_test.
    """
    try:
        series = [_as_float(p, float("nan")) for p in (prices or [])]
        series = [p for p in series if not math.isnan(p)]
        trend = str(direction or "bull").strip().lower()
        is_bear = trend.startswith("bear") or trend in ("down", "decline")
        label = "bear" if is_bear else "bull"
        band_pct = _as_float(max_band_pct, 5.0)
        if band_pct < 0.0:
            band_pct = 0.0
        expected_line_side = "after"

        def _respond(result):
            return json.dumps({
                "result": result,
                "error": None,
                "metadata": {
                    "tool": "line_timing_relative_to_secondary_break_test",
                    "provenance": {
                        "source_grounded": [
                            "line occurs generally not before but after a secondary break or rally",
                            "line most useful to the speculator who has previously sold and wants to get back in",
                            "bull indication after a line of accumulation points to a new figure higher than the decline's origin",
                            "new top above the origin is conclusive evidence of resumption",
                            "converse for a bear market",
                        ],
                        "model_extrapolated": [
                            "max_band_pct default of 5 percent to judge whether a segment is a line",
                            "line dated by its midpoint against the secondary move index",
                            "line_end_index defaults to the end of the record",
                        ],
                    },
                },
            })

        if not series:
            return _respond({
                "direction": label,
                "classification": "no_evidence",
                "line_before_or_after": None,
                "reason": "no prices were supplied, so no line can be dated against a secondary move",
            })

        n = len(series)
        start = 0 if line_start_index is None else int(line_start_index)
        end = (n - 1) if line_end_index is None else int(line_end_index)
        start = max(0, min(start, n - 1))
        end = max(0, min(end, n - 1))
        if end < start:
            start, end = end, start

        if secondary_move_index is None:
            move_index = series.index(max(series) if is_bear else min(series))
        else:
            move_index = int(secondary_move_index)
        move_index = max(0, min(move_index, n - 1))

        window = series[start:end + 1]
        window_high = max(window)
        window_low = min(window)
        window_mean = sum(window) / float(len(window))
        window_range_pct = (
            (window_high - window_low) / window_mean * 100.0 if window_mean else 0.0
        )
        is_line = window_range_pct <= band_pct

        line_mid_index = (start + end) / 2.0
        if line_mid_index < move_index:
            before_or_after = "before"
        elif line_mid_index > move_index:
            before_or_after = "after"
        else:
            before_or_after = "coincident"
        matches_experience = (before_or_after == expected_line_side)

        post_line = series[end + 1:]
        if post_line:
            post_extreme_price = min(post_line) if is_bear else max(post_line)
            post_extreme_index = end + 1 + post_line.index(post_extreme_price)
        else:
            post_extreme_price = None
            post_extreme_index = None

        breakout_points = (
            (post_extreme_price - series[end]) if post_extreme_price is not None else None
        )
        breakout_direction = _sign(breakout_points) if breakout_points is not None else "none"

        origin = _as_float(origin_price, series[0])
        points_beyond_origin = None
        new_figure_conclusive = False
        if post_extreme_price is not None:
            points_beyond_origin = (
                (origin - post_extreme_price) if is_bear
                else (post_extreme_price - origin)
            )
            new_figure_conclusive = points_beyond_origin > 0.0

        if not is_line:
            classification = "not_a_line"
            reason = (
                "the segment from index %d to %d ranges %.2f percent, wider than the %.2f percent "
                "band, so it is not a line and cannot be dated against the secondary move"
                % (start, end, window_range_pct, band_pct)
            )
        elif before_or_after == "after":
            classification = "line_after_secondary_move"
            reason = (
                "the line (midpoint index %.1f) falls after the secondary move (index %d), as "
                "experience says it generally does; it is a re-entry signal for the trader who "
                "has already sold, not a predictor of the break" % (line_mid_index, move_index)
            )
        elif before_or_after == "before":
            classification = "line_before_secondary_move"
            reason = (
                "the line (midpoint index %.1f) falls before the secondary move (index %d); this "
                "is the dependable-prediction case, which experience says is the exception rather "
                "than the rule" % (line_mid_index, move_index)
            )
        else:
            classification = "line_coincident_with_secondary_move"
            reason = (
                "the line's midpoint falls on the secondary move itself (index %d), so the "
                "sequencing test cannot separate them" % move_index
            )

        if is_line:
            if new_figure_conclusive:
                use = "re_entry_signal_confirmed_by_new_figure"
                reason += (
                    "; the %s indication after the line carried the average %.2f points beyond the "
                    "origin figure of %.2f, conclusive evidence that the %s movement had been resumed"
                    % (
                        "bear" if is_bear else "bull",
                        math.fabs(points_beyond_origin),
                        origin,
                        label,
                    )
                )
            elif breakout_direction == "none":
                use = "no_indication_yet"
                reason += "; but no price has yet moved away from the line to give an indication"
            else:
                use = "re_entry_signal_not_yet_confirmed"
                reason += (
                    "; the %s indication out of the line has not yet reached a new figure beyond "
                    "the origin of %.2f" % ("bear" if is_bear else "bull", origin)
                )

        result = {
            "direction": label,
            "line_start_index": start,
            "line_end_index": end,
            "line_high": window_high,
            "line_low": window_low,
            "line_range_pct": window_range_pct,
            "is_line": is_line,
            "secondary_move_index": move_index,
            "secondary_move_price": series[move_index],
            "line_before_or_after": before_or_after,
            "expected_by_experience": expected_line_side,
            "matches_experience": matches_experience,
            "post_line_extreme_price": post_extreme_price,
            "post_line_extreme_index": post_extreme_index,
            "breakout_points": breakout_points,
            "breakout_direction": breakout_direction,
            "origin_price": origin,
            "new_figure_points_beyond_origin": points_beyond_origin,
            "new_figure_conclusive": new_figure_conclusive,
            "classification": classification,
            "reason": reason,
        }
        if is_line:
            result["use"] = use
        else:
            result["use"] = "none"

        if verbose:
            result["prices"] = series
            result["thresholds"] = {"max_band_pct": band_pct}
            result["rule"] = (
                "experience tells us that when the line occurs it is, generally, not before but "
                "after a secondary break or rally, so the line serves the trader who has already "
                "sold rather than as a forecast of the break"
            )

        return _respond(result)
    except Exception as exc:  # pragma: no cover - defensive
        return json.dumps({
            "result": None,
            "error": str(exc),
            "metadata": {
                "tool": "line_timing_relative_to_secondary_break_test",
                "provenance": {
                    "source_grounded": ["line generally occurs after a secondary break or rally"],
                    "model_extrapolated": ["max_band_pct default"],
                },
            },
        })