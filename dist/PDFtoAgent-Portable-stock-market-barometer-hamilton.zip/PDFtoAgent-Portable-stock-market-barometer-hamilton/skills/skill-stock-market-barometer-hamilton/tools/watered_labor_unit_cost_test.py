"""Watered labor: unit-cost-of-production dilution test (Hamilton, ch. "Its Greatest Vindication - 1917").

Quantifies "watered labor" the way Director-General Piez measured it in the Atlantic
Coast shipyards: workmen received $2 for the same time that a year earlier brought
only $1, while individual output was only two-thirds of what it had been. Dividing
the change in wages per unit of TIME by the change in individual OUTPUT per worker
gives the multiplier applied to the unit of cost of production (2 / (2/3) = 3x, i.e.
an efficiency of only one-third), and rules whether a wage advance is real earnings
(earned by output) or pure dilution of the unit of cost of production.

The chapter adds that the larger wages were "only excused by the higher prices for
commodities of which those wages themselves had been the automatic cause", and that
the water was "less the cash wages than the slacking, shirking and bad work": pass a
commodity price index before/after and the test re-expresses the wage in real terms
before deciding whether cash wages or slacking is the dominant cause.

Use when you have a before/after wage rate per unit of time AND a before/after
individual output per worker for the same labor, and want to know how much water
the wage advance put into unit costs, and whether cash wages or slacking is the
dominant cause.

Depends on: water_in_capitalization_test (ch09, "Water in the Barometer") -- that
tool settles water in CAPITALIZATION from market price vs stated values; this one is
the same "water" family applied to LABOR, where the dilution is wage-per-time over
output-per-worker and the ruling is real-earnings vs dilution.

Do NOT use for: water in stock/capitalization (call water_in_capitalization_test),
and do NOT use when you only have aggregate payroll and no per-worker output.
"""

import json
import math
from typing import Optional


def _provenance():
    return {
        "source_grounded": [
            "Piez shipyard measurement: $2 for the time that a year earlier brought $1",
            "individual output only two-thirds of what it had been a year before",
            "unit cost multiplier = change in wages per unit of time / change in individual output per worker",
            "resulting efficiency one-third -> unit of cost of production trebled",
            "wage advance excusable only by a corresponding productive return",
            "larger wages only excused by the higher prices for commodities the wages caused",
            "the water was less the cash wages than the slacking, shirking and bad work",
        ],
        "model_extrapolated": [
            "real wage ratio = wage ratio / commodity price index ratio",
            "log decomposition of the unit-cost multiplier into cash-wage and slacking shares",
            "dilution_tolerance_pct default 0.0",
            "'balanced' dominance band of 5 percentage points between the two shares",
            "edge handling for zero / negative / missing baselines (unmeasurable reading, error stays null)",
        ],
    }


def _ratio(after, before):
    if after is None or before is None:
        return None
    after = float(after)
    before = float(before)
    if before == 0.0:
        return None
    return after / before


async def watered_labor_unit_cost_test(
    wage_per_unit_time_before: Optional[float] = None,
    wage_per_unit_time_after: Optional[float] = None,
    output_per_worker_before: Optional[float] = None,
    output_per_worker_after: Optional[float] = None,
    price_index_before: Optional[float] = None,
    price_index_after: Optional[float] = None,
    dilution_tolerance_pct: Optional[float] = 0.0,
    verbose: bool = True,
) -> str:
    """Measure the water in a wage advance: wage change per unit of time over the worker's output change.

    Use when you have a before/after wage rate per unit of time (hour, day, week) and
    a before/after individual output per worker for the same labor, and want (a) the
    multiplier applied to the unit of cost of production, (b) a ruling of real
    earnings versus dilution (watered labor), and (c) whether cash wages or slacking
    is the dominant cause.

    Do NOT use for water in a capitalization (call water_in_capitalization_test), and
    do NOT call it when you have no per-worker output figure -- the test is defined as
    wage-per-time divided by output-per-worker.

    Args:
        wage_per_unit_time_before: wage for one unit of time before (e.g. 1.0 dollar/hour).
        wage_per_unit_time_after: wage for the SAME unit of time after (e.g. 2.0).
        output_per_worker_before: individual output per worker per unit of time before (e.g. 1.0).
        output_per_worker_after: individual output per worker per unit of time after (e.g. 0.6667).
        price_index_before: commodity price level before, to state the wage in real terms.
        price_index_after: commodity price level after -- the chapter's excuse for the wage.
        dilution_tolerance_pct: percent by which the unit cost may rise before the
            advance is called dilution (0.0 = any rise is water).
        verbose: False returns the compact ruling; True adds the decomposition and reason.
    """
    tol_pct = 0.0 if dilution_tolerance_pct is None else float(dilution_tolerance_pct)

    wage_ratio = _ratio(wage_per_unit_time_after, wage_per_unit_time_before)
    output_ratio = _ratio(output_per_worker_after, output_per_worker_before)
    price_ratio = _ratio(price_index_after, price_index_before)
    if price_ratio is not None and price_ratio <= 0.0:
        price_ratio = None

    if (wage_ratio is None or output_ratio is None
            or wage_ratio <= 0.0 or output_ratio <= 0.0):
        result = {
            "verdict": "unmeasurable",
            "reason": "wage or output baseline is missing, zero or negative, so the "
                      "unit-cost multiplier cannot be formed",
            "wage_ratio": wage_ratio,
            "output_ratio": output_ratio,
            "unit_cost_multiplier": None,
            "efficiency_ratio": None,
            "water_pct": None,
            "real_earnings": None,
            "dominant_cause": "unmeasurable",
        }
        if verbose:
            result["inputs"] = {
                "wage_per_unit_time_before": wage_per_unit_time_before,
                "wage_per_unit_time_after": wage_per_unit_time_after,
                "output_per_worker_before": output_per_worker_before,
                "output_per_worker_after": output_per_worker_after,
                "price_index_before": price_index_before,
                "price_index_after": price_index_after,
                "dilution_tolerance_pct": tol_pct,
            }
        return json.dumps({
            "result": result,
            "error": None,
            "metadata": {"provenance": _provenance()},
        })

    unit_cost_multiplier = wage_ratio / output_ratio
    efficiency_ratio = output_ratio / wage_ratio
    water_pct = (unit_cost_multiplier - 1.0) * 100.0
    real_wage_ratio = wage_ratio / price_ratio if price_ratio else wage_ratio
    real_multiplier = real_wage_ratio / output_ratio

    if wage_ratio == 1.0 and output_ratio == 1.0:
        verdict = "no_change"
        real_earnings = True
        reason = "neither wages nor individual output changed, so there is no water to measure"
    elif unit_cost_multiplier <= 1.0 + tol_pct / 100.0:
        verdict = "real_earnings"
        real_earnings = True
        reason = (
            "output per worker rose at least as fast as wages (unit cost multiplier "
            "%.4f within tolerance %.2f%%): the advance is earned, not water"
            % (unit_cost_multiplier, tol_pct)
        )
    else:
        verdict = "watered_labor_dilution"
        real_earnings = False
        reason = (
            "wages rose %.4fx while individual output moved %.4fx: the unit of cost of "
            "production is multiplied by %.4f (efficiency %.4f, %.2f%% water)"
            % (wage_ratio, output_ratio, unit_cost_multiplier, efficiency_ratio, water_pct)
        )

    log_total = math.log(real_multiplier)
    if abs(log_total) < 1e-12:
        wage_share = None
        slack_share = None
        dominant = "no_dilution"
    else:
        log_wage = math.log(real_wage_ratio)
        log_slack = -math.log(output_ratio)
        wage_share = log_wage / log_total
        slack_share = log_slack / log_total
        if abs(wage_share - slack_share) <= 0.05:
            dominant = "balanced"
        elif wage_share > slack_share:
            dominant = "cash_wages"
        else:
            dominant = "slacking"

    result = {
        "verdict": verdict,
        "wage_ratio": wage_ratio,
        "output_ratio": output_ratio,
        "unit_cost_multiplier": unit_cost_multiplier,
        "water_pct": water_pct,
        "real_earnings": real_earnings,
        "dominant_cause": dominant,
    }
    if verbose:
        result["efficiency_ratio"] = efficiency_ratio
        result["wage_change_pct"] = (wage_ratio - 1.0) * 100.0
        result["output_change_pct"] = (output_ratio - 1.0) * 100.0
        result["real_wage_ratio"] = real_wage_ratio
        result["real_unit_cost_multiplier"] = real_multiplier
        result["wage_contribution_share"] = wage_share
        result["slacking_contribution_share"] = slack_share
        result["reason"] = reason
        result["inputs"] = {
            "wage_per_unit_time_before": wage_per_unit_time_before,
            "wage_per_unit_time_after": wage_per_unit_time_after,
            "output_per_worker_before": output_per_worker_before,
            "output_per_worker_after": output_per_worker_after,
            "price_index_before": price_index_before,
            "price_index_after": price_index_after,
            "dilution_tolerance_pct": tol_pct,
        }
    return json.dumps({
        "result": result,
        "error": None,
        "metadata": {"provenance": _provenance()},
    })