import json
from typing import List, Optional


async def falling_market_bear_support_test(
    price_series: List[float],
    short_interest_shares: Optional[List[float]] = None,
    short_selling_permitted: bool = True,
    short_interest_now_shares: float = 0.0,
    shares_outstanding: float = 0.0,
    lookback_periods: int = 10,
    decline_threshold_pct: float = 5.0,
    min_uncovered_pct_of_shares: float = 1.0,
    min_uncovered_shares: float = 0.0,
    verbose: bool = True,
) -> str:
    """Judge whether a falling market is cushioned by an uncovered bear account whose covering supports it, or is an unsupported decline liable to a panic break of the kind seen where short selling is prohibited.

    Use when a market is falling and you want to know what is underneath it.
    Give the price path of the average or stock and, if you have it, the short
    interest (an uncovered bear account). The chapter's rule: there is no such
    valuable support for a falling market as the uncovered bear account; when it
    is absent -- as in English bank stocks, where the law prohibits short
    selling -- nothing but a bankers' combination hastily improvised can check
    the devastating decline, and any free market without that liberty would be
    liable to an unsupported panic break at any stage of its progress.

    Do NOT use this to detect an overrun (call
    primary_overrun_crowding_detector), and do NOT use it to attribute a move to
    manipulation (call manipulation_scope_by_movement_classifier).

    Args:
        price_series: the price path, oldest first, of the market or stock
            being judged (an average or a single issue).
        short_interest_shares: short interest over the same window, oldest
            first, in shares. The most recent reading is treated as the
            uncovered bear account.
        short_selling_permitted: False where short selling is prohibited (the
            English bank-stock case) -- the support is then absent by law.
        short_interest_now_shares: single current short-interest reading in
            shares, used when no series is supplied.
        shares_outstanding: shares outstanding of the issue, used to express the
            bear account as a share of the stock.
        lookback_periods: how many trailing periods define "falling"
            (default 10).
        decline_threshold_pct: fall, in per cent, at or beyond which the market
            counts as falling (default 5.0).
        min_uncovered_pct_of_shares: bear account as a share of shares
            outstanding, in per cent, at or above which it counts as real
            support (default 1.0).
        min_uncovered_shares: absolute share count at or above which the bear
            account counts as real support (default 0.0; used when shares
            outstanding are not supplied).
        verbose: False returns the compact ruling; True adds the full breakdown.

    Returns:
        JSON string with result/error/metadata. Result holds falling, the bear
        account measurement, supported, and the verdict -- "supported_decline",
        "unsupported_decline_panic_risk" or "not_a_falling_market".
    """
    try:
        prices = [float(p) for p in (price_series or []) if p is not None]

        window = (
            int(lookback_periods)
            if lookback_periods is not None and int(lookback_periods) > 0
            else 1
        )
        seg = prices[-window:] if prices else []
        if len(seg) >= 2:
            first, last = seg[0], seg[-1]
            change_pct = ((last - first) / first * 100.0) if first != 0.0 else 0.0
        else:
            change_pct = 0.0

        thr = float(decline_threshold_pct) if decline_threshold_pct is not None else 5.0
        if change_pct < 0.0 and abs(change_pct) >= thr:
            falling = True
        elif change_pct < 0.0:
            falling = False
        else:
            falling = False

        permitted = bool(short_selling_permitted)
        if short_interest_shares:
            shorts = [float(s) for s in short_interest_shares if s is not None]
            bear_shares = shorts[-1]
        elif short_interest_now_shares is not None:
            bear_shares = float(short_interest_now_shares)
        else:
            bear_shares = 0.0
        if not permitted:
            bear_shares = 0.0

        so = float(shares_outstanding) if shares_outstanding else 0.0
        if so > 0.0 and bear_shares > 0.0:
            bear_pct = bear_shares / so * 100.0
        else:
            bear_pct = None

        pct_thr = (
            float(min_uncovered_pct_of_shares)
            if min_uncovered_pct_of_shares is not None
            else 1.0
        )
        abs_thr = float(min_uncovered_shares) if min_uncovered_shares else 0.0
        if bear_pct is not None:
            real_account = bear_pct >= pct_thr
            basis = "%.4f%% of shares outstanding >= %.4f%%" % (bear_pct, pct_thr)
        else:
            real_account = bear_shares > 0.0 and bear_shares >= abs_thr
            basis = "%.1f shares >= %.1f shares" % (bear_shares, abs_thr)

        supported = permitted and real_account

        if not falling:
            verdict = "not_a_falling_market"
            reason = (
                "The market is not falling over the last %d period(s) (change "
                "%.4f%%): no support question arises." % (window, change_pct)
            )
        elif supported:
            verdict = "supported_decline"
            reason = (
                "The decline is cushioned by an uncovered bear account of %.1f "
                "shares (%s): there is no such valuable support for a falling "
                "market, and covering will check the decline."
                % (bear_shares, basis)
            )
        elif not permitted:
            verdict = "unsupported_decline_panic_risk"
            reason = (
                "Short selling is prohibited, so there is no uncovered bear account "
                "at all: nothing but a hastily improvised bankers' combination can "
                "check the devastating decline."
            )
        else:
            verdict = "unsupported_decline_panic_risk"
            reason = (
                "The falling market has no uncovered bear account beneath it (%s "
                "fails the test): it is unsupported pressure, liable to a panic "
                "break at any stage of its progress." % basis
            )

        result = {
            "falling": falling,
            "decline_pct": change_pct,
            "short_selling_permitted": permitted,
            "uncovered_bear_shares": bear_shares,
            "bear_account_pct_of_shares": bear_pct,
            "bear_account_is_real": real_account,
            "supported": supported,
            "verdict": verdict,
        }
        if verbose:
            result["lookback_periods"] = window
            result["decline_threshold_pct"] = thr
            result["min_uncovered_pct_of_shares"] = pct_thr
            result["min_uncovered_shares"] = abs_thr
            result["periods_supplied"] = len(prices)
            result["reason"] = reason
        return json.dumps(
            {
                "result": result,
                "error": None,
                "metadata": {
                    "provenance": {
                        "source_grounded": [
                            "no such valuable support for a falling market as the uncovered bear account",
                            "when it is absent only a hastily improvised bankers' combination can check the decline",
                            "English law prohibits short selling in bank stocks",
                            "unsupported pressure made the Baring crisis of 1890 serious",
                            "without the liberty to sell short a market is liable to an unsupported panic break",
                        ],
                        "model_extrapolated": [
                            "decline threshold of 5.0% defining a falling market",
                            "lookback window of 10 periods",
                            "bear account threshold of 1.0% of shares outstanding",
                            "absolute share fallback when shares outstanding are unknown",
                            "flat/no-decline reading returns not_a_falling_market rather than an error",
                        ],
                    }
                },
            }
        )
    except Exception as exc:
        return json.dumps(
            {
                "result": None,
                "error": str(exc),
                "metadata": {
                    "provenance": {
                        "source_grounded": [
                            "no such valuable support for a falling market as the uncovered bear account",
                            "without short selling a market is liable to an unsupported panic break",
                        ],
                        "model_extrapolated": [
                            "decline threshold of 5.0% defining a falling market",
                            "lookback window of 10 periods",
                        ],
                    }
                },
            }
        )