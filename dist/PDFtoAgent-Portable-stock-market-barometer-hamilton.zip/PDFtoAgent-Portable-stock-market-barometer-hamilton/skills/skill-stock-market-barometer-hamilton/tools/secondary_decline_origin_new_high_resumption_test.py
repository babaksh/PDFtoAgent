import json
import math
from typing import Dict, List, Optional


def _as_float(value, default: float) -> float:
    try:
        if value is None:
            return float(default)
        return float(value)
    except (TypeError, ValueError):
        return float(default)


async def secondary_decline_origin_new_high_resumption_test(
    prices: Optional[List[float]] = None,
    origin_price: Optional[float] = None,
    direction: str = "bull",
    confirming_prices: Optional[List[float]] = None,
    confirming_origin_price: Optional[float] = None,
    verbose: bool = True,
) -> str:
    """Rule whether the primary movement has resumed by testing for a new extreme above (bull) or below (bear) the figure from which the secondary move took its origin.

    Use when a secondary decline (in a bull market) or a secondary rally (in a bear
    market) has run its course and you must decide whether the major movement has
    resumed. The chapter's test is explicit: the averages must make a new top above
    the figure from which that decline took its origin, and such a new top is
    conclusive evidence, on all the chapter's records, that the bull movement had been
    resumed. The converse applies in a bear market after a secondary rally -- a new
    low below the figure from which the rally took its origin.

    Extends: joint_average_turn_confirmation_test (chMANIPULATION AND PROFESSIONAL
    TRADING), which asked whether two averages jointly confirm a turn; this tool names
    the reference level the earlier tool never did -- the origin price of the
    secondary move -- and gives the new top its stated conclusive weight.

    Inputs: `prices` is the average's price path running from the origin of the
    secondary move through the recovery being tested (chronological). `origin_price`
    defaults to the first element of `prices` when omitted. Pass
    `confirming_prices` (and optionally `confirming_origin_price`) to require the
    second average to clear its own origin as well.

    Do NOT use this to decide whether a move was a secondary reaction or only a daily
    fluctuation -- use secondary_vs_daily_movement_duration_bound_test. Do NOT use it
    to date a line in the averages -- use line_timing_relative_to_secondary_break_test.
    """
    try:
        series = [ _as_float(p, float("nan")) for p in (prices or []) ]
        series = [p for p in series if not math.isnan(p)]
        trend = str(direction or "bull").strip().lower()
        is_bear = trend.startswith("bear") or trend in ("down", "decline")
        label = "bear" if is_bear else "bull"

        if not series:
            result = {
                "direction": label,
                "classification": "no_evidence",
                "primary_movement_resumed": False,
                "reason": "no prices were supplied, so no new figure can be tested",
            }
            if verbose:
                result["origin_price"] = None
                result["rule"] = (
                    "a new top above the origin of the secondary decline (or a new low below the "
                    "origin of a secondary rally) is conclusive"
                )
            return json.dumps({
                "result": result,
                "error": None,
                "metadata": {
                    "tool": "secondary_decline_origin_new_high_resumption_test",
                    "provenance": {
                        "source_grounded": [
                            "new top above the figure from which the secondary decline took its origin",
                            "conclusive evidence on all the chapter's records",
                            "converse for a bear market after a secondary rally",
                        ],
                        "model_extrapolated": ["empty input returns a no_evidence reading"],
                    },
                },
            })

        origin = _as_float(origin_price, series[0])

        if is_bear:
            extreme_price = max(series)
            extreme_index = series.index(extreme_price)
        else:
            extreme_price = min(series)
            extreme_index = series.index(extreme_price)

        after = series[extreme_index + 1:]
        if after:
            best_after = max(after) if not is_bear else min(after)
            best_index = extreme_index + 1 + after.index(best_after)
        else:
            best_after = None
            best_index = None

        secondary_move_points = (
            (extreme_price - origin) if is_bear else (origin - extreme_price)
        )
        secondary_move_pct = (
            (secondary_move_points / origin * 100.0) if origin else 0.0
        )

        if best_after is None:
            resumed = False
            beyond = None
            classification = "insufficient_record"
            reason = (
                "the record ends at the %s of the secondary move, so no later figure has been "
                "made to test against the origin" % ("high" if is_bear else "low")
            )
        else:
            beyond = (origin - best_after) if is_bear else (best_after - origin)
            if beyond > 0.0:
                resumed = True
                classification = "resumed"
                reason = (
                    "the average made a new %s of %.2f, %.2f points beyond the origin figure of "
                    "%.2f from which the secondary %s took its origin -- conclusive on the "
                    "chapter's records that the %s movement has been resumed"
                    % (
                        "low" if is_bear else "top",
                        best_after,
                        beyond,
                        origin,
                        "rally" if is_bear else "decline",
                        label,
                    )
                )
            else:
                resumed = False
                classification = "not_resumed"
                reason = (
                    "the best later figure of %.2f still falls %.2f points short of the origin "
                    "figure of %.2f, so the resumption is not established"
                    % (best_after, -beyond, origin)
                )

        result = {
            "direction": label,
            "origin_price": origin,
            "secondary_extreme_price": extreme_price,
            "secondary_extreme_index": extreme_index,
            "secondary_move_points": secondary_move_points,
            "secondary_move_pct": secondary_move_pct,
            "post_extreme_best_price": best_after,
            "post_extreme_best_index": best_index,
            "new_figure_points_beyond_origin": beyond,
            "primary_movement_resumed": resumed,
            "classification": classification,
            "reason": reason,
        }

        confirming_series = [ _as_float(p, float("nan")) for p in (confirming_prices or []) ]
        confirming_series = [p for p in confirming_series if not math.isnan(p)]
        if confirming_series:
            c_origin = _as_float(confirming_origin_price, confirming_series[0])
            c_extreme = max(confirming_series) if is_bear else min(confirming_series)
            c_index = confirming_series.index(c_extreme)
            c_after = confirming_series[c_index + 1:]
            c_best = (min(c_after) if is_bear else max(c_after)) if c_after else None
            c_beyond = (
                (c_origin - c_best) if is_bear else (c_best - c_origin)
            ) if c_best is not None else None
            c_resumed = bool(c_beyond is not None and c_beyond > 0.0)
            result["confirming_average_origin_price"] = c_origin
            result["confirming_average_new_figure_points_beyond_origin"] = c_beyond
            result["confirming_average_resumed"] = c_resumed
            result["averages_confirm_each_other"] = bool(resumed and c_resumed)
            result["primary_movement_resumed"] = bool(resumed and c_resumed)
            if result["primary_movement_resumed"]:
                result["classification"] = "resumed_by_both_averages"
                result["reason"] = (
                    "both averages made a new figure beyond the origin of the secondary move, so "
                    "the resumption is confirmed"
                )
            elif resumed and not c_resumed:
                result["classification"] = "resumed_by_one_average_only"
                result["reason"] = (
                    "only the leading average made a new figure beyond its origin; the second "
                    "average has not confirmed it"
                )

        if verbose:
            result["prices"] = series
            result["rule"] = (
                "a new top above the figure from which the secondary decline took its origin is "
                "conclusive evidence that the bull movement had been resumed; the converse holds "
                "in a bear market after a secondary rally"
            )
            result["thresholds"] = {"origin_price_source": "first price" if origin_price is None else "supplied"}

        return json.dumps({
            "result": result,
            "error": None,
            "metadata": {
                "tool": "secondary_decline_origin_new_high_resumption_test",
                "provenance": {
                    "source_grounded": [
                        "new top above the figure from which the secondary decline took its origin",
                        "conclusive evidence on all the chapter's records",
                        "converse new low in a bear market after a secondary rally",
                        "averages must confirm each other",
                    ],
                    "model_extrapolated": [
                        "origin_price defaults to the first price of the window",
                        "secondary extreme taken as the window extreme (min in bull, max in bear)",
                        "resumption verdict requires both averages when confirming_prices is supplied",
                    ],
                },
            },
        })
    except Exception as exc:  # pragma: no cover - defensive
        return json.dumps({
            "result": None,
            "error": str(exc),
            "metadata": {
                "tool": "secondary_decline_origin_new_high_resumption_test",
                "provenance": {
                    "source_grounded": ["new top above the origin of the secondary decline"],
                    "model_extrapolated": ["default origin price"],
                },
            },
        })