"""Character of the forecast business phase read from the PRECEDING major market swing (1917).

Hamilton: "The business depression of 1908-9, predicted by the bear market of 1907,
was deep rather than long. The period of prosperity of the latter part of 1909 and
1910 was more extended but much shallower; and the market bull movement which
preceded it was also slower and longer than the bear market, while its range was
correspondingly less." The barometer does not predict duration, but it does indicate
the CHARACTER of the boom or depression it forecasts: a steep, wide, SHORT swing
forecasts a deep but brief phase; a slow, narrow, LONG swing forecasts a shallower
but more extended one.

Use when: you have a completed major swing (range in percent, duration in months,
and optionally its price path) and want to know what kind of business phase it
forecasts -- deep but short, or shallow but extended.

Depends on: major_swing_duration_ratio (ch05, "Major Market Swings") -- duration
alone is not enough there; this chapter adds RANGE and SPEED to duration and maps
the three to the character of the forecast phase.

Do NOT use for: dating or confirming the swing itself, and do NOT use for the daily
or secondary movement -- this reads a completed MAJOR swing only.
"""

import json
from typing import List, Optional


def _provenance():
    return {
        "source_grounded": [
            "depression of 1908-9 predicted by the bear market of 1907 was deep rather than long",
            "prosperity of late 1909-1910 was more extended but much shallower",
            "that bull movement was slower and longer than the bear market",
            "its range was correspondingly less",
            "barometer indicates the character, and even the dimensions, of the thing it predicts",
        ],
        "model_extrapolated": [
            "benchmark_range_pct default 25.0 and benchmark_months default 12.0 (the chapter "
            "gives no numeric cutoffs, only the relative comparison of the two examples)",
            "speed measured as range percent per month against the benchmark speed",
            "mixed reading for swings that are not consistently steep-wide-short or slow-narrow-long",
            "flat (zero-range) swing reported as 'no_forecast_signal'",
            "duration derived from an optional period/year index at periods_per_year=12",
        ],
    }


async def forecast_phase_character_from_preceding_swing(
    prices: Optional[List[float]] = None,
    periods: Optional[List[float]] = None,
    swing_range_pct: Optional[float] = None,
    swing_months: Optional[float] = None,
    direction: Optional[str] = None,
    periods_per_year: Optional[float] = 12.0,
    benchmark_range_pct: Optional[float] = 25.0,
    benchmark_months: Optional[float] = 12.0,
    verbose: bool = True,
) -> str:
    """Classify the business phase a completed major swing forecasts: deep-but-short or extended-but-shallow.

    Use when a major (primary) market swing is complete and you want the character of
    the boom or depression the barometer is forecasting. Pass either the swing's price
    path (`prices`, with optional `periods` in decimal years) or its measured
    `swing_range_pct` and `swing_months` directly.

    Do NOT use for the daily or secondary movement, and do NOT use to date or confirm
    the swing -- this tool only reads the character of a swing you have already
    measured.

    Args:
        prices: optional price path of the completed swing (first to last print).
        periods: optional decimal-year (or period) index aligned with `prices`.
        swing_range_pct: absolute percent range of the swing, used when no price path is given.
        swing_months: duration of the swing in months, used when no price path is given.
        direction: "up" or "down"; inferred from `prices` when omitted.
        periods_per_year: units per year in `periods` (12 = decimal years in months).
        benchmark_range_pct: percent range dividing a wide swing from a narrow one.
        benchmark_months: months dividing a long swing from a short one.
        verbose: False returns the compact classification; True adds the measures and reason.
    """
    ppy = 12.0 if periods_per_year is None else float(periods_per_year)
    if ppy == 0.0:
        ppy = 12.0
    bench_range = 25.0 if benchmark_range_pct is None else float(benchmark_range_pct)
    bench_months = 12.0 if benchmark_months is None else float(benchmark_months)
    if bench_months <= 0.0:
        bench_months = 12.0

    range_pct = None if swing_range_pct is None else abs(float(swing_range_pct))
    months = None if swing_months is None else float(swing_months)
    dirn = direction

    if prices:
        vals = [float(p) for p in prices if p is not None]
        if len(vals) >= 2:
            start, end = vals[0], vals[-1]
            if start != 0.0:
                range_pct = abs(end - start) / abs(start) * 100.0
            if dirn is None:
                if end > start:
                    dirn = "up"
                elif end < start:
                    dirn = "down"
                else:
                    dirn = "flat"
            if months is None:
                if periods and len(periods) >= 2:
                    months = abs(float(periods[-1]) - float(periods[0])) * ppy
                else:
                    months = (len(vals) - 1) * (12.0 / ppy)
        elif len(vals) == 1:
            range_pct = 0.0
            months = 0.0 if months is None else months
            if dirn is None:
                dirn = "flat"
    else:
        if range_pct is not None and dirn is None:
            dirn = "flat"

    if range_pct is None or range_pct == 0.0:
        return json.dumps({
            "result": {
                "classification": "no_forecast_signal",
                "depth": "none",
                "extension": "none",
                "reason": "the preceding swing has no range, so it indicates no phase: "
                          "a flat market forecasts nothing",
                "range_pct": range_pct,
                "swing_months": months,
                "direction": dirn or "flat",
            },
            "error": None,
            "metadata": {"provenance": _provenance()},
        })

    if months is None or months <= 0.0:
        months = 0.0
        speed = None
    else:
        speed = range_pct / months

    bench_speed = bench_range / bench_months
    wide = range_pct >= bench_range
    long_swing = months >= bench_months
    fast = (speed is not None) and (speed >= bench_speed)
    if speed is None:
        fast = wide

    if fast and wide and not long_swing:
        classification = "deep_but_short"
        depth = "deep"
        extension = "brief"
        reason = (
            "a steep, wide and short swing (%.2f%% in %.2f months, %.2f%% per month "
            "against a benchmark %.2f%% per month): the forecast phase should be deep "
            "rather than long, as the 1907 bear market foretold the 1908-9 depression"
            % (range_pct, months, speed if speed is not None else 0.0, bench_speed)
        )
    elif (not fast) and (not wide) and long_swing:
        classification = "shallow_but_extended"
        depth = "shallow"
        extension = "extended"
        reason = (
            "a slow, narrow and long swing (%.2f%% in %.2f months, %.2f%% per month "
            "against a benchmark %.2f%% per month): the forecast phase should be "
            "shallower but more extended, as the slow 1909 bull market preceded the "
            "prosperity of late 1909-1910"
            % (range_pct, months, speed if speed is not None else 0.0, bench_speed)
        )
    else:
        classification = "mixed"
        depth = "deep" if wide else "shallow"
        extension = "extended" if long_swing else "brief"
        reason = (
            "the swing is %s but %s and %s relative to the benchmarks (%.2f%% range, "
            "%.2f months), so range, speed and duration do not point the same way; "
            "the chapter's rule reads a clear character only when they agree"
            % (
                "wide" if wide else "narrow",
                "fast" if fast else "slow",
                "long" if long_swing else "short",
                range_pct,
                months,
            )
        )

    result = {
        "classification": classification,
        "depth": depth,
        "extension": extension,
        "range_pct": range_pct,
        "swing_months": months,
        "direction": dirn or "flat",
    }
    if verbose:
        result["speed_pct_per_month"] = speed
        result["benchmark_speed_pct_per_month"] = bench_speed
        result["wide_vs_benchmark"] = wide
        result["long_vs_benchmark"] = long_swing
        result["reason"] = reason
        result["inputs"] = {
            "benchmark_range_pct": bench_range,
            "benchmark_months": bench_months,
            "periods_per_year": ppy,
        }
    return json.dumps({
        "result": result,
        "error": None,
        "metadata": {"provenance": _provenance()},
    })