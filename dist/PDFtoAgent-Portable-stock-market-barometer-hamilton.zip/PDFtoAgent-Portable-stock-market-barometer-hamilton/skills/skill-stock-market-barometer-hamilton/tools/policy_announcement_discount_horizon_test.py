"""Measure how a known public act is discounted in prices: landing lag and foresight horizon."""

import json
import math
from typing import List, Optional


def _clean(values) -> List[float]:
    if not values:
        return []
    out: List[float] = []
    for v in values:
        try:
            f = float(v)
        except (TypeError, ValueError):
            continue
        if math.isnan(f) or math.isinf(f):
            continue
        out.append(f)
    return out


def _finite(v) -> bool:
    return v is not None and not (math.isnan(v) or math.isinf(v))


def _r(v, nd: int = 4):
    return None if not _finite(v) else round(float(v), nd)


def _pct(a: float, b: float):
    """Percent change from b to a; None when the base is zero."""
    if not (_finite(a) and _finite(b)) or b == 0.0:
        return None
    return (a - b) / abs(b) * 100.0


def _dir_label(sign: float) -> str:
    """THREE-WAY sign label: a net-zero expected move has no direction."""
    if sign > 0.0:
        return "up"
    if sign < 0.0:
        return "down"
    return "none"


async def policy_announcement_discount_horizon_test(
    prices: List[float],
    announcement_index: int = 0,
    event_index: int = -1,
    direction: str = "up",
    announcement_late_in_session: bool = True,
    periods_per_year: float = 12.0,
    max_foresight_months: float = 6.0,
    min_anticipation_pct: float = 2.0,
    verbose: bool = True,
) -> str:
    """Measure how a KNOWN PUBLIC ACT is discounted in prices: the lag before the move
    lands, and the foresight horizon over which a foreseen but not yet granted act is
    discounted in advance.

    Use when you have a price series, the session in which an act became publicly known,
    and -- for a foreseen act -- the session at which it was actually granted, and you
    want to know whether and when the market discounted it. Two measurements, both always
    computed from the series you pass in:

      * ANNOUNCEMENT LAG. The chapter's instance: the announcement that the railroads
        would be taken over was made late on the day after Christmas, 1917; "The stock
        market had not time to discount the new ownership on that day, but on the
        following day, December 27th, the average price of the twenty active railroad
        stocks closed at 78.08 -- an advance of no less than 6.41 points from the closing
        prices of the day before." So an announcement made too late in the session lands
        in the NEXT session. The tool measures the same-session move and the next-session
        move and reports where the discounting actually landed (`landing_lag_periods`).

      * FORESIGHT HORIZON. A foreseen but not yet granted act is discounted in advance:
        rate advances "were not granted ... until the following August, but Wall Street
        knew that they must necessarily be advanced, and, as usual, discounted that
        advantage as far ahead as it could see it -- in this case nearly six months." The
        tool walks back from `event_index` to the earliest session from which the
        cumulative move in the expected direction already reaches `min_anticipation_pct`,
        and reports `foresight_periods` and `foresight_months`.

    Extends `manipulation_shock_deflection_test` (chWALL STREET OF THE MOVIES): that tool
    windowed a REACTION AFTER a shock to decide whether manipulation deflected the
    barometer. This one measures the FORESIGHT HORIZON before a foreseen act and the
    one-session landing lag of an after-hours announcement.

    Do NOT use this to decide whether a shock was mere manipulation (call
    manipulation_shock_deflection_test) and do NOT use it to bound how far a guarantied
    stock may advance (call guaranty_value_discount_ceiling_test).

    Args:
        prices: the average or security price series, oldest first.
        announcement_index: position of the session in which the act became publicly known.
        event_index: position of the session at which the foreseen act was actually
            granted; -1 (the default) means the last observation.
        direction: the direction the act should move prices, "up" or "down".
         announcement_late_in_session: True when the announcement came too late in the
            session for the move to land that day (the chapter's case). When True the
            landing test is biased toward the next session: the same session must carry a
            STRICTLY larger move in the expected direction to be credited with the
            discounting.
        periods_per_year: 252 for daily data, 12 for monthly.
        max_foresight_months: the horizon beyond which discounting counts as extraor-
            dinary; the chapter's instance is "nearly six months".
        min_anticipation_pct: cumulative move in the expected direction, in percent, that
            must accumulate before the act for it to count as discounted in advance.
        verbose: False returns the two measurements and the verdict; True adds the series
            and the intermediate moves.

    Returns:
        JSON {"result": ..., "error": None, "metadata": {...}}.
    """
    try:
        ppy = 12.0 if periods_per_year is None else float(periods_per_year)
        if ppy <= 0.0:
            ppy = 12.0
        max_months = 6.0 if max_foresight_months is None else float(max_foresight_months)
        min_pct = 2.0 if min_anticipation_pct is None else float(min_anticipation_pct)
        try:
            ann = int(announcement_index)
        except (TypeError, ValueError):
            ann = 0
        try:
            ev = int(event_index)
        except (TypeError, ValueError):
            ev = -1
        late = bool(announcement_late_in_session)
        d = str(direction).strip().lower() if direction is not None else "up"
        # THREE-WAY resolution: "down" -> -1, "up" -> +1, anything else -> 0 (no direction).
        if d == "down":
            sign = -1.0
        elif d == "up":
            sign = 1.0
        else:
            sign = 0.0

        p = _clean(prices)
        n = len(p)
        # A series with zero net change -- or no observations at all -- has NO
        # direction, whatever the caller requested.
        if n == 0 or max(p) == min(p):
            sign = 0.0
        if n < 2:
            result = {
                "classification": "insufficient_data",
                "landing_classification": "no_discounting_measured",
                "landing_lag_periods": None,
                "lands_next_session": False,
                "foresight_periods": None,
                "foresight_months": None,
                "discounted_in_advance": False,
                "direction": _dir_label(sign),
                "reason": ("At least two price observations are needed to measure either "
                           "the landing lag or the foresight horizon."),
                "observations": n,
            }
            return json.dumps({
                "result": result,
                "error": None,
                "metadata": {
                    "provenance": {
                        "source_grounded": [
                            "the stock market had not time to discount the new ownership on that day",
                            "discounted that advantage as far ahead as it could see it--in this case nearly six months",
                        ],
                        "model_extrapolated": ["insufficient-data boundary reading below 2 observations"],
                    }
                },
            })

        if ev < 0 or ev > n - 1:
            ev = n - 1
        if ann < 0:
            ann = 0
        if ann > n - 1:
            ann = n - 1

        # ---- 1. where the announcement's discounting landed.
        same_session_move = _pct(p[ann], p[ann - 1]) if ann - 1 >= 0 else None
        next_session_move = _pct(p[ann + 1], p[ann]) if ann + 1 <= n - 1 else None

        def _toward(move):
            if move is None:
                return None
            return sign * move

        same_score = _toward(same_session_move)
        next_score = _toward(next_session_move)

        # `announcement_late_in_session` decides the landing test. When the act became
        # known too late in the day there was "not time to discount" it that session, so
        # the same session is credited only if it carries a STRICTLY larger move in the
        # expected direction; when the announcement had the whole session ahead of it, a
        # tie goes to the announcement session itself. Positive move required either way:
        # a zero move is no discounting, not a landing.
        if late:
            landed_next = next_score is not None and (same_score is None or next_score >= same_score)
            landed_same = not landed_next and same_score is not None
        else:
            landed_same = same_score is not None and (next_score is None or same_score >= next_score)
            landed_next = not landed_same and next_score is not None

        if landed_next:
            best_score = next_score
        elif landed_same:
            best_score = same_score
        else:
            best_score = None

        if best_score is not None and best_score > 0.0:
            landing_lag_periods = 1 if landed_next else 0
        else:
            landing_lag_periods = None

        landing_index = None if landing_lag_periods is None else ann + landing_lag_periods
        landing_move = (same_session_move if landing_lag_periods == 0
                        else (next_session_move if landing_lag_periods == 1 else None))

        if landing_lag_periods is None:
            landing_classification = "no_discounting_measured"
        elif landing_lag_periods == 1:
            landing_classification = "lands_next_session"
        else:
            landing_classification = "lands_same_session"

        # ---- 2. foresight horizon: walk back from the event.
        foresight_periods = None
        start_index = None
        anticipation_pct = None
        for j in range(ev - 1, -1, -1):
            if sign == 0.0 or p[j] == 0.0:
                continue
            move = (p[ev] - p[j]) / abs(p[j]) * 100.0
            if sign * move >= min_pct:
                start_index = j
                foresight_periods = ev - j
                anticipation_pct = move
            else:
                break
        # walk back is cumulative from each candidate start; keep the earliest that qualifies
        if start_index is not None:
            anticipation_pct = ((p[ev] - p[start_index]) / abs(p[start_index]) * 100.0
                                if p[start_index] != 0.0 else None)
        foresight_months = (foresight_periods * 12.0 / ppy) if foresight_periods else 0.0

        discounted_in_advance = bool(foresight_periods is not None and foresight_periods > 0)
        beyond = bool(foresight_months is not None and foresight_months > max_months)

        if discounted_in_advance and beyond:
            classification = "discounted_beyond_stated_horizon"
        elif discounted_in_advance:
            classification = "discounted_in_advance"
        else:
            classification = "not_discounted_in_advance"

        parts = []
        if landing_lag_periods is None:
            parts.append("no move at or after the announcement session could be measured")
        else:
            parts.append("the discounting landed "
                         + ("in the NEXT session" if landing_lag_periods == 1
                            else "in the announcement session itself")
                         + " (" + format(abs(landing_move or 0.0), ".2f") + "% move)")
            if late and landing_lag_periods == 1:
                parts.append("as expected, the announcement came too late in the session "
                             "for the market to discount it that day")
            elif late and landing_lag_periods == 0:
                parts.append("although the announcement was late in the session, the move "
                             "landed the same day")
        if discounted_in_advance:
            parts.append("the act was discounted " + format(foresight_months, ".1f")
                         + " months (" + str(foresight_periods)
                         + " periods) before it was granted, a cumulative "
                         + format(abs(anticipation_pct or 0.0), ".2f") + "% move in the "
                         "expected direction, against a stated horizon of "
                         + format(max_months, ".1f") + " months")
        else:
            parts.append("no cumulative move of " + format(min_pct, ".2f")
                         + "% in the expected direction accumulated before the act, so it "
                           "was not discounted in advance")
        reason = "; ".join(parts).capitalize() + "."

        result = {
            "classification": classification,
            "landing_classification": landing_classification,
            "landing_lag_periods": landing_lag_periods,
            "landing_index": landing_index,
            "lands_next_session": bool(landing_lag_periods == 1),
            "same_session_move_pct": _r(same_session_move),
            "next_session_move_pct": _r(next_session_move),
            "landing_move_pct": _r(landing_move),
            "announcement_index": ann,
            "announcement_late_in_session": late,
            "foresight_periods": foresight_periods,
            "foresight_months": _r(foresight_months, 4),
            "anticipation_pct": _r(anticipation_pct),
            "discounted_in_advance": discounted_in_advance,
            "beyond_stated_horizon": beyond,
            "max_foresight_months": max_months,
            "min_anticipation_pct": min_pct,
            "event_index": ev,
            "direction": _dir_label(sign),
            "reason": reason,
            "observations": n,
        }

        if verbose:
            result["detail"] = {
                "prices": [round(v, 4) for v in p],
                "periods_per_year": ppy,
                "rule_quote": ("The stock market had not time to discount the new ownership "
                               "on that day, but on the following day, December 27th, the "
                               "average price of the twenty active railroad stocks closed at "
                               "78.08--an advance of no less than 6.41 points from the "
                               "closing prices of the day before."),
            }

        return json.dumps({
            "result": result,
            "error": None,
            "metadata": {
                "provenance": {
                    "source_grounded": [
                        "the stock market had not time to discount the new ownership on that day",
                        "on the following day, December 27th, the average closed at 78.08, an advance of 6.41 points",
                        "Wall Street knew that rates must necessarily be advanced, and discounted that advantage as far ahead as it could see it--in this case nearly six months",
                    ],
                    "model_extrapolated": [
                        "landing lag decided by which of the announcement session or the next session carries the strictly larger move in the expected direction, with a tie going to the next session when announcement_late_in_session is True",
                        "foresight horizon measured as the earliest start from which a cumulative move of >= 2.0% in the expected direction reaches the event",
                        "max_foresight_months default of 6.0 (chapter's instance: nearly six months)",
                        "periods_per_year default of 12 (monthly average)",
                        "indices clamped into the series, event_index -1 resolved to the last observation",
                    ],
                }
            },
        })
    except Exception as exc:
        return json.dumps({
            "result": {
                "classification": "insufficient_data",
                "landing_lag_periods": None,
                "foresight_periods": None,
                "discounted_in_advance": False,
                "reason": "Could not measure the discounting of the act: " + str(exc),
            },
            "error": None,
            "metadata": {
                "provenance": {
                    "source_grounded": [
                        "the stock market had not time to discount the new ownership on that day",
                    ],
                    "model_extrapolated": ["boundary reading on unusable input"],
                }
            },
        })