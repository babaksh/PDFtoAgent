"""Standing-rule screen: may the small speculator trade this stock on margin at all?"""

import json
import math
from typing import Optional

_PROVENANCE = {
    "source_grounded": [
        "standing rule: in such a stock the small speculator should not trade on margin at all",
        "disqualifier: no permanent market has been created",
        "disqualifier: a new flotation",
        "disqualifier: notoriously, by majority holdings, in control of the people who dictate the policies of the corporation",
        "counsel of perfection: take only a small risk and buy only what he can in some way finance himself",
        "exception: only where the nature of the speculator's own business gives him access to special information should he embark his money in stocks of such a character",
        "and even then his margin should be of the most ample kind",
        "such stocks are good to let alone",
        "by the time a stock is listed on the Stock Exchange there is generally a dependable market",
    ],
    "model_extrapolated": [
        "majority-holdings cut-off of 50 per cent of shares outstanding",
        "permanent-market test: at least 80 per cent of sessions traded",
        "new-flotation cut-off of 12 months of listing history",
        "ample-margin cut-off of 50 per cent margin for the special-information exception",
        "self-financing test against the speculator's own capital",
    ],
}


def _num(value, default):
    if value is None:
        return float(default)
    try:
        out = float(value)
    except (TypeError, ValueError):
        return float(default)
    if math.isnan(out) or math.isinf(out):
        return float(default)
    return out


async def speculative_stock_marketability_margin_screen(
    shares_outstanding: float,
    number_of_holders: float = 0.0,
    largest_group_shares: float = 0.0,
    traded_sessions: Optional[float] = None,
    total_sessions: Optional[float] = None,
    months_listed: Optional[float] = None,
    listed_on_exchange: bool = False,
    special_information_from_own_business: bool = False,
    position_shares: float = 0.0,
    price_per_share: float = 0.0,
    own_capital: float = 0.0,
    margin_pct: float = 0.0,
    majority_share_threshold_pct: float = 50.0,
    min_traded_session_share_pct: float = 80.0,
    new_flotation_months: float = 12.0,
    ample_margin_pct: float = 50.0,
    verbose: bool = True,
) -> str:
    """Screen a stock against the chapter's standing rule and say whether the small
    speculator may trade it on margin at all.

    Use BEFORE opening a margin position in a particular stock, when you have the
    ownership distribution (shares outstanding, number of holders, the largest
    concentrated holding), how often the stock actually trades, and how long it has
    been listed. The chapter states the rule as a counsel of perfection: in a stock
    for which no permanent market has been created -- a new flotation, or one which
    is still, by majority holdings, in control of the people who dictate the policies
    of the corporation -- the small speculator should not trade on margin at all.
    Where the nature of his own business gives him special information, he may
    embark, but even then his margin must be of the most ample kind.

    Extends: ownership_distribution_real_market_test (chWATER IN THE BAROMETER),
    which only decides whether a quoted price is a real market price from the
    distribution. This tool adds the margin-eligibility decision itself (do not
    trade on margin at all / take only a small self-financed risk), the
    new-flotation and no-permanent-market conditions, and the special-information
    exception with an ample margin.

    Do NOT use it for a stock that is active and well distributed but merely liable
    to go quiet once its special circumstances are discounted -- that is
    inactive_stock_margin_carry_exclusion. Do NOT use it to size the lot once the
    stock passes -- call margin_capital_loss_exposure_test.

    Returns a classification (one of four) plus the reasons, and the stated
    consequence.
    """
    shares_out = max(_num(shares_outstanding, 0.0), 0.0)
    holders = max(_num(number_of_holders, 0.0), 0.0)
    largest = max(_num(largest_group_shares, 0.0), 0.0)
    months = None if months_listed is None else max(_num(months_listed, 0.0), 0.0)
    pos = max(_num(position_shares, 0.0), 0.0)
    price = max(_num(price_per_share, 0.0), 0.0)
    capital = max(_num(own_capital, 0.0), 0.0)
    margin = max(_num(margin_pct, 0.0), 0.0)
    maj_cut = max(_num(majority_share_threshold_pct, 50.0), 0.0)
    session_cut = max(_num(min_traded_session_share_pct, 80.0), 0.0)
    flotation_cut = max(_num(new_flotation_months, 12.0), 0.0)
    ample_cut = max(_num(ample_margin_pct, 50.0), 0.0)

    control_share_pct = (100.0 * largest / shares_out) if shares_out > 0 else None
    avg_shares_per_holder = (shares_out / holders) if holders > 0 else None

    traded_share_pct = None
    if traded_sessions is not None and total_sessions is not None:
        ts = max(_num(traded_sessions, 0.0), 0.0)
        tt = max(_num(total_sessions, 0.0), 0.0)
        if tt > 0:
            traded_share_pct = 100.0 * ts / tt

    # 1. majority holdings in control of the policy-makers
    majority_control = bool(
        control_share_pct is not None and control_share_pct >= maj_cut
    )

    # 2. no permanent market: too thin a record of actual trading
    no_permanent_market = bool(
        traded_share_pct is not None and traded_share_pct < session_cut
    )

    # 3. a new flotation
    is_new_flotation = bool(months is not None and months < flotation_cut)

    conditions = []
    if majority_control:
        conditions.append("majority_holdings_in_control")
    if no_permanent_market:
        conditions.append("no_permanent_market")
    if is_new_flotation:
        conditions.append("new_flotation")

    if majority_control or no_permanent_market or is_new_flotation:
        if special_information_from_own_business:
            margin_ample = margin >= ample_cut
            self_financed = True if capital <= 0 else (pos * price <= capital)
            if margin_ample:
                classification = "special_information_exception_ample_margin"
                action = (
                    "Embark only on the strength of your own business's special information, "
                    "and only with an ample margin (%.4g%% posted, at or above the %.4g%% "
                    "required)." % (margin, ample_cut)
                )
                margin_allowed = True
            else:
                classification = "special_information_but_margin_not_ample"
                action = (
                    "Do not trade on margin. Dow's rule for the informed insider is that even "
                    "then his margin should be of the most ample kind; %.4g%% is below the "
                    "%.4g%% required." % (margin, ample_cut)
                )
                margin_allowed = False
            reason = (
                "The stock fails the standing rule on: %s. Only where the nature of the "
                "speculator's own business gives him access to special information should he "
                "embark his money in a stock of such a character."
                % ", ".join(conditions)
            )
        else:
            margin_ample = None
            self_financed = True if capital <= 0 else (pos * price <= capital)
            classification = "no_margin_at_all"
            action = (
                "Do not trade on margin at all. As a counsel of perfection, take only a small "
                "risk and buy only what you can in some way finance yourself%s."
                % ("" if self_financed else "; at %.4g shares by %.4g the position is more than your own capital of %.4g" % (pos, price, capital))
            )
            reason = (
                "The stock fails the standing rule on: %s. Such stocks are good to let alone."
                % ", ".join(conditions)
            )
            margin_allowed = False
    else:
        margin_ample = margin >= ample_cut
        self_financed = True if capital <= 0 else (pos * price <= capital)
        classification = "margin_permissible"
        action = (
            "A dependable market exists in the stock%s; the standing rule does not bar a "
            "margin purchase here."
            % ("" if not listed_on_exchange else " and it is listed on the Stock Exchange")
        )
        reason = (
            "No disqualifying condition holds: control holdings are %.4g%% of shares "
            "outstanding (below %.4g%%), the stock traded in %.4g%% of sessions (at or above "
            "%.4g%%) and it has been listed %.4g months (at or above %.4g)."
            % (
                control_share_pct if control_share_pct is not None else 0.0,
                maj_cut,
                traded_share_pct if traded_share_pct is not None else 100.0,
                session_cut,
                months if months is not None else flotation_cut,
                flotation_cut,
            )
        )
        margin_allowed = True

    result = {
        "classification": classification,
        "margin_allowed": margin_allowed,
        "conditions_met": conditions,
        "majority_control": majority_control,
        "control_share_pct": control_share_pct,
        "no_permanent_market": no_permanent_market,
        "traded_session_share_pct": traded_share_pct,
        "new_flotation": is_new_flotation,
        "months_listed": months,
        "margin_pct": margin,
        "ample_margin_required_pct": ample_cut,
        "self_financed": self_financed,
        "action": action,
    }

    if verbose:
        result["average_shares_per_holder"] = avg_shares_per_holder
        result["special_information_from_own_business"] = bool(special_information_from_own_business)
        result["listed_on_exchange"] = bool(listed_on_exchange)
        result["thresholds"] = {
            "majority_share_threshold_pct": maj_cut,
            "min_traded_session_share_pct": session_cut,
            "new_flotation_months": flotation_cut,
        }
        result["reason"] = reason

    return json.dumps({"result": result, "error": None, "metadata": {"provenance": _PROVENANCE}})