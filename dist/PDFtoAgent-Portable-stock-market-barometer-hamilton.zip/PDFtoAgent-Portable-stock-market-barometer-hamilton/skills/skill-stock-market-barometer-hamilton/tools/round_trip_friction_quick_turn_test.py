import json
from typing import Optional


async def round_trip_friction_quick_turn_test(
    expected_move_points: float,
    price: float,
    is_floor_trader: bool = False,
    expected_move_pct: Optional[float] = None,
    commission_pct_each_way: float = 0.125,
    market_turn_pct: float = 0.25,
    floor_trader_turn_saved_pct: float = 100.0,
    required_edge_pct: float = 0.0,
    verbose: bool = True,
) -> str:
    """Decide whether a quick turn is worth attempting by comparing the expected move against the round-trip friction of a legal eighth per cent commission each way plus the market turn -- which the floor trader escapes and the outsider does not.

    Use when someone is considering snatching a turn of a point or so: give the
    expected move (in points) and the price, and say whether the trader is a
    floor trader (a member who pays himself no commission and can save the
    turn, or part of it, for himself) or an outsider (who pays a broker's
    commission of a legal eighth per cent each way and also pays the market
    turn of a quarter per cent). The chapter's verdict is that the floor trader
    can afford to trade for the quick turn where the outsider cannot: the
    outsider is betting heavy odds on an even-money chance.

    Do NOT use this to work out what price an order will actually get -- call
    market_turn_effective_execution_price for that -- and do NOT use it to
    judge a multi-day or position trade, where the chapter says commissions and
    the turn do not amount to much against a value buyer with ample margin.

    Args:
        expected_move_points: the move hoped for, in price points (the chapter's
            quick turn is "a point or so").
        price: current price of the stock, used to convert points to percent.
        is_floor_trader: True for a member trading for himself (no commission,
            saves the turn); False for the outside customer.
        expected_move_pct: optional -- give the expected move directly in
            percent instead of in points.
        commission_pct_each_way: broker's commission, per cent, each way
            (default 0.125, the chapter's "legal eighth per cent").
        market_turn_pct: the bid/asked turn, per cent (default 0.25, the
            chapter's quarter of one per cent average).
        floor_trader_turn_saved_pct: share of the turn the floor trader saves
            for himself (default 100.0 = he deals at the middle; 0.0 = he pays
            the full turn like an outsider).
        required_edge_pct: margin by which the net move must exceed friction
            before the turn is worth attempting (default 0.0 = any positive
            net edge counts).
        verbose: False returns the compact ruling; True adds the full breakdown.

    Returns:
        JSON string with result/error/metadata. Result holds the gross move,
        the round-trip friction, the net edge, the odds against and the verdict
        -- "worth_attempting", "break_even" or "not_worth_attempting".
    """
    try:
        px = float(price) if price is not None else 0.0
        move_pts = float(expected_move_points) if expected_move_points is not None else 0.0
        if expected_move_pct is not None:
            gross_pct = float(expected_move_pct)
            if px > 0.0:
                move_pts = gross_pct / 100.0 * px
        else:
            gross_pct = (move_pts / px * 100.0) if px > 0.0 else 0.0

        comm_each = float(commission_pct_each_way) if commission_pct_each_way is not None else 0.125
        turn = float(market_turn_pct) if market_turn_pct is not None else 0.25
        floor = bool(is_floor_trader)

        if floor:
            saved = float(floor_trader_turn_saved_pct) if floor_trader_turn_saved_pct is not None else 100.0
            saved = max(0.0, min(100.0, saved))
            commission_pct = 0.0
            turn_paid_pct = turn * (1.0 - saved / 100.0)
        else:
            commission_pct = 2.0 * comm_each
            turn_paid_pct = turn

        friction_pct = commission_pct + turn_paid_pct
        net_pct = abs(gross_pct) - friction_pct
        edge = float(required_edge_pct) if required_edge_pct is not None else 0.0

        if net_pct > edge:
            verdict = "worth_attempting"
            if floor:
                reason = (
                    "Floor trader: pays himself no commission and saves %.1f%% of the "
                    "turn, so friction is only %.4f%% against a %.4f%% move -- he can "
                    "afford the quick turn."
                    % (0.0 if not floor else float(floor_trader_turn_saved_pct or 100.0), friction_pct, abs(gross_pct))
                )
            else:
                reason = (
                    "Outsider: net edge of %.4f%% after %.4f%% friction exceeds the "
                    "%.4f%% required edge." % (net_pct, friction_pct, edge)
                )
        elif net_pct == edge:
            verdict = "break_even"
            reason = (
                "The expected move of %.4f%% exactly equals the round-trip friction "
                "of %.4f%% plus the %.4f%% required edge: no edge either way."
                % (abs(gross_pct), friction_pct, edge)
            )
        else:
            verdict = "not_worth_attempting"
            if floor:
                reason = (
                    "Even the floor trader's reduced friction of %.4f%% exceeds the "
                    "expected move of %.4f%%." % (friction_pct, abs(gross_pct))
                )
            else:
                reason = (
                    "Outsider: commission of an eighth per cent each way (%.4f%%) with "
                    "the market turn of a quarter per cent (%.4f%%) is %.4f%% of "
                    "friction against a %.4f%% move -- betting heavy odds on an "
                    "even-money chance."
                    % (commission_pct, turn_paid_pct, friction_pct, abs(gross_pct))
                )

        odds_against = (friction_pct / abs(gross_pct)) if abs(gross_pct) > 0.0 else None

        result = {
            "trader": "floor_trader" if floor else "outsider",
            "gross_move_pct": abs(gross_pct),
            "round_trip_friction_pct": friction_pct,
            "net_edge_pct": net_pct,
            "verdict": verdict,
        }
        if verbose:
            result["expected_move_points"] = move_pts
            result["price"] = px
            result["commission_round_trip_pct"] = commission_pct
            result["market_turn_paid_pct"] = turn_paid_pct
            result["required_edge_pct"] = edge
            result["odds_friction_to_move"] = odds_against
            result["reason"] = reason
        return json.dumps(
            {
                "result": result,
                "error": None,
                "metadata": {
                    "provenance": {
                        "source_grounded": [
                            "commission of a legal eighth per cent each way",
                            "market turn of a quarter per cent",
                            "the quick turn snatched is a point or so",
                            "floor trader pays himself no commission and can save the turn or part of it",
                            "outsider bets heavy odds on an even-money chance",
                        ],
                        "model_extrapolated": [
                            "required edge of 0.0% above friction before attempting",
                            "floor trader credited with 100% of the turn saved by default",
                            "percent basis for expressing the expected turn",
                            "break_even reading when net edge equals friction exactly",
                            "price fallback of 0.0 when price is None",
                        ],
                    }
                },
            }
        )
    except Exception as exc:
        return json.dumps(
            {
                "result": None,
                "error": str(exc),
                "metadata": {
                    "provenance": {
                        "source_grounded": [
                            "commission of a legal eighth per cent each way",
                            "market turn of a quarter per cent",
                        ],
                        "model_extrapolated": [
                            "required edge of 0.0% above friction before attempting",
                            "floor trader credited with 100% of the turn saved by default",
                        ],
                    }
                },
            }
        )