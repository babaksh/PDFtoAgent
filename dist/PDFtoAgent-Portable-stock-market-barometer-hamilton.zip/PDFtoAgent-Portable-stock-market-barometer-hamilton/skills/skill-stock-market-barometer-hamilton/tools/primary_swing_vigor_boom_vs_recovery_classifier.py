import json
from typing import List, Optional


async def primary_swing_vigor_boom_vs_recovery_classifier(
    primary_points_industrials: Optional[float] = None,
    primary_points_railroads: Optional[float] = None,
    secondary_points_industrials: Optional[List[float]] = None,
    secondary_points_railroads: Optional[List[float]] = None,
    vigor_threshold: Optional[float] = None,
    average_agreement_floor: Optional[float] = None,
    verbose: bool = True,
) -> str:
    """Classify a primary advance as forecasting a business BOOM or only a slow
    conservative recovery, from the vigor of the secondary movements inside it.

    Use when you have a completed-or-running primary (major) advance measured in
    POINTS in the industrials and in the railroads, together with the point size
    of the secondary reactions/rallies that occurred inside that advance, and you
    want the barometer's business verdict: a boom in business, or a conservative
    recovery that comes slowly, takes more than the usual time to establish
    itself, and will not carry prices to new high records.

    Rule (chapter): "In a strong primary swing the secondary movement is
    correspondingly vigorous." The tool therefore scores the CURRENT swing's own
    vigor (mean secondary extent / primary extent) in each average, and adds the
    two-average magnitude check -- the railroads must have travelled at least
    `average_agreement_floor` (default two-thirds) of the industrials' advance,
    as they did in the April 1922 advance of twenty-nine points industrials and
    rather more than two-thirds as much in the railroads.

    Extends: forecast_phase_character_from_preceding_swing (chITS GREATEST
    VINDICATION-1917) -- that tool scores the business phase forecast by a
    PRECEDING completed swing; this one scores the current swing's own secondary
    vigor and adds the two-average magnitude check plus the no-new-high-records
    verdict.

    Do NOT use for: classifying the DIRECTION of a swing (that is a
    bull/bear determination), for daily-fluctuation noise, or for comparing two
    separate eras' swings -- use major_swing_amplitude_dwindling_test for that.

    Args:
        primary_points_industrials: point extent of the primary advance in the
            industrial average (positive number).
        primary_points_railroads: point extent of the same advance in the rail
            average.
        secondary_points_industrials: point extents of the secondary movements
            inside that advance, industrials.
        secondary_points_railroads: same for the rails; omit (None) if only the
            industrial secondaries are recorded -- the vigor test then rests on
            the industrials alone and a boom cannot be confirmed by both
            averages.
        vigor_threshold: fraction of the primary advance a mean secondary
            movement must cover to count as vigorous (default 0.33).
        average_agreement_floor: minimum rails/industrials extent ratio for the
            two averages to agree in magnitude (default 0.66).
        verbose: False returns the compact verdict and the key ratios only.

    Returns:
        JSON string with keys result/error/metadata.
    """
    try:
        prim_ind = abs(0.0 if primary_points_industrials is None else float(primary_points_industrials))
        prim_rail = abs(0.0 if primary_points_railroads is None else float(primary_points_railroads))
        vigor_threshold = 0.33 if vigor_threshold is None else float(vigor_threshold)
        agreement_floor = 0.66 if average_agreement_floor is None else float(average_agreement_floor)

        sec_ind = [abs(float(v)) for v in (secondary_points_industrials or [])]
        sec_rail = None if secondary_points_railroads is None else [
            abs(float(v)) for v in (secondary_points_railroads or [])
        ]

        mean_sec_ind = (sum(sec_ind) / len(sec_ind)) if sec_ind else 0.0
        mean_sec_rail = None
        if sec_rail is not None:
            mean_sec_rail = (sum(sec_rail) / len(sec_rail)) if sec_rail else 0.0

        if prim_ind > 0:
            vigor_ind = mean_sec_ind / prim_ind
        else:
            vigor_ind = 0.0
        if sec_rail is None:
            vigor_rail = None
        elif prim_rail > 0:
            vigor_rail = (mean_sec_rail or 0.0) / prim_rail
        else:
            vigor_rail = 0.0

        if prim_ind > 0:
            rails_share = prim_rail / prim_ind
        else:
            rails_share = 0.0 if prim_rail == 0 else None

        rails_confirm = bool(rails_share is not None and rails_share >= agreement_floor)

        if vigor_rail is None:
            vigor_confirmed = bool(vigor_ind >= vigor_threshold)
            basis = "industrials_only"
        else:
            vigor_confirmed = bool(vigor_ind >= vigor_threshold and vigor_rail >= vigor_threshold)
            basis = "both_averages"

        if prim_ind <= 0 and prim_rail <= 0:
            classification = "no_primary_movement"
            reason = (
                "No primary advance was recorded in either average; there is no "
                "swing whose vigor can be scored, so the barometer says nothing "
                "about a boom or a recovery."
            )
        elif not vigor_confirmed and not rails_confirm:
            classification = "conservative_recovery_no_new_high_records"
            reason = (
                "The secondary movements lack virility in a swing the railroads "
                "have not matched in magnitude; the barometer forecasts some "
                "recovery, but slow, taking more than the usual time to "
                "establish itself, and not carrying prices to new high records."
            )
        elif not vigor_confirmed and rails_confirm:
            classification = "conservative_recovery_no_new_high_records"
            reason = (
                "The two averages agree in magnitude, but the secondary "
                "movements inside the primary advance are not correspondingly "
                "vigorous; the forecast is of a conservative recovery that will "
                "come slowly rather than a boom in business."
            )
        elif vigor_confirmed and not rails_confirm:
            classification = "conservative_recovery_rails_lag"
            reason = (
                "The secondary movements are vigorous, but the rail average has "
                "not travelled the required share of the industrial advance; the "
                "advance is not confirmed by both averages, so the forecast "
                "stops short of a boom."
            )
        else:
            classification = "boom_in_business"
            reason = (
                "Vigorous secondary movements in a primary advance confirmed by "
                "both averages: the barometer is prophetic of a boom in business."
            )

        result = {
            "classification": classification,
            "reason": reason,
            "boom_forecast": classification == "boom_in_business",
            "primary_points_industrials": prim_ind,
            "primary_points_railroads": prim_rail,
            "rails_share_of_industrials": rails_share,
            "vigor_industrials": vigor_ind,
            "vigor_railroads": vigor_rail,
            "vigor_threshold": vigor_threshold,
            "vigor_confirmed": vigor_confirmed,
            "rails_confirm": rails_confirm,
            "vigor_check_basis": basis,
        }
        if verbose:
            result["secondary_mean_industrials"] = mean_sec_ind
            result["secondary_mean_railroads"] = mean_sec_rail
            result["secondary_count_industrials"] = len(sec_ind)
            result["secondary_count_railroads"] = 0 if sec_rail is None else len(sec_rail)
            result["average_agreement_floor"] = agreement_floor
        else:
            result = {
                k: result[k]
                for k in (
                    "classification",
                    "reason",
                    "boom_forecast",
                    "rails_share_of_industrials",
                    "vigor_industrials",
                    "vigor_railroads",
                    "vigor_confirmed",
                    "rails_confirm",
                )
            }

        return json.dumps({
            "result": result,
            "error": None,
            "metadata": {"provenance": {
                "source_grounded": [
                    "in a strong primary swing the secondary movement is correspondingly vigorous",
                    "April 1922 advance: 29 points industrials, rather more than two-thirds as much rails",
                    "verdict pair: boom in business vs conservative recovery",
                    "recovery slow and more than usual time to establish itself",
                    "bull market which will not carry prices to new high records",
                ],
                "model_extrapolated": [
                    "vigor_threshold default 0.33 (fraction of the primary advance a mean secondary must cover)",
                    "average_agreement_floor default 0.66 (two-thirds rail confirmation)",
                    "mean of the absolute secondary extents as the vigor statistic",
                    "rails vigor omitted -> single-average basis cannot confirm a boom",
                    "flat/zero primary advance reported as no_primary_movement",
                ],
            }},
        })
    except Exception as exc:  # pragma: no cover - defensive
        return json.dumps({
            "result": None,
            "error": "primary_swing_vigor_boom_vs_recovery_classifier failed: %s" % exc,
            "metadata": {"provenance": {
                "source_grounded": [],
                "model_extrapolated": ["defensive error wrapper"],
            }},
        })