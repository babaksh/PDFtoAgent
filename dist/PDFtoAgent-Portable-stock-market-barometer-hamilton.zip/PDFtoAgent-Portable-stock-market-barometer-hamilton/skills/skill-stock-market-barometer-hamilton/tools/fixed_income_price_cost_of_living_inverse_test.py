"""Test the chapter's layman's rule: fixed-income price is inverse to the cost of living."""

import json
import math
from typing import List, Optional


def _clean(values) -> List[float]:
    if not values:
        return []
    out: List[float] = []
    for v in values:
        try:
            f = float(v)
        except (TypeError, ValueError):
            continue
        if math.isnan(f) or math.isinf(f):
            continue
        out.append(f)
    return out


def _finite(v) -> bool:
    return v is not None and not (math.isnan(v) or math.isinf(v))


def _mean(xs: List[float]):
    return sum(xs) / len(xs) if xs else None


def _std(xs: List[float]):
    if len(xs) < 2:
        return None
    m = _mean(xs)
    var = sum((x - m) ** 2 for x in xs) / (len(xs) - 1)
    return math.sqrt(var) if var > 0.0 else 0.0


def _correlation(a: List[float], b: List[float]):
    n = min(len(a), len(b))
    if n < 3:
        return None
    x = a[:n]
    y = b[:n]
    mx = _mean(x)
    my = _mean(y)
    sx = _std(x)
    sy = _std(y)
    if sx is None or sy is None or sx == 0.0 or sy == 0.0:
        return None
    cov = sum((x[i] - mx) * (y[i] - my) for i in range(n)) / (n - 1)
    return cov / (sx * sy)


def _inverse_step_agreement(a: List[float], b: List[float]):
    """Share of period-steps in which the two series move in OPPOSITE directions."""
    n = min(len(a), len(b))
    if n < 2:
        return None, 0
    opposite = 0
    counted = 0
    for i in range(1, n):
        da = a[i] - a[i - 1]
        db = b[i] - b[i - 1]
        if not (_finite(da) and _finite(db)):
            continue
        if da == 0.0 or db == 0.0:
            continue
        counted += 1
        if (da > 0 and db < 0) or (da < 0 and db > 0):
            opposite += 1
    if counted == 0:
        return None, 0
    return opposite / counted, counted


def _pct_change(series: List[float]):
    if len(series) < 2 or series[0] == 0.0:
        return None
    return (series[-1] - series[0]) / abs(series[0]) * 100.0


def _r(v, nd: int = 6):
    return None if not _finite(v) else round(float(v), nd)


async def fixed_income_price_cost_of_living_inverse_test(
    prices: List[float],
    cost_of_living: List[float],
    income_per_share: Optional[List[float]] = None,
    min_inverse_agreement: float = 0.6,
    verbose: bool = True,
) -> str:
    """Test the chapter's layman's rule on a fixed-income security: its price stands in
    INVERSE ratio to the cost of living, and its apparent yield measured in dollars rises
    as the price falls.

    Use when you have a bond or bond-like price series (or an average of forty
    representative bonds) and a cost-of-living index over the same periods, and you want
    to know whether the two really do stand in inverse ratio -- the chapter uses this to
    show that the railroad stocks under federal control had entered the fixed-income
    class, because their decline and recovery "virtually paralleled" bonds and
    "corresponded closely to the inflation and subsequent deflation of the cost of
    living".

    Three measurements are reported, all of them always computed:
      * `price_cost_of_living_correlation` -- should be clearly negative;
      * `inverse_step_agreement` -- share of period-steps in which price and the cost of
        living move in opposite directions;
      * the price x cost-of-living product -- if price is in strict inverse ratio to the
        cost of living this product is constant, so its coefficient of variation
        (`inverse_ratio_cv`) measures how nearly the rule holds;
      * `apparent_yield_pct` -- income / price, first and last, which the chapter says
        must be LARGER when the price is lower.

    Do NOT use this on a speculative equity: the chapter says explicitly that a
    speculative issue's price is governed by prospective earning capacity, not by the
    cost of living -- classify the issue first with
    speculative_vs_fixed_income_security_classifier.

    Args:
        prices: price series of the security held for fixed income, oldest first.
        cost_of_living: cost-of-living (necessaries) index over the same periods.
        income_per_share: the fixed income per share per period; if omitted a unit income
            of 1.0 per period is used, which leaves the DIRECTION of the apparent yield
            unchanged.
        min_inverse_agreement: share of period-steps that must move oppositely before the
            inverse relation is said to hold.
        verbose: False returns the measurement block; True adds the aligned series.

    Returns:
        JSON {"result": {...}, "error": None, "metadata": {...}} with `holds` (bool),
        `classification` and a short `reason`.
    """
    try:
        min_inverse_agreement = 0.6 if min_inverse_agreement is None else float(min_inverse_agreement)

        price = _clean(prices)
        col = _clean(cost_of_living)
        income = _clean(income_per_share) if income_per_share else []

        n = min(len(price), len(col))
        if n == 0:
            result = {
                "classification": "insufficient_data",
                "holds": False,
                "reason": "No price / cost-of-living observations were supplied, so the "
                          "inverse relation cannot be measured.",
                "observations_compared": 0,
                "price_cost_of_living_correlation": None,
                "inverse_step_agreement": None,
                "inverse_ratio_cv": None,
                "apparent_yield_start_pct": None,
                "apparent_yield_end_pct": None,
                "price_pct_change": None,
                "cost_of_living_pct_change": None,
                "min_inverse_agreement": min_inverse_agreement,
            }
            return json.dumps({
                "result": result,
                "error": None,
                "metadata": {
                    "provenance": {
                        "source_grounded": [
                            "price of securities held for fixed income is in inverse ratio to the cost of living",
                        ],
                        "model_extrapolated": ["boundary reading on empty input"],
                    }
                },
            })

        p = price[:n]
        c = col[:n]

        corr = _correlation(p, c)
        inv_agree, steps = _inverse_step_agreement(p, c)

        product = [p[i] * c[i] for i in range(n)]
        pm = _mean(product)
        ps = _std(product)
        cv = (ps / abs(pm)) if (pm not in (None, 0.0) and ps is not None) else None

        inc = [income[i] if i < len(income) else 1.0 for i in range(n)] if income else [1.0] * n
        yields = [
            (inc[i] / p[i] * 100.0) if p[i] != 0.0 else float("nan") for i in range(n)
        ]
        yield_start = yields[0]
        yield_end = yields[-1]
        price_pct = _pct_change(p)
        col_pct = _pct_change(c)

        moved = (inv_agree is not None and steps > 0) or n < 2
        if n < 2:
            classification = "insufficient_data"
            holds = False
            reason = ("Only one aligned observation; a direction of movement cannot be "
                      "measured from a single point.")
        elif not moved:
            classification = "no_movement"
            holds = False
            reason = ("Neither the price nor the cost of living moved over the window, so "
                      "there is no inverse relation to confirm or deny.")
        else:
            inverse_steps_ok = bool(inv_agree is not None and inv_agree >= min_inverse_agreement)
            corr_negative = bool(corr is not None and corr < 0.0)
            yield_rose_as_price_fell = bool(
                _finite(yield_start) and _finite(yield_end) and _finite(price_pct)
                and price_pct < 0.0 and yield_end > yield_start
            )
            yield_fell_as_price_rose = bool(
                _finite(yield_start) and _finite(yield_end) and _finite(price_pct)
                and price_pct > 0.0 and yield_end < yield_start
            )
            price_moved = bool(_finite(price_pct) and price_pct != 0.0)

            if price_moved and inverse_steps_ok and corr_negative and (
                    yield_rose_as_price_fell or yield_fell_as_price_rose):
                classification = "inverse_relation_holds"
                holds = True
                reason = ("Price and the cost of living moved oppositely in "
                          + format(inv_agree * 100.0, ".0f") + "% of steps (>= "
                          + format(min_inverse_agreement * 100.0, ".0f")
                          + "%), their correlation is " + format(corr, ".2f")
                          + ", and the apparent dollar yield moved from "
                          + format(yield_start, ".2f") + "% to " + format(yield_end, ".2f")
                          + "% as the price went " + format(price_pct, ".2f")
                          + "%: the layman's rule holds.")
            elif price_moved and inverse_steps_ok and corr_negative:
                classification = "inverse_price_but_yield_unmeasured"
                holds = False
                reason = ("Price and the cost of living did move oppositely in "
                          + format(inv_agree * 100.0, ".0f") + "% of steps with a negative "
                          "correlation of " + format(corr, ".2f")
                          + ", but the apparent yield did not change as the chapter's rule "
                          "requires, so the rule is not confirmed.")
            else:
                classification = "inverse_relation_fails"
                holds = False
                failed = []
                if not inverse_steps_ok:
                    failed.append(
                        "price and the cost of living moved oppositely in only "
                        + format((inv_agree or 0.0) * 100.0, ".0f") + "% of steps, below the "
                        + format(min_inverse_agreement * 100.0, ".0f") + "% required"
                    )
                if not corr_negative:
                    failed.append(
                        "their correlation is not negative"
                        + ("" if corr is None else " (" + format(corr, ".2f") + ")")
                    )
                if not price_moved:
                    failed.append("the price did not move over the window")
                reason = ("The layman's rule does not hold: " + "; ".join(failed)
                          + ". The issue is not behaving as a security held for fixed "
                            "income.")

        result = {
            "classification": classification,
            "holds": holds,
            "reason": reason,
            "observations_compared": n,
            "price_pct_change": _r(price_pct, 4),
            "cost_of_living_pct_change": _r(col_pct, 4),
            "price_cost_of_living_correlation": _r(corr, 4),
            "inverse_step_agreement": _r(inv_agree, 4),
            "inverse_steps_counted": steps,
            "inverse_ratio_cv": _r(cv, 6),
            "apparent_yield_start_pct": _r(yield_start, 4),
            "apparent_yield_end_pct": _r(yield_end, 4),
            "min_inverse_agreement": min_inverse_agreement,
            "income_supplied": bool(income),
        }

        if verbose:
            result["detail"] = {
                "prices": [round(v, 4) for v in p],
                "cost_of_living": [round(v, 4) for v in c],
                "price_times_cost_of_living": [round(v, 4) for v in product],
                "apparent_yield_pct": [None if not _finite(v) else round(v, 4) for v in yields],
                "rule_quote": ("the price of securities held for fixed income is in inverse "
                               "ratio to the cost of living"),
            }

        return json.dumps({
            "result": result,
            "error": None,
            "metadata": {
                "provenance": {
                    "source_grounded": [
                        "price of securities held for fixed income is in inverse ratio to the cost of living",
                        "if the cost of living is high the price of bonds will be low and their apparent yield in dollars will be large",
                        "if the cost of living is low the price will be high and the apparent yield correspondingly less",
                        "bond price fluctuates strictly according to the purchasing power of the income",
                    ],
                    "model_extrapolated": [
                        "inverse relation measured as >= 0.6 of steps moving oppositely plus a negative correlation",
                        "strict inverse proportionality measured as coefficient of variation of price x cost of living",
                        "apparent yield computed as income / price; unit income of 1.0 substituted when income is not supplied",
                        "no-movement and single-observation boundary readings",
                    ],
                }
            },
        })
    except Exception as exc:
        return json.dumps({
            "result": {
                "classification": "insufficient_data",
                "holds": False,
                "reason": "Could not test the inverse relation: " + str(exc),
            },
            "error": None,
            "metadata": {
                "provenance": {
                    "source_grounded": [
                        "price of securities held for fixed income is in inverse ratio to the cost of living",
                    ],
                    "model_extrapolated": ["boundary reading on unusable input"],
                }
            },
        })