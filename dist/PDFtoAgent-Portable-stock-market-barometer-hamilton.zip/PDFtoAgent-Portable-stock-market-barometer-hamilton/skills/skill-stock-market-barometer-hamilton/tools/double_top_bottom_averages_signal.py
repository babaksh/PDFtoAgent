import json
from typing import List, Optional


def _clean(values: Optional[List]) -> List[float]:
    out: List[float] = []
    if not values:
        return out
    for v in values:
        try:
            f = float(v)
        except (TypeError, ValueError):
            continue
        out.append(f)
    return out


def _denom(x: float) -> float:
    return abs(x) if abs(x) > 1e-12 else 1.0


def _pivots(series: List[float], window: int, kind: str) -> List[int]:
    n = len(series)
    if n < 3:
        return []
    w = max(1, int(window))
    out: List[int] = []
    for i in range(n):
        lo = max(0, i - w)
        hi = min(n, i + w + 1)
        seg = series[lo:hi]
        if kind == "top":
            if series[i] < max(seg):
                continue
            if i > 0 and series[i] <= series[i - 1]:
                continue
            if i < n - 1 and series[i] < series[i + 1]:
                continue
        else:
            if series[i] > min(seg):
                continue
            if i > 0 and series[i] >= series[i - 1]:
                continue
            if i < n - 1 and series[i] > series[i + 1]:
                continue
        out.append(i)
    return out


def _intervening_move(series: List[float], i: int, j: int, kind: str) -> float:
    if j <= i:
        return 0.0
    seg = series[i:j + 1]
    base = series[i]
    if kind == "top":
        return (base - min(seg)) / _denom(base) * 100.0
    return (max(seg) - base) / _denom(base) * 100.0


def _best_pair(series: List[float], window: int, kind: str, tol_pct: float,
               max_sep: int, min_recession_pct: float) -> Optional[dict]:
    piv = _pivots(series, window, kind)
    best: Optional[dict] = None
    for a in range(len(piv)):
        for b in range(a + 1, len(piv)):
            i, j = piv[a], piv[b]
            if j - i > max_sep:
                continue
            p1, p2 = series[i], series[j]
            spread = abs(p2 - p1) / _denom(p1) * 100.0
            if spread > tol_pct:
                continue
            rec = _intervening_move(series, i, j, kind)
            if rec < min_recession_pct:
                continue
            cand = {
                "first_index": i,
                "second_index": j,
                "first_price": p1,
                "second_price": p2,
                "separation_periods": j - i,
                "spread_pct": spread,
                "intervening_move_pct": rec,
            }
            if best is None or spread < best["spread_pct"] or (
                    abs(spread - best["spread_pct"]) < 1e-12 and rec > best["intervening_move_pct"]):
                best = cand
    return best


def _net_direction(series: List[float]) -> str:
    if len(series) < 2:
        return "flat"
    net = series[-1] - series[0]
    if abs(net) < 1e-12:
        return "flat"
    return "up" if net > 0 else "down"


async def double_top_bottom_averages_signal(
    industrials: List[float],
    railroads: Optional[List[float]] = None,
    periods: Optional[List[str]] = None,
    direction: str = "auto",
    swing_window: int = 2,
    tolerance_pct: float = 0.5,
    max_separation_periods: int = 12,
    min_recession_pct: float = 1.0,
    verbose: bool = True,
) -> str:
    """Detect a double top or double bottom in the market AVERAGES and return the
    warning that the rise or decline is probably over.

    Use when you have two average series (industrials and railroads) around a suspected
    culmination, and want the chapter's own 1909 reading: the industrials made 100.50
    early in October and 100.53 early in November -- two highs within a working tolerance
    of 0.03 points, weeks apart, with a reaction between them. That is a double top.
    The chapter's stated weight: "It is by no means infallible, but is often useful;
    and experience has shown that when the market makes a double top or a double bottom
    in the averages there is strong reason for suspecting that the rise or decline is
    over."

    Extends double_top_bottom_detector (chDOW'S THEORY, APPLIED TO SPECULATION): that
    tool reads the pattern in ONE stock from ONE price series. This one reads it in the
    two market AVERAGES, whose two tops may be weeks apart and need not be made by the
    same average on the same day (rails topped in August 1909, industrials in
    September-November), and it reports the reliability weight as well as the pattern.
    Do NOT use for a single stock's price series -- call double_top_bottom_detector;
    do NOT use to date the turn of the market -- call confirmed_turn_dating_test.

    direction: "top", "bottom" or "auto" (auto follows the net direction of the
    industrials: up -> look for a double top, down -> a double bottom).
    tolerance_pct: how close two extremes must be to count as a double top/bottom.
    max_separation_periods: how far apart in time the two extremes may be.
    min_recession_pct: the reaction required between the two extremes.
    """
    try:
        ind = _clean(industrials)
        rail = _clean(railroads)
        labels = list(periods) if periods else []
        window = 2 if swing_window is None else int(swing_window)
        if window < 1:
            window = 1
        tol = 0.5 if tolerance_pct is None else float(tolerance_pct)
        max_sep = 12 if max_separation_periods is None else int(max_separation_periods)
        if max_sep < 1:
            max_sep = 1
        min_rec = 1.0 if min_recession_pct is None else float(min_recession_pct)

        def label(i: int):
            return str(labels[i]) if 0 <= i < len(labels) else str(i)

        want = str(direction).strip().lower()
        if want not in ("top", "bottom"):
            want = "top" if _net_direction(ind) == "up" else "bottom"

        result = {
            "direction": want,
            "industrial_direction": _net_direction(ind),
            "pattern": "none",
            "warning": "no double top or double bottom in the averages",
            "both_averages": False,
        }

        def scan(series: List[float]) -> Optional[dict]:
            if len(series) < 3:
                return None
            pair = _best_pair(series, window, want, tol, max_sep, min_rec)
            if pair is None:
                return None
            pair = dict(pair)
            pair["first_period"] = label(pair["first_index"])
            pair["second_period"] = label(pair["second_index"])
            pair["pattern"] = "double_top" if want == "top" else "double_bottom"
            return pair

        ind_pair = scan(ind)
        rail_pair = scan(rail) if rail else None

        chosen = None
        which = None
        if ind_pair is not None and rail_pair is not None:
            chosen = ind_pair if ind_pair["spread_pct"] <= rail_pair["spread_pct"] else rail_pair
            which = "both"
        elif ind_pair is not None:
            chosen, which = ind_pair, "industrials"
        elif rail_pair is not None:
            chosen, which = rail_pair, "railroads"

        if chosen is not None:
            result["pattern"] = chosen["pattern"]
            result["formed_in"] = which
            result["both_averages"] = (ind_pair is not None and rail_pair is not None)
            result["first_price"] = chosen["first_price"]
            result["second_price"] = chosen["second_price"]
            result["spread_pct"] = chosen["spread_pct"]
            result["separation_periods"] = chosen["separation_periods"]
            result["intervening_move_pct"] = chosen["intervening_move_pct"]
            result["first_period"] = chosen["first_period"]
            result["second_period"] = chosen["second_period"]
            move = "rise" if want == "top" else "decline"
            result["warning"] = (
                "double " + want + " in the averages (" + str(round(chosen["first_price"], 4)) +
                " and " + str(round(chosen["second_price"], 4)) + ", " +
                str(chosen["separation_periods"]) + " periods apart): strong reason for "
                "suspecting that the " + move + " is over"
            )
            result["reliability"] = "not infallible, but often useful"
        else:
            result["formed_in"] = "none"
            result["spread_pct"] = None
            result["separation_periods"] = None
            result["intervening_move_pct"] = None
            result["reliability"] = "not infallible, but often useful"

        if verbose:
            result["industrial_pair"] = ind_pair
            result["railroad_pair"] = rail_pair
            result["tolerance_pct"] = tol
            result["max_separation_periods"] = max_sep
            result["min_recession_pct"] = min_rec
            result["swing_window"] = window
            result["periods_observed"] = len(ind)

        return json.dumps({
            "result": result,
            "error": None,
            "metadata": {"provenance": {
                "source_grounded": ["double top / double bottom in the averages as the formation",
                                    "two extremes within a working tolerance (100.50 vs 100.53)",
                                    "two tops may be weeks apart",
                                    "verdict: strong reason for suspecting the rise or decline is over",
                                    "stated reliability: not infallible, but often useful"],
                "model_extrapolated": ["tolerance default of " + str(round(tol, 4)) + "% between the two extremes",
                                       "max separation of " + str(max_sep) + " periods",
                                       "required intervening reaction of " + str(round(min_rec, 4)) + "%",
                                       "swing window of " + str(window) + " periods for locating the extremes",
                                       "auto mode follows the net direction of the industrials",
                                       "flat series yields no pattern"],
            }},
        })
    except Exception as exc:
        return json.dumps({
            "result": {"pattern": "none", "warning": "unreadable input", "both_averages": False},
            "error": str(exc),
            "metadata": {"provenance": {
                "source_grounded": ["double top / double bottom in the averages"],
                "model_extrapolated": ["exception guard returns a neutral reading"],
            }},
        })