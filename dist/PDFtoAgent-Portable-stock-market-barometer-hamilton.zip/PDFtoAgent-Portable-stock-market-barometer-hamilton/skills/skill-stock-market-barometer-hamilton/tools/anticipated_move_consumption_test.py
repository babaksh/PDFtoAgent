"""Measure how much of an anticipated special movement the price has already discounted."""

import json
import math
from typing import Optional

_PROVENANCE = {
    "source_grounded": [
        "expected special movement of four points",
        "a point and a half of the expected four points already shown in the advance",
        "he buys when the movement is almost completed",
        "the special movement is over: the opportunity is gone",
        "if the anticipated movement fails to materialize, take the loss or the small profit and wait",
    ],
    "model_extrapolated": [
        "consumed-share cutoff of 25 per cent of the expected move",
        "round-trip friction in points (commission plus the turn) deducted from what remains",
        "entry price and expected end price supplied by the caller",
        "direction handling for an anticipated decline",
        "direction 'none' when no usable direction is given or the prices are flat",
    ],
}


def _num(value, default):
    if value is None:
        return float(default)
    try:
        out = float(value)
    except (TypeError, ValueError):
        return float(default)
    if math.isnan(out) or math.isinf(out):
        return float(default)
    return out


async def anticipated_move_consumption_test(
    expected_move_points: float = 4.0,
    already_shown_points: float = 1.5,
    entry_price: Optional[float] = None,
    expected_end_price: Optional[float] = None,
    direction: str = "up",
    round_trip_friction_points: float = 0.0,
    max_consumed_pct: float = 25.0,
    verbose: bool = True,
) -> str:
    """Measure how much of an expected 'special movement' in a stock is already
    reflected in its price before entry, and rule whether the opportunity is gone.

    Use when a speculator has been told (correctly) of a coming quick movement of a
    known number of points in a particular stock and is about to buy it: the chapter's
    case is a four-point movement of which a point and a half is already shown in the
    advance, so that by the time he buys, "the movement is almost completed" and the
    opportunity has gone. Pass the expected size of the movement and the part of it
    the price has already run; if you know the prices instead, pass entry_price and
    expected_end_price and the tool derives the same two numbers for you.

    Do NOT use this for a purchase made on permanent value rather than on a special
    movement (the chapter's other class of buyer holds through fluctuations), and do
    NOT use it to judge whether a general market move is over -- that is a barometer
    question. Do NOT use it to size the position -- call margin_capital_loss_exposure_test.

    direction is 'up' for an anticipated advance, 'down' for an anticipated decline,
    and reports 'none' when no usable direction is supplied or the two prices are
    identical (a flat pair has no direction).

    Returns the points consumed, the share of the expected move consumed, the points
    remaining after round-trip friction, and a gone / intact verdict.
    """
    raw_direction = (direction or "").strip().lower()
    if raw_direction in ("up", "rise", "rising", "advance", "long", "buy"):
        direction = "up"
    elif raw_direction in ("down", "fall", "falling", "decline", "short", "sell"):
        direction = "down"
    else:
        direction = "none"

    expected = _num(expected_move_points, 0.0)
    shown = _num(already_shown_points, 0.0)
    friction = max(_num(round_trip_friction_points, 0.0), 0.0)
    cutoff = max(_num(max_consumed_pct, 25.0), 0.0)

    derived_from_prices = False
    entry = None if entry_price is None else _num(entry_price, 0.0)
    target = None if expected_end_price is None else _num(expected_end_price, 0.0)
    if entry is not None and target is not None:
        net_move = target - entry
        if net_move > 0:
            direction = "up"
        elif net_move < 0:
            direction = "down"
        else:
            direction = "none"
        expected = shown + abs(net_move)
        derived_from_prices = True

    if expected <= 0:
        consumed_pct = None
        remaining = None
        net_remaining = None
        verdict = "no_move_expected"
        reason = "No expected movement was supplied: there is nothing here to anticipate."
    elif shown <= 0:
        consumed_pct = 0.0
        remaining = expected
        net_remaining = expected - friction
        if net_remaining > 0:
            verdict = "opportunity_intact"
            reason = (
                "None of the expected %.4g points is in the price yet; %.4g points remain "
                "after %.4g points of round-trip friction."
                % (expected, net_remaining, friction)
            )
        else:
            verdict = "opportunity_gone"
            reason = (
                "Even before any of the expected %.4g points is discounted, round-trip "
                "friction of %.4g points eats the whole move."
                % (expected, friction)
            )
    else:
        consumed_pct = 100.0 * shown / expected
        remaining = expected - shown
        net_remaining = remaining - friction
        if net_remaining <= 0:
            verdict = "opportunity_gone"
            reason = (
                "%.4g of the expected %.4g points is already in the price and round-trip "
                "friction of %.4g points consumes the %.4g points that remain."
                % (shown, expected, friction, remaining)
            )
        elif consumed_pct >= cutoff:
            verdict = "opportunity_gone"
            reason = (
                "%.4g%% of the expected %.4g points is already discounted, past the %.4g%% "
                "cutoff; only %.4g points remain, net %.4g after friction. The chapter's own "
                "case is worse: a point and a half of four points already shown, and the "
                "buyer comes in when the movement is almost completed."
                % (consumed_pct, expected, cutoff, remaining, net_remaining)
            )
        else:
            verdict = "opportunity_intact"
            reason = (
                "Only %.4g%% of the expected %.4g points is discounted, inside the %.4g%% "
                "cutoff; %.4g points remain after friction."
                % (consumed_pct, expected, cutoff, net_remaining)
            )

    result = {
        "direction": direction,
        "expected_move_points": expected,
        "already_shown_points": shown,
        "consumed_pct": consumed_pct,
        "remaining_points": remaining,
        "round_trip_friction_points": friction,
        "net_remaining_points": net_remaining,
        "max_consumed_pct": cutoff,
        "verdict": verdict,
    }

    if verbose:
        result["derived_from_prices"] = derived_from_prices
        result["entry_price"] = entry
        result["expected_end_price"] = target
        result["chapter_case"] = {
            "expected_move_points": 4.0,
            "already_shown_points": 1.5,
            "consumed_pct": 37.5,
            "verdict": "opportunity_gone",
        }
        result["reason"] = reason

    return json.dumps({"result": result, "error": None, "metadata": {"provenance": _PROVENANCE}})