"""Test whether a sudden break shows FORCED liquidation: marketable sold first.

Implements the reading this chapter makes of the 1906 break: "We see that the
railroad stocks suffered more than the industrials, and we should remember that
they were in a higher class, both relatively and positively. But in a sudden
and demoralizing break people sell the things for which there is some market
in order to protect those for which there is no market."

The chapter states both declines in POINTS: the twenty railroad stocks fell
from 138.36 to 120.36 (18.00 points) while the twelve industrials fell from
103 to 86.45 (16.55 points) - the higher-class, more marketable issues
suffered more, and that is the signature of forced liquidation.

Use this when two averages (or two grades of security) have broken together
and you must decide whether their DIVERGENCE is a failed corroboration or is
exactly what a forced-liquidation break looks like - the more marketable,
higher-class issues being sacrificed to protect the less marketable ones.

Do NOT use this when the averages are expected to agree in an ordinary market
(use `average_corroboration_check`, chCYCLES AND STOCK MARKET RECORDS), and do
NOT use it for the single-issue "is this a forced-selling bargain" question
(use `forced_liquidation_bargain_detector`, chWATER IN THE BAROMETER).

Depends on: `average_corroboration_check` (chCYCLES AND STOCK MARKET RECORDS)
- that tool treats divergence between the two averages as a FAILED
corroboration. This chapter adds the case where divergence is EXPECTED and
does not invalidate the reading: in a shock break the marketable issues are
sold first, so the gradient between the two declines is read as forced
liquidation rather than as failed corroboration.
"""

import json
from typing import List, Optional

try:
    import numpy as _np  # noqa: F401  (optional; stdlib path is sufficient)
except ImportError:  # pragma: no cover
    _np = None


def _clean(seq: Optional[List[float]]) -> List[float]:
    out = []
    for v in seq or []:
        try:
            out.append(float(v))
        except (TypeError, ValueError):
            continue
    return out


def _argmax(seq: List[float]) -> int:
    best = 0
    for i in range(1, len(seq)):
        if seq[i] > seq[best]:
            best = i
    return best


def _leg(seq: List[float], start: int, name: str) -> dict:
    """Pre-break high to post-break low for one series, from index `start`."""
    if len(seq) < 2:
        return {"series": name, "measurable": False}
    s = max(0, min(start, len(seq) - 1))
    peak_idx = _argmax(seq[:s + 1]) if s > 0 else 0
    peak = seq[peak_idx]
    tail = seq[s:]
    low = min(tail)
    low_idx = s + tail.index(low)
    decline_points = peak - low
    decline_pct = (decline_points / peak * 100.0) if peak > 0.0 else None
    return {
        "series": name,
        "measurable": True,
        "pre_break_price": peak,
        "low_price": low,
        "decline_points": decline_points,
        "decline_pct": decline_pct,
        "pre_break_index": peak_idx,
        "low_index": low_idx,
    }


async def forced_liquidation_marketable_first_test(
    prices: List[float],
    break_index: int = 0,
    recoverable_average: Optional[List[float]] = None,
    confined_average: Optional[List[float]] = None,
    gradient_basis: str = "points",
    min_gradient: float = 1.0,
    verbose: bool = True,
) -> str:
    """Test a sudden break for forced liquidation: marketable issues sold first.

    Use when a sudden, demoralizing break has hit two averages (or two grades
    of security) together and you need to know whether the more marketable,
    higher-class average has suffered the more - the signature of holders
    selling what has a market in order to protect what has none. Read that
    gradient as forced liquidation, NOT as a failed corroboration.

    Args:
        prices: Price series for ONE average over the break. Used alone only
            when you have a single series; the two-average gradient - the real
            test - is then reported as unmeasurable.
        break_index: Index of the observation at or just before the shock. The
            pre-break level is the highest price up to that index and the break
            low is the lowest price from that index onwards.
        recoverable_average: Price series of the MORE marketable / higher-class
            average - the one that has a market. In 1906, the twenty active
            railroad stocks: 138.36 to 120.36.
        confined_average: Price series of the LESS marketable average - the one
            holders sacrifice the other to protect. In 1906, the twelve
            industrials: 103 to 86.45.
        gradient_basis: Which decline the gradient is measured on - "points"
            (price points, the default, because that is how the chapter states
            the 1906 comparison) or "pct" (per cent of the pre-break price).
        min_gradient: Threshold for a material gradient - 1.0 price point on
            the "points" basis, 0.5 percentage points on the "pct" basis.
        verbose: True returns the full reading plus both averages' detail;
            False returns the compact decision only.

    Returns:
        JSON with result/error/metadata. `result.classification` is one of
        forced_liquidation_marketable_sold_first,
        corroboration_intact_confined_sold_first,
        no_forced_liquidation_gradient, insufficient_history,
        insufficient_data.
    """
    provenance = {
        "source_grounded": [
            "sudden demoralizing break: sell what has a market to protect what has none",
            "railroad stocks suffered more than the industrials in 1906",
            "rails were in a higher class, relatively and positively",
            "1906 rails 138.36 -> 120.36 (18.00 pts) vs industrials 103 -> 86.45",
        ],
        "model_extrapolated": [
            "gradient_basis points|pct with min_gradient 1.0 point / 0.5 pct",
            "break low = lowest price at or after break_index",
            "recoverable_average / confined_average as the two grade names",
            "with one series only the gradient is reported unmeasurable",
        ],
    }

    series = _clean(prices)
    rec = _clean(recoverable_average)
    con = _clean(confined_average)

    basis = str(gradient_basis).strip().lower() if gradient_basis is not None else "points"
    if basis not in ("points", "pct"):
        basis = "points"
    default_gradient = 1.0 if basis == "points" else 0.5
    try:
        min_gradient = default_gradient if min_gradient is None else float(min_gradient)
    except (TypeError, ValueError):
        min_gradient = default_gradient

    try:
        bi = int(break_index) if break_index is not None else 0
    except (TypeError, ValueError):
        bi = 0

    single = _leg(series, bi, "prices") if len(series) >= 2 else None
    rec_leg = _leg(rec, bi, "recoverable_average") if len(rec) >= 2 else None
    con_leg = _leg(con, bi, "confined_average") if len(con) >= 2 else None

    both = bool(rec_leg and con_leg and rec_leg.get("measurable") and con_leg.get("measurable"))

    if not (single or rec_leg or con_leg):
        return json.dumps({
            "result": {
                "classification": "insufficient_data",
                "gradient_points": None,
                "gradient_pct_points": None,
                "forced_liquidation_detected": None,
                "marketable_decline_points": None,
                "confined_decline_points": None,
                "gradient_basis": basis,
                "min_gradient": min_gradient,
                "reason": "No usable price series supplied; pass `prices`, or both "
                          "`recoverable_average` and `confined_average`.",
            },
            "error": None,
            "metadata": {"provenance": provenance, "n_prices": len(series)},
        })

    if not both:
        one = single or rec_leg or con_leg
        out = {
            "classification": "insufficient_history",
            "gradient_points": None,
            "gradient_pct_points": None,
            "forced_liquidation_detected": None,
            "marketable_decline_points": (rec_leg or {}).get("decline_points"),
            "confined_decline_points": (con_leg or {}).get("decline_points"),
            "gradient_basis": basis,
            "min_gradient": min_gradient,
            "reason": "Only one average was supplied, so the gradient between the "
                      "marketable and the confined average cannot be measured. "
                      "Forced liquidation is a RELATIVE test: pass both "
                      "`recoverable_average` and `confined_average`. The single "
                      "series supplied fell %.2f points from its pre-break high."
                      % one.get("decline_points", 0.0),
        }
        if verbose:
            out["single_average"] = single
            out["recoverable_average"] = rec_leg
            out["confined_average"] = con_leg
        return json.dumps({
            "result": out,
            "error": None,
            "metadata": {"provenance": provenance, "n_prices": len(series)},
        })

    rec_pts = rec_leg["decline_points"]
    con_pts = con_leg["decline_points"]
    rec_pct = rec_leg["decline_pct"]
    con_pct = con_leg["decline_pct"]

    gradient_points = rec_pts - con_pts
    gradient_pct = None if (rec_pct is None or con_pct is None) else rec_pct - con_pct

    measured = gradient_points if basis == "points" else gradient_pct
    if measured is None:
        detected = None
        classification = "insufficient_history"
        reason = ("On the %s basis the declines are unmeasurable (a pre-break price "
                  "of zero), so no gradient can be read." % basis)
        fired = False
        reversed_ = False
    else:
        fired = bool(measured >= min_gradient)
        reversed_ = bool(measured <= -min_gradient)
        if fired:
            detected = True
            classification = "forced_liquidation_marketable_sold_first"
            reason = (
                "The more marketable, higher-class average fell %.2f points (%.2f "
                "per cent) against %.2f points (%.2f per cent) for the less "
                "marketable one - a gradient of %.2f points (%.2f percentage "
                "points). Holders sold what has a market to protect what has none: "
                "this is forced liquidation in a sudden demoralizing break, and the "
                "divergence does NOT invalidate the reading of the averages."
                % (rec_pts, rec_pct if rec_pct is not None else 0.0,
                   con_pts, con_pct if con_pct is not None else 0.0,
                   gradient_points, gradient_pct if gradient_pct is not None else 0.0)
            )
        elif reversed_:
            detected = False
            classification = "corroboration_intact_confined_sold_first"
            reason = (
                "The less marketable average fell %.2f points (%.2f per cent) "
                "against %.2f points (%.2f per cent) for the marketable one - a "
                "gradient of %.2f points the wrong way. The marketable issues were "
                "NOT sacrificed first, so this is not the forced-liquidation "
                "pattern; treat the divergence as an ordinary corroboration "
                "question." % (con_pts, con_pct if con_pct is not None else 0.0,
                               rec_pts, rec_pct if rec_pct is not None else 0.0,
                               gradient_points)
            )
        else:
            detected = False
            classification = "no_forced_liquidation_gradient"
            reason = (
                "The marketable average fell %.2f points and the less marketable one "
                "%.2f points, a gradient of only %.2f - inside the %.2f threshold on "
                "the %s basis. The two averages broke together: no "
                "forced-liquidation gradient." % (rec_pts, con_pts, measured,
                                                  min_gradient, basis)
            )

    disagree = bool(
        gradient_points is not None
        and gradient_pct is not None
        and gradient_points > 0.0
        and gradient_pct < 0.0
    )
    if disagree and detected is not None:
        reason += (" Note: the two bases disagree - in points the marketable average "
                   "fell the more, but as a percentage of its own pre-break level it "
                   "fell the less. The chapter states the comparison in points.")

    out = {
        "classification": classification,
        "forced_liquidation_detected": detected,
        "gradient_points": gradient_points,
        "gradient_pct_points": gradient_pct,
        "gradient_basis": basis,
        "min_gradient": min_gradient,
        "marketable_decline_points": rec_pts,
        "confined_decline_points": con_pts,
        "marketable_decline_pct": rec_pct,
        "confined_decline_pct": con_pct,
        "bases_disagree": disagree,
        "reason": reason,
    }
    if verbose:
        out["single_average"] = single
        out["recoverable_average"] = rec_leg
        out["confined_average"] = con_leg

    return json.dumps({
        "result": out,
        "error": None,
        "metadata": {"provenance": provenance, "n_prices": len(series)},
    })