import json
from typing import List, Optional


async def speculative_volume_period_comparison_test(
    current_volumes: Optional[List[float]] = None,
    reference_volumes: Optional[List[float]] = None,
    bull_market_volumes: Optional[List[float]] = None,
    bear_market_volumes: Optional[List[float]] = None,
    current_label: str = "current period",
    reference_label: str = "earlier period",
    stagnation_tolerance: Optional[float] = None,
    contraction_threshold: Optional[float] = None,
    verbose: bool = True,
) -> str:
    """Rule whether speculation is stagnant, contracted or genuinely expanding by
    comparing the monthly average of daily stock trading in one era against an
    earlier era.

    Use when you have the monthly average of daily trading (the volume measure
    recorded on the twenty-five-year chart) for the period under study, e.g.
    1911-1914 inclusive, and for an earlier reference era, e.g. the four years
    preceding the re-election of McKinley, and you want the chapter's verdict:
    speculative business "very little if any better in volume than" the earlier
    era -- stagnant -- versus a marked contraction versus genuine expansion.

    The tool also applies the chapter's directional rule, "business in stocks is
    always far lighter in a bear market than in a bull market", to whatever bull
    and bear volume samples you supply, and flags the case where a bear market
    is NOT lighter, which contradicts that rule.

    Extends: bull_bear_volume_expansion_contraction_test (chFORECASTING A BULL
    MARKET-1908-1909) -- that tool classifies a swing by whether volume expands
    on rises and contracts on declines; this one adds the ERA-TO-ERA level
    comparison of the monthly average of daily trading (1911-14 against the
    pre-1900 period, and the post-1921 contraction).

    Do NOT use for: classifying a single swing bull or bear, for daily volume
    spikes around a news event, or for the price averages themselves.

    Args:
        current_volumes: monthly averages of daily stock trading for the period
            under study, in any consistent unit (shares or dollars).
        reference_volumes: the same measure for the earlier era being compared.
        bull_market_volumes: monthly averages during a bull market (optional,
            for the bear-lighter rule).
        bear_market_volumes: monthly averages during a bear market (optional).
        current_label: name of the period under study.
        reference_label: name of the earlier reference era.
        stagnation_tolerance: half-width of "very little if any better"
            (default 0.05, i.e. within 5 per cent).
        contraction_threshold: fraction below the reference that counts as a
            marked contraction (default 0.20).
        verbose: False returns the compact verdict and the key ratios only.

    Returns:
        JSON string with keys result/error/metadata.
    """
    try:
        cur = [float(v) for v in (current_volumes or [])]
        ref = [float(v) for v in (reference_volumes or [])]
        bull = None if bull_market_volumes is None else [float(v) for v in bull_market_volumes]
        bear = None if bear_market_volumes is None else [float(v) for v in bear_market_volumes]

        tol = 0.05 if stagnation_tolerance is None else abs(float(stagnation_tolerance))
        contraction = 0.20 if contraction_threshold is None else abs(float(contraction_threshold))

        cur_mean = (sum(cur) / len(cur)) if cur else 0.0
        ref_mean = (sum(ref) / len(ref)) if ref else 0.0

        if cur_mean > 0 and ref_mean > 0:
            era_ratio = cur_mean / ref_mean
        else:
            era_ratio = None

        if era_ratio is None:
            classification = "unmeasured"
            reason = (
                "Both eras need at least one non-zero monthly average of daily "
                "trading to be compared; with %s=%r and %s=%r the era "
                "comparison is left unmeasured rather than guessed."
                % (current_label, cur_mean, reference_label, ref_mean)
            )
        elif era_ratio < (1.0 - contraction):
            classification = "contracted"
            reason = (
                "The monthly average of daily trading in %s is %.2f of that in "
                "%s, a marked contraction: speculative business has fallen well "
                "below the earlier level."
                % (current_label, era_ratio, reference_label)
            )
        elif era_ratio <= (1.0 + tol):
            classification = "stagnant"
            reason = (
                "The monthly average of daily trading in %s is %.2f of that in "
                "%s -- very little if any better: speculative business is "
                "stagnant, not strong enough to stimulate any large volume of "
                "speculation."
                % (current_label, era_ratio, reference_label)
            )
        else:
            classification = "expanding"
            reason = (
                "The monthly average of daily trading in %s is %.2f of that in "
                "%s, comfortably above the stagnation band: speculation is "
                "genuinely expanding."
                % (current_label, era_ratio, reference_label)
            )

        bull_mean = (sum(bull) / len(bull)) if bull else None
        bear_mean = (sum(bear) / len(bear)) if bear else None
        if bull_mean is None or bear_mean is None:
            bear_lighter = None
            bear_ratio = None
        elif bull_mean > 0:
            bear_ratio = bear_mean / bull_mean
            bear_lighter = bool(bear_ratio < 1.0)
        else:
            bear_ratio = None
            bear_lighter = bool(bear_mean == 0.0)

        if bear_lighter is None:
            reason += (
                " The bear-market-lighter rule was not checked: no bull and bear "
                "volume samples were supplied."
            )
        elif bear_lighter:
            reason += (
                " The bear sample is %.2f of the bull sample, consistent with "
                "the rule that business in stocks is always far lighter in a "
                "bear market than in a bull market." % bear_ratio
            )
        else:
            reason += (
                " The bear sample is %.2f of the bull sample, contradicting the "
                "rule that business in stocks is always far lighter in a bear "
                "market than in a bull market." % bear_ratio
            )

        result = {
            "classification": classification,
            "reason": reason,
            "current_label": current_label,
            "reference_label": reference_label,
            "current_mean_volume": cur_mean,
            "reference_mean_volume": ref_mean,
            "era_volume_ratio": era_ratio,
            "bear_lighter_than_bull": bear_lighter,
            "bear_over_bull_ratio": bear_ratio,
        }
        if verbose:
            result["current_months"] = len(cur)
            result["reference_months"] = len(ref)
            result["current_volumes"] = cur
            result["reference_volumes"] = ref
            result["bull_mean_volume"] = bull_mean
            result["bear_mean_volume"] = bear_mean
            result["stagnation_tolerance"] = tol
            result["contraction_threshold"] = contraction

        return json.dumps({
            "result": result,
            "error": None,
            "metadata": {"provenance": {
                "source_grounded": [
                    "monthly average of daily stock trading is the recorded volume measure",
                    "1911-1914 inclusive very little if any better in volume than the four years before McKinley's re-election",
                    "business in stocks is always far lighter in a bear market than in a bull market",
                    "since the June-August 1921 deflation bear market culmination volume has shown a marked contraction",
                    "verdict set: stagnant / contracted / expanding speculation",
                ],
                "model_extrapolated": [
                    "stagnation_tolerance default 0.05 for 'very little if any better'",
                    "contraction_threshold default 0.20 for 'marked contraction'",
                    "era comparison made on the mean of the supplied monthly averages",
                    "reference era chosen by the caller (the chapter's is pre-1900 vs 1911-14)",
                    "unmeasured classification when either era mean is zero or absent",
                ],
            }},
        })
    except Exception as exc:  # pragma: no cover - defensive
        return json.dumps({
            "result": None,
            "error": "speculative_volume_period_comparison_test failed: %s" % exc,
            "metadata": {"provenance": {
                "source_grounded": [],
                "model_extrapolated": ["defensive error wrapper"],
            }},
        })