"""Split a post-break decline into its scare phase and its confidence phase.

Applies the two-phase reading of a panic decline that this chapter quotes from
*The Wall Street Journal* of 1906: "The first decline in a panic is scare, and
the second and slower decline is the demonstration of the general shock to
confidence." The chapter adds the reading that closes the argument - the
commentator said of the market on July 2d that "the line of prices was well
below the line of values and that the indications were bullish", and that
inference proved correct (the decline proved to be a bear swing inside a bull
market, and the line being made was one of accumulation).

Use this when a market has broken and you need to know WHICH decline you are
looking at: the fast scare decline, the intervening rally, or the second and
slower decline that really tests the strength of the market - and therefore
whether the strength-testing decline is still ahead of you.

Do NOT use this for the 40-60 per cent retracement band and the later sag back
to the old low (use `panic_shock_retracement_and_sag_test`), and do NOT use it
to compare two averages against each other (use
`forced_liquidation_marketable_first_test` for that).
"""

import json
from typing import List, Optional

try:
    import numpy as _np  # noqa: F401  (optional; stdlib path is sufficient)
except ImportError:  # pragma: no cover
    _np = None


def _argmax(seq: List[float]) -> int:
    best = 0
    for i in range(1, len(seq)):
        if seq[i] > seq[best]:
            best = i
    return best


def _span(periods: Optional[List[float]], i: int, j: int, n: int) -> float:
    if periods is not None and len(periods) >= n and i < len(periods) and j < len(periods):
        try:
            d = abs(float(periods[j]) - float(periods[i]))
            if d > 0.0:
                return d
        except (TypeError, ValueError):
            pass
    d = float(abs(j - i))
    return d if d > 0.0 else 1.0


def _zigzag(series: List[float], start: int, min_move_pct: float):
    """Return alternating extreme points [(index, price), ...] from `start`."""
    up = 1.0 + min_move_pct / 100.0
    down = 1.0 - min_move_pct / 100.0
    anchors = [(start, series[start])]
    direction = -1
    cur_i, cur_p = start, series[start]
    for i in range(start + 1, len(series)):
        px = series[i]
        if direction < 0:
            if px < cur_p:
                cur_i, cur_p = i, px
            elif px >= cur_p * up:
                anchors.append((cur_i, cur_p))
                direction = 1
                cur_i, cur_p = i, px
        else:
            if px > cur_p:
                cur_i, cur_p = i, px
            elif px <= cur_p * down:
                anchors.append((cur_i, cur_p))
                direction = -1
                cur_i, cur_p = i, px
    if (cur_i, cur_p) != anchors[-1]:
        anchors.append((cur_i, cur_p))
    return anchors


async def panic_decline_scare_then_confidence_phase_test(
    prices: List[float],
    periods: Optional[List[float]] = None,
    value_line: Optional[float] = None,
    break_index: Optional[int] = None,
    min_leg_move_pct: float = 3.0,
    verbose: bool = True,
) -> str:
    """Classify a post-break decline as scare or confidence-shock phase.

    Use when a sudden, demoralizing break has occurred and you must decide
    whether the decline now running is the first fast decline (scare) or the
    second and slower decline which is the demonstration of the general shock
    to confidence - the decline that really tests the strength of the market -
    and whether that test is still ahead.

    Args:
        prices: Price series (an average or a single issue) running from the
            pre-break level through the decline and any later recovery.
        periods: Optional dating for each price (day or month numbers, or
            decimal years); used to measure how FAST each decline ran. Index
            spacing is used when omitted.
        value_line: Optional estimate of the line of values. When supplied the
            tool applies the chapter's reading: prices well below values are a
            bullish indication.
        break_index: Optional index of the observation at or just before the
            shock; the pre-break high is then taken as the highest price up to
            that index. When omitted the highest price in the series is used.
        min_leg_move_pct: Minimum reversal, in per cent, that marks a new leg
            of the decline (3.0).
        verbose: True returns the full reading plus every leg; False returns
            the compact decision only.

    Returns:
        JSON with result/error/metadata. `result.phase` is one of no_decline,
        scare_phase, panic_rally_between_phases, confidence_shock_phase,
        post_confidence_shock, insufficient_data.
    """
    provenance = {
        "source_grounded": [
            "first decline in a panic is scare",
            "second and slower decline is the general shock to confidence",
            "line of prices well below the line of values is bullish",
            "second decline really tests the strength of the market",
        ],
        "model_extrapolated": [
            "min_leg_move_pct = 3.0 to separate one decline leg from the next",
            "phase named from the count of decline legs and the last extreme",
            "decline speed measured as points per unit period",
        ],
    }

    try:
        series = [float(p) for p in (prices or [])]
    except (TypeError, ValueError):
        series = []
    per = None
    if periods is not None:
        try:
            per = [float(p) for p in periods]
        except (TypeError, ValueError):
            per = None
    min_leg_move_pct = 3.0 if min_leg_move_pct is None else float(min_leg_move_pct)
    if min_leg_move_pct <= 0.0:
        min_leg_move_pct = 3.0

    n = len(series)
    if n < 2:
        return json.dumps({
            "result": {
                "phase": "insufficient_data",
                "decline_legs": [],
                "n_decline_legs": 0,
                "strength_testing_decline_still_ahead": None,
                "template_confirmed": None,
                "price_below_value_line": None,
                "value_reading": None,
                "reason": "Fewer than two prices supplied; a decline cannot be "
                          "split into its scare and confidence phases.",
            },
            "error": None,
            "metadata": {"provenance": provenance, "n_prices": n},
        })

    value_line = None if value_line is None else float(value_line)

    start = 0
    if break_index is not None:
        try:
            bi = int(break_index)
        except (TypeError, ValueError):
            bi = 0
        bi = max(0, min(bi, n - 1))
        start = _argmax(series[:bi + 1])
    else:
        start = _argmax(series)

    extremes = _zigzag(series, start, min_leg_move_pct)
    down_legs = []
    up_legs = []
    for k in range(len(extremes) - 1):
        i0, p0 = extremes[k]
        i1, p1 = extremes[k + 1]
        span = _span(per, i0, i1, n)
        leg = {
            "from_index": i0,
            "to_index": i1,
            "from_price": p0,
            "to_price": p1,
            "points": p1 - p0,
            "pct": (p1 - p0) / p0 * 100.0 if p0 else 0.0,
            "periods": span,
            "points_per_period": abs(p1 - p0) / span,
        }
        if p1 < p0:
            down_legs.append(leg)
        elif p1 > p0:
            up_legs.append(leg)

    last_price = series[-1]
    last_extreme_is_low = bool(extremes[-1][0] == n - 1 and len(extremes) > 1
                               and extremes[-1][1] <= extremes[-2][1]) if len(extremes) > 1 else False

    n_down = len(down_legs)
    if n_down == 0:
        phase = "no_decline"
        ahead = None
        confirmed = None
        reason = ("No decline of %.1f per cent or more runs from the high of %.2f; "
                  "there is no panic decline to split into phases."
                  % (min_leg_move_pct, series[start]))
    elif n_down == 1:
        leg = down_legs[0]
        if last_extreme_is_low or extremes[-1][1] <= extremes[0][1]:
            phase = "scare_phase"
        else:
            phase = "panic_rally_between_phases"
        ahead = True
        confirmed = None
        reason = (
            "One decline so far: %.2f points (%.1f per cent) in %.2f periods, "
            "%.3f points per period. This is the first decline, which is scare; "
            "the second and slower decline that really tests the strength of the "
            "market is still ahead." % (abs(leg["points"]), abs(leg["pct"]),
                                        leg["periods"], leg["points_per_period"])
        )
    else:
        first, second = down_legs[0], down_legs[1]
        confirmed = bool(first["points_per_period"] > second["points_per_period"])
        if last_extreme_is_low:
            phase = "confidence_shock_phase"
        else:
            phase = "post_confidence_shock"
        ahead = False
        if confirmed:
            reason = (
                "Two declines: the first ran %.3f points per period (%.2f points), "
                "the second only %.3f points per period (%.2f points). The first "
                "decline was scare; the second and slower decline is the "
                "demonstration of the general shock to confidence, and it is the "
                "one that really tests the strength of the market."
                % (first["points_per_period"], abs(first["points"]),
                   second["points_per_period"], abs(second["points"]))
            )
        else:
            reason = (
                "Two declines, but the second ran %.3f points per period against "
                "%.3f for the first, so the decline has NOT slowed: this is not "
                "the scare-then-confidence sequence the panic record describes."
                % (second["points_per_period"], first["points_per_period"])
            )

    below_value = None
    value_reading = None
    if value_line is not None and value_line != 0.0:
        below_value = bool(last_price < value_line)
        gap_pct = (last_price - value_line) / value_line * 100.0
        if below_value:
            value_reading = ("bullish" if gap_pct <= -5.0 else "mildly_bullish")
        else:
            value_reading = "not_bullish"
        reason += (" Last price %.2f is %.1f per cent from the value line of %.2f, "
                   "so the reading from values is %s."
                   % (last_price, gap_pct, value_line, value_reading))
        if confirmed is None and n_down >= 2:
            pass
    elif value_line is not None and value_line == 0.0:
        below_value = None
        value_reading = None

    compact = {
        "phase": phase,
        "n_decline_legs": n_down,
        "strength_testing_decline_still_ahead": ahead,
        "template_confirmed": confirmed,
        "price_below_value_line": below_value,
        "value_reading": value_reading,
        "last_price": last_price,
        "pre_break_high": series[start],
        "reason": reason,
    }

    payload = dict(compact)
    if verbose:
        payload["decline_legs"] = down_legs
        payload["rally_legs"] = up_legs
        payload["value_line"] = value_line
        payload["min_leg_move_pct"] = min_leg_move_pct
        payload["extremes"] = [{"index": i, "price": p} for i, p in extremes]

    return json.dumps({
        "result": payload,
        "error": None,
        "metadata": {"provenance": provenance, "n_prices": n},
    })