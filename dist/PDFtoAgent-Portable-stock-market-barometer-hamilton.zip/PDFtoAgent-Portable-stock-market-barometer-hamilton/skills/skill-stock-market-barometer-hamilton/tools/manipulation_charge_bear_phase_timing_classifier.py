"""Classify a charge of manipulation by WHEN it is raised.

The chapter's own words on the accusation that a rising market is the work of
"guilty manipulation by gamblers":

    "But that charge is always made in a bear market and in the transition
    period between a major decline and its succeeding upward movement."

The timing is therefore itself the test: a charge dated to one of those two
phases is the ordinary, expected accusation; one raised once the succeeding
upward movement is established falls outside the chapter's rule.
"""

import json
import math
from typing import List, Optional


def _clean(values) -> List[float]:
    if not values:
        return []
    out = []
    for v in values:
        try:
            f = float(v)
        except (TypeError, ValueError):
            continue
        if math.isnan(f) or math.isinf(f):
            continue
        out.append(f)
    return out


def _idx(x, default: int) -> int:
    try:
        return int(x)
    except (TypeError, ValueError):
        return default


async def manipulation_charge_bear_phase_timing_classifier(
    prices: List[float],
    periods: Optional[List[float]] = None,
    accusation_index: Optional[int] = None,
    min_decline_pct: float = 10.0,
    established_advance_pct: float = 20.0,
    verbose: bool = True,
) -> str:
    """Classify a charge of manipulation by the market phase in which it was raised.

    Use when you have a price (or average) series spanning a major decline and
    its recovery, plus the point in that record at which someone accused the
    market of manipulation, and you want to place the accusation in time. The
    chapter states the charge is ALWAYS made either in a bear market or in the
    transition period between a major decline and its succeeding upward
    movement, so the dating of the charge is what the tool reports.

    Do NOT use this to decide whether manipulation actually occurred -- the
    chapter's point is that the charge is a phase artifact, and separate tests
    (`manipulation_implausibility_from_narrow_volume_test`,
    `manipulation_advance_plausibility_test`) address the substance.

    Args:
        prices: price or average series, oldest first, spanning the decline and its aftermath.
        periods: matching period labels as numbers (years, month numbers); optional, used for dating.
        accusation_index: index in `prices` at which the charge was made; defaults to the last period.
        min_decline_pct: peak-to-trough decline that qualifies as the major decline.
        established_advance_pct: advance from the low, in percent, that marks the succeeding
                upward movement as established and ends the transition period.
        verbose: False returns the compact verdict; True adds the dated detail.

    Returns:
        JSON {"result": {...}, "error": None, "metadata": {...}} with
        `classification`, `market_phase_at_accusation` and a short `reason`.
    """
    try:
        min_decline_pct = 10.0 if min_decline_pct is None else float(min_decline_pct)
        established_advance_pct = (
            20.0 if established_advance_pct is None else float(established_advance_pct)
        )

        px = _clean(prices)
        labels = _clean(periods) if periods else []

        if len(px) < 2:
            return json.dumps({
                "result": {
                    "classification": "insufficient_data",
                    "market_phase_at_accusation": "unknown",
                    "reason": "A price series of at least two observations is needed to date a "
                              "major decline and the accusation against it.",
                    "accusation_index": None,
                },
                "error": None,
                "metadata": {
                    "provenance": {
                        "source_grounded": [
                            "that charge is always made in a bear market and in the transition period",
                        ],
                        "model_extrapolated": ["insufficient-data boundary reading"],
                    }
                },
            })

        idx = _idx(accusation_index, len(px) - 1)
        if idx < 0:
            idx = 0
        if idx >= len(px):
            idx = len(px) - 1

        # Locate the major decline: largest peak-to-trough drawdown in the record.
        peak_i = 0
        trough_i = 0
        peak_val = px[0]
        worst_dd = 0.0
        best_peak_i = 0
        best_trough_i = 0
        for i in range(1, len(px)):
            if px[i] > peak_val:
                peak_val = px[i]
                peak_i = i
            denom = abs(peak_val) if peak_val != 0.0 else 1.0
            dd = (peak_val - px[i]) / denom * 100.0
            if dd > worst_dd:
                worst_dd = dd
                best_peak_i = peak_i
                best_trough_i = i

        low_val = px[best_trough_i]
        low_denom = abs(low_val) if low_val != 0.0 else 1.0
        advance_at_accusation_pct = (px[idx] - low_val) / low_denom * 100.0

        has_major_decline = worst_dd >= min_decline_pct

        if not has_major_decline:
            phase = "no_major_decline_in_record"
            classification = "outside_stated_pattern"
            expected = False
            reason = ("The record shows no peak-to-trough decline reaching the "
                      + format(min_decline_pct, ".1f") + "% the test requires (largest was "
                      + format(worst_dd, ".1f")
                      + "%), so no bear market or transition period can be dated; the charge is "
                        "not placed in either phase the chapter names.")
        elif idx <= best_trough_i:
            phase = "bear_market"
            classification = "bear_market_charge"
            expected = True
            reason = ("The accusation was made at index " + str(idx)
                      + ", on or before the low of the major decline at index " + str(best_trough_i)
                      + ": that is a bear market, one of the two phases in which the chapter says "
                        "the charge is always made.")
        elif advance_at_accusation_pct < established_advance_pct:
            phase = "transition_period"
            classification = "transition_period_charge"
            expected = True
            reason = ("The accusation was made at index " + str(idx) + ", after the low of the "
                      "major decline at index " + str(best_trough_i) + " but with the advance from "
                      "that low still only " + format(advance_at_accusation_pct, ".1f")
                      + "% against the " + format(established_advance_pct, ".1f")
                      + "% that marks the succeeding upward movement as established: this is the "
                        "transition period, the second phase the chapter names.")
        else:
            phase = "succeeding_upward_movement_established"
            classification = "outside_stated_pattern"
            expected = False
            reason = ("The accusation was made at index " + str(idx) + ", by which point the "
                      "advance from the low of the major decline was "
                      + format(advance_at_accusation_pct, ".1f") + "%, past the "
                      + format(established_advance_pct, ".1f")
                      + "% that establishes the succeeding upward movement. The chapter says the "
                        "charge is always made in a bear market or in the transition period, so "
                        "this accusation falls outside the stated pattern.")

        result = {
            "classification": classification,
            "market_phase_at_accusation": phase,
            "charge_in_expected_phase": expected,
            "accusation_index": idx,
            "major_decline_low_index": best_trough_i,
            "major_decline_peak_index": best_peak_i,
            "major_decline_pct": round(worst_dd, 4),
            "advance_from_low_at_accusation_pct": round(advance_at_accusation_pct, 4),
            "price_at_accusation": round(px[idx], 4),
            "accusation_period": labels[idx] if idx < len(labels) else None,
            "low_period": labels[best_trough_i] if best_trough_i < len(labels) else None,
            "reason": reason,
        }
        if verbose:
            result["detail"] = {
                "min_decline_pct": min_decline_pct,
                "established_advance_pct": established_advance_pct,
                "peak_period": labels[best_peak_i] if best_peak_i < len(labels) else None,
                "peak_period": labels[best_peak_i] if best_peak_i < len(labels) else None,
                "prices": [round(v, 4) for v in px],
                "rule_quote": "that charge is always made in a bear market and in the transition period between a major decline and its succeeding upward movement",
            }

        return json.dumps({
            "result": result,
            "error": None,
            "metadata": {
                "provenance": {
                    "source_grounded": [
                        "charge always made in a bear market",
                        "charge always made in the transition period between a major decline and its succeeding upward movement",
                        "the chapter's own instance: the charge raised while the 1908 bull market was unpopular",
                    ],
                    "model_extrapolated": [
                        "major decline threshold of 10.0% peak-to-trough",
                        "succeeding upward movement treated as established at a 20.0% advance from the low",
                        "accusation dated by index into the supplied series, defaulting to the last period",
                    ],
                }
            },
        })
    except Exception as exc:
        return json.dumps({
            "result": {
                "classification": "insufficient_data",
                "market_phase_at_accusation": "unknown",
                "charge_in_expected_phase": False,
                "reason": "Could not evaluate the price record: " + str(exc),
            },
            "error": None,
            "metadata": {
                "provenance": {
                    "source_grounded": [
                        "charge always made in a bear market or the transition period",
                    ],
                    "model_extrapolated": ["boundary reading on unusable input"],
                }
            },
        })