"""Test two market averages for agreement in DIRECTION (not strength).

Extends `average_corroboration_check` (chCYCLES AND STOCK MARKET RECORDS):
that tool asks whether two averages corroborate each other; this one applies
the stricter and more specific rule stated in "Forecasting a Bull Market" --
the two averages MAY vary in strength but they will NOT materially vary in
direction -- and it grades the answer by the Dow movement class the observed
move belongs to (binding for major swings, approximate for secondary
reactions and rallies, explicitly NOT true of the daily fluctuation, and
utterly misleading for individual stocks).
"""

import json
import math
from typing import List, Optional

_MAJOR = "major"
_SECONDARY = "secondary"
_DAILY = "daily"
_INDIVIDUAL = "individual_stock"


def _clean_series(values) -> List[float]:
    if not values:
        return []
    out = []
    for v in values:
        try:
            f = float(v)
        except (TypeError, ValueError):
            continue
        if math.isnan(f) or math.isinf(f):
            continue
        out.append(f)
    return out


def _tail(series: List[float], window: Optional[int]) -> List[float]:
    if window is None:
        return list(series)
    try:
        w = int(window)
    except (TypeError, ValueError):
        return list(series)
    if w <= 0 or w >= len(series):
        return list(series)
    return list(series[-w:])


def _direction_and_strength(series: List[float], min_move_pct: float):
    """Three-way reading: up / down / flat. Never folds zero onto a direction."""
    if len(series) < 2:
        return "flat", 0.0
    first = series[0]
    denom = abs(first) if first != 0.0 else 1.0
    pct = (series[-1] - first) / denom * 100.0
    tol = abs(float(min_move_pct))
    if pct > tol:
        direction = "up"
    elif pct < -tol:
        direction = "down"
    else:
        direction = "flat"
    return direction, pct


def _normalise_class(movement_class) -> str:
    raw = str(movement_class if movement_class is not None else _MAJOR).strip().lower()
    if raw in ("major", "primary", "major_swing", "primary_swing"):
        return _MAJOR
    if raw in ("secondary", "secondary_reaction", "secondary_rally", "reaction", "rally"):
        return _SECONDARY
    if raw in ("daily", "daily_fluctuation", "day", "day_to_day"):
        return _DAILY
    if raw in ("individual", "individual_stock", "single_stock", "stock"):
        return _INDIVIDUAL
    return _MAJOR


async def average_direction_not_strength_confirmation_test(
    industrials: List[float],
    railroads: List[float],
    movement_class: str = "major",
    window: Optional[int] = None,
    min_move_pct: float = 0.5,
    verbose: bool = True,
) -> str:
    """Test whether two market averages agree in DIRECTION, not in strength.

    Use when you have two averages (for example the industrial and the railroad
    average) over a common window and you need to know whether a move shown by
    one is confirmed by the other. The chapter's rule is that the averages may
    differ in how far they move but must not materially differ in WHICH WAY
    they move -- and that rule is binding on major swings, only approximately
    true of secondary reactions and rallies, not true of the daily fluctuation,
    and misleading for individual stocks. Pass `movement_class` accordingly.

    Do NOT use this to measure how closely the two averages track each other in
    magnitude or correlation -- strength is explicitly allowed to vary here and
    is reported, never scored against. Do NOT use it for a single stock against
    an average; the chapter says that comparison is misleading.

    Args:
        industrials: price series of the first average (oldest first).
        railroads: price series of the second average over the same window.
        movement_class: "major" | "secondary" | "daily" | "individual_stock".
        window: number of trailing periods to read; None or 0 uses the whole series.
        min_move_pct: percent band inside which a move counts as flat, not directional.
        verbose: False returns the compact verdict; True adds the per-average detail.

    Returns:
        JSON {"result": {...}, "error": None, "metadata": {...}} where result
        carries `direction_agreement`, `confirmation` and `reason`.
    """
    try:
        min_move_pct = 0.5 if min_move_pct is None else float(min_move_pct)
        cls = _normalise_class(movement_class)

        ind = _clean_series(industrials)
        rr = _clean_series(railroads)
        ind_w = _tail(ind, window)
        rr_w = _tail(rr, window)
        common = min(len(ind_w), len(rr_w))
        if common < len(ind_w):
            ind_w = ind_w[-common:] if common else []
        if common < len(rr_w):
            rr_w = rr_w[-common:] if common else []

        ind_dir, ind_pct = _direction_and_strength(ind_w, min_move_pct)
        rr_dir, rr_pct = _direction_and_strength(rr_w, min_move_pct)

        if len(ind_w) < 2 or len(rr_w) < 2:
            agreement = "not_established"
        elif ind_dir == "flat" or rr_dir == "flat":
            agreement = "not_established"
        elif ind_dir == rr_dir:
            agreement = "agree"
        else:
            agreement = "opposed"

        strength_variation = abs(ind_pct - rr_pct)

        if cls == _DAILY:
            confirmation = "rule_not_applicable"
            reason = (
                "The chapter states the direction rule would NOT be true of the daily "
                "fluctuation; agreement or disagreement on a day-to-day move proves nothing."
            )
        elif cls == _INDIVIDUAL:
            confirmation = "rule_not_applicable"
            reason = (
                "The chapter states the direction rule might be utterly misleading for "
                "individual stocks; only two averages may be compared this way."
            )
        elif agreement == "agree":
            confirmation = "confirmed" if cls == _MAJOR else "corroborated_approximately"
            reason = (
                "Both averages moved " + ind_dir + " over the window, so they agree in "
                "direction while differing in strength by " + format(strength_variation, ".2f")
                + " percentage points -- which the chapter expressly permits."
                if cls == _MAJOR else
                "Both averages moved " + ind_dir + " over the window; the chapter holds the "
                "rule only approximately true of secondary reactions and rallies, so this "
                "corroboration is suggestive, not binding."
            )
        elif agreement == "opposed":
            confirmation = "rule_violated_false_signal" if cls == _MAJOR else "weakly_contradicted"
            reason = (
                "The averages moved in opposite directions (" + ind_dir + " vs " + rr_dir +
                ") over a major movement, which the chapter says they will not do; treat the "
                "single-average indication as a false signal."
                if cls == _MAJOR else
                "The averages moved in opposite directions (" + ind_dir + " vs " + rr_dir +
                "); for a secondary reaction or rally the rule holds only approximately, so "
                "do not act on one average alone."
            )
        else:
            confirmation = "inconclusive"
            reason = (
                "At least one average shows no directional move inside the materiality band, "
                "or the two series are too short to compare; there is nothing to confirm yet."
            )

        result = {
            "movement_class": cls,
            "industrial_direction": ind_dir,
            "railroad_direction": rr_dir,
            "direction_agreement": agreement,
            "strength_variation_pct": round(strength_variation, 4),
            "confirmation": confirmation,
            "reason": reason,
        }
        if verbose:
            result["detail"] = {
                "window_used": common,
                "industrial_pct_change": round(ind_pct, 4),
                "railroad_pct_change": round(rr_pct, 4),
                "min_move_pct": min_move_pct,
                "strength_is_scored": False,
                "rule_quote": "may vary in strength but will not materially vary in direction",
            }

        return json.dumps({
            "result": result,
            "error": None,
            "metadata": {
                "provenance": {
                    "source_grounded": [
                        "averages may vary in strength but not materially in direction",
                        "rule is true of major swings",
                        "rule is approximately true of secondary reactions and rallies",
                        "rule is not true of the daily fluctuation",
                        "rule may be utterly misleading for individual stocks",
                    ],
                    "model_extrapolated": [
                        "materiality band min_move_pct = 0.5%",
                        "window over which each average's direction is measured",
                        "confirmation labels per movement class",
                    ],
                }
            },
        })
    except Exception as exc:
        return json.dumps({
            "result": {
                "movement_class": _normalise_class(movement_class),
                "industrial_direction": "flat",
                "railroad_direction": "flat",
                "direction_agreement": "not_established",
                "strength_variation_pct": 0.0,
                "confirmation": "inconclusive",
                "reason": "Could not evaluate the two averages: " + str(exc),
            },
            "error": None,
            "metadata": {
                "provenance": {
                    "source_grounded": ["averages may vary in strength but not materially in direction"],
                    "model_extrapolated": ["materiality band min_move_pct = 0.5%"],
                }
            },
        })