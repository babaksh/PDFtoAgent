import json
from typing import List, Optional


async def detached_review_objective_exit_rule(
    shares: float,
    entry_price: float,
    current_price: float = None,
    price_path: Optional[List[float]] = None,
    adverse_points: float = 2.0,
    reference_shares: float = 1000.0,
    verbose: bool = True,
) -> str:
    """Rule on an immediate exit at a small fixed point loss so as to recover an objective view.

    Use when a position has been taken on analyzed value and the market is NOT moving the way the
    inference said it would, and you must decide whether to take the loss and get out. The rule
    stated in this chapter: the trader took a two-point loss on a thousand shares of stock without
    hesitation if the market did not move his way, because he could not form a correct judgment
    unless he got out and took an objective view.

    Inputs: shares (position size), entry_price, current_price (if omitted the last element of
    price_path is used), price_path (optional observed path since entry, used to read whether the
    market moved as inferred), adverse_points (the fixed point loss, default 2.0 for a
    thousand-share position) and reference_shares (the 1000-share size the stated loss applies to;
    the loss limit is scaled by value, so the same dollar discipline holds for any size).

    The reported `direction` is read from the observed price_path: it is 'up' when the path's net
    change is positive, 'down' when it is negative and 'none' when the observed path did not move
    at all. With no price_path it is read from current_price against entry_price the same three-way
    way, so a market that has not moved never reports a direction.

    Do NOT use this as a trailing stop on a winning position -- the rule fires only against an
    adverse move. Do NOT use it to decide whether a probe purchase showed a public response --
    call probe_purchase_public_response_test instead.
    """

    try:
        n_shares = 0.0 if shares is None else float(shares)
        entry = 0.0 if entry_price is None else float(entry_price)
        limit_pts = 2.0 if adverse_points is None else float(adverse_points)
        ref_shares = 1000.0 if reference_shares is None else float(reference_shares)
        if ref_shares <= 0.0:
            ref_shares = 1000.0

        path = [float(p) for p in (price_path or []) if p is not None]
        if current_price is None:
            current = path[-1] if path else entry
        else:
            current = float(current_price)

        move_points = current - entry
        adverse = max(0.0, entry - current)

        # The direction is the reading of how the market actually moved, so it is taken from the
        # observed price_path when one is supplied (its own net change), and only from the move
        # against entry when no path is given. A window that did not move has no direction.
        if len(path) >= 2:
            observed_move_points = path[-1] - path[0]
        elif len(path) == 1:
            observed_move_points = path[0] - entry
        else:
            observed_move_points = move_points
        if observed_move_points > 0.0:
            direction = "up"
        elif observed_move_points < 0.0:
            direction = "down"
        else:
            direction = "none"

        limit_dollars = limit_pts * ref_shares
        # keep the same dollar discipline for any size: limit in points scales inversely with size
        if n_shares > 0.0:
            scaled_limit_points = limit_dollars / n_shares
        else:
            scaled_limit_points = limit_pts
        loss_dollars = n_shares * adverse
        position_value_dollars = n_shares * entry

        market_moved_his_way = bool(move_points > 0.0)
        stop_hit = bool(adverse >= scaled_limit_points)

        if stop_hit:
            verdict = "exit_now"
            exit_now = True
            reason = (
                "The market has not moved as inferred: the adverse move of %s points (limit %s "
                "points for %s shares) is a loss of %s dollars. Take it without hesitation, get out "
                "and take an objective view -- a correct judgment is impossible while still in the "
                "position." % (_fmt(adverse), _fmt(scaled_limit_points), _fmt(n_shares), _fmt(loss_dollars))
            )
        elif market_moved_his_way:
            verdict = "hold"
            exit_now = False
            reason = (
                "The market has moved his way by %s points: the inference is justified, so there is "
                "no discouragement and no exit. Stay with the position."
                % _fmt(move_points)
            )
        else:
            verdict = "hold_within_limit"
            exit_now = False
            reason = (
                "The market has not moved his way, but the adverse move of %s points is still inside "
                "the %s-point limit for %s shares: hold and watch, and take the loss without "
                "hesitation the moment the limit is reached."
                % (_fmt(adverse), _fmt(scaled_limit_points), _fmt(n_shares))
            )

        compact = {
            "verdict": verdict,
            "exit_now": exit_now,
            "adverse_points": adverse,
            "limit_points": scaled_limit_points,
            "loss_dollars": loss_dollars,
            "direction": direction,
        }
        if not verbose:
            result = compact
        else:
            best = max(path) if path else current
            worst = min(path) if path else current
            result = dict(compact)
            result.update({
                "reason": reason,
                "position": {
                    "shares": n_shares,
                    "entry_price": entry,
                    "current_price": current,
                    "position_value_dollars": position_value_dollars,
                    "move_points": move_points,
                    "open_pl_dollars": n_shares * move_points,
                },
                "exit_rule": {
                    "stated_adverse_points": limit_pts,
                    "reference_shares": ref_shares,
                    "stated_loss_dollars": limit_dollars,
                    "scaled_limit_points": scaled_limit_points,
                    "adverse_points": adverse,
                    "loss_dollars": loss_dollars,
                    "stop_hit": stop_hit,
                    "points_to_exit": max(0.0, scaled_limit_points - adverse),
                },
                "market_reading": {
                    "direction": direction,
                    "observed_move_points": observed_move_points,
                    "market_moved_his_way": market_moved_his_way,
                    "best_price_seen": best,
                    "worst_price_seen": worst,
                    "periods_examined": len(path),
                },
            })

        return json.dumps({
            "result": result,
            "error": None,
            "metadata": {"provenance": {
                "source_grounded": [
                    "take a two-point loss on a thousand shares without hesitation if the market did not move his way",
                    "a correct judgment is impossible unless he got out and took an objective view",
                    "exit fires on the adverse move, not on a favourable one",
                ],
                "model_extrapolated": [
                    "adverse_points default 2.0 and reference_shares default 1000.0",
                    "loss limit scaled by value (two-point x thousand-share dollar loss held constant) for other sizes",
                    "hold_within_limit branch while the adverse move is inside the limit",
                    "current_price falls back to the last price_path value, then to entry_price",
                    "direction read from the net change of the observed price_path (three-way: up/down/none), falling back to the move against entry_price when no path is supplied",
                ],
            }},
        })
    except Exception as exc:  # pragma: no cover - defensive
        return json.dumps({
            "result": None,
            "error": "detached_review_objective_exit_rule failed: %s" % exc,
            "metadata": {"provenance": {
                "source_grounded": [],
                "model_extrapolated": ["error-handling path"],
            }},
        })


def _fmt(x: Optional[float]) -> str:
    return "n/a" if x is None else ("%.2f" % x)