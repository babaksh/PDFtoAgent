import json
import math
from typing import List, Optional


def _as_float(value, default: float) -> float:
    try:
        if value is None:
            return float(default)
        return float(value)
    except (TypeError, ValueError):
        return float(default)


def _sign(points: float) -> str:
    if points > 0.0:
        return "up"
    if points < 0.0:
        return "down"
    return "none"


async def secondary_onset_vs_primary_resumption_speed_rule(
    prices: Optional[List[float]] = None,
    primary_direction: str = "bull",
    turn_index: Optional[int] = None,
    min_abruptness_ratio: float = 1.5,
    verbose: bool = True,
) -> str:
    """Classify a move as the onset of a secondary reaction or the resumption of the major movement by the chapter's tried speed rule.

    Use when the averages have turned and you must say whether the move into the turn
    was the abrupt onset of a secondary reaction, or whether the move out of the turn
    is the slower resumption of the major movement. The chapter states the rule
    directly: the change in the broad general direction of the market is abrupt, while
    the resumption of the major movement is appreciably slower.

    Extends: secondary_swing_duration_asymmetry_test (chMAJOR MARKET SWINGS), which
    measured the decline/recovery duration pair inside a bull primary only. This tool
    states the rule over the abruptness of any single move in BOTH directions -- a
    break in a bull market and a rally in a bear market -- and returns a per-move
    classification.

    Inputs: `prices` is the chronological price path of one average spanning the turn,
    `primary_direction` is 'bull' or 'bear', and `turn_index` is the index of the
    extreme that separates the two legs (defaults to the detected counter-move
    extreme: the low in a bull market, the high in a bear market).

    Do NOT use this to decide whether a move was a secondary movement or only a daily
    fluctuation -- use secondary_vs_daily_movement_duration_bound_test. Do NOT use it
    to decide whether the primary movement has definitely resumed -- use
    secondary_decline_origin_new_high_resumption_test for the conclusive new-top test.
    """
    try:
        series = [_as_float(p, float("nan")) for p in (prices or [])]
        series = [p for p in series if not math.isnan(p)]
        trend = str(primary_direction or "bull").strip().lower()
        is_bear = trend.startswith("bear") or trend in ("down", "decline")
        label = "bear" if is_bear else "bull"
        ratio = _as_float(min_abruptness_ratio, 1.5)
        if ratio < 1.0:
            ratio = 1.0

        def _respond(result):
            return json.dumps({
                "result": result,
                "error": None,
                "metadata": {
                    "tool": "secondary_onset_vs_primary_resumption_speed_rule",
                    "provenance": {
                        "source_grounded": [
                            "change in the broad general direction of the market is abrupt",
                            "resumption of the major movement is appreciably slower",
                            "rule applies to a break in a bull market and a rally in a bear market",
                        ],
                        "model_extrapolated": [
                            "min_abruptness_ratio default of 1.5 for 'appreciably'",
                            "turn_index defaults to the detected counter-move extreme",
                            "speed measured as absolute points per period",
                        ],
                    },
                },
            })

        if len(series) < 3:
            result = {
                "primary_direction": label,
                "classification": "no_evidence",
                "reason": (
                    "fewer than three prices were supplied, so no move and no turn can be "
                    "measured against the abruptness rule"
                ),
                "counter_leg": None,
                "resumption_leg": None,
            }
            if verbose:
                result["prices"] = series
            return _respond(result)

        if turn_index is None:
            target = max(series) if is_bear else min(series)
            turn_index = series.index(target)
        else:
            try:
                turn_index = int(turn_index)
            except (TypeError, ValueError):
                target = max(series) if is_bear else min(series)
                turn_index = series.index(target)
        turn_index = max(0, min(turn_index, len(series) - 1))

        counter_prices = series[:turn_index + 1]
        resumption_prices = series[turn_index:]
        counter_periods = max(1, len(counter_prices) - 1)
        resumption_periods = max(1, len(resumption_prices) - 1)

        counter_points = counter_prices[-1] - counter_prices[0]
        resumption_points = resumption_prices[-1] - resumption_prices[0]
        counter_speed = math.fabs(counter_points) / float(counter_periods)
        resumption_speed = math.fabs(resumption_points) / float(resumption_periods)

        counter_direction = _sign(counter_points)
        resumption_direction = _sign(resumption_points)
        market_moved = any(p != series[0] for p in series)
        expected_counter = ("up" if is_bear else "down") if market_moved else "none"
        expected_resumption = ("down" if is_bear else "up") if market_moved else "none"

        if counter_speed > 0.0 and resumption_speed > 0.0:
            abruptness_ratio = counter_speed / resumption_speed
        else:
            abruptness_ratio = 0.0

        if counter_speed > 0.0:
            counter_verdict = "abrupt"
        else:
            counter_verdict = "flat"

        if resumption_speed > 0.0:
            resumption_verdict = "abrupt"
        else:
            resumption_verdict = "flat"

        if counter_speed > 0.0 and resumption_speed > 0.0:
            if counter_speed >= resumption_speed * ratio:
                counter_verdict = "abrupt"
                resumption_verdict = "slow"
            elif resumption_speed >= counter_speed * ratio:
                counter_verdict = "slow"
                resumption_verdict = "abrupt"
            else:
                counter_verdict = "comparable"
                resumption_verdict = "comparable"

        if counter_verdict == "abrupt" and resumption_verdict == "slow":
            if resumption_direction == expected_resumption:
                classification = "resumption_of_major_movement"
                reason = (
                    "the counter move ran %.2f points per period against a resumption of only "
                    "%.2f points per period in the %s direction, a ratio of %.2f to 1 -- abrupt "
                    "into the turn and appreciably slower out of it, so the move out of the turn "
                    "reads as the resumption of the major movement"
                    % (counter_speed, resumption_speed, expected_resumption, abruptness_ratio)
                )
            else:
                classification = "indeterminate"
                reason = (
                    "the counter move was the more abrupt, but the move out of the turn is still "
                    "in the counter direction (%s), so the major movement has not yet resumed"
                    % resumption_direction
                )
        elif resumption_verdict == "abrupt" and counter_verdict == "slow":
            classification = "onset_of_secondary_reaction"
            reason = (
                "the move out of the turn ran %.2f points per period against only %.2f for the "
                "move into it -- the abrupt change of broad direction is the later move, so it "
                "reads as the onset of a secondary reaction and the major movement has not "
                "resumed" % (resumption_speed, counter_speed)
            )
        elif counter_speed == 0.0 and resumption_speed == 0.0:
            classification = "no_evidence"
            reason = "neither leg of the record moved, so the abruptness rule cannot be applied"
        else:
            classification = "indeterminate"
            reason = (
                "the two legs ran at comparable speeds (%.2f against %.2f points per period); "
                "the rule needs one leg appreciably more abrupt than the other"
                % (counter_speed, resumption_speed)
            )

        counter_leg = {
            "start_price": counter_prices[0],
            "end_price": counter_prices[-1],
            "points": counter_points,
            "periods": counter_periods,
            "speed_points_per_period": counter_speed,
            "direction": counter_direction,
            "expected_direction_for_a_secondary_move": expected_counter,
            "verdict": counter_verdict,
        }
        resumption_leg = {
            "start_price": resumption_prices[0],
            "end_price": resumption_prices[-1],
            "points": resumption_points,
            "periods": resumption_periods,
            "speed_points_per_period": resumption_speed,
            "direction": resumption_direction,
            "expected_direction_for_a_resumption": expected_resumption,
            "verdict": resumption_verdict,
        }

        result = {
            "primary_direction": label,
            "turn_index": turn_index,
            "turn_price": series[turn_index],
            "abruptness_ratio": abruptness_ratio,
            "min_abruptness_ratio": ratio,
            "counter_leg": counter_leg,
            "resumption_leg": resumption_leg,
            "classification": classification,
            "reason": reason,
        }
        if verbose:
            result["prices"] = series
            result["rule"] = (
                "the change in the broad general direction of the market is abrupt, while the "
                "resumption of the major movement is appreciably slower"
            )

        return _respond(result)
    except Exception as exc:  # pragma: no cover - defensive
        return json.dumps({
            "result": None,
            "error": str(exc),
            "metadata": {
                "tool": "secondary_onset_vs_primary_resumption_speed_rule",
                "provenance": {
                    "source_grounded": ["resumption of the major movement is appreciably slower"],
                    "model_extrapolated": ["min_abruptness_ratio default"],
                },
            },
        })