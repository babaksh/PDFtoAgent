import json
from typing import List, Optional


async def probe_purchase_public_response_test(
    probe_shares: float,
    entry_price: float,
    current_price: float,
    baseline_volume: float = 0.0,
    probe_window_volume: float = 0.0,
    observed_follow_through_points: float = 0.0,
    expected_follow_through_points: float = 1.0,
    min_probe_shares: float = 0.0,
    min_volume_response_ratio: float = 1.5,
    abort_loss_points: float = 1.0,
    verbose: bool = True,
) -> str:
    """Test the market with a probe purchase the way Jay Gould did, and rule on holding or abandoning it.

    Use when you have put on (or are sizing) a deliberately sized probe purchase to find out
    whether the investing and speculating public responds as anticipated, and you must decide
    whether to carry the position or abandon it. The procedure stated in this chapter: Gould
    based his position on values and tested the market with purchases of SUFFICIENT stock to show
    whether there was a public response -- whether he had correctly foreseen the public
    appreciation of values. If the response was NOT what he expected he did not hesitate to take
    loss after loss of a point or so, in order to reconsider his position from a detached point of
    view.

    Inputs: probe_shares (size of the probe in shares), entry_price and current_price,
    baseline_volume and probe_window_volume (public trading volume before versus during the
    probe), observed_follow_through_points versus expected_follow_through_points (price
    follow-through in points), min_probe_shares (the size below which the purchase is too small to
    show a response), min_volume_response_ratio (how much public volume must expand to count as a
    response), and abort_loss_points (the 'point or so' at which the probe is abandoned).

    Do NOT use this to measure intraday responses to a leading stock's moves -- call
    public_response_follow_through_test (chDOW'S THEORY, APPLIED TO SPECULATION) instead. Do NOT
    use it for a stop-loss discipline on an ordinary position -- call
    detached_review_objective_exit_rule instead.
    Depends on: public_response_follow_through_test (chDOW'S THEORY, APPLIED TO SPECULATION) --
    this tool adds the deliberately sized probe and the withdrawal-and-reconsider consequence
    when the expected response fails to appear.
    """

    try:
        shares = 0.0 if probe_shares is None else float(probe_shares)
        entry = 0.0 if entry_price is None else float(entry_price)
        current = 0.0 if current_price is None else float(current_price)
        base_vol = 0.0 if baseline_volume is None else float(baseline_volume)
        window_vol = 0.0 if probe_window_volume is None else float(probe_window_volume)
        obs_ft = 0.0 if observed_follow_through_points is None else float(observed_follow_through_points)
        exp_ft = 1.0 if expected_follow_through_points is None else float(expected_follow_through_points)
        min_shares = 0.0 if min_probe_shares is None else float(min_probe_shares)
        min_ratio = 1.5 if min_volume_response_ratio is None else float(min_volume_response_ratio)
        abort_pts = 1.0 if abort_loss_points is None else float(abort_loss_points)

        move_points = current - entry
        loss_points = max(0.0, entry - current)
        pl_dollars = shares * move_points
        loss_dollars = shares * loss_points
        probe_cost_dollars = shares * entry

        # --- the public response: volume expansion and price follow-through
        if base_vol > 0.0 and window_vol > base_vol:
            volume_ratio = window_vol / base_vol
            volume_measured = True
            volume_responded = bool(volume_ratio >= min_ratio)
        else:
            # no baseline supplied: the volume test cannot be measured, so it is not counted
            volume_ratio = None
            volume_measured = False
            volume_responded = None
        follow_through_met = bool(obs_ft >= exp_ft)

        checks = [follow_through_met]
        if volume_measured and volume_responded is not None:
            checks.append(volume_responded)
        response_as_anticipated = bool(all(checks))

        sufficient_size = bool(shares >= min_shares)
        stop_hit = bool(loss_points >= abort_pts)

        if not sufficient_size:
            verdict = "probe_inconclusive"
            exit_now = False
            reason = (
                "The purchase of %s shares is below the %s shares needed to show whether there is a "
                "public response: the test is inconclusive and proves nothing either way."
                % (_fmt(shares), _fmt(min_shares))
            )
        elif response_as_anticipated:
            verdict = "response_anticipated_hold"
            exit_now = False
            reason = (
                "The public responded as anticipated (volume ratio %s against a %s requirement, "
                "follow-through %s points against %s expected): the foreseen appreciation of "
                "values is confirmed and the position stands."
                % (_fmt(volume_ratio), _fmt(min_ratio), _fmt(obs_ft), _fmt(exp_ft))
            )
        elif stop_hit:
            verdict = "abandon_and_reconsider"
            exit_now = True
            reason = (
                "The response was not what was expected and the probe shows a loss of %s points "
                "(at or beyond the %s-point abandonment limit): take the loss of %s dollars without "
                "hesitation and reconsider the position from a detached point of view."
                % (_fmt(loss_points), _fmt(abort_pts), _fmt(loss_dollars))
            )
        else:
            verdict = "response_missing_wait_for_abort"
            exit_now = False
            reason = (
                "The response was not what was expected (follow-through %s points against %s "
                "expected%s) but the loss of %s points is still short of the %s-point abandonment "
                "limit: give the probe until that point or so, then take the loss and reconsider."
                % (
                    _fmt(obs_ft),
                    _fmt(exp_ft),
                    "" if volume_ratio is None else ", volume ratio %s against %s" % (_fmt(volume_ratio), _fmt(min_ratio)),
                    _fmt(loss_points),
                    _fmt(abort_pts),
                )
            )

        compact = {
            "verdict": verdict,
            "exit_now": exit_now,
            "response_as_anticipated": response_as_anticipated,
            "volume_response_ratio": volume_ratio,
            "follow_through_points": obs_ft,
            "loss_points": loss_points,
            "loss_dollars": loss_dollars,
        }
        if not verbose:
            result = compact
        else:
            result = dict(compact)
            result.update({
                "reason": reason,
                "probe": {
                    "probe_shares": shares,
                    "min_probe_shares": min_shares,
                    "sufficient_size": sufficient_size,
                    "entry_price": entry,
                    "current_price": current,
                    "move_points": move_points,
                    "probe_cost_dollars": probe_cost_dollars,
                    "open_pl_dollars": pl_dollars,
                },
                "public_response": {
                    "baseline_volume": base_vol,
                    "probe_window_volume": window_vol,
                    "volume_response_ratio": volume_ratio,
                    "min_volume_response_ratio": min_ratio,
                    "volume_measured": volume_measured,
                    "volume_responded": volume_responded,
                    "observed_follow_through_points": obs_ft,
                    "expected_follow_through_points": exp_ft,
                    "follow_through_met": follow_through_met,
                    "response_as_anticipated": response_as_anticipated,
                },
                "abandonment": {
                    "abort_loss_points": abort_pts,
                    "loss_points": loss_points,
                    "loss_dollars": loss_dollars,
                    "stop_hit": stop_hit,
                    "exit_now": exit_now,
                    "points_to_abandonment": max(0.0, abort_pts - loss_points),
                },
            })

        return json.dumps({
            "result": result,
            "error": None,
            "metadata": {"provenance": {
                "source_grounded": [
                    "test the market with purchases of sufficient stock to show whether there was a public response",
                    "the probe tests whether the public appreciation of values was correctly foreseen",
                    "if the response was not what he expected he would take loss after loss of a point or so",
                    "the loss is taken in order to reconsider the position from a detached point of view",
                ],
                "model_extrapolated": [
                    "'a point or so' set to abort_loss_points=1.0",
                    "public response measured as probe-window volume over baseline volume plus price follow-through in points",
                    "min_volume_response_ratio default 1.5 and expected_follow_through_points default 1.0",
                    "min_probe_shares default 0.0 and the probe_inconclusive reading for a too-small purchase",
                    "response_missing_wait_for_abort branch for a failed response before the loss limit is reached",
                ],
            }},
        })
    except Exception as exc:  # pragma: no cover - defensive
        return json.dumps({
            "result": None,
            "error": "probe_purchase_public_response_test failed: %s" % exc,
            "metadata": {"provenance": {
                "source_grounded": [],
                "model_extrapolated": ["error-handling path"],
            }},
        })


def _fmt(x: Optional[float]) -> str:
    return "n/a" if x is None else ("%.2f" % x)