import json
import math
from typing import List, Optional


def _as_float(value, default: float) -> float:
    try:
        if value is None:
            return float(default)
        return float(value)
    except (TypeError, ValueError):
        return float(default)


def _clean(values) -> List[float]:
    out: List[float] = []
    for v in values or []:
        try:
            f = float(v)
        except (TypeError, ValueError):
            continue
        if math.isnan(f) or math.isinf(f):
            continue
        out.append(f)
    return out


def _as_int(value, default: int) -> int:
    try:
        if value is None:
            return int(default)
        return int(value)
    except (TypeError, ValueError):
        return int(default)


async def line_warning_retraction_rule(
    industrials: Optional[List[float]] = None,
    railroads: Optional[List[float]] = None,
    industrial_line_low: Optional[float] = None,
    railroad_line_low: Optional[float] = None,
    warning_index: Optional[int] = None,
    periods: Optional[List[str]] = None,
    retraction_window_days: int = 1,
    confirmation_window_days: int = 30,
    verbose: bool = True,
) -> str:
    """Rule whether a penetration below a line's lower boundary by one average alone, reversed within one trading day, is a void warning.

    Use when one average has dipped through the lower side of a Dow-theory line and you
    must say whether that is a signal. The chapter's rule is explicit and the 1914 case
    is its worked example: "Only once, on June 25th, did the railroads give a warning at
    one hundred. This was taken back the following day with a continuance of the line in
    both averages up to July 18th in the case of the railroads and July 27th in the case
    of the industrials. At the latter date, eight days before the German army invaded
    Belgium, the industrials confirmed the warning the railroads had given." So a
    penetration by ONE average alone that is reversed within one trading day is a VOID
    warning: the line continues unbroken, and no signal is dated until the second
    average confirms, days or weeks later.

    Extends: line_fractional_penetration_tolerance (chMANIPULATION AND PROFESSIONAL
    TRADING), which judges whether a dip through the lower side of a line is only a
    technical break. This tool adds the explicit one-trading-day retraction window and
    the consequence of a retracted break: the line is not ended, and the dating of the
    signal is deferred until the other average confirms days or weeks later.

    Inputs: `industrials` and `railroads`, the two daily averages across the line and
    its break (give both for the two-average ruling; one alone yields an unconfirmed
    reading); `industrial_line_low` / `railroad_line_low`, each line's lower boundary
    (when omitted the boundary is the running minimum of prior prints, so a warning is
    any print that makes a new low for the series so far); `warning_index`, the index of
    the penetration (when omitted the earliest single-average penetration is found); and
    optionally `periods`, the trading-day labels used to date the signal.
    `retraction_window_days` is how many trading days the break may persist and still be
    taken back; `confirmation_window_days` is how long the second average has to confirm.

    Do NOT use this to measure whether a congestion is a line -- use
    line_dimensions_measurement. Do NOT use it to classify how the line resolved -- use
    line_accumulation_distribution_classifier.
    """
    try:
        ind = _clean(industrials)
        rr = _clean(railroads)
        labels = list(periods) if periods else []
        ret_window = _as_int(retraction_window_days, 1)
        if ret_window < 1:
            ret_window = 1
        conf_window = _as_int(confirmation_window_days, 30)
        if conf_window < 1:
            conf_window = 1

        def _respond(result):
            return json.dumps({
                "result": result,
                "error": None,
                "metadata": {
                    "tool": "line_warning_retraction_rule",
                    "provenance": {
                        "source_grounded": [
                            "a warning given by one average alone",
                            "taken back the following day",
                            "continuance of the line in both averages after the retraction",
                            "the signal is dated only when the second average confirms",
                            "confirmation may come days or weeks later",
                            "worked case: railroads warned at 100 on June 25, retracted June 26",
                            "worked case: industrials confirmed on July 27",
                        ],
                        "model_extrapolated": [
                            "retraction_window_days default of 1 trading day",
                            "confirmation_window_days default of 30 trading days",
                            "line lower boundary defaults to the running minimum of prior prints",
                            "confirmation counted as a further penetration by the other average that is not itself taken back",
                        ],
                    },
                },
            })

        supplied = [s for s in (ind, rr) if s]
        if not supplied:
            return _respond({
                "classification": "no_evidence",
                "warning_given": False,
                "warning_void": None,
                "line_continues": None,
                "signal_dated_index": None,
                "signal_dated_period": None,
                "reason": "no averages were supplied, so no penetration of a line can be ruled on",
            })

        n = min(len(s) for s in supplied)
        ind = ind[:n] if ind else []
        rr = rr[:n] if rr else []

        def _boundary(series, declared, idx):
            if declared is not None:
                try:
                    val = float(declared)
                    if not math.isnan(val):
                        return val
                except (TypeError, ValueError):
                    pass
            prior = series[:idx]
            if not prior:
                return None
            return min(prior)

        def _penetration_indices(series, declared):
            hits = []
            for i in range(1, len(series)):
                boundary = _boundary(series, declared, i)
                if boundary is None:
                    continue
                if series[i] < boundary:
                    hits.append((i, boundary))
            return hits

        ind_hits = _penetration_indices(ind, industrial_line_low) if ind else []
        rr_hits = _penetration_indices(rr, railroad_line_low) if rr else []

        ind_hit_set = set(i for i, _ in ind_hits)
        rr_hit_set = set(i for i, _ in rr_hits)

        if warning_index is None:
            if ind and rr:
                alone = sorted((i for i in (ind_hit_set | rr_hit_set) if not (i in ind_hit_set and i in rr_hit_set)))
                joint = sorted(i for i in ind_hit_set if i in rr_hit_set)
                if alone:
                    chosen = alone[0]
                    joint_warning = False
                elif joint:
                    chosen = joint[0]
                    joint_warning = True
                else:
                    chosen = None
                    joint_warning = False
            else:
                only_hits = ind_hits or rr_hits
                chosen = only_hits[0][0] if only_hits else None
                joint_warning = False
        else:
            chosen = max(0, min(_as_int(warning_index, 0), n - 1))
            joint_warning = bool(ind) and bool(rr) and (chosen in ind_hit_set) and (chosen in rr_hit_set)

        if chosen is None or n < 2:
            return _respond({
                "classification": "no_warning",
                "warning_given": False,
                "warning_index": None,
                "warning_average": None,
                "warning_void": None,
                "line_continues": True,
                "signal_dated_index": None,
                "signal_dated_period": None,
                "reason": "no average penetrated below the lower boundary of its line, so there is no warning to rule on",
            })

        index = chosen
        ind_broke = index in ind_hit_set
        rr_broke = index in rr_hit_set

        if joint_warning or (ind_broke and rr_broke):
            warning_average = "both"
            warning_series = ind if ind else rr
            boundary = _boundary(warning_series, industrial_line_low if ind else railroad_line_low, index)
            retracted = None
            for j in range(index + 1, min(index + ret_window, n - 1) + 1):
                if (ind and rr and ind[j] >= _boundary(ind, industrial_line_low, index)
                        and rr[j] >= _boundary(rr, railroad_line_low, index)):
                    retracted = j
                    break
            single_average_alone = False
        elif ind_broke:
            warning_average = "industrials"
            warning_series = ind
            boundary = _boundary(ind, industrial_line_low, index)
            retracted = None
            for j in range(index + 1, min(index + ret_window, n - 1) + 1):
                if ind[j] >= boundary:
                    retracted = j
                    break
            single_average_alone = True
        else:
            warning_average = "railroads"
            warning_series = rr
            boundary = _boundary(rr, railroad_line_low, index)
            retracted = None
            for j in range(index + 1, min(index + ret_window, n - 1) + 1):
                if rr[j] >= boundary:
                    retracted = j
                    break
            single_average_alone = True

        warning_price = warning_series[index]
        penetration_points = boundary - warning_price if boundary is not None else None

        confirm_index = None
        confirming_average = None
        if single_average_alone and ind and rr:
            other_hits = rr_hits if warning_average == "industrials" else ind_hits
            other_series = rr if warning_average == "industrials" else ind
            other_declared = railroad_line_low if warning_average == "industrials" else industrial_line_low
            for j, _b in other_hits:
                if j <= index:
                    continue
                if j > index + conf_window:
                    break
                ob = _boundary(other_series, other_declared, j)
                taken_back = False
                for k in range(j + 1, min(j + ret_window, n - 1) + 1):
                    if other_series[k] >= ob:
                        taken_back = True
                        break
                if not taken_back:
                    confirm_index = j
                    confirming_average = (
                        "railroads" if warning_average == "industrials" else "industrials"
                    )
                    break

        if single_average_alone and retracted is not None:
            void = True
            line_continues = True
            if confirm_index is not None:
                classification = "void_warning_then_confirmed_break"
                signal_index = confirm_index
                reason = (
                    "the %s penetrated to %.2f, %.2f points below the line's lower boundary of %.2f, "
                    "but took it back on the following trading day (index %d); the line continued "
                    "unbroken until the %s confirmed at index %d, %d trading days later, and that is "
                    "where the signal is dated"
                    % (
                        warning_average, warning_price, penetration_points, boundary,
                        retracted, confirming_average, confirm_index, confirm_index - index,
                    )
                )
            else:
                classification = "void_warning"
                signal_index = None
                reason = (
                    "the %s penetrated to %.2f, %.2f points below the line's lower boundary of %.2f, "
                    "but took it back on the following trading day (index %d), so the warning is void: "
                    "the line continues in both averages and no signal is dated until the second "
                    "average confirms"
                    % (
                        warning_average, warning_price, penetration_points, boundary, retracted,
                    )
                )
        elif single_average_alone:
            void = False
            line_continues = False
            if confirm_index is not None:
                classification = "confirmed_break"
                signal_index = confirm_index
                reason = (
                    "the %s penetrated to %.2f, %.2f points below the boundary of %.2f and did not "
                    "take it back within %d trading day(s); the %s confirmed at index %d, %d trading "
                    "days later, and that is where the signal is dated"
                    % (
                        warning_average, warning_price, penetration_points, boundary, ret_window,
                        confirming_average, confirm_index, confirm_index - index,
                    )
                )
            else:
                classification = "standing_warning_unconfirmed"
                signal_index = None
                reason = (
                    "the %s penetrated to %.2f, %.2f points below the boundary of %.2f and did not "
                    "take it back within %d trading day(s); the second average has not confirmed "
                    "within %d trading days, so the warning stands unconfirmed and the signal is not "
                    "yet dated"
                    % (
                        warning_average, warning_price, penetration_points, boundary, ret_window,
                        conf_window,
                    )
                )
        else:
            void = False
            line_continues = False
            classification = "joint_break_no_single_average_warning"
            signal_index = index
            reason = (
                "both averages penetrated below their line boundaries together at index %d, so this "
                "is not the one-average warning the retraction rule governs; the signal is dated "
                "there and then" % index
            )

        result = {
            "classification": classification,
            "warning_given": True,
            "warning_index": index,
            "warning_period": labels[index] if index < len(labels) else None,
            "warning_average": warning_average,
            "warning_price": warning_price,
            "line_lower_boundary": boundary,
            "penetration_points": penetration_points,
            "single_average_alone": single_average_alone,
            "retracted_within_window": retracted is not None if single_average_alone else False,
            "retraction_index": retracted,
            "retraction_period": labels[retracted] if (retracted is not None and retracted < len(labels)) else None,
            "trading_days_to_retraction": (retracted - index) if retracted is not None else None,
            "warning_void": void,
            "line_continues": line_continues,
            "confirming_average": confirming_average,
            "confirmation_index": confirm_index,
            "confirmation_period": (
                labels[confirm_index] if (confirm_index is not None and confirm_index < len(labels)) else None
            ),
            "trading_days_to_confirmation": (confirm_index - index) if confirm_index is not None else None,
            "signal_dated_index": signal_index,
            "signal_dated_period": (
                labels[signal_index] if (signal_index is not None and signal_index < len(labels)) else None
            ),
            "signal_dated": signal_index is not None,
            "reason": reason,
        }

        if verbose:
            result["thresholds"] = {
                "retraction_window_days": ret_window,
                "confirmation_window_days": conf_window,
            }
            if ind:
                result["industrials"] = ind
            if rr:
                result["railroads"] = rr
            result["rule"] = (
                "a penetration below a line by one average alone, taken back the following day, is a "
                "void warning: the line continues and the signal is dated only when the other average "
                "confirms, days or weeks later"
            )

        return _respond(result)
    except Exception as exc:  # pragma: no cover - defensive
        return json.dumps({
            "result": None,
            "error": str(exc),
            "metadata": {
                "tool": "line_warning_retraction_rule",
                "provenance": {
                    "source_grounded": ["warning taken back the following day is void"],
                    "model_extrapolated": ["retraction_window_days default"],
                },
            },
        })