import json
from typing import List, Optional


def _pivots(prices: List[float], window: int):
    n = len(prices)
    if n < 3:
        return [], []
    highs = []
    lows = []
    for i in range(n):
        lo = max(0, i - window)
        hi = min(n - 1, i + window)
        seg = prices[lo:hi + 1]
        v = prices[i]
        ties = sum(1 for x in seg if x == v)
        if ties == 1 and v == max(seg) and v > min(seg):
            highs.append((i, v))
        if ties == 1 and v == min(seg) and v < max(seg):
            lows.append((i, v))
    return highs, lows


def _dedupe_same_kind(points):
    kept = []
    for i, v in points:
        if kept and i - kept[-1][0] <= 1:
            if v > kept[-1][1]:
                kept[-1] = (i, v)
        else:
            kept.append((i, v))
    return kept


async def double_top_bottom_detector(
    prices: List[float],
    swing_window: int = 3,
    near_top_tolerance_pct: float = 1.5,
    moderate_decline_pct: float = 3.0,
    max_decline_pct: float = 12.0,
    min_recession_pct: float = 2.0,
    verbose: bool = True,
) -> str:
    """Detect Dow's double top or double bottom in a price series.

    Dow, editorial of July 20, 1901: "Records of trading show that in many
    cases when a stock reaches top it will have a moderate decline and then go
    back again to near the highest figures. If after such a move, the price
    again recedes, it is liable to decline some distance." The same sequence
    inverted (a bottom, a moderate rally, a return near the lowest figures,
    then another advance) gives the double bottom.

    Dow's own caveats are carried in the output: "Those, however, who attempt
    to trade on this theory alone find a good many exceptions and a good many
    times when signals are not given."

    Use when you have a price series for one stock and want the sequence
    top -> moderate decline -> return near the high -> second recession, which
    is the signal that the price is liable to decline some distance.

    Do NOT use on two market averages looking for a narrow horizontal band --
    that is `line_formation_breakout` (chCYCLES AND STOCK MARKET RECORDS); a
    double top is a two-peak formation with a decline between them, not a
    sustained "line".
    """
    provenance = {
        "source_grounded": [
            "sequence: a top, a moderate decline, a return to near the highest figures, then another recession",
            "consequence: if after such a move the price again recedes, it is liable to decline some distance",
            "double bottom is the same formation inverted",
            "caveat: many exceptions and many times when signals are not given",
        ],
        "model_extrapolated": [
            "near_top_tolerance_pct = 1.5 for 'near the highest figures'",
            "moderate_decline_pct = 3.0 as the minimum decline between the two tops",
            "max_decline_pct = 12.0 as the limit beyond which the decline is no longer 'moderate'",
            "min_recession_pct = 2.0 for the second recession that confirms the formation",
            "swing_window = 3 periods for identifying pivot highs and lows",
            "a missing confirmation is reported as 'no_signal_given', echoing Dow's caveat",
        ],
    }
    try:
        series = [0.0 if p is None else float(p) for p in (prices or [])]
        window = 3 if swing_window is None else int(swing_window)
        if window < 1:
            window = 1
        near = 1.5 if near_top_tolerance_pct is None else float(near_top_tolerance_pct)
        mod = 3.0 if moderate_decline_pct is None else float(moderate_decline_pct)
        maxdec = 12.0 if max_decline_pct is None else float(max_decline_pct)
        minrec = 2.0 if min_recession_pct is None else float(min_recession_pct)

        highs, lows = _pivots(series, window)
        highs = _dedupe_same_kind(highs)
        lows = _dedupe_same_kind([(i, -v) for i, v in lows])
        lows = [(i, -v) for i, v in lows]

        formations = []
        # double tops
        for k in range(len(highs) - 1):
            i1, p1 = highs[k]
            i2, p2 = highs[k + 1]
            if p2 > p1 * (1.0 + near / 100.0):
                continue
            if p2 < p1 * (1.0 - near / 100.0):
                continue
            intervening = [(i, v) for i, v in lows if i1 < i < i2]
            if not intervening:
                continue
            trough_i, trough_v = min(intervening, key=lambda t: t[1])
            decline_pct = (p1 - trough_v) / p1 * 100.0 if p1 != 0.0 else 0.0
            if decline_pct < mod or decline_pct > maxdec:
                continue
            after = series[trough_i:i2 + 1]
            retrace_pct = (p2 - trough_v) / trough_v * 100.0 if trough_v != 0.0 else 0.0
            tail = series[i2:]
            lowest_after = min(tail) if tail else p2
            recession_pct = (p2 - lowest_after) / p2 * 100.0 if p2 != 0.0 else 0.0
            confirmed = recession_pct >= minrec
            formations.append({
                "kind": "double_top",
                "first_extreme_index": i1,
                "first_extreme_price": p1,
                "intervening_extreme_index": trough_i,
                "intervening_extreme_price": trough_v,
                "second_extreme_index": i2,
                "second_extreme_price": p2,
                "moderate_decline_pct": decline_pct,
                "retrace_pct": retrace_pct,
                "second_move_pct": recession_pct,
                "confirmed": confirmed,
            })
        # double bottoms
        for k in range(len(lows) - 1):
            i1, p1 = lows[k]
            i2, p2 = lows[k + 1]
            if p2 < p1 * (1.0 - near / 100.0):
                continue
            if p2 > p1 * (1.0 + near / 100.0):
                continue
            intervening = [(i, v) for i, v in highs if i1 < i < i2]
            if not intervening:
                continue
            peak_i, peak_v = max(intervening, key=lambda t: t[1])
            rally_pct = (peak_v - p1) / p1 * 100.0 if p1 != 0.0 else 0.0
            if rally_pct < mod or rally_pct > maxdec:
                continue
            retrace_pct = (p2 - peak_v) / peak_v * 100.0 if peak_v != 0.0 else 0.0
            tail = series[i2:]
            highest_after = max(tail) if tail else p2
            advance_pct = (highest_after - p2) / p2 * 100.0 if p2 != 0.0 else 0.0
            confirmed = advance_pct >= minrec
            formations.append({
                "kind": "double_bottom",
                "first_extreme_index": i1,
                "first_extreme_price": p1,
                "intervening_extreme_index": peak_i,
                "intervening_extreme_price": peak_v,
                "second_extreme_index": i2,
                "second_extreme_price": p2,
                "moderate_decline_pct": rally_pct,
                "retrace_pct": retrace_pct,
                "second_move_pct": advance_pct,
                "confirmed": confirmed,
            })

        formations.sort(key=lambda f: f["second_extreme_index"])
        confirmed_forms = [f for f in formations if f["confirmed"]]

        if confirmed_forms:
            f = confirmed_forms[-1]
            detection = "confirmed"
            if f["kind"] == "double_top":
                expected_direction = "down"
                reason = ("A top at %.2f, a moderate decline of %.2f%%, a return to %.2f near "
                          "the highest figures, and a further recession of %.2f%%: the price is "
                          "liable to decline some distance."
                          % (f["first_extreme_price"], f["moderate_decline_pct"],
                             f["second_extreme_price"], f["second_move_pct"]))
            else:
                expected_direction = "up"
                reason = ("A bottom at %.2f, a moderate rally of %.2f%%, a return to %.2f near "
                          "the lowest figures, and a further advance of %.2f%%: the price is "
                          "liable to rise some distance."
                          % (f["first_extreme_price"], f["moderate_decline_pct"],
                             f["second_extreme_price"], f["second_move_pct"]))
        elif formations:
            f = formations[-1]
            detection = "formation_without_confirmation"
            expected_direction = "none"
            reason = ("The %s formed (two extremes at %.2f and %.2f with a %.2f%% move between "
                      "them) but the price has not yet receded from the second extreme; no "
                      "signal is given yet."
                      % (f["kind"], f["first_extreme_price"], f["second_extreme_price"],
                         f["moderate_decline_pct"]))
        else:
            detection = "not_detected"
            expected_direction = "none"
            reason = ("No double top or double bottom was found: the series did not show a top "
                      "(bottom), a moderate decline (rally), a return near the highest (lowest) "
                      "figures and a further recession (advance). Often no signal is given at all.")

        result = {
            "detection": detection,
            "expected_direction": expected_direction,
            "reason": reason,
            "num_formations": len(formations),
            "num_confirmed": len(confirmed_forms),
            "latest_formation_kind": (confirmed_forms[-1]["kind"] if confirmed_forms
                                      else (formations[-1]["kind"] if formations else None)),
            "latest_second_extreme_price": (confirmed_forms[-1]["second_extreme_price"]
                                            if confirmed_forms else
                                            (formations[-1]["second_extreme_price"] if formations else None)),
            "latest_second_move_pct": (confirmed_forms[-1]["second_move_pct"]
                                       if confirmed_forms else
                                       (formations[-1]["second_move_pct"] if formations else None)),
        }
        if verbose:
            result["formations"] = formations
            result["num_pivot_highs"] = len(highs)
            result["num_pivot_lows"] = len(lows)
            result["params"] = {
                "swing_window": window,
                "near_top_tolerance_pct": near,
                "moderate_decline_pct": mod,
                "max_decline_pct": maxdec,
                "min_recession_pct": minrec,
            }
            result["caveat"] = ("Those who attempt to trade on this theory alone find a good "
                                "many exceptions and a good many times when signals are not given.")
        return json.dumps({"result": result, "error": None,
                           "metadata": {"provenance": provenance}})
    except Exception as exc:
        return json.dumps({"result": None, "error": str(exc),
                           "metadata": {"provenance": provenance}})