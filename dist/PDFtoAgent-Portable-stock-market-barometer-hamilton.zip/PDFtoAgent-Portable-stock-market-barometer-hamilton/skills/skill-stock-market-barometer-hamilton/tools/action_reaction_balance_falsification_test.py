import json
from typing import Dict, List, Optional

_PROVENANCE = {
    "source_grounded": [
        "action and reaction are equal premise tested on recorded swings",
        "no bull market advance is offset by an exactly corresponding decline",
        "the failure holds still more of the time consumed than of the extent",
        "bull markets are as a rule materially longer in duration than bear markets",
        "no approximation to pendulum regularity in the arc of the swing or its velocity",
        "chapter record: -40, +50, -60, +45, -30, +20, +60 points, different period each",
    ],
    "model_extrapolated": [
        "balance_tolerance_pct default 10.0",
        "pairing rule: each advance paired with the next following decline",
        "deviation measured as |ratio - 1| in percent",
        "regularity judged from the spread of ratios across pairs",
        "zero-extent and zero-duration pairs excluded from the means and counted apart",
    ],
}


def _meta() -> dict:
    return {"provenance": _PROVENANCE}


def _num(d: dict, keys, default=None):
    for k in keys:
        if k in d and d[k] is not None:
            try:
                return float(d[k])
            except (TypeError, ValueError):
                return default
    return default


def _dir(d: dict) -> str:
    raw = str(d.get("direction", "")).strip().lower()
    if raw in ("up", "bull", "advance", "advance_up", "rising", "+"):
        return "up"
    if raw in ("down", "bear", "decline", "declining", "-"):
        return "down"
    if "bull" in raw or "advance" in raw or raw.startswith("up"):
        return "up"
    if "bear" in raw or "declin" in raw or raw.startswith("down"):
        return "down"
    return "unknown"


async def action_reaction_balance_falsification_test(
    swings: List[Dict],
    balance_tolerance_pct: float = 10.0,
    verbose: bool = True,
) -> str:
    """Test the premise that action and reaction are equal over successive major swings.

    Use when you have a table of successive major market swings, each with its extent
    in points and its duration, and want to know whether a balancing equation holds.
    Each advance is paired against the decline that follows it and compared twice --
    once in extent (the arc) and once in time consumed (the velocity) -- and the tool
    reports whether the equality fails, and whether it fails still more in time than
    in extent, as the chapter says it must.

    Do NOT use for Babson's composite area/depth/duration balance of a single chart
    area -- call babson_area_depth_duration_balance_test (chA UNIQUE QUALITY OF
    FORECAST) instead; this tool tests paired swings separately in extent and time.
    """
    try:
        tol = 10.0 if balance_tolerance_pct is None else float(balance_tolerance_pct)

        rows = []
        for d in swings or []:
            if not isinstance(d, dict):
                continue
            rows.append(
                {
                    "direction": _dir(d),
                    "extent_points": _num(d, ("extent_points", "extent", "points")),
                    "duration_months": _num(
                        d, ("duration_months", "duration", "months", "duration_years")
                    ),
                    "label": d.get("label", d.get("period", None)),
                }
            )

        up_ext = [r["extent_points"] for r in rows if r["direction"] == "up" and r["extent_points"] is not None]
        dn_ext = [r["extent_points"] for r in rows if r["direction"] == "down" and r["extent_points"] is not None]
        up_dur = [r["duration_months"] for r in rows if r["direction"] == "up" and r["duration_months"] is not None]
        dn_dur = [r["duration_months"] for r in rows if r["direction"] == "down" and r["duration_months"] is not None]

        pairs = []
        n_degenerate = 0
        for i, adv in enumerate(rows):
            if adv["direction"] != "up":
                continue
            react = None
            for j in range(i + 1, len(rows)):
                if rows[j]["direction"] == "down":
                    react = rows[j]
                    break
            if react is None:
                continue

            a_ext = adv["extent_points"]
            d_ext = react["extent_points"]
            a_dur = adv["duration_months"]
            d_dur = react["duration_months"]

            ext_ratio = None
            ext_dev = None
            ext_bal = False
            if a_ext is not None and d_ext is not None and a_ext != 0:
                ext_ratio = d_ext / a_ext
                ext_dev = abs(ext_ratio - 1.0) * 100.0
                ext_bal = ext_dev <= tol

            dur_ratio = None
            dur_dev = None
            dur_bal = False
            if a_dur is not None and d_dur is not None and a_dur != 0:
                dur_ratio = d_dur / a_dur
                dur_dev = abs(dur_ratio - 1.0) * 100.0
                dur_bal = dur_dev <= tol

            if (a_ext is None or d_ext is None or a_ext == 0) or (
                a_dur is None or d_dur is None or a_dur == 0
            ):
                n_degenerate += 1

            pairs.append(
                {
                    "advance_label": adv["label"],
                    "reaction_label": react["label"],
                    "advance_extent_points": a_ext,
                    "reaction_extent_points": d_ext,
                    "extent_ratio": ext_ratio,
                    "extent_deviation_pct": ext_dev,
                    "extent_balanced": ext_bal,
                    "advance_duration": a_dur,
                    "reaction_duration": d_dur,
                    "duration_ratio": dur_ratio,
                    "duration_deviation_pct": dur_dev,
                    "duration_balanced": dur_bal,
                }
            )

        ext_devs = [p["extent_deviation_pct"] for p in pairs if p["extent_deviation_pct"] is not None]
        dur_devs = [p["duration_deviation_pct"] for p in pairs if p["duration_deviation_pct"] is not None]
        mean_ext_dev = sum(ext_devs) / len(ext_devs) if ext_devs else 0.0
        mean_dur_dev = sum(dur_devs) / len(dur_devs) if dur_devs else 0.0

        ext_ratios = [p["extent_ratio"] for p in pairs if p["extent_ratio"] is not None]
        dur_ratios = [p["duration_ratio"] for p in pairs if p["duration_ratio"] is not None]
        arc_spread = (max(ext_ratios) - min(ext_ratios)) * 100.0 if ext_ratios else 0.0
        vel_spread = (max(dur_ratios) - min(dur_ratios)) * 100.0 if dur_ratios else 0.0

        n_ext_bal = sum(1 for p in pairs if p["extent_balanced"])
        n_dur_bal = sum(1 for p in pairs if p["duration_balanced"])
        n_pairs = len(pairs)

        if n_pairs == 0:
            verdict = "insufficient_record"
        elif n_ext_bal == n_pairs and n_dur_bal == n_pairs:
            verdict = "balance_holds"
        else:
            verdict = "no_balancing_equation"

        time_worse_than_extent = bool(ext_devs and dur_devs and mean_dur_dev > mean_ext_dev)

        mean_up_dur = sum(up_dur) / len(up_dur) if up_dur else None
        mean_dn_dur = sum(dn_dur) / len(dn_dur) if dn_dur else None
        if mean_up_dur is None or mean_dn_dur is None:
            duration_comparison = "unmeasurable"
        elif mean_up_dur > mean_dn_dur:
            duration_comparison = "bull_longer"
        elif mean_up_dur < mean_dn_dur:
            duration_comparison = "bear_longer"
        else:
            duration_comparison = "equal"
        bull_longer_than_bear = duration_comparison == "bull_longer"

        arc_regular = bool(ext_ratios) and arc_spread <= tol
        velocity_regular = bool(dur_ratios) and vel_spread <= tol
        pendulum_regularity = bool(arc_regular and velocity_regular)

        if verdict == "insufficient_record":
            reason = (
                "no advance was followed by a decline in the record supplied, so the "
                "balancing equation cannot be tested"
            )
        elif verdict == "balance_holds":
            reason = (
                "every advance was matched by its following decline in both extent and "
                "time within %.1f%%" % tol
            )
        else:
            reason = (
                "%d of %d paired swings fail equality in extent (mean deviation %.1f%%) "
                "and the failure is larger in time consumed (%.1f%%) -> no balancing "
                "equation" % (n_pairs - n_ext_bal, n_pairs, mean_ext_dev, mean_dur_dev)
            )

        payload = {
            "n_swings": len(rows),
            "n_pairs": n_pairs,
            "n_extent_balanced": n_ext_bal,
            "n_duration_balanced": n_dur_bal,
            "mean_extent_deviation_pct": mean_ext_dev,
            "mean_duration_deviation_pct": mean_dur_dev,
            "time_deviation_exceeds_extent_deviation": time_worse_than_extent,
            "duration_comparison": duration_comparison,
            "bull_longer_than_bear": bull_longer_than_bear,
            "arc_regularity_pct_spread": arc_spread,
            "velocity_regularity_pct_spread": vel_spread,
            "pendulum_regularity": pendulum_regularity,
            "verdict": verdict,
            "balance_tolerance_pct": tol,
            "n_degenerate_pairs": n_degenerate,
            "mean_advance_duration": mean_up_dur,
            "mean_decline_duration": mean_dn_dur,
            "pairs": pairs,
            "reason": reason,
        }
        if not verbose:
            payload = {
                k: payload[k]
                for k in (
                    "n_swings",
                    "n_pairs",
                    "n_extent_balanced",
                    "n_duration_balanced",
                    "mean_extent_deviation_pct",
                    "mean_duration_deviation_pct",
                    "time_deviation_exceeds_extent_deviation",
                    "duration_comparison",
                    "bull_longer_than_bear",
                    "n_degenerate_pairs",
                    "pendulum_regularity",
                    "verdict",
                )
            }
        return json.dumps({"result": payload, "error": None, "metadata": _meta()})
    except Exception as exc:  # noqa: BLE001 - contract requires a reading, never a raise
        return json.dumps(
            {
                "result": {"verdict": "indeterminate", "reason": str(exc)},
                "error": None,
                "metadata": _meta(),
            }
        )