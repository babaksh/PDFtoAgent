import json
import math
from typing import List, Optional


def _as_float(value, default: float) -> float:
    try:
        if value is None:
            return float(default)
        return float(value)
    except (TypeError, ValueError):
        return float(default)


def _clean(values) -> List[float]:
    out: List[float] = []
    for v in values or []:
        try:
            f = float(v)
        except (TypeError, ValueError):
            continue
        if math.isnan(f) or math.isinf(f):
            continue
        out.append(f)
    return out


def _as_int(value, default: int) -> int:
    try:
        if value is None:
            return int(default)
        return int(value)
    except (TypeError, ValueError):
        return int(default)


async def manipulation_scope_public_sentiment_limit(
    move_pct: float = 0.0,
    duration_periods: int = 0,
    issues_affected: int = 1,
    market_prices: Optional[List[float]] = None,
    earnings: Optional[List[float]] = None,
    volume_of_trade: Optional[List[float]] = None,
    max_group_issues: int = 5,
    daily_max_periods: int = 5,
    primary_min_periods: int = 60,
    primary_min_move_pct: float = 10.0,
    min_merit_move_pct: float = 1.0,
    lookback_periods: int = 10,
    verbose: bool = True,
) -> str:
    """Rule whether a claimed manipulation could account for an observed move, given its breadth, the market's own trend, and public sentiment.

    Use when someone attributes a rise (or a supported market) to manipulation and you
    must rule on the claim. The chapter answers the question "Who makes the market?" by
    dismissing the manipulators, the issuing houses, the floor traders and the operators:
    "The market is made by the saving, investing public of the whole United States,
    first, last and all the time. There is no possible financial combination which can
    manipulate a bull market, by propaganda or in any other way, when the combined
    intelligence of the investing public sees that it is time to curtail their
    commitments in view of a coming decline in prices, earnings and the volume of trade.
    The most an expert manipulator can do is to stimulate activity in a particular stock,
    or a small group in a market which is already rising on its merits, with the approval
    of public sentiment." Three conditions therefore bound any possible manipulation: the
    move must be confined to a single issue or a small group; the market must already be
    rising on its merits; and public sentiment must approve -- and sentiment no
    combination can override. A move of primary magnitude and duration fails outright,
    because "no possible financial combination can manipulate a bull market".

    Extends: manipulation_scope_by_movement_classifier (chMECHANICS OF THE MARKET),
    which classifies a move by its Dow movement class and its breadth. This tool adds
    the two conditions the earlier chapter never named: the move must already be going
    with the trend on its merits, and it must have the approval of public sentiment,
    which no combination can override.

    Inputs: `move_pct`, the size of the move in percent; `duration_periods`, how many
    periods it took; `issues_affected`, how many issues moved; and the three series
    public sentiment is read from -- `market_prices`, `earnings`, and `volume_of_trade`
    (all chronological). `max_group_issues` bounds what still counts as a "small group";
    `daily_max_periods` separates a mere daily fluctuation from a longer move,
    `primary_min_periods` and `primary_min_move_pct` mark a move of primary magnitude,
    which no combination can produce; `min_merit_move_pct` is how much the broad market
    must already have risen for it to count as rising on its merits; `lookback_periods`
    is the window over which the trend of prices, earnings and trade is read.

    Do NOT use this to judge whether a single stock's move was manipulative on volume
    evidence -- use manipulation_implausibility_from_narrow_volume_test. Do NOT use it
    to classify a move's Dow movement class alone -- use
    manipulation_scope_by_movement_classifier.
    """
    try:
        move = _as_float(move_pct, 0.0)
        periods = _as_int(duration_periods, 0)
        if periods < 0:
            periods = 0
        issues = _as_int(issues_affected, 1)
        if issues < 0:
            issues = 0
        group_max = _as_int(max_group_issues, 5)
        if group_max < 1:
            group_max = 1
        daily_max = _as_int(daily_max_periods, 5)
        if daily_max < 1:
            daily_max = 1
        primary_periods = _as_int(primary_min_periods, 60)
        if primary_periods < 1:
            primary_periods = 1
        primary_move = _as_float(primary_min_move_pct, 10.0)
        if primary_move < 0.0:
            primary_move = 0.0
        merit_pct = _as_float(min_merit_move_pct, 1.0)
        if merit_pct < 0.0:
            merit_pct = 0.0
        lookback = _as_int(lookback_periods, 10)
        if lookback < 2:
            lookback = 2

        prices = _clean(market_prices)
        earns = _clean(earnings)
        trade = _clean(volume_of_trade)

        def _respond(result):
            return json.dumps({
                "result": result,
                "error": None,
                "metadata": {
                    "tool": "manipulation_scope_public_sentiment_limit",
                    "provenance": {
                        "source_grounded": [
                            "the market is made by the saving investing public, first, last and all the time",
                            "no financial combination can manipulate a bull market by propaganda or otherwise when the public curtails commitments",
                            "the most a manipulator can do is stimulate activity in a particular stock or a small group",
                            "the market must already be rising on its merits",
                            "the approval of public sentiment is required",
                            "sentiment is read from a coming decline in prices, earnings and the volume of trade",
                        ],
                        "model_extrapolated": [
                            "max_group_issues default of 5 issues for a 'small group'",
                            "daily_max_periods default of 5 for a mere daily fluctuation",
                            "primary_min_periods default of 60 and primary_min_move_pct default of 10 percent for a primary move",
                            "min_merit_move_pct default of 1 percent for 'rising on its merits'",
                            "lookback_periods default of 10 for reading prices, earnings and trade",
                            "sentiment counted as approving when prices, earnings and volume of trade are all not falling",
                        ],
                    },
                },
            })

        if periods <= daily_max:
            movement_class = "daily"
        elif periods >= primary_periods and abs(move) >= primary_move:
            movement_class = "primary"
        else:
            movement_class = "secondary"

        def _trend_pct(series, window):
            if len(series) < 2:
                return None, "unmeasured"
            segment = series[-window:] if window > 0 else series
            if len(segment) < 2:
                segment = series
            first = segment[0]
            last = segment[-1]
            if first == 0.0:
                return None, "unmeasured"
            change = (last - first) / abs(first) * 100.0
            if change > 0.0:
                return change, "up"
            if change < 0.0:
                return change, "down"
            return 0.0, "none"

        price_pct, price_dir = _trend_pct(prices, lookback)
        earn_pct, earn_dir = _trend_pct(earns, lookback)
        trade_pct, trade_dir = _trend_pct(trade, lookback)

        measured = [d for d in (price_dir, earn_dir, trade_dir) if d != "unmeasured"]
        if not measured:
            sentiment = "unmeasured"
            sentiment_approves = None
        elif any(d == "down" for d in measured):
            sentiment = "against"
            sentiment_approves = False
        elif all(d == "up" for d in measured):
            sentiment = "approving"
            sentiment_approves = True
        else:
            sentiment = "neutral"
            sentiment_approves = True

        market_rising = price_dir == "up" and price_pct is not None and price_pct >= merit_pct
        if price_pct is None:
            merit_reading = "unmeasured"
        elif market_rising:
            merit_reading = "rising_on_merits"
        elif price_dir == "up":
            merit_reading = "rising_below_merit_threshold"
        elif price_dir == "none":
            merit_reading = "flat"
        else:
            merit_reading = "falling"

        breadth_ok = 1 <= issues <= group_max
        if issues <= 0:
            breadth_reading = "no_issues"
        elif issues == 1:
            breadth_reading = "single_issue"
        elif breadth_ok:
            breadth_reading = "small_group"
        else:
            breadth_reading = "market_wide"

        could_account = bool(
            movement_class != "primary"
            and breadth_ok
            and market_rising
            and sentiment_approves is True
        )

        if movement_class == "primary":
            classification = "not_accountable_primary_movement"
            reason = (
                "the move runs %.2f percent over %d periods, of primary magnitude and duration, and "
                "there is no possible financial combination which can manipulate a bull market; the "
                "market is made by the saving, investing public" % (move, periods)
            )
        elif not breadth_ok:
            classification = "not_accountable_market_wide_move"
            reason = (
                "the move spans %d issues, outside the single issue or %d issue small group a "
                "manipulator can stimulate, so no combination of manipulators accounts for it: the "
                "market is made by the saving, investing public" % (issues, group_max)
            )
        elif not market_rising:
            classification = "not_accountable_market_not_rising_on_merits"
            reason = (
                "the broad market is %s over the last %d periods (%.2f percent against a %.2f percent "
                "merit threshold), so this is not activity in a market already rising on its merits "
                "and manipulation cannot account for it"
                % (merit_reading, lookback, price_pct if price_pct is not None else 0.0, merit_pct)
            )
        elif sentiment_approves is not True:
            classification = "not_accountable_public_sentiment_against"
            reason = (
                "public sentiment reads %s from prices (%s), earnings (%s) and the volume of trade "
                "(%s); when the investing public sees a coming decline in prices, earnings and trade "
                "no financial combination can manipulate a bull market"
                % (sentiment, price_dir, earn_dir, trade_dir)
            )
        else:
            classification = "accountable_within_limits"
            reason = (
                "the move is confined to %d issue(s), it is only a %s movement of %.2f percent over %d "
                "periods, the market has already risen %.2f percent over %d periods on its merits, and "
                "public sentiment approves on prices, earnings and the volume of trade, so an expert "
                "manipulator could at most stimulate activity here"
                % (issues, movement_class, move, periods, price_pct, lookback)
            )

        result = {
            "move_pct": move,
            "duration_periods": periods,
            "movement_class": movement_class,
            "issues_affected": issues,
            "breadth_reading": breadth_reading,
            "breadth_within_manipulable_scope": breadth_ok,
            "market_price_change_pct": price_pct,
            "market_trend_direction": price_dir,
            "rising_on_merits_reading": merit_reading,
            "market_rising_on_merits": market_rising,
            "earnings_change_pct": earn_pct,
            "earnings_direction": earn_dir,
            "volume_of_trade_change_pct": trade_pct,
            "volume_of_trade_direction": trade_dir,
            "public_sentiment": sentiment,
            "public_sentiment_approves": sentiment_approves,
            "manipulation_could_account": could_account,
            "classification": classification,
            "reason": reason,
        }

        if verbose:
            result["thresholds"] = {
                "max_group_issues": group_max,
                "daily_max_periods": daily_max,
                "primary_min_periods": primary_periods,
                "primary_min_move_pct": primary_move,
                "min_merit_move_pct": merit_pct,
                "lookback_periods": lookback,
            }
            result["rule"] = (
                "the most an expert manipulator can do is stimulate activity in a particular stock, "
                "or a small group in a market already rising on its merits, with the approval of "
                "public sentiment; no possible financial combination can manipulate a bull market"
            )
            if prices:
                result["market_prices"] = prices
            if earns:
                result["earnings"] = earns
            if trade:
                result["volume_of_trade"] = trade

        return _respond(result)
    except Exception as exc:  # pragma: no cover - defensive
        return json.dumps({
            "result": None,
            "error": str(exc),
            "metadata": {
                "tool": "manipulation_scope_public_sentiment_limit",
                "provenance": {
                    "source_grounded": [
                        "manipulation limited to a particular stock or small group",
                        "approval of public sentiment required",
                    ],
                    "model_extrapolated": ["max_group_issues default"],
                },
            },
        })