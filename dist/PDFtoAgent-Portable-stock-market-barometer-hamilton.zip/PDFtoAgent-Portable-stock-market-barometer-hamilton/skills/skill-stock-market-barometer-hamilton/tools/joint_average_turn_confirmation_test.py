import json
from typing import List, Optional


async def joint_average_turn_confirmation_test(
    industrials: List[float],
    railroads: List[float],
    industrial_bear_low: float,
    railroad_bear_low: float,
    industrial_rally_high: Optional[float] = None,
    railroad_rally_high: Optional[float] = None,
    industrial_penetration_points: float = 8.0,
    railroad_penetration_points: float = 9.0,
    min_new_high_points: float = 0.0,
    verbose: bool = True,
) -> str:
    """Decide whether a primary market movement has resumed or reversed from TWO averages jointly.

    Use when you have price paths of the industrial average and the railroad average since a
    dated bear low and you must decide whether the main bear movement has RESUMED or a primary
    bull market has been CONFIRMED. Dow's rule as stated in this chapter: the averages must
    confirm each other -- a resumption of the bear movement requires BOTH averages to decline
    below the recorded bear low by their OWN stated amounts (eight points in the industrials,
    nine points in the railroads), while a primary bull market requires a REPEATED NEW HIGH
    recorded by BOTH averages. One average alone never confirms.

    Inputs: industrials / railroads (price series covering the period under test),
    industrial_bear_low / railroad_bear_low (the low figures of the main bear movement, e.g.
    64.90 industrials and 65.52 railroads on June 20, 1921), industrial_rally_high /
    railroad_rally_high (the highs of the previous rally that a repeated new high must exceed),
    and the two penetration distances in points.

    Do NOT use this to test corroboration generally -- call average_corroboration_check
    (chCYCLES AND STOCK MARKET RECORDS) instead. Do NOT use it for a single average; the joint
    requirement is the whole point. Depends on: average_corroboration_check (chCYCLES AND
    STOCK MARKET RECORDS) -- this tool adds the joint new-extreme condition and gives each
    average its own penetration distance in points from the dated low.
    """

    try:
        ind = [float(p) for p in (industrials or []) if p is not None]
        rr = [float(p) for p in (railroads or []) if p is not None]

        ind_low = None if industrial_bear_low is None else float(industrial_bear_low)
        rr_low = None if railroad_bear_low is None else float(railroad_bear_low)
        ind_req = 8.0 if industrial_penetration_points is None else float(industrial_penetration_points)
        rr_req = 9.0 if railroad_penetration_points is None else float(railroad_penetration_points)
        min_nh = 0.0 if min_new_high_points is None else float(min_new_high_points)

        ind_rally = None if industrial_rally_high is None else float(industrial_rally_high)
        rr_rally = None if railroad_rally_high is None else float(railroad_rally_high)

        ind_min = min(ind) if ind else None
        rr_min = min(rr) if rr else None
        ind_max = max(ind) if ind else None
        rr_max = max(rr) if rr else None

        # --- bear resumption: each average must penetrate its own dated low by its own distance
        ind_pen = max(0.0, ind_low - ind_min) if (ind_low is not None and ind_min is not None) else 0.0
        rr_pen = max(0.0, rr_low - rr_min) if (rr_low is not None and rr_min is not None) else 0.0
        ind_trig = None if ind_low is None else ind_low - ind_req
        rr_trig = None if rr_low is None else rr_low - rr_req
        ind_bear_met = bool(ind_low is not None and ind_min is not None and ind_pen >= ind_req)
        rr_bear_met = bool(rr_low is not None and rr_min is not None and rr_pen >= rr_req)
        joint_bear_met = bool(ind_bear_met and rr_bear_met)

        ind_to_bear = max(0.0, ind_req - ind_pen) if ind_low is not None else None
        rr_to_bear = max(0.0, rr_req - rr_pen) if rr_low is not None else None

        # --- bull confirmation: a repeated new high recorded by BOTH averages
        ind_nh = max(0.0, ind_max - ind_rally) if (ind_rally is not None and ind_max is not None) else 0.0
        rr_nh = max(0.0, rr_max - rr_rally) if (rr_rally is not None and rr_max is not None) else 0.0
        # a repeated new high must EXCEED the previous rally high, by at least min_new_high_points
        ind_bull_met = bool(
            ind_rally is not None and ind_max is not None and ind_max > ind_rally and ind_nh >= min_nh
        )
        rr_bull_met = bool(
            rr_rally is not None and rr_max is not None and rr_max > rr_rally and rr_nh >= min_nh
        )
        joint_bull_met = bool(ind_bull_met and rr_bull_met)

        ind_to_nh = max(0.0, ind_rally - ind_max) if ind_rally is not None else None
        rr_to_nh = max(0.0, rr_rally - rr_max) if rr_rally is not None else None

        has_data = bool(ind and rr)
        if joint_bear_met:
            verdict = "bear_resumed"
            reason = (
                "Both averages penetrated the recorded bear low by their own stated distances "
                "(%s points industrials, %s points railroads): the main bear movement has resumed."
                % (_fmt(ind_req), _fmt(rr_req))
            )
        elif joint_bull_met:
            verdict = "bull_confirmed"
            reason = (
                "Both averages recorded the repeated new high (%s points and %s points above the "
                "previous rally highs): a primary bull market is indicated."
                % (_fmt(ind_nh), _fmt(rr_nh))
            )
        elif has_data:
            verdict = "unconfirmed"
            reason = (
                "The averages do not jointly indicate a turn: neither both penetrations of the "
                "dated bear low nor a repeated new high in both averages has been recorded."
            )
        else:
            verdict = "unconfirmed"
            reason = "No price data supplied for one or both averages: no joint reading is possible."

        compact = {
            "verdict": verdict,
            "industrial_penetration_points": ind_pen,
            "railroad_penetration_points": rr_pen,
            "industrial_points_to_bear_trigger": ind_to_bear,
            "railroad_points_to_bear_trigger": rr_to_bear,
            "joint_bear_met": joint_bear_met,
            "industrial_new_high_points": ind_nh,
            "railroad_new_high_points": rr_nh,
            "joint_bull_met": joint_bull_met,
        }
        if not verbose:
            result = compact
        else:
            result = dict(compact)
            result.update({
                "reason": reason,
                "bear_resumption": {
                    "industrial_bear_low": ind_low,
                    "railroad_bear_low": rr_low,
                    "industrial_trigger_price": ind_trig,
                    "railroad_trigger_price": rr_trig,
                    "industrial_required_points": ind_req,
                    "railroad_required_points": rr_req,
                    "industrial_low_seen": ind_min,
                    "railroad_low_seen": rr_min,
                    "industrial_penetration_points": ind_pen,
                    "railroad_penetration_points": rr_pen,
                    "industrial_penetration_met": ind_bear_met,
                    "railroad_penetration_met": rr_bear_met,
                    "joint_bear_met": joint_bear_met,
                    "industrial_points_to_trigger": ind_to_bear,
                    "railroad_points_to_trigger": rr_to_bear,
                },
                "bull_confirmation": {
                    "industrial_rally_high": ind_rally,
                    "railroad_rally_high": rr_rally,
                    "industrial_high_seen": ind_max,
                    "railroad_high_seen": rr_max,
                    "industrial_new_high_points": ind_nh,
                    "railroad_new_high_points": rr_nh,
                    "min_new_high_points": min_nh,
                    "industrial_new_high_met": ind_bull_met,
                    "railroad_new_high_met": rr_bull_met,
                    "joint_bull_met": joint_bull_met,
                    "industrial_points_to_new_high": ind_to_nh,
                    "railroad_points_to_new_high": rr_to_nh,
                },
                "periods_tested": {"industrials": len(ind), "railroads": len(rr)},
            })

        return json.dumps({
            "result": result,
            "error": None,
            "metadata": {"provenance": {
                "source_grounded": [
                    "averages must confirm each other",
                    "bear resumption needs industrials to decline eight points below the recorded bear low",
                    "bear resumption needs railroads to decline nine points below the recorded bear low",
                    "bull confirmation needs a repeated new high recorded by both averages",
                    "no decisive turn while one average alone records the extreme",
                ],
                "model_extrapolated": [
                    "penetration defaults of 8.0 / 9.0 points generalised to any dated bear low",
                    "min_new_high_points default 0.0 (any advance over the previous rally high counts)",
                    "verdict label set: bear_resumed / bull_confirmed / unconfirmed",
                    "unconfirmed reading returned when a series is empty or a reference extreme is absent",
                ],
            }},
        })
    except Exception as exc:  # pragma: no cover - defensive
        return json.dumps({
            "result": None,
            "error": "joint_average_turn_confirmation_test failed: %s" % exc,
            "metadata": {"provenance": {
                "source_grounded": [],
                "model_extrapolated": ["error-handling path"],
            }},
        })


def _fmt(x: Optional[float]) -> str:
    return "n/a" if x is None else ("%.2f" % x)