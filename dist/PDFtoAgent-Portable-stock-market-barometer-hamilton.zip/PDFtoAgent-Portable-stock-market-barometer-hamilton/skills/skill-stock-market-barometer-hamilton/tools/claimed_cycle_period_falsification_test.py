import json
from typing import List, Optional

_PROVENANCE = {
    "source_grounded": [
        "claimed crisis cycle period (ten, twenty, sixteen, fourteen years)",
        "observed crisis years 1837, 1857, 1873, 1884, 1893, 1907",
        "prophesied crisis years 1877, 1903, 1913",
        "20-year theory deflated to 16 for 1857-1873",
        "1893-1907 interval of fourteen years",
        "verdict: theory takes so much humoring it has only record value",
    ],
    "model_extrapolated": [
        "hit_tolerance_years default 1.0",
        "interval_tolerance_years default 2.0",
        "humoring_score = revisions + missed prophecies",
        "usable_periodicity requires zero missed prophecies and zero revisions",
        "forecast_untested verdict when no prophesied years are supplied",
    ],
}


def _meta(extra: Optional[dict] = None) -> dict:
    meta = {"provenance": _PROVENANCE}
    if extra:
        meta.update(extra)
    return meta


def _out(payload: dict, verbose: bool, compact_keys: List[str]) -> str:
    if not verbose:
        payload = {k: payload[k] for k in compact_keys if k in payload}
    return json.dumps({"result": payload, "error": None, "metadata": _meta()})


async def claimed_cycle_period_falsification_test(
    crisis_years: List[float],
    claimed_period_years: float = 20.0,
    prophesied_years: Optional[List[float]] = None,
    period_revisions: Optional[List[float]] = None,
    hit_tolerance_years: float = 1.0,
    interval_tolerance_years: float = 2.0,
    verbose: bool = True,
) -> str:
    """Test a claimed crisis-cycle period against the actual record of crisis years.

    Use when someone asserts a fixed periodicity of business crises (ten, twenty,
    sixteen, fourteen years) and you have (a) the crisis years that actually occurred
    and (b) the crisis years the theory prophesied. It checks each prophesied year
    against the nearest real crisis, measures the observed intervals against the
    claimed period, counts how many times the claimed period had to be revised to fit
    the dates, and returns a verdict of usable periodicity or self-humoring.

    Do NOT use for measuring panic intervals or forecasting the next panic window --
    call panic_interval_rule (chCYCLES AND STOCK MARKET RECORDS) instead; that tool
    grades the record, this one grades the FORECAST and the theory's revisions.

    Depends on: panic_interval_rule (chCYCLES AND STOCK MARKET RECORDS) for the
    underlying interval measurement; this tool adds the prophecy check and the
    revision count.
    """
    try:
        years: List[float] = []
        for y in crisis_years or []:
            if y is not None:
                years.append(float(y))
        years.sort()

        claimed = 20.0 if claimed_period_years is None else float(claimed_period_years)
        hit_tol = 1.0 if hit_tolerance_years is None else float(hit_tolerance_years)
        iv_tol = 2.0 if interval_tolerance_years is None else float(interval_tolerance_years)

        intervals = [years[i + 1] - years[i] for i in range(len(years) - 1)]
        mean_interval = sum(intervals) / len(intervals) if intervals else 0.0
        matched = sum(1 for iv in intervals if abs(iv - claimed) <= iv_tol)
        interval_match_share = matched / len(intervals) if intervals else 0.0

        prophecies = []
        for py in prophesied_years or []:
            if py is None:
                continue
            target = float(py)
            nearest = None
            if years:
                nearest = min(years, key=lambda y: abs(y - target))
            offset = None if nearest is None else nearest - target
            hit = offset is not None and abs(offset) <= hit_tol
            prophecies.append(
                {
                    "prophesied_year": target,
                    "nearest_crisis_year": nearest,
                    "nearest_crisis_offset_years": offset,
                    "crisis_occurred": bool(hit),
                }
            )

        n_prophesied = len(prophecies)
        missed_years = [p["prophesied_year"] for p in prophecies if not p["crisis_occurred"]]
        prophecy_hit_share = (
            (n_prophesied - len(missed_years)) / n_prophesied if n_prophesied else None
        )

        sequence = [claimed] + [float(p) for p in (period_revisions or []) if p is not None]
        revisions = sum(1 for i in range(1, len(sequence)) if sequence[i] != sequence[i - 1])

        humoring_score = revisions + len(missed_years)

        if n_prophesied == 0:
            verdict = "forecast_untested"
        elif len(missed_years) == 0 and revisions == 0:
            verdict = "usable_periodicity"
        else:
            verdict = "self_humoring"

        reason = (
            "prophesied %d crisis year(s), %d missed; claimed period revised %d time(s); "
            "observed intervals match the claim in %.0f%% of cases"
            % (n_prophesied, len(missed_years), revisions, interval_match_share * 100.0)
        )
        if verdict == "forecast_untested":
            reason = "no prophesied years supplied, so the forecast itself is untested"
        elif verdict == "usable_periodicity":
            reason = (
                "every prophesied year saw a crisis and the period was never revised -> "
                "usable periodicity"
            )
        else:
            reason = (
                "the theory had to be humored %d time(s) to fit the dates -> "
                "self-humoring, record value only" % humoring_score
            )

        payload = {
            "claimed_period_years": claimed,
            "n_crisis_years": len(years),
            "n_intervals": len(intervals),
            "interval_match_share": interval_match_share,
            "n_prophesied_years": n_prophesied,
            "prophecy_hit_share": prophecy_hit_share,
            "period_revisions": revisions,
            "humoring_score": humoring_score,
            "verdict": verdict,
            "mean_interval_years": mean_interval,
            "claimed_period_deviation_years": mean_interval - claimed,
            "intervals": intervals,
            "period_sequence": sequence,
            "prophecies": prophecies,
            "missed_prophecies": missed_years,
            "reason": reason,
        }
        return _out(
            payload,
            verbose,
            [
                "claimed_period_years",
                "n_crisis_years",
                "n_intervals",
                "interval_match_share",
                "n_prophesied_years",
                "prophecy_hit_share",
                "period_revisions",
                "humoring_score",
                "verdict",
            ],
        )
    except Exception as exc:  # noqa: BLE001 - contract requires a reading, never a raise
        return json.dumps(
            {
                "result": {
                    "claimed_period_years": claimed_period_years,
                    "verdict": "indeterminate",
                    "reason": str(exc),
                },
                "error": None,
                "metadata": _meta(),
            }
        )