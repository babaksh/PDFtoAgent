import json
from typing import List, Optional


async def secular_decline_exceeding_major_swings_test(
    tops: List[float],
    top_periods: List[float],
    major_swing_amplitudes_pct: List[float],
    end_period: Optional[float] = None,
    terminal_price: Optional[float] = None,
    cycle_years: Optional[float] = None,
    panic_interval_years: Optional[float] = None,
    monotonic_tolerance_pct: Optional[float] = None,
    verbose: bool = True,
) -> str:
    """Detect a secular (multi-year) decline that is WIDER and LONGER than any
    major swing or assumed cycle period, by testing a series of successive rally
    tops.

    Use when you have the successive HIGH points (rally tops) of one average over
    a long stretch -- e.g. the railroad average tops 138.36 (Jan 1906), 134.46
    (Aug 1909), 124.35 (Oct 1912), 109.43 (Jan 1914), 112.28 (Oct 1916) running
    on into June 1921 -- and you want to know whether the whole movement is a
    secular decline of the kind the chapter calls "not only wider than the major
    swings but even more considerable than any of these assumed cycle periods".

    How it decides (all three must hold for a positive reading):
      1. MONOTONIC TOPS -- each successive top fails to exceed the one before it,
         allowing a small tolerance (`monotonic_tolerance_pct`) so that a
         half-hearted rally that marginally betters the previous top still counts
         as part of the decline.
      2. WIDER -- the amplitude from the first (record) top down to the terminal
         price exceeds the amplitude of EVERY observed major swing supplied in
         `major_swing_amplitudes_pct`.
      3. LONGER -- the span from the first top to `end_period` exceeds the assumed
         cycle period (`cycle_years`, the Jevons ten-year cycle in the chapter).

    Do NOT use this to classify an ordinary primary/major swing (call
    `dow_three_movement_classification` or `primary_swing_duration_bound_test`
    instead), and do NOT use it for a single top or an index with no dates -- the
    time dimension is essential, since "longer than the cycle" is half the test.

    Args:
        tops: Successive rally-top prices of the average, in chronological order.
        top_periods: Date of each top, in decimal years (e.g. 1906.06 for
            Jan 22 1906). Must line up with `tops`.
        major_swing_amplitudes_pct: Peak-to-trough percentage amplitude of each
            major swing observed inside the same stretch. Required -- the secular
            movement must be wider than all of them.
        end_period: End of the decline in decimal years (default: date of the last
            top). Use 1921.46 for "June, 1921".
        terminal_price: Price at `end_period` (default: the last top). The chapter
            measures width from the record top down to the price of the day.
        cycle_years: Assumed cycle period in years (default 10.0, the Jevons
            ten-year cycle the chapter cites).
        panic_interval_years: Panic-to-panic interval used as a second, purely
            informational benchmark (default 16.0, the chapter's 1857-1873 gap).
        monotonic_tolerance_pct: How far a later top may exceed the previous top
            and still count as part of the decline (default 5.0).
        verbose: False returns the compact verdict; True adds the per-top rows and
            benchmark detail.

    Returns:
        JSON string {"result": {...}, "error": ..., "metadata": {...}} where
        result.classification is "secular_decline_exceeding_major_swings" or
        "no_secular_decline".
    """
    try:
        cycle_years = 10.0 if cycle_years is None else float(cycle_years)
        panic_interval_years = (
            16.0 if panic_interval_years is None else float(panic_interval_years)
        )
        monotonic_tolerance_pct = (
            5.0 if monotonic_tolerance_pct is None else float(monotonic_tolerance_pct)
        )

        tops_in = [float(t) for t in (tops or []) if t is not None]
        periods_in = [float(p) for p in (top_periods or []) if p is not None]
        swings_in = [
            float(a) for a in (major_swing_amplitudes_pct or []) if a is not None
        ]

        n = len(tops_in)

        if len(periods_in) >= n and n >= 1:
            start_period = periods_in[0]
            last_top_period = periods_in[n - 1]
        elif len(periods_in) >= 2:
            start_period = periods_in[0]
            last_top_period = periods_in[-1]
        elif n >= 1:
            start_period = 0.0
            last_top_period = float(n - 1)
        else:
            start_period = 0.0
            last_top_period = 0.0

        end = last_top_period if end_period is None else float(end_period)

        if terminal_price is None:
            end_price = tops_in[-1] if n else 0.0
        else:
            end_price = float(terminal_price)

        rows = []
        declines = 0
        pairs = 0
        for i in range(n):
            prev = tops_in[i - 1] if i > 0 else None
            if prev is None:
                rows.append(
                    {
                        "index": i,
                        "period": periods_in[i] if i < len(periods_in) else None,
                        "top": tops_in[i],
                        "change_pct_from_previous_top": None,
                        "counts_as_decline": None,
                    }
                )
                continue
            change_pct = (tops_in[i] - prev) / prev * 100.0 if prev != 0 else 0.0
            counts = change_pct <= monotonic_tolerance_pct
            pairs += 1
            if counts:
                declines += 1
            rows.append(
                {
                    "index": i,
                    "period": periods_in[i] if i < len(periods_in) else None,
                    "top": tops_in[i],
                    "change_pct_from_previous_top": change_pct,
                    "counts_as_decline": counts,
                }
            )

        decline_share = (declines / pairs) if pairs else 0.0
        monotonic_decline = bool(pairs > 0 and declines == pairs)

        span_years = end - start_period
        if span_years < 0:
            span_years = 0.0

        amplitude_pct = 0.0
        if n >= 1 and tops_in[0] != 0:
            amplitude_pct = (tops_in[0] - end_price) / tops_in[0] * 100.0
        if amplitude_pct < 0:
            amplitude_pct = 0.0

        widest_swing = max(swings_in) if swings_in else None
        if widest_swing is None:
            wider_than_major_swings = True
        else:
            wider_than_major_swings = bool(amplitude_pct > widest_swing)

        longer_than_cycle = bool(span_years > cycle_years)

        secular = bool(
            monotonic_decline and wider_than_major_swings and longer_than_cycle
        )
        classification = (
            "secular_decline_exceeding_major_swings"
            if secular
            else "no_secular_decline"
        )

        if secular:
            reason = (
                "Successive tops fail to rise (%.1f%% of top-to-top steps decline "
                "within the %.1f%% tolerance) over a span of %.2f years, which exceeds "
                "the %.1f-year assumed cycle, and the %.2f%% amplitude down to the "
                "terminal price is wider than every observed major swing."
                % (
                    decline_share * 100.0,
                    monotonic_tolerance_pct,
                    span_years,
                    cycle_years,
                    amplitude_pct,
                )
            )
        elif n < 2:
            reason = (
                "Fewer than two rally tops supplied, so no succession of tops can be "
                "tested for a secular decline."
            )
        elif not monotonic_decline:
            reason = (
                "Only %.1f%% of successive tops fail to rise, so the tops are not a "
                "steadily declining line of values."
                % (decline_share * 100.0)
            )
        elif not wider_than_major_swings:
            reason = (
                "The amplitude of %.2f%% does not exceed the widest observed major "
                "swing of %.2f%%, so the movement is not wider than the major swings."
                % (amplitude_pct, widest_swing if widest_swing is not None else 0.0)
            )
        else:
            reason = (
                "The span of %.2f years does not exceed the %.1f-year assumed cycle "
                "period, so the movement is not longer than a cycle."
                % (span_years, cycle_years)
            )

        result = {
            "classification": classification,
            "reason": reason,
            "secular_decline_detected": secular,
            "monotonic_decline": monotonic_decline,
            "decline_share": decline_share,
            "span_years": span_years,
            "amplitude_pct": amplitude_pct,
            "wider_than_major_swings": wider_than_major_swings,
            "longer_than_cycle": longer_than_cycle,
            "span_vs_cycle_ratio": (span_years / cycle_years) if cycle_years else 0.0,
            "span_vs_panic_interval_ratio": (
                span_years / panic_interval_years if panic_interval_years else 0.0
            ),
            "top_count": n,
        }

        if verbose:
            result["tops"] = rows
            result["major_swing_amplitudes_pct"] = swings_in
            result["widest_major_swing_pct"] = widest_swing
            result["params"] = {
                "cycle_years": cycle_years,
                "panic_interval_years": panic_interval_years,
                "monotonic_tolerance_pct": monotonic_tolerance_pct,
                "start_period": start_period,
                "end_period": end,
                "terminal_price": end_price,
            }

        return json.dumps(
            {
                "result": result,
                "error": None,
                "metadata": {
                    "provenance": {
                        "source_grounded": [
                            "successive rally tops of one average compared top to top",
                            "movement wider than the major swings",
                            "movement more considerable than any assumed cycle period",
                            "Jevons ten-year cycle as the cycle benchmark",
                            "panic-to-panic interval 1857-1873 as a second benchmark",
                            "span of the railroad decline dated 1906 to June 1921",
                        ],
                        "model_extrapolated": [
                            "monotonic tolerance of 5 pct for a later top that marginally betters the previous one",
                            "amplitude measured from the first top to the terminal price (or last top)",
                            "wider test compares against the caller's observed major-swing amplitudes",
                            "longer test uses span > cycle_years on decimal-year dates",
                            "panic interval reported as a ratio only, not a pass/fail criterion",
                            "span floored at zero when end_period precedes the first top",
                        ],
                    }
                },
            }
        )
    except Exception as exc:  # pragma: no cover - defensive
        return json.dumps(
            {
                "result": None,
                "error": str(exc),
                "metadata": {
                    "provenance": {
                        "source_grounded": [],
                        "model_extrapolated": [],
                    }
                },
            }
        )