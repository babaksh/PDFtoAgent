import json
from typing import List, Optional


def _clean(values: Optional[List]) -> List[float]:
    out: List[float] = []
    if not values:
        return out
    for v in values:
        try:
            f = float(v)
        except (TypeError, ValueError):
            continue
        out.append(f)
    return out


def _denom(x: float) -> float:
    return abs(x) if abs(x) > 1e-12 else 1.0


def _level_at(series: List[float], years: List[float], when: float) -> Optional[float]:
    idx = None
    for i, y in enumerate(years):
        if y <= when:
            idx = i
    if idx is None:
        idx = 0
    return series[idx] if idx < len(series) else None


async def record_for_barometer_forecast_error_test(
    industrials: List[float],
    railroads: Optional[List[float]] = None,
    period_years: Optional[List[float]] = None,
    call_year: float = 1909.0,
    direction: str = "bull",
    call_label: str = "",
    min_premature_months: float = 1.0,
    min_premature_points: float = 1.0,
    verbose: bool = True,
) -> str:
    """Score a commentator's DATED call that a bull or bear market has ended against the
    subsequent extremes of the two averages, and decide whether the call was premature
    and by how many months and points.

    Use when someone has declared the bull market (or bear market) over as of a certain
    date and you want the chapter's own audit of that call: measure the call date against
    the extreme each average actually went on to make, in months and in points. The
    chapter's worked case is Alexander D. Noyes, who closed his history with the opening
    of 1909 and said "the end of this singular demonstration came with the opening of
    1909". The averages went on: railroads to 134.46 in August 1909, industrials to
    100.53 at the beginning of November 1909 -- and at the end of the year the railroads
    stood at 130 on December 31st as against 134 in mid-August, with the industrials a
    bare point away from the top. Verdict: he failed to see the movement would continue
    in force; he was "accepting a record for a barometer".

    Do NOT use this to date market turns -- call confirmed_turn_dating_test. Do NOT use
    it to judge a call by its reasoning or its sources; it scores the call only against
    what the two averages subsequently did.
    Depends on: nothing from earlier chapters; it consumes the two average series that
    confirmed_turn_dating_test and double_top_bottom_averages_signal also read.

    direction "bull": the commentator said the BULL market had ended, so the test looks
    for a subsequent HIGH in each average. direction "bear": said the bear market had
    ended, so it looks for a subsequent LOW.
    period_years: decimal years for each observation (e.g. 1909.6 for mid-August 1909),
    defaulting to evenly spaced indices when omitted.
    """
    try:
        ind = _clean(industrials)
        rail = _clean(railroads)
        years = _clean(period_years)
        when = 1909.0 if call_year is None else float(call_year)
        kind = "bear" if str(direction).strip().lower() == "bear" else "bull"
        min_m = 1.0 if min_premature_months is None else float(min_premature_months)
        min_p = 1.0 if min_premature_points is None else float(min_premature_points)

        n = len(ind)
        if n == 0:
            n = len(rail)
        if not years:
            years = [float(i) for i in range(n)]
        else:
            years = years[:n] if len(years) >= n else years + [years[-1] + (i - len(years) + 1)
                                                               for i in range(len(years), n)]

        result = {
            "call_label": str(call_label),
            "call_year": when,
            "declared_end_of": kind + " market",
            "periods_observed": n,
            "premature": False,
            "max_months_premature": 0.0,
            "max_points_missed": 0.0,
            "averages_scored": 0,
            "verdict": "no data -- the call cannot be scored",
        }
        if n == 0:
            return json.dumps({
                "result": result,
                "error": None,
                "metadata": {"provenance": {
                    "source_grounded": ["call scored against the subsequent extremes of both averages",
                                        "measure in months and in points"],
                    "model_extrapolated": ["empty input returns an unscored, not-premature reading"],
                }},
            })

        def score(name: str, series: List[float]) -> Optional[dict]:
            m = min(len(series), len(years))
            if m == 0:
                return None
            s = series[:m]
            ys = years[:m]
            post = [(i, s[i]) for i in range(m) if ys[i] >= when]
            if not post:
                post = [(m - 1, s[m - 1])]
            if kind == "bull":
                ext_i, ext_p = max(post, key=lambda t: (t[1], -t[0]))
            else:
                ext_i, ext_p = min(post, key=lambda t: (t[1], -t[0]))
            base = _level_at(s, ys, when)
            if base is None:
                base = s[0]
            months = max(0.0, (ys[ext_i] - when) * 12.0)
            points = (ext_p - base) if kind == "bull" else (base - ext_p)
            tail = s[-1]
            residual = (ext_p - tail) if kind == "bull" else (tail - ext_p)
            return {
                "average": name,
                "level_at_call": base,
                "extreme_price": ext_p,
                "extreme_year": ys[ext_i],
                "extreme_index": ext_i,
                "months_premature": months,
                "points_missed": points,
                "points_missed_pct": points / _denom(base) * 100.0,
                "still_near_extreme_points_at_end": residual,
            }

        rows: List[dict] = []
        a = score("industrials", ind)
        if a is not None:
            rows.append(a)
        if rail:
            b = score("railroads", rail)
            if b is not None:
                rows.append(b)

        result["averages_scored"] = len(rows)
        if rows:
            result["max_months_premature"] = max(r["months_premature"] for r in rows)
            result["max_points_missed"] = max(r["points_missed"] for r in rows)
            result["industrials"] = rows[0]
            if len(rows) > 1:
                result["railroads"] = rows[1]
            hit_m = result["max_months_premature"] >= min_m
            hit_p = result["max_points_missed"] >= min_p
            result["premature"] = bool(hit_m and hit_p)
            worst = max(rows, key=lambda r: r["months_premature"])
            if result["premature"]:
                result["verdict"] = (
                    "call premature: the movement continued in force for " +
                    str(round(result["max_months_premature"], 2)) + " months and " +
                    str(round(result["max_points_missed"], 4)) + " points after the call -- " +
                    "the observer was accepting a record for a barometer"
                )
            else:
                result["verdict"] = (
                    "call not shown premature: the furthest subsequent extreme was " +
                    str(round(result["max_points_missed"], 4)) + " points and " +
                    str(round(result["max_months_premature"], 2)) + " months beyond the call"
                )
            result["worst_average"] = worst["average"]
            result["min_premature_months"] = min_m
            result["min_premature_points"] = min_p

        if verbose:
            result["scores"] = rows
            result["period_years"] = years

        return json.dumps({
            "result": result,
            "error": None,
            "metadata": {"provenance": {
                "source_grounded": ["dated call scored against the subsequent extremes of both averages",
                                    "measured in months of continuation",
                                    "measured in points beyond the level at the call",
                                    "railroads to 134.46 in August, industrials to 100.53 in November",
                                    "year-end check: 130 on December 31st against 134 in mid-August",
                                    "verdict vocabulary: failed to see / accepting a record for a barometer"],
                "model_extrapolated": ["premature requires BOTH " + str(round(min_m, 4)) + " months and " +
                                       str(round(min_p, 4)) + " points",
                                       "level at the call taken from the last observation at or before the call year",
                                       "flat series scores zero months and zero points, hence not premature"],
            }},
        })
    except Exception as exc:
        return json.dumps({
            "result": {"premature": False, "max_months_premature": 0.0, "max_points_missed": 0.0,
                       "verdict": "unreadable input"},
            "error": str(exc),
            "metadata": {"provenance": {
                "source_grounded": ["call scored against the subsequent extremes of both averages"],
                "model_extrapolated": ["exception guard returns a neutral reading"],
            }},
        })