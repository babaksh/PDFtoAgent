import json
from typing import Any, Dict, List, Optional


def _get(d: Dict[str, Any], *names: str, default: Any = None) -> Any:
    for n in names:
        if isinstance(d, dict) and n in d and d[n] is not None:
            return d[n]
    return default


def _f(v: Any, default: Optional[float] = None) -> Optional[float]:
    try:
        if v is None:
            return default
        return float(v)
    except (TypeError, ValueError):
        return default


def _norm_kind(v: Any) -> str:
    s = str(v or "").strip().lower()
    if s in ("depression", "below", "contraction", "down"):
        return "depression"
    if s in ("expansion", "above", "prosperity", "inflation", "up"):
        return "expansion"
    return s or "unknown"


async def babson_area_depth_duration_balance_test(
    areas: List[Dict[str, Any]],
    min_inverse_pair_share: float = 0.5,
    balance_tolerance_pct: float = 25.0,
    verbose: bool = True,
) -> str:
    """Test Babson's stated regularity over a set of chart areas (depth vs time, and balance).

    Use when you have a set of dated business-condition areas like the black plots
    of Babson's picture chart -- each with a kind (expansion above the rising
    wealth line, or depression below it), a magnitude in chart points, and a start
    and end date -- and you want to test the two regularities the chapter states
    for them: (1) shallow areas consume more time and short areas are deeper or
    higher, and (2) the black areas above and below the wealth line balance each
    other, at least approximately.

    Do NOT use this to measure how far the market led a business area -- call
    stock_market_lead_time_over_business_record for that.
    """
    try:
        areas_in = list(areas) if areas else []
        min_share = 0.5 if min_inverse_pair_share is None else float(min_inverse_pair_share)
        tol = 25.0 if balance_tolerance_pct is None else float(balance_tolerance_pct)

        rows: List[Dict[str, Any]] = []
        for i, a in enumerate(areas_in):
            if not isinstance(a, dict):
                continue
            kind = _norm_kind(_get(a, "kind", "type", "area_kind"))
            mag = _f(_get(a, "depth_points", "magnitude", "depth", "height_points", "points"))
            if mag is not None:
                mag = abs(mag)
            dur = _f(_get(a, "duration_years", "duration", "years"))
            st = _f(_get(a, "start_year", "start"))
            en = _f(_get(a, "end_year", "end"))
            if dur is None and st is not None and en is not None:
                dur = en - st
            squares = None if (mag is None or dur is None) else mag * dur
            rows.append({
                "label": str(_get(a, "label", "name", default="area_%d" % (i + 1))),
                "kind": kind,
                "magnitude_points": mag,
                "duration_years": dur,
                "start_year": st,
                "end_year": en,
                "area_squares": squares,
            })

        n = len(rows)
        above = [r for r in rows if r["kind"] == "expansion"]
        below = [r for r in rows if r["kind"] == "depression"]

        above_depth = sum(r["magnitude_points"] for r in above if r["magnitude_points"] is not None)
        below_depth = sum(r["magnitude_points"] for r in below if r["magnitude_points"] is not None)
        above_sq = sum(r["area_squares"] for r in above if r["area_squares"] is not None)
        below_sq = sum(r["area_squares"] for r in below if r["area_squares"] is not None)

        def _ratio(x: float, y: float) -> Optional[float]:
            hi = max(x, y)
            lo = min(x, y)
            if hi <= 0.0:
                return None
            return lo / hi

        def _imbal(x: float, y: float) -> Optional[float]:
            hi = max(x, y)
            lo = min(x, y)
            if hi <= 0.0:
                return None
            return (hi - lo) / hi * 100.0

        area_ratio = _ratio(above_sq, below_sq)
        area_imbal = _imbal(above_sq, below_sq)
        depth_ratio = _ratio(above_depth, below_depth)
        depth_imbal = _imbal(above_depth, below_depth)

        if n == 0:
            balanced: Optional[bool] = None
        elif not above or not below:
            balanced = False
        else:
            balanced = bool(area_imbal is not None and area_imbal <= tol + 1e-12)

        usable = [r for r in rows if r["magnitude_points"] is not None and r["duration_years"] is not None]
        consistent = 0
        violating = 0
        for i in range(len(usable)):
            for j in range(i + 1, len(usable)):
                dm = usable[i]["magnitude_points"] - usable[j]["magnitude_points"]
                dt = usable[i]["duration_years"] - usable[j]["duration_years"]
                if abs(dm) < 1e-12 or abs(dt) < 1e-12:
                    continue
                if (dm > 0) == (dt > 0):
                    violating += 1
                else:
                    consistent += 1
        decided = consistent + violating
        inv_share: Optional[float] = (float(consistent) / float(decided)) if decided else None
        inv_holds: Optional[bool] = None if inv_share is None else bool(inv_share >= min_share - 1e-12)

        claims = {"area_balance": balanced, "inverse_depth_duration": inv_holds}
        verdict = bool(balanced is True and inv_holds is True)

        if n == 0:
            reason = "no chart areas supplied; neither regularity can be measured"
        elif verdict:
            reason = ("both regularities hold: shallower areas run longer in %.0f%% of pairs and the "
                      "above/below chart areas balance within %.1f%% (%.1f%%)"
                      % (100.0 * (inv_share or 0.0), tol, area_imbal if area_imbal is not None else 0.0))
        else:
            parts = []
            if balanced is None:
                parts.append("balance unmeasurable (one side of the wealth line has no area)")
            elif not balanced:
                parts.append("above/below areas do not balance (%.1f%% apart, tolerance %.1f%%)"
                             % (area_imbal if area_imbal is not None else 0.0, tol))
            if inv_holds is None:
                parts.append("depth-vs-time relation unmeasurable (fewer than two comparable areas)")
            elif not inv_holds:
                parts.append("depth-vs-time relation fails (only %.0f%% of pairs inverse, need %.0f%%)"
                             % (100.0 * (inv_share or 0.0), 100.0 * min_share))
            reason = "; ".join(parts) if parts else "regularity not confirmed"

        result: Dict[str, Any] = {
            "areas_tested": n,
            "expansion_areas": len(above),
            "depression_areas": len(below),
            "above_depth_sum": above_depth,
            "below_depth_sum": below_depth,
            "depth_balance_ratio": depth_ratio,
            "depth_imbalance_pct": depth_imbal,
            "above_area_squares": above_sq,
            "below_area_squares": below_sq,
            "area_balance_ratio": area_ratio,
            "area_imbalance_pct": area_imbal,
            "balance_tolerance_pct": tol,
            "inverse_pairs_consistent": consistent,
            "inverse_pairs_violating": violating,
            "inverse_pair_share": inv_share,
            "min_inverse_pair_share": min_share,
            "balance_holds": balanced,
            "inverse_depth_duration_holds": inv_holds,
            "claims_measured": claims,
            "verdict": verdict,
            "reason": reason,
        }
        if verbose:
            result["rows"] = rows

        return json.dumps({
            "result": result,
            "error": None,
            "metadata": {"provenance": {
                "source_grounded": [
                    "shallow areas tend to become broader in time consumed",
                    "where the time to complete the area is less the depression or expansion is deeper or higher",
                    "the black areas above or below balance each other, at least approximately",
                    "areas are plotted above and below the rising line of growing wealth",
                ],
                "model_extrapolated": [
                    "min_inverse_pair_share default 0.5 (majority of pairs behave inversely)",
                    "balance_tolerance_pct default 25.0 for 'at least approximately'",
                    "balance measured on chart squares (magnitude x duration), not depth alone",
                    "tied pairs (equal depth or equal duration) excluded from the pair count",
                ],
            }},
        })
    except Exception as exc:  # noqa: BLE001
        return json.dumps({
            "result": None,
            "error": "babson_area_depth_duration_balance_test failed: %s" % exc,
            "metadata": {"provenance": {
                "source_grounded": [],
                "model_extrapolated": ["error path"],
            }},
        })