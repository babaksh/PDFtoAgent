"""National debt as a percentage of national wealth: solvency grade and exchange-credit implication (1917).

Hamilton: "Great Britain's debt at that time (1815-16) represented 31 1/2 per cent of
her estimated national wealth. ... previous to the Boer War (1899-1902) it amounted to
not much more than 4 per cent ... the Boer War cost Great Britain about a billion
dollars, and raised the proportion of debt to national wealth to over 6 per cent ...
The British debt now is estimated at 33 per cent of the national wealth, or a
proportion of about 1 1/2 per cent more than that at the conclusion of the Napoleonic
wars ... No doubt it is a formidably high proportion. But it is far from a hopeless
proportion; and this is a basic reason why, of all the money units depreciated in the
conflict, the British pound sterling approximates respectably in exchange credit to
the American dollar."

Use when: you have a national debt and an estimated national wealth (or the ratio
already expressed as a percent) and want the chapter's grade -- light, moderate,
formidable or hopeless -- plus what that implies for the currency's exchange credit.

The test is comparative, not absolute: the ruling rests on where the proportion
stands against the chapter's own precedents (4 per cent before the Boer War, over
6 per cent after it, 31 1/2 per cent after the Napoleonic wars, 33 per cent now).

Do NOT use for a corporate or municipal debt burden, and do NOT use to estimate
national wealth -- supply the wealth estimate; the tool only grades the ratio.
"""

import json
from typing import Optional


def _provenance():
    return {
        "source_grounded": [
            "1815-16 British debt 31.5 per cent of estimated national wealth",
            "before the Boer War (1899-1902) not much more than 4 per cent",
            "Boer War raised the proportion to over 6 per cent",
            "British debt now estimated at 33 per cent of national wealth",
            "33 per cent is about 1.5 percentage points more than after the Napoleonic wars",
            "'formidably high proportion' but 'far from a hopeless proportion'",
            "not hopeless is the basic reason sterling approximates respectably to the dollar",
        ],
        "model_extrapolated": [
            "hopeless_threshold_pct default 50.0 -- the chapter never names a hopeless level, "
            "it only says 33 per cent was far from hopeless",
            "grade bands: light <= 4, moderate <= 6, formidable up to the hopeless threshold",
            "exchange-credit wording ('respectable' / 'impaired') not a chapter formula",
            "unmeasurable reading when wealth is zero or the ratio is not supplied",
        ],
    }


async def debt_to_national_wealth_solvency_test(
    national_debt: Optional[float] = None,
    national_wealth: Optional[float] = None,
    debt_pct: Optional[float] = None,
    light_threshold_pct: Optional[float] = 4.0,
    moderate_threshold_pct: Optional[float] = 6.0,
    formidable_threshold_pct: Optional[float] = 31.5,
    hopeless_threshold_pct: Optional[float] = 50.0,
    verbose: bool = True,
) -> str:
    """Grade a national debt against estimated national wealth as light, moderate, formidable or hopeless.

    Use when you have a national debt figure and an estimate of national wealth (or
    the ratio already as a percent) and want the chapter's solvency grade plus the
    implication for the currency's exchange credit -- the reason sterling, at 33 per
    cent, still ranked respectably against the dollar.

    Do NOT use for a corporate, municipal or railroad debt burden, and do NOT use it
    to estimate national wealth itself -- the caller supplies the wealth estimate.

    Args:
        national_debt: total national debt in money units (e.g. 33.0 billion).
        national_wealth: estimated national wealth in the SAME units (e.g. 100.0 billion).
        debt_pct: the ratio already expressed as a percent; used when the two levels
            are not supplied.
        light_threshold_pct: percent at or below which the burden is light (4.0, pre-Boer War).
        moderate_threshold_pct: percent at or below which the burden is moderate (6.0, post-Boer War).
        formidable_threshold_pct: percent of the Napoleonic precedent that makes the
            burden formidable (31.5).
        hopeless_threshold_pct: percent above which the burden is ruled hopeless (50.0).
        verbose: False returns the compact grade; True adds the comparisons and reason.
    """
    light = 4.0 if light_threshold_pct is None else float(light_threshold_pct)
    moderate = 6.0 if moderate_threshold_pct is None else float(moderate_threshold_pct)
    formidable = 31.5 if formidable_threshold_pct is None else float(formidable_threshold_pct)
    hopeless = 50.0 if hopeless_threshold_pct is None else float(hopeless_threshold_pct)

    pct = None if debt_pct is None else float(debt_pct)
    if pct is None and national_debt is not None and national_wealth is not None:
        wealth = float(national_wealth)
        if wealth != 0.0:
            pct = float(national_debt) / wealth * 100.0

    if pct is None:
        result = {
            "grade": "unmeasurable",
            "hopeless": None,
            "debt_pct": None,
            "exchange_credit": "unknown",
            "reason": "no debt-to-wealth ratio supplied (or national wealth is zero), "
                      "so the proportion cannot be graded",
        }
        if verbose:
            result["inputs"] = {
                "national_debt": national_debt,
                "national_wealth": national_wealth,
                "debt_pct": debt_pct,
            }
        return json.dumps({
            "result": result,
            "error": None,
            "metadata": {"provenance": _provenance()},
        })

    if pct <= light:
        grade = "light"
        hopeless_flag = False
        exchange = "sound"
        reason = (
            "%.2f per cent is no more than the pre-Boer War proportion (about %.1f per cent): "
            "a burden Britain had been steadily paying off" % (pct, light)
        )
    elif pct <= moderate:
        grade = "moderate"
        hopeless_flag = False
        exchange = "sound"
        reason = (
            "%.2f per cent is within the proportion the Boer War raised it to (over %.1f per "
            "cent): noticeable but well short of formidable" % (pct, moderate)
        )
    elif pct <= hopeless:
        if pct <= formidable:
            grade = "formidable_but_manageable"
            reason = (
                "%.2f per cent is below the Napoleonic-war precedent of %.1f per cent: heavy "
                "but inside a proportion the nation lived with and paid down" % (pct, formidable)
            )
        else:
            grade = "formidable"
            reason = (
                "%.2f per cent is %.2f points above the Napoleonic-war precedent of %.1f per "
                "cent, as Britain's post-war 33 per cent was: formidably high, but far from "
                "hopeless at this distance from the precedent" % (pct, pct - formidable, formidable)
            )
        hopeless_flag = False
        exchange = "respectable"
        reason += (
            "; and being far from hopeless is a basic reason the currency still approximates "
            "respectably in exchange credit to a sound money unit"
        )
    else:
        grade = "hopeless"
        hopeless_flag = True
        exchange = "impaired"
        reason = (
            "%.2f per cent exceeds even a generous reading of the survivable precedent (%.1f per "
            "cent) by %.2f points: no longer merely formidable, and the currency's exchange "
            "credit must suffer with it" % (pct, formidable, pct - formidable)
        )

    result = {
        "grade": grade,
        "debt_pct": pct,
        "hopeless": hopeless_flag,
        "exchange_credit": exchange,
    }
    if verbose:
        result["excess_over_napoleonic_precedent_pts"] = pct - formidable
        result["multiple_of_napoleonic_precedent"] = (
            pct / formidable if formidable != 0.0 else None
        )
        result["reason"] = reason
        result["inputs"] = {
            "national_debt": national_debt,
            "national_wealth": national_wealth,
            "light_threshold_pct": light,
            "moderate_threshold_pct": moderate,
            "formidable_threshold_pct": formidable,
            "hopeless_threshold_pct": hopeless,
        }
    return json.dumps({
        "result": result,
        "error": None,
        "metadata": {"provenance": _provenance()},
    })