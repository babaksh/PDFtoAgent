"""Grade a barometer reading down to half its usual value when one average is impaired."""

import json
import math
from typing import List, Optional


def _clean(values) -> List[float]:
    if not values:
        return []
    out: List[float] = []
    for v in values:
        try:
            f = float(v)
        except (TypeError, ValueError):
            continue
        if math.isnan(f) or math.isinf(f):
            continue
        out.append(f)
    return out


def _finite(v) -> bool:
    return v is not None and not (math.isnan(v) or math.isinf(v))


def _r(v, nd: int = 4):
    return None if not _finite(v) else round(float(v), nd)


def _pct(series: List[float]):
    if len(series) < 2 or series[0] == 0.0:
        return None
    return (series[-1] - series[0]) / abs(series[0]) * 100.0


def _direction(pct, flat_band: float):
    if pct is None:
        return "none"
    if pct > flat_band:
        return "up"
    if pct < -flat_band:
        return "down"
    return "flat"


def _sign_agreement(a: List[float], b: List[float]):
    n = min(len(a), len(b))
    if n < 2:
        return None
    agree = 0
    counted = 0
    for i in range(1, n):
        da = a[i] - a[i - 1]
        db = b[i] - b[i - 1]
        if not (_finite(da) and _finite(db)):
            continue
        if da == 0.0 and db == 0.0:
            continue
        counted += 1
        if (da > 0 and db > 0) or (da < 0 and db < 0):
            agree += 1
    if counted == 0:
        return None
    return agree / counted


async def barometer_confidence_impairment_weighting(
    industrials: List[float],
    railroads: List[float],
    bond_prices: Optional[List[float]] = None,
    impaired_average: str = "railroads",
    government_ownership_and_guaranty: bool = False,
    min_move_pct: float = 1.0,
    min_bond_agreement: float = 0.6,
    impaired_weight: float = 0.5,
    verbose: bool = True,
) -> str:
    """Grade a barometer reading down to HALF its usual value, or less, when one of the
    two averages has lost its speculative character and so cannot confirm the other.

    Use after you have a reading from the two averages and you must decide how much
    weight to put on it. The chapter: "for a year or more the averages had half their
    usual value as a barometer, or indeed less than half, for the movement in the
    industrials lacked the essential confirmation of a corresponding movement in the
    speculative railroad stocks" -- the railroads, under government ownership and
    guaranty, "had in a real sense ceased ... to be speculative".

    The tool returns a CONFIDENCE WEIGHT, not merely a confirmed/unconfirmed flag:
      * `confidence_weight` -- 1.0 when the two averages corroborate normally; the
        impaired weight (0.5 by default) when the reading is unconfirmed BECAUSE the
        impaired average has lost its speculative character; 0.0 when it is unconfirmed
        for no stated reason (the chapter's "unfortunate guess");
      * `below_half` -- True when the lack of confirmation is aggravated (the impaired
        average is also travelling counter to the confirming one), which is the
        "indeed less than half" case.

    The impairment itself is MEASURED, not assumed: on the default call path the tool
    checks that the impaired average moves with bonds (`bond_sign_agreement`), and when
    government ownership and guaranty is declared it is combined with that measurement.

    Extends `average_corroboration_check` (chCYCLES AND STOCK MARKET RECORDS): that tool
    returns a corroboration verdict. This one adds the GRADED CONSEQUENCE and its CAUSE
    -- confirmation lost because one average became non-speculative leaves the barometer
    worth half or less, not merely "not corroborated".

    Do NOT use this before you know which market the impaired average is following
    (call series_market_tracking_regime_test), and do NOT use it to test whether two
    averages corroborate in the ordinary sense (call average_corroboration_check).

    Args:
        industrials: the industrial average, oldest first.
        railroads: the railroad average over the same periods.
        bond_prices: bond / fixed-income average over the same periods; needed to measure
            whether the impaired average has really left the speculative class.
        impaired_average: which of the two has lost its speculative character,
            "railroads" or "industrials".
        government_ownership_and_guaranty: True when the impairment is government
            ownership and guaranty, the chapter's cause.
        min_move_pct: percent band inside which an average reads as flat.
        min_bond_agreement: share of periods the impaired average must move with bonds
            before it counts as having adopted the bond market.
        impaired_weight: the weight given to an impaired-but-explained reading; the
            chapter says half, "or indeed less".
        verbose: False returns the weight and the verdict; True adds the measurements.

    Returns:
        JSON {"result": {...}, "error": None, "metadata": {...}} with `classification`,
        `confidence_weight` and a short `reason`.
    """
    try:
        min_move_pct = 1.0 if min_move_pct is None else float(min_move_pct)
        min_bond_agreement = 0.6 if min_bond_agreement is None else float(min_bond_agreement)
        weight = 0.5 if impaired_weight is None else float(impaired_weight)
        if weight < 0.0:
            weight = 0.0
        if weight > 1.0:
            weight = 1.0
        gov = bool(government_ownership_and_guaranty)
        which = str(impaired_average).strip().lower() if impaired_average is not None else "railroads"
        if which not in ("railroads", "industrials"):
            which = "railroads"

        ind = _clean(industrials)
        rail = _clean(railroads)
        bonds = _clean(bond_prices) if bond_prices else []

        n = min(len(ind), len(rail))
        ind = ind[:n]
        rail = rail[:n]

        ind_pct = _pct(ind)
        rail_pct = _pct(rail)
        ind_dir = _direction(ind_pct, min_move_pct)
        rail_dir = _direction(rail_pct, min_move_pct)

        if n < 2:
            result = {
                "classification": "insufficient_data",
                "confidence_weight": 0.0,
                "below_half": False,
                "reason": ("At least two aligned observations of the two averages are "
                           "needed before any reading can be weighted."),
                "industrials_direction": ind_dir,
                "railroads_direction": rail_dir,
                "impaired_average": which,
                "impaired_is_non_speculative": False,
                "bond_sign_agreement": None,
                "bond_condition_measured": bool(len(bonds) >= 2),
                "government_ownership_and_guaranty": gov,
                "observations_compared": n,
            }
            return json.dumps({
                "result": result,
                "error": None,
                "metadata": {
                    "provenance": {
                        "source_grounded": [
                            "the averages had half their usual value as a barometer, or indeed less than half",
                        ],
                        "model_extrapolated": ["insufficient-data boundary reading below 2 observations"],
                    }
                },
            })

        confirming = ind if which == "railroads" else rail
        impaired = rail if which == "railroads" else ind
        confirming_dir = ind_dir if which == "railroads" else rail_dir
        impaired_dir = rail_dir if which == "railroads" else ind_dir
        confirming_name = "industrials" if which == "railroads" else "railroads"

        corroborated = (
            ind_dir != "flat" and rail_dir != "flat" and ind_dir == rail_dir
        )
        ran_counter = (
            confirming_dir != "flat" and impaired_dir != "flat"
            and confirming_dir != impaired_dir
        )

        bond_agreement = _sign_agreement(impaired, bonds) if len(bonds) >= 2 else None
        bond_measured = bond_agreement is not None
        bond_met = bool(bond_measured and bond_agreement >= min_bond_agreement)

        if gov and bond_measured:
            non_speculative = gov and bond_met
            impairment_basis = "government ownership and guaranty declared, and the impaired average moves with bonds"
        elif gov:
            non_speculative = False
            impairment_basis = ("government ownership and guaranty declared, but no bond "
                                "series was supplied, so the loss of speculative character "
                                "was NOT measured")
        elif bond_measured:
            non_speculative = bond_met
            impairment_basis = "the impaired average moves with bonds (measured)"
        else:
            non_speculative = False
            impairment_basis = ("neither government guaranty nor a bond series was "
                                "supplied, so no cause of impairment was measured")

        if corroborated:
            classification = "full_confidence"
            confidence_weight = 1.0
            below_half = False
            reason = ("Both averages moved " + ind_dir
                      + " together, so the reading is confirmed in the ordinary way and "
                        "the barometer carries its usual value.")
        elif non_speculative:
            classification = "impaired_half_value"
            confidence_weight = weight if not ran_counter else weight / 2.0
            below_half = ran_counter
            reason = ("The " + confirming_name + " moved " + confirming_dir
                      + " without confirmation from the " + which + ", which moved "
                      + impaired_dir + "; but the " + which
                      + " has lost its speculative character (" + impairment_basis
                      + "), so the averages have half their usual value as a barometer"
                      + (", and indeed less than half, because the " + which
                         + " ran counter to the " + confirming_name
                         if ran_counter else "") + ".")
        else:
            classification = "no_confidence"
            confidence_weight = 0.0
            below_half = False
            reason = ("The " + confirming_name + " moved " + confirming_dir
                      + " without confirmation from the " + which + ", which moved "
                      + impaired_dir + ", and no cause was established for the " + which
                      + " having ceased to be speculative (" + impairment_basis
                      + "). An unexplained one-average indication is the chapter's "
                        "'unfortunate guess': give the reading no weight.")

        result = {
            "classification": classification,
            "confidence_weight": round(confidence_weight, 4),
            "below_half": below_half,
            "reason": reason,
            "impaired_average": which,
            "confirming_average": confirming_name,
            "impaired_is_non_speculative": non_speculative,
            "impairment_basis": impairment_basis,
            "corroborated": corroborated,
            "ran_counter": ran_counter,
            "industrials_direction": ind_dir,
            "railroads_direction": rail_dir,
            "industrials_pct_change": _r(ind_pct),
            "railroads_pct_change": _r(rail_pct),
            "bond_sign_agreement": _r(bond_agreement),
            "bond_condition_measured": bond_measured,
            "government_ownership_and_guaranty": gov,
            "impaired_weight": weight,
            "min_bond_agreement": min_bond_agreement,
            "observations_compared": n,
        }

        if verbose:
            result["detail"] = {
                "industrials": [round(v, 4) for v in ind],
                "railroads": [round(v, 4) for v in rail],
                "bond_prices": [round(v, 4) for v in bonds],
                "min_move_pct": min_move_pct,
                "rule_quote": ("Thus for a year or more the averages had half their usual "
                               "value as a barometer, or indeed less than half, for the "
                               "movement in the industrials lacked the essential "
                               "confirmation of a corresponding movement in the "
                               "speculative railroad stocks."),
            }

        return json.dumps({
            "result": result,
            "error": None,
            "metadata": {
                "provenance": {
                    "source_grounded": [
                        "the averages had half their usual value as a barometer, or indeed less than half",
                        "the movement in the industrials lacked the essential confirmation of a corresponding movement in the speculative railroad stocks",
                        "through government ownership and guaranty the railroads had ceased, for the time at least, to be speculative",
                        "an indication by one average alone is a short way of going wrong",
                    ],
                    "model_extrapolated": [
                        "half value implemented as confidence_weight 0.5, and 'less than half' as 0.25 when the impaired average also runs counter",
                        "impairment measured as bond sign agreement >= 0.6 of periods, combined with the declared guaranty",
                        "unexplained non-confirmation weighted 0.0 rather than the impaired weight",
                        "flat band of 1.0% for the direction test",
                        "insufficient-data boundary reading below 2 observations",
                    ],
                }
            },
        })
    except Exception as exc:
        return json.dumps({
            "result": {
                "classification": "insufficient_data",
                "confidence_weight": 0.0,
                "below_half": False,
                "reason": "Could not weight the barometer reading: " + str(exc),
            },
            "error": None,
            "metadata": {
                "provenance": {
                    "source_grounded": [
                        "the averages had half their usual value as a barometer",
                    ],
                    "model_extrapolated": ["boundary reading on unusable input"],
                }
            },
        })