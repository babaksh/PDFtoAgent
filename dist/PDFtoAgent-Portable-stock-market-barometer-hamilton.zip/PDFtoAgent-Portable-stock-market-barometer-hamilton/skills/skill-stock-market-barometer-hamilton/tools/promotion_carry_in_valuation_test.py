"""Settle whether a promotion is raw from its carry-in valuation.

Use when you have a promotion's numbers and want the chapter's arithmetic on
Amalgamated Copper: compare the arms-length price paid for control, the market
quotation, and the value at which the property is carried into the new company,
and test whether the capital raised exceeds what the control actually acquired
could have cost. The chapter's finding was that the $75,000,000 capital should
have been sufficient to pay for the entire capital of the constituent
companies, although only a control, presumably 51 per cent, was acquired.

Inputs: capital_raised, control_fraction_acquired, arms_length_price_per_share,
market_quotation_per_share, carried_in_value_per_share and the acquired
company's shares outstanding (or its whole capital in dollars). Do NOT use
this on a seasoned company's book value versus price -- call
water_in_capitalization_test. Do NOT use it to test a flotation's
oversubscription claim -- call flotation_oversubscription_credibility_test.

Depends on: water_in_capitalization_test (WATER IN THE BAROMETER) -- this adds
the arms-length acquisition cost and the market quotation as the comparison
basis, and adds the capital-sufficiency test of capital raised against the
control percentage actually acquired.
"""

import json
from typing import Any, Optional


async def promotion_carry_in_valuation_test(
    capital_raised: Optional[float] = None,
    control_fraction_acquired: Optional[float] = None,
    arms_length_price_per_share: Optional[float] = None,
    market_quotation_per_share: Optional[float] = None,
    carried_in_value_per_share: Optional[float] = None,
    constituent_shares_outstanding: Optional[float] = None,
    constituent_capital_dollars: Optional[float] = None,
    min_carry_in_premium_pct: float = 10.0,
    verbose: bool = True,
) -> str:
    """Test a promotion for raw over-valuation and excess capital raised."""

    def _f(v: Any, default: Optional[float] = None) -> Optional[float]:
        try:
            if v is None:
                return default
            return float(v)
        except (TypeError, ValueError):
            return default

    def _pct(new: float, base: float) -> float:
        return ((new - base) / base * 100.0) if base else 0.0

    try:
        capital = _f(capital_raised, 0.0) or 0.0
        frac = _f(control_fraction_acquired, 0.0) or 0.0
        arms = _f(arms_length_price_per_share, 0.0) or 0.0
        mkt = _f(market_quotation_per_share, 0.0) or 0.0
        carry = _f(carried_in_value_per_share, 0.0) or 0.0
        shares = _f(constituent_shares_outstanding, 0.0) or 0.0
        const_cap = _f(constituent_capital_dollars, None)
        min_prem = _f(min_carry_in_premium_pct, 10.0) or 0.0

        if const_cap is None:
            const_cap = shares * arms
        elif shares <= 0 and arms > 0:
            shares = const_cap / arms

        cost_control = frac * shares * arms
        cost_whole = const_cap

        prem_arms = _pct(carry, arms) if arms > 0 else 0.0
        prem_mkt = _pct(carry, mkt) if mkt > 0 else 0.0

        covers_whole = bool(capital > 0 and cost_whole > 0 and capital >= cost_whole)
        control_multiple = (capital / cost_control) if cost_control > 0 else 0.0
        excess_over_control = capital - cost_control

        over_arms = bool(prem_arms >= min_prem)
        over_mkt = bool(prem_mkt >= min_prem)
        only_control = bool(0.0 < frac < 1.0)

        if cost_whole <= 0 and cost_control <= 0:
            verdict = "not_testable"
            reason = ("no constituent capital and no control cost can be measured, so "
                      "the promotion cannot be tested")
            raw = False
        elif covers_whole and only_control:
            verdict = "raw_promotion"
            reason = ("capital raised of %.0f covers the entire constituent capital of "
                      "%.0f although only %.1f%% control was acquired; the stock is "
                      "carried in at %.2f%% over the arms-length price"
                      % (capital, cost_whole, frac * 100.0, prem_arms))
            raw = True
        elif over_arms or over_mkt:
            verdict = "raw_promotion"
            reason = ("property is carried in at %.2f%% over the arms-length price and "
                      "%.2f%% over the market quotation, above the %.2f%% test"
                      % (prem_arms, prem_mkt, min_prem))
            raw = True
        else:
            verdict = "not_raw_on_carry_in"
            reason = ("carry-in value is %.2f%% over the arms-length price and %.2f%% "
                      "over the market quotation, within the %.2f%% test"
                      % (prem_arms, prem_mkt, min_prem))
            raw = False

        result = {
            "verdict": verdict,
            "reason": reason,
            "promotion_is_raw": bool(raw),
            "capital_raised": round(capital, 4),
            "control_fraction_acquired": round(frac, 4),
            "arms_length_price_per_share": round(arms, 4),
            "market_quotation_per_share": round(mkt, 4),
            "carried_in_value_per_share": round(carry, 4),
            "carry_in_premium_over_arms_length_pct": round(prem_arms, 4),
            "carry_in_premium_over_market_quotation_pct": round(prem_mkt, 4),
            "cost_of_control_at_arms_length": round(cost_control, 4),
            "cost_of_entire_constituent_capital": round(cost_whole, 4),
            "capital_multiple_of_control_cost": round(control_multiple, 4),
            "excess_capital_over_control_cost": round(excess_over_control, 4),
            "capital_covers_entire_constituent_capital": covers_whole,
            "control_cost_share_of_capital_raised": round((cost_control / capital) if capital else 0.0, 4),
        }
        if verbose:
            result["thresholds"] = {"min_carry_in_premium_pct": min_prem}
            result["tests_applied"] = [
                "carried-in value versus arms-length price paid for control",
                "carried-in value versus contemporaneous market quotation",
                "capital raised versus the cost of the control percentage actually acquired",
                "capital raised versus the entire capital of the constituent companies",
            ]

        return json.dumps({
            "result": result,
            "error": None,
            "metadata": {"provenance": {
                "source_grounded": [
                    "arms-length price paid for control as the comparison basis",
                    "contemporaneous market quotation as the comparison basis",
                    "value at which the property is carried into the new company",
                    "capital raised should have been sufficient to pay for the entire capital of the constituent companies",
                    "only a control, presumably 51 per cent, was declared to have been acquired",
                ],
                "model_extrapolated": [
                    "materiality threshold of 10.0 percent for the carry-in premium",
                    "entire constituent capital taken as shares outstanding times the arms-length price when not supplied",
                    "constituent shares derived from the stated capital when only the capital is supplied",
                    "control cost taken as control fraction times shares times arms-length price",
                    "raw verdict also raised on carry-in premium alone, without the capital test",
                ],
            }},
        })
    except Exception as exc:  # pragma: no cover - defensive
        return json.dumps({
            "result": None,
            "error": "%s: %s" % (type(exc).__name__, exc),
            "metadata": {"provenance": {
                "source_grounded": [],
                "model_extrapolated": [],
            }},
        })