import json
from typing import Any, Dict, List, Optional


async def primary_swing_duration_bound_test(
    swings: List[Dict],
    dow_min_years: float = 4.0,
    dow_max_years: float = 6.0,
    corrected_rarely_years: float = 3.0,
    corrected_oftener_years: float = 2.0,
    support_share: float = 0.5,
    verbose: bool = True,
) -> str:
    """Test observed primary (major) swing durations against Dow's claimed extent and against the corrected bound.

    Use when you have a SET of dated primary swings -- each with a start year and
    an end year (or an explicit duration in years) -- and you want to know which
    claim about the length of the primary movement the record supports: Dow's own
    claim in the "Swings Within Swings" editorial of January 4, 1902 that "the
    third swing is the great move covering from four to six years", or the
    corrected bound this chapter reaches after examining the record -- that the
    major swing was never "from four to six years, rarely three years and
    oftener less than two".

    Returns, per swing, its length in years and which bounds it falls inside;
    then the share of swings inside Dow's band, the share at or under the
    "rarely three years" bound, the share under the "oftener less than two"
    bound, and a verdict naming the claim the data supports.

    Do NOT use this to classify a single movement as daily / secondary / primary
    -- call `dow_three_movement_classification` (chCYCLES AND STOCK MARKET
    RECORDS). Do NOT use it to test a predicted swing length derived from crisis
    intervals -- call `crisis_cycle_halving_falsification_test`.

    Extends: `dow_three_movement_classification` (chCYCLES AND STOCK MARKET
    RECORDS) -- it supplies the revised duration bounds for the primary swing
    (Dow's 4-6 years rejected; rarely 3, oftener under 2) and turns them into a
    pass/fail test over a SET of observed swing date ranges instead of a
    classification of one movement.
    """
    try:
        dow_min_years = 4.0 if dow_min_years is None else float(dow_min_years)
        dow_max_years = 6.0 if dow_max_years is None else float(dow_max_years)
        corrected_rarely_years = 3.0 if corrected_rarely_years is None else float(corrected_rarely_years)
        corrected_oftener_years = 2.0 if corrected_oftener_years is None else float(corrected_oftener_years)
        support_share = 0.5 if support_share is None else float(support_share)
        rows: List[Dict[str, Any]] = []
        for raw in swings or []:
            if not isinstance(raw, dict):
                continue
            duration = raw.get("duration_years")
            start = raw.get("start_year")
            end = raw.get("end_year")
            if duration is None:
                if start is None or end is None:
                    continue
                duration = float(end) - float(start)
            duration = float(duration)
            rows.append({
                "label": raw.get("label"),
                "direction": raw.get("direction"),
                "start_year": None if start is None else float(start),
                "end_year": None if end is None else float(end),
                "years": duration,
                "in_dow_band": bool(dow_min_years <= duration <= dow_max_years),
                "within_rarely_three": bool(duration <= corrected_rarely_years),
                "under_two": bool(duration < corrected_oftener_years),
            })

        n = len(rows)
        if n == 0:
            result: Dict[str, Any] = {
                "n_swings": 0,
                "mean_years": 0.0,
                "max_years": 0.0,
                "min_years": 0.0,
                "dow_band_share": 0.0,
                "rarely_three_share": 0.0,
                "under_two_share": 0.0,
                "swings_in_dow_band": 0,
                "dow_claim_supported": False,
                "corrected_claim_supported": False,
                "verdict": "insufficient_data",
                "reason": "No swing with a usable duration was supplied, so neither claim can be tested.",
            }
            if verbose:
                result["swings"] = []
                result["thresholds"] = {
                    "dow_min_years": dow_min_years,
                    "dow_max_years": dow_max_years,
                    "corrected_rarely_years": corrected_rarely_years,
                    "corrected_oftener_years": corrected_oftener_years,
                    "support_share": support_share,
                }
            return json.dumps({
                "result": result,
                "error": None,
                "metadata": {"provenance": {
                    "source_grounded": [
                        "Dow: the third swing is the great move covering from four to six years",
                        "corrected bound: never from four to six years, rarely three years, oftener less than two",
                    ],
                    "model_extrapolated": [
                        "'rarely three' read as duration <= 3 years; 'oftener less than two' read as duration < 2 years",
                        "a claim counts as supported when at least 50% (support_share) of observed swings satisfy it",
                        "verdict labels and the insufficient_data case for an empty swing set",
                    ],
                }},
            })

        durations = [row["years"] for row in rows]
        in_dow = sum(1 for row in rows if row["in_dow_band"])
        within_rare = sum(1 for row in rows if row["within_rarely_three"])
        under_two = sum(1 for row in rows if row["under_two"])
        dow_share = in_dow / float(n)
        rare_share = within_rare / float(n)
        two_share = under_two / float(n)

        dow_supported = bool(dow_share >= support_share)
        corrected_supported = bool(rare_share >= support_share and two_share >= support_share)

        if n > 0 and dow_supported and corrected_supported:
            verdict = "ambiguous_both_supported"
        elif dow_supported:
            verdict = "dow_four_to_six_years"
        elif corrected_supported:
            verdict = "corrected_rarely_three_oftener_under_two"
        else:
            verdict = "neither_claim_supported"

        if verdict == "dow_four_to_six_years":
            reason = (
                "Dow's claim is supported: %d of %d primary swings (%.2f) fall inside 'from four to six years' "
                "(>= %.2f of the record), while only %.2f are at or under three years."
                % (in_dow, n, dow_share, support_share, rare_share)
            )
        elif verdict == "corrected_rarely_three_oftener_under_two":
            reason = (
                "Dow's claim is refuted and the corrected bound is supported: only %d of %d swings (%.2f) fall "
                "inside four to six years, %.2f are at or under three years and %.2f are under two years -- never "
                "four to six years, rarely three, oftener less than two."
                % (in_dow, n, dow_share, rare_share, two_share)
            )
        elif verdict == "ambiguous_both_supported":
            reason = (
                "Both claims are met by at least %.2f of the record (Dow band %.2f, three years or less %.2f, "
                "under two %.2f); the sample is too mixed to separate them."
                % (support_share, dow_share, rare_share, two_share)
            )
        else:
            reason = (
                "Neither claim is supported: only %.2f of the swings fall inside Dow's four-to-six-year band and "
                "only %.2f are at or under three years, both below the %.2f needed."
                % (dow_share, rare_share, support_share)
            )

        result = {
            "n_swings": n,
            "mean_years": sum(durations) / float(n),
            "max_years": max(durations),
            "min_years": min(durations),
            "dow_band_share": dow_share,
            "rarely_three_share": rare_share,
            "under_two_share": two_share,
            "swings_in_dow_band": in_dow,
            "dow_claim_supported": dow_supported,
            "corrected_claim_supported": corrected_supported,
            "verdict": verdict,
            "reason": reason,
        }
        if verbose:
            result["swings"] = rows
            result["thresholds"] = {
                "dow_min_years": dow_min_years,
                "dow_max_years": dow_max_years,
                "corrected_rarely_years": corrected_rarely_years,
                "corrected_oftener_years": corrected_oftener_years,
                "support_share": support_share,
            }
        return json.dumps({
            "result": result,
            "error": None,
            "metadata": {"provenance": {
                "source_grounded": [
                    "Dow: the third swing is the great move covering from four to six years",
                    "corrected bound: never from four to six years, rarely three years, oftener less than two",
                ],
                "model_extrapolated": [
                    "'rarely three' read as duration <= 3 years; 'oftener less than two' read as duration < 2 years",
                    "a claim counts as supported when at least 50% (support_share) of observed swings satisfy it",
                    "verdict labels and the insufficient_data case for an empty swing set",
                ],
            }},
        })
    except Exception as exc:  # pragma: no cover - defensive
        return json.dumps({
            "result": None,
            "error": "%s: %s" % (type(exc).__name__, exc),
            "metadata": {"provenance": {
                "source_grounded": [],
                "model_extrapolated": ["error path only"],
            }},
        })