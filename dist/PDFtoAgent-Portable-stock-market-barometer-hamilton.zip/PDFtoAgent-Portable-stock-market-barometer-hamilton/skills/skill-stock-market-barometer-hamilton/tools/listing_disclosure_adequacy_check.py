import json
from typing import Optional


async def listing_disclosure_adequacy_check(
    purposes_disclosed: bool = False,
    contracts_disclosed: bool = False,
    commissions_disclosed: bool = False,
    operating_figures_published: bool = False,
    other_material_disclosed: bool = False,
    reporting_intervals_per_year: float = 0.0,
    periods_since_last_report: Optional[float] = None,
    operating_figures_documented: Optional[float] = None,
    min_intervals_per_year: float = 2.0,
    max_periods_since_last_report: float = 2.0,
    verbose: bool = True,
) -> str:
    """Check a security against the publicity the chapter requires for listing -- fullest disclosure of purposes, contracts, commissions and operating figures at frequent intervals -- and classify it as adequately disclosed or a blind pool.

    Use when vetting a security (or an exchange's unlisted department) against
    the chapter's standard. The chapter's rule: registration cannot be made
    until the fullest possible disclosure of purposes, contracts, commissions
    and everything else has been made; companies must publish the fullest
    possible figures of their operation at frequent intervals; and a company
    that refuses lays its management under the gravest suspicion. It was of just
    such a security -- American Sugar in Havemeyer's day -- that the chapter's
    paper did not hesitate to use the epithet "blind pool".

    Do NOT use this to classify a market move or attribute manipulation (call
    manipulation_scope_by_movement_classifier), and do NOT use it for the
    mechanics of execution (call market_turn_effective_execution_price).

    Args:
        purposes_disclosed: the purposes of the company are fully disclosed.
        contracts_disclosed: its contracts are fully disclosed.
        commissions_disclosed: commissions (promotion and underwriting) are
            disclosed.
        operating_figures_published: it publishes the fullest possible operating
            figures.
        other_material_disclosed: everything else material is disclosed.
        reporting_intervals_per_year: how many times a year operating figures
            are published, used to judge "frequent intervals".
        periods_since_last_report: periods elapsed since the last report, used
            when the caller tracks recency rather than frequency.
        operating_figures_documented: share of required operating-figure items
            actually published, in per cent (0-100); overrides the boolean when
            supplied.
        min_intervals_per_year: publications per year at or above which the
            reporting counts as frequent (default 2.0, semiannual or better).
        max_periods_since_last_report: periods since the last report at or below
            which the reporting counts as current (default 2.0).
        verbose: False returns the compact ruling; True adds the full breakdown.

    Returns:
        JSON string with result/error/metadata. Result holds the disclosure
        score, the items missing, the verdict -- "adequately_disclosed",
        "partial_disclosure" or "blind_pool" -- and a short reason.
    """
    try:
        items = {
            "purposes": bool(purposes_disclosed),
            "contracts": bool(contracts_disclosed),
            "commissions": bool(commissions_disclosed),
            "operating_figures": bool(operating_figures_published),
            "other_material": bool(other_material_disclosed),
        }
        missing = [name for name, ok in items.items() if not ok]

        doc = operating_figures_documented
        if doc is not None:
            doc_pct = max(0.0, min(100.0, float(doc)))
        else:
            doc_pct = (len(items) - len(missing)) / float(len(items)) * 100.0

        freq_ok = None
        min_iv = float(min_intervals_per_year) if min_intervals_per_year is not None else 2.0
        iv = float(reporting_intervals_per_year) if reporting_intervals_per_year else 0.0
        if iv > 0.0:
            freq_ok = iv >= min_iv
        if periods_since_last_report is not None:
            max_gap = (
                float(max_periods_since_last_report)
                if max_periods_since_last_report is not None
                else 2.0
            )
            current = float(periods_since_last_report) <= max_gap
            freq_ok = current if freq_ok is None else (freq_ok and current)

        complete = len(missing) == 0
        if complete and (freq_ok is None or freq_ok):
            verdict = "adequately_disclosed"
            reason = (
                "Fullest disclosure of purposes, contracts, commissions and "
                "everything else, with operating figures published at frequent "
                "intervals: the buyer can find out all about the property."
            )
        elif not complete and doc_pct > 0.0:
            verdict = "partial_disclosure"
            reason = (
                "Disclosure is partial (%.1f%% of required items; missing: %s). "
                "Until the fullest disclosure is made the security is not a "
                "listed-grade security." % (doc_pct, ", ".join(missing))
            )
        else:
            verdict = "blind_pool"
            reason = (
                "No material disclosure at all: this is the blind pool the chapter "
                "describes -- management lays itself under the gravest suspicion by "
                "refusing the terms of publicity."
            )
        if complete and freq_ok is False:
            verdict = "partial_disclosure"
            reason = (
                "All items are disclosed, but operating figures are not published "
                "at frequent intervals (%.2f per year against a %.2f minimum): "
                "disclosure is not current enough to protect the buyer."
                % (iv, min_iv)
            )

        result = {
            "disclosed_items": items,
            "disclosure_score_pct": doc_pct,
            "missing_items": missing,
            "frequent_reporting": freq_ok,
            "verdict": verdict,
        }
        if verbose:
            result["reporting_intervals_per_year"] = iv
            result["min_intervals_per_year"] = min_iv
            result["periods_since_last_report"] = (
                float(periods_since_last_report)
                if periods_since_last_report is not None
                else None
            )
            result["max_periods_since_last_report"] = (
                float(max_periods_since_last_report)
                if max_periods_since_last_report is not None
                else 2.0
            )
            result["reason"] = reason
        return json.dumps(
            {
                "result": result,
                "error": None,
                "metadata": {
                    "provenance": {
                        "source_grounded": [
                            "fullest possible disclosure of purposes",
                            "fullest possible disclosure of contracts",
                            "fullest possible disclosure of commissions",
                            "fullest possible disclosure of everything else",
                            "fullest possible operating figures at frequent intervals",
                            "refusal to comply lays management under the gravest suspicion",
                            "blind pool epithet applied to non-complying unlisted securities",
                        ],
                        "model_extrapolated": [
                            "five scored disclosure items (purposes, contracts, commissions, operating figures, other material)",
                            "frequent intervals defined as 2.0 reports per year",
                            "max gap of 2.0 periods since the last report",
                            "partial_disclosure intermediate class between adequate and blind pool",
                            "disclosure score as the share of items disclosed",
                        ],
                    }
                },
            }
        )
    except Exception as exc:
        return json.dumps(
            {
                "result": None,
                "error": str(exc),
                "metadata": {
                    "provenance": {
                        "source_grounded": [
                            "fullest possible disclosure of purposes, contracts, commissions",
                            "blind pool epithet for non-complying securities",
                        ],
                        "model_extrapolated": [
                            "frequent intervals defined as 2.0 reports per year",
                            "five scored disclosure items",
                        ],
                    }
                },
            }
        )