"""Classify each period of a manipulated stock's record into the chapter's stages.

Use when you have a manipulated stock's record split into periods (sales,
price range, closing price, brokers) and you want each period named as one of
the stages the chapter identifies in the Amalgamated Copper campaign:
reluctant insider accumulation, the deliberate break that establishes a real
price, the quiet period of cultivation, the final distribution on a rising
market, and the public's own boom after the operator is out.

Inputs: periods (one dict per period: label, opening_price, closing_price,
period_high, period_low, sales_shares, days, brokers, insider_buying),
operator_brokers (houses known to act for the operator), market_prices
(general market level per period, used for the "rising general market" test).
Do NOT use this to test whether the insiders were compelled -- call
forced_insider_accumulation_classifier. Do NOT use it to detect brokers on
both sides -- call matched_order_both_sides_detector.
"""

import json
from typing import Any, Dict, List, Optional


async def manipulated_distribution_stage_taxonomy(
    periods: List[Dict],
    operator_brokers: Optional[List[str]] = None,
    market_prices: Optional[List[float]] = None,
    quiet_range_points: float = 5.0,
    heavy_rate_multiple: float = 1.25,
    light_rate_multiple: float = 0.75,
    verbose: bool = True,
) -> str:
    """Name the manipulation stage of every period in a stock's record."""

    def _f(v: Any, default: float = 0.0) -> float:
        try:
            if v is None:
                return default
            return float(v)
        except (TypeError, ValueError):
            return default

    def _dir(x: float) -> str:
        if x > 1e-12:
            return "up"
        if x < -1e-12:
            return "down"
        return "flat"

    def _median(xs: List[float]) -> float:
        s = sorted(xs)
        m = len(s)
        if m == 0:
            return 0.0
        if m % 2 == 1:
            return s[m // 2]
        return 0.5 * (s[m // 2 - 1] + s[m // 2])

    try:
        quiet_range_points = _f(quiet_range_points, 5.0)
        heavy_rate_multiple = _f(heavy_rate_multiple, 1.25)
        light_rate_multiple = _f(light_rate_multiple, 0.75)
        op_set = {str(b) for b in (operator_brokers or []) if b is not None}
        mkt = [_f(v) for v in (market_prices or [])]

        raw = [p for p in (periods or []) if isinstance(p, dict)]

        parsed: List[Dict[str, Any]] = []
        for i, p in enumerate(raw):
            opening = _f(p.get("opening_price", p.get("open")))
            closing = _f(p.get("closing_price", p.get("close")))
            high = _f(p.get("period_high", p.get("high")))
            low = _f(p.get("period_low", p.get("low")))
            if high == 0.0 and low == 0.0:
                high = max(opening, closing)
                low = min(opening, closing)
            if high < low:
                high, low = low, high
            days = int(_f(p.get("days"), 0.0))
            sales = _f(p.get("sales_shares", p.get("sales")))
            brokers = [str(b) for b in (p.get("brokers") or [])]
            parsed.append({
                "label": str(p.get("label") or ("period_%d" % (i + 1))),
                "start": p.get("start"),
                "end": p.get("end"),
                "opening_price": opening,
                "closing_price": closing,
                "period_high": high,
                "period_low": low,
                "sales_shares": sales,
                "rate": (sales / float(days)) if days > 0 else sales,
                "insider_buying": bool(p.get("insider_buying", False)),
                "brokers": brokers,
            })

        n = len(parsed)
        base_rate = _median([r["rate"] for r in parsed]) if n else 0.0

        rows: List[Dict[str, Any]] = []
        seen_distribution = False
        prev_op: List[str] = []
        for i, r in enumerate(parsed):
            rng = r["period_high"] - r["period_low"]
            net = r["closing_price"] - r["opening_price"]
            net_dir = _dir(net)
            net_pct = (net / r["opening_price"] * 100.0) if r["opening_price"] else 0.0
            rate = r["rate"]
            vs_base = (rate / base_rate) if base_rate > 0 else 0.0
            if base_rate <= 0:
                activity = "no_recorded_sales"
            elif rate >= base_rate * heavy_rate_multiple:
                activity = "heavy"
            elif rate <= base_rate * light_rate_multiple:
                activity = "light"
            else:
                activity = "moderate"
            op_here = [b for b in r["brokers"] if b in op_set]
            market_dir = "unknown"
            if i < len(mkt) and i + 1 < len(mkt) and mkt[i] > 0:
                market_dir = _dir(mkt[i + 1] - mkt[i])
            elif i + 1 < len(mkt):
                market_dir = _dir(mkt[i + 1] - mkt[i]) if mkt[i] != 0 else "unknown"

            if r["insider_buying"] and net_dir == "down" and market_dir == "up":
                stage = "reluctant_insider_accumulation"
                reason = ("insiders reported buying while the stock fell %.2f points "
                          "and the general market rose" % net)
            elif op_here and net_dir == "down" and not prev_op:
                stage = "deliberate_break_to_real_price"
                reason = ("operator brokers appear for the first time and the price is "
                          "broken %.2f points, establishing a more real price" % net)
            elif op_here and net_dir == "down" and activity == "heavy":
                stage = "deliberate_break_to_real_price"
                reason = ("operator brokers active and the price broken %.2f points, "
                          "establishing a more real price" % net)
            elif rng <= quiet_range_points and activity != "heavy":
                stage = "quiet_cultivation"
                reason = ("extreme fluctuation of %.2f points is within the quiet "
                          "band of %.2f points on %s volume" % (rng, quiet_range_points, activity))
            elif activity == "heavy" and net_dir == "up" and op_here:
                stage = "final_distribution_on_rising_market"
                reason = ("heavy sales at %.2fx the campaign median rate with the price "
                          "up %.2f points and operator brokers executing" % (vs_base, net))
                seen_distribution = True
            elif activity == "heavy" and net_dir == "up" and not op_here:
                stage = "publics_own_boom"
                reason = ("heavy sales with the price up %.2f points and no operator "
                          "brokers in the record" % net)
            elif seen_distribution and net_dir == "up" and not op_here:
                stage = "publics_own_boom"
                reason = ("advance of %.2f points continues after the operator's "
                          "distribution with no operator brokers" % net)
            elif net_dir == "down" and activity != "light":
                stage = "deliberate_break_to_real_price"
                reason = ("price broken %.2f points on %s volume" % (net, activity))
            elif r["insider_buying"]:
                stage = "reluctant_insider_accumulation"
                reason = ("insiders reported buying while the stock moved %.2f points" % net)
            else:
                stage = "unclassified"
                reason = ("period does not match any stage signature: %s volume, "
                          "%.2f point range, net %.2f" % (activity, rng, net))

            row = {
                "label": r["label"],
                "start": r["start"],
                "end": r["end"],
                "stage": stage,
                "reason": reason,
                "sales_shares": r["sales_shares"],
                "daily_sales_rate": round(rate, 4),
                "activity_class": activity,
                "range_points": round(rng, 4),
                "net_price_change": round(net, 4),
                "net_price_change_pct": round(net_pct, 4),
                "net_price_direction": net_dir,
                "market_direction": market_dir,
                "operator_brokers_present": op_here,
            }
            if verbose:
                row["brokers"] = r["brokers"]
            rows.append(row)
            prev_op = op_here

        stages = [r["stage"] for r in rows]
        canonical = [
            "reluctant_insider_accumulation",
            "deliberate_break_to_real_price",
            "quiet_cultivation",
            "final_distribution_on_rising_market",
            "publics_own_boom",
        ]
        order_idx = [canonical.index(s) for s in stages if s in canonical]
        in_order = all(b >= a for a, b in zip(order_idx, order_idx[1:])) if len(order_idx) > 1 else (len(order_idx) == 1)

        distribution_period = None
        boom_period = None
        for r in rows:
            if distribution_period is None and r["stage"] == "final_distribution_on_rising_market":
                distribution_period = r["label"]
            if boom_period is None and r["stage"] == "publics_own_boom":
                boom_period = r["label"]

        summary = {
            "period_count": n,
            "stage_sequence": stages,
            "stages_named": sorted(set(stages)),
            "stages_in_chapter_order": bool(in_order),
            "distribution_period": distribution_period,
            "public_boom_period": boom_period,
            "campaign_high": (max(r["period_high"] for r in parsed) if parsed else None),
            "campaign_low": (min(r["period_low"] for r in parsed) if parsed else None),
        }

        compact_rows = [
            {k: r[k] for k in ("label", "stage", "reason", "activity_class",
                               "range_points", "net_price_change", "net_price_direction")}
            for r in rows
        ]

        result: Dict[str, Any] = {
            "period_count": n,
            "rows": rows if verbose else compact_rows,
            "summary": summary,
        }
        if verbose:
            result["stage_definitions"] = {
                "reluctant_insider_accumulation": "insiders buying against their will, price falling while the general market rises",
                "deliberate_break_to_real_price": "operator breaks the price to a real level before marking it up",
                "quiet_cultivation": "light volume, extreme fluctuation under the quiet band, bullish sentiment cultivated",
                "final_distribution_on_rising_market": "heavy volume, rising price, operator brokers executing the block",
                "publics_own_boom": "heaviest volume and largest advance after the operator's stock is marketed",
            }

        return json.dumps({
            "result": result,
            "error": None,
            "metadata": {"provenance": {
                "source_grounded": [
                    "quiet period extreme fluctuation of less than five points",
                    "reluctant insider accumulation judged from the downward movement of the stock",
                    "deliberate break of the market before putting the stock up",
                    "final distribution of the block in the third movement on a rising market",
                    "public's own boom after the pool stock had been marketed",
                    "general bull movement of the McKinley boom as the market backdrop",
                ],
                "model_extrapolated": [
                    "heavy/light activity cutoffs of 1.25x and 0.75x the campaign median rate",
                    "operator-broker presence required for the final distribution stage",
                    "public boom inferred from heavy volume and advance with no operator brokers",
                    "decision-tree precedence when a period matches two stage signatures",
                ],
            }},
        })
    except Exception as exc:  # pragma: no cover - defensive
        return json.dumps({
            "result": None,
            "error": "%s: %s" % (type(exc).__name__, exc),
            "metadata": {"provenance": {
                "source_grounded": [],
                "model_extrapolated": [],
            }},
        })