"""Plan buying on a reaction in a major bull swing and adding to holdings as the market rises."""

import json
import math
from typing import List, Optional

_PROVENANCE = {
    "source_grounded": [
        "precondition: when once the major bull swing is established",
        "buy in the dulness which develops after a secondary reaction in a major bull swing",
        "if on the completion of his purchase a stock reacts, take the loss without hesitation and wait",
        "instead of purchasing on the way down, he may well add to his holdings as the market rises",
        "each advance adds to his margin of safety",
        "guard: provided he does not pyramid too much",
        "guard: conceding that his holdings are not overextended so that his own account would be a tempting object of attack",
        "guard: protect himself with stop-loss orders",
        "the fallacious assumption of averaging on the way down is explicitly rejected",
    ],
    "model_extrapolated": [
        "dulness test: a low share of the swing's daily range over the lookback",
        "pyramid cap of 3 additions to the initial lot",
        "overextension cap of 3 times the speculator's own capital in market value",
        "entry on a rising market only, never on a decline",
        "stop-loss distance in per cent below the average cost",
    ],
}


def _num(value, default):
    if value is None:
        return float(default)
    try:
        out = float(value)
    except (TypeError, ValueError):
        return float(default)
    if math.isnan(out) or math.isinf(out):
        return float(default)
    return out


def _clean(seq):
    out = []
    for v in seq or []:
        try:
            out.append(float(v))
        except (TypeError, ValueError):
            out.append(None)
    return [v for v in out if v is not None]


async def pyramid_on_advance_stop_loss_plan(
    prices: Optional[List[float]] = None,
    capital: float = 0.0,
    initial_shares: float = 100.0,
    addition_shares: float = 100.0,
    price_per_share: float = 0.0,
    major_bull_swing_established: bool = True,
    reaction_low: Optional[float] = None,
    swing_high: Optional[float] = None,
    max_additions: float = 3.0,
    max_position_multiple_of_capital: float = 3.0,
    stop_loss_pct: float = 2.0,
    dulness_lookback: float = 10.0,
    dulness_range_pct: float = 1.0,
    verbose: bool = True,
) -> str:
    """Plan a purchase in an established major bull swing: buy in the dulness after a
    secondary reaction, then add to holdings only as the market rises, capped against
    over-pyramiding and over-extension, and protected by stop-loss orders.

    Use when the major bull swing is established and a secondary reaction has just run
    its course. Pass the stock's recent price series (and optionally the reaction low
    and the swing high), your capital, and the lot sizes you contemplate. The tool
    decides whether the market is in the dulness the chapter waits for, builds the
    initial lot, and then schedules the permitted additions on advances -- never on
    declines, which the chapter calls the fallacious assumption.

    Do NOT use it to decide whether the major swing IS a bull swing (that is a
    barometer question), and do NOT use it before the reaction has run: if the market
    is still falling, the plan is to take the loss and wait. Do NOT use it to size a
    margin lot against a stop -- call margin_capital_loss_exposure_test.

    Returns whether the moment is right, the entry price, the planned additions, the
    caps that bind, the stop-loss levels, and a verdict.
    """
    capital = max(_num(capital, 0.0), 0.0)
    init_shares = max(_num(initial_shares, 100.0), 0.0)
    add_shares = max(_num(addition_shares, 100.0), 0.0)
    price = max(_num(price_per_share, 0.0), 0.0)
    max_adds = int(max(_num(max_additions, 3.0), 0.0))
    max_mult = max(_num(max_position_multiple_of_capital, 3.0), 0.0)
    stop_pct = max(_num(stop_loss_pct, 2.0), 0.0)
    lookback = int(max(_num(dulness_lookback, 10.0), 1.0))
    dull_pct = max(_num(dulness_range_pct, 1.0), 0.0)
    series = _clean(prices)

    if not series and price <= 0:
        return json.dumps({
            "result": {
                "verdict": "no_price_data",
                "ready_to_buy": False,
                "additions_planned": 0,
                "total_shares": 0.0,
            },
            "error": None,
            "metadata": {"provenance": _PROVENANCE},
        })

    last = series[-1] if series else price
    if series and len(series) >= 2:
        net_move = last - series[0]
        if net_move > 0:
            direction = "up"
        elif net_move < 0:
            direction = "down"
        else:
            direction = "none"
    else:
        net_move = 0.0
        direction = "none"

    window = series[-lookback:] if series else [last]
    lo = min(window)
    hi = max(window)
    mid = (hi + lo) / 2.0 if hi > 0 or lo > 0 else 0.0
    range_pct = (100.0 * (hi - lo) / mid) if mid > 0 else 0.0
    is_dull = range_pct <= dull_pct

    rising = direction == "up"
    falling = direction == "down"

    if len(series) < 2:
        verdict = "insufficient_record"
        ready = False
        reason = (
            "Fewer than two prices were supplied, so neither the direction of the market nor "
            "its dulness can be read. Wait for a record of the reaction and of the dulness "
            "that follows it."
        )
    elif not major_bull_swing_established:
        verdict = "wait_major_bull_swing_not_established"
        ready = False
        reason = (
            "The major bull swing is not established. Buying for a rise is only a feasible "
            "proposition once it is; until then the indecisive fluctuations eat up capital in "
            "commissions and interest."
        )
    elif falling and not is_dull:
        verdict = "exit_and_wait"
        ready = False
        reason = (
            "The market is still falling (%.4g points over the record). If on the completion "
            "of the purchase a stock reacts, take the loss without hesitation and wait for the "
            "dulness that develops after the secondary reaction." % net_move
        )
    elif not is_dull:
        verdict = "wait_for_dulness"
        ready = False
        reason = (
            "The recent range is %.4g%% of the mid price, wider than the %.4g%% dulness band; "
            "wait for the period of dulness which develops after a secondary reaction in a "
            "major bull swing." % (range_pct, dull_pct)
        )
    else:
        ready = True
        verdict = "buy_initial_lot_then_add_on_advances"
        reason = (
            "The major bull swing is established and the market is dull (%.4g%% range over the "
            "last %.4g sessions, inside the %.4g%% band). Buy the initial lot here, add only as "
            "the market rises, and protect with stop-loss orders."
            % (range_pct, len(window), dull_pct)
        )

    entry_price = last if last > 0 else price
    entry_price = entry_price if entry_price > 0 else 0.0

    # additions: only on advances above the previous level, capped by count and by overextension
    additions = []
    shares_held = init_shares if ready else 0.0
    cost = shares_held * entry_price
    if ready and add_shares > 0 and entry_price > 0:
        step_points = max(entry_price * (dull_pct / 100.0), entry_price * 0.01)
        level = entry_price + step_points
        for i in range(max_adds):
            projected_value = (shares_held + add_shares) * level
            overextended = (capital > 0) and (projected_value > max_mult * capital)
            if overextended:
                break
            shares_held += add_shares
            cost += add_shares * level
            avg_cost = cost / shares_held if shares_held > 0 else 0.0
            additions.append({
                "step": i + 1,
                "trigger_price": level,
                "add_shares": add_shares,
                "cumulative_shares": shares_held,
                "average_cost": avg_cost,
                "position_value": shares_held * level,
                "stop_loss_price": avg_cost * (1.0 - stop_pct / 100.0),
            })
            level += step_points

    avg_cost = (cost / shares_held) if shares_held > 0 else 0.0
    position_value = shares_held * entry_price
    overextended_now = (capital > 0) and (position_value > max_mult * capital)
    pyramid_capped = bool(ready and max_adds > 0 and len(additions) < max_adds and not overextended_now)

    stop_price = avg_cost * (1.0 - stop_pct / 100.0)
    stop_dollars = (avg_cost - stop_price) * shares_held if shares_held > 0 else 0.0

    result = {
        "verdict": verdict,
        "ready_to_buy": ready,
        "major_bull_swing_established": bool(major_bull_swing_established),
        "direction": direction,
        "recent_range_pct": range_pct,
        "dulness_range_pct": dull_pct,
        "is_dull": is_dull,
        "entry_price": entry_price,
        "initial_shares": init_shares if ready else 0.0,
        "additions_planned": len(additions),
        "max_additions": max_adds,
        "pyramid_capped": pyramid_capped,
        "total_shares": shares_held,
        "average_cost": avg_cost,
        "position_value": position_value,
        "capital": capital,
        "position_multiple_of_capital": (position_value / capital) if capital > 0 else None,
        "max_position_multiple_of_capital": max_mult,
        "overextended": overextended_now,
        "stop_loss_pct": stop_pct,
        "stop_loss_price": stop_price,
        "stop_loss_dollars": stop_dollars,
    }

    if verbose:
        result["reaction_low"] = None if reaction_low is None else _num(reaction_low, 0.0)
        result["swing_high"] = None if swing_high is None else _num(swing_high, 0.0)
        result["net_move_points"] = net_move
        result["window_low"] = lo
        result["window_high"] = hi
        result["addition_schedule"] = additions
        result["reason"] = reason

    return json.dumps({"result": result, "error": None, "metadata": {"provenance": _PROVENANCE}})