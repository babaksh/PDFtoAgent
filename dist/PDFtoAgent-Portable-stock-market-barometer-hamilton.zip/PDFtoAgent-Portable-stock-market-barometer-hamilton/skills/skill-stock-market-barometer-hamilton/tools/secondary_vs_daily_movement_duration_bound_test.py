import json
import math
from typing import Dict, List, Optional


def _as_float(value, default: float) -> float:
    try:
        if value is None:
            return float(default)
        return float(value)
    except (TypeError, ValueError):
        return float(default)


async def secondary_vs_daily_movement_duration_bound_test(
    moves: Optional[List[Dict]] = None,
    daily_max_days: float = 3.0,
    secondary_min_days: float = 21.0,
    dow_min_days: float = 40.0,
    dow_max_days: float = 60.0,
    extent_reference_points: float = 6.0,
    verbose: bool = True,
) -> str:
    """Classify each observed move as a mere daily fluctuation or a true secondary movement using Dow's counter-movement duration bound.

    Use when you have one or more observed moves (each with a duration in days and an
    extent in price points) and you must decide whether the move is only a daily
    fluctuation or a genuine secondary reaction/rally. The discriminator the chapter
    supplies is DURATION, not extent: Dow estimated a counter movement at from forty
    to sixty days, later experience showed the longer range is exceedingly rare and
    the duration may be appreciably less than forty days. Extent alone cannot decide
    it -- one day in late December 1917 carried the railroad average up over six
    points and was still only a daily fluctuation, while there have been true
    secondary movements that did not carry even so far.

    Extends: primary_swing_duration_bound_test (chCHARLES H. DOW, AND HIS THEORY),
    which applies a duration bound to PRIMARY swings of years; this tool applies the
    bound to SECONDARY counter-movements of days and adds the extent-overlap branch.

    Do NOT use this to classify a primary (major) swing measured in months or years --
    use primary_swing_duration_bound_test. Do NOT use it to detect whether a primary
    movement has resumed after a secondary decline -- use
    secondary_decline_origin_new_high_resumption_test.

    Each entry of `moves` should be a dict with:
      label (str, optional), duration_days (float), extent_points (float).
    """
    try:
        daily_max_days = _as_float(daily_max_days, 3.0)
        secondary_min_days = _as_float(secondary_min_days, 21.0)
        dow_min_days = _as_float(dow_min_days, 40.0)
        dow_max_days = _as_float(dow_max_days, 60.0)
        extent_reference_points = _as_float(extent_reference_points, 6.0)

        entries = [m for m in (moves or []) if isinstance(m, dict)]
        classified: List[Dict] = []
        counts: Dict[str, int] = {}

        for position, move in enumerate(entries):
            label = str(move.get("label") or ("move_%d" % position))
            duration = _as_float(move.get("duration_days"), 0.0)
            extent = math.fabs(_as_float(move.get("extent_points"), 0.0))

            if duration <= 0.0:
                classification = "indeterminate"
                band_status = "no_duration"
                reason = (
                    "no measurable duration was supplied; the duration bound cannot be applied"
                )
            elif duration <= daily_max_days:
                classification = "daily_fluctuation"
                band_status = "at_or_below_daily_limit"
                reason = (
                    "duration of %.1f days is at or below the %0.1f-day daily limit, so the move "
                    "is a daily fluctuation no matter how large its extent"
                    % (duration, daily_max_days)
                )
            elif duration < secondary_min_days:
                classification = "indeterminate"
                band_status = "below_secondary_support"
                reason = (
                    "duration of %.1f days exceeds a daily fluctuation but falls below the "
                    "%.1f-day floor at which a counter movement is supported; duration does not "
                    "establish it" % (duration, secondary_min_days)
                )
            elif duration < dow_min_days:
                classification = "secondary_movement"
                band_status = "short_of_dow_forty_days"
                reason = (
                    "duration of %.1f days is appreciably less than Dow's forty days but at or "
                    "above the %.1f-day support floor, which later experience allows"
                    % (duration, secondary_min_days)
                )
            elif duration <= dow_max_days:
                classification = "secondary_movement"
                band_status = "within_dow_forty_to_sixty_days"
                reason = (
                    "duration of %.1f days lies inside Dow's forty-to-sixty-day estimate for a "
                    "counter movement (the upper end is exceedingly rare)" % duration
                )
            else:
                classification = "beyond_dow_counter_movement_bound"
                band_status = "beyond_dow_sixty_days"
                reason = (
                    "duration of %.1f days exceeds even the rare upper end of Dow's "
                    "forty-to-sixty-day estimate; a move this long should be re-examined as "
                    "something other than a counter movement" % duration
                )

            extent_alone_misleading = False
            if extent >= extent_reference_points and classification == "daily_fluctuation":
                extent_alone_misleading = True
            elif extent < extent_reference_points and classification == "secondary_movement":
                extent_alone_misleading = True

            counts[classification] = counts.get(classification, 0) + 1

            row = {
                "label": label,
                "duration_days": duration,
                "extent_points": extent,
                "classification": classification,
                "dow_band_status": band_status,
                "extent_alone_misleading": extent_alone_misleading,
                "reason": reason,
            }
            if verbose:
                row["extent_reference_points"] = extent_reference_points
                row["extent_vs_reference_points"] = extent - extent_reference_points
            classified.append(row)

        compact_moves = [
            {
                "label": r["label"],
                "classification": r["classification"],
                "duration_days": r["duration_days"],
                "extent_points": r["extent_points"],
            }
            for r in classified
        ]

        result = {
            "total_moves": len(classified),
            "counts": counts,
            "moves": classified if verbose else compact_moves,
        }
        if not classified:
            result["classification"] = "no_evidence"
            result["reason"] = (
                "no moves were supplied; supply moves with duration_days and extent_points"
            )
        if verbose:
            result["thresholds"] = {
                "daily_max_days": daily_max_days,
                "secondary_min_days": secondary_min_days,
                "dow_min_days": dow_min_days,
                "dow_max_days": dow_max_days,
                "extent_reference_points": extent_reference_points,
            }
            result["rule"] = (
                "duration, not extent, decides: a move at or below the daily limit is a daily "
                "fluctuation however large, and a true secondary movement may carry less than "
                "the reference extent"
            )

        return json.dumps({
            "result": result,
            "error": None,
            "metadata": {
                "tool": "secondary_vs_daily_movement_duration_bound_test",
                "provenance": {
                    "source_grounded": [
                        "Dow counter-movement estimate of forty to sixty days",
                        "upper end of the range exceedingly rare",
                        "duration may be appreciably less than forty days",
                        "one-day advance of over six points in the railroad average (Dec 1917) was only a daily fluctuation",
                        "true secondary movements existed that did not carry even six points",
                        "extent alone cannot decide the classification",
                    ],
                    "model_extrapolated": [
                        "daily_max_days default of 3 days",
                        "secondary_min_days default of 21 days as 'appreciably less than forty'",
                        "label 'beyond_dow_counter_movement_bound' for moves past sixty days",
                        "extent_reference_points fixed at the chapter's six-point example",
                    ],
                },
            },
        })
    except Exception as exc:  # pragma: no cover - defensive
        return json.dumps({
            "result": None,
            "error": str(exc),
            "metadata": {
                "tool": "secondary_vs_daily_movement_duration_bound_test",
                "provenance": {
                    "source_grounded": ["Dow counter-movement estimate of forty to sixty days"],
                    "model_extrapolated": ["default thresholds"],
                },
            },
        })