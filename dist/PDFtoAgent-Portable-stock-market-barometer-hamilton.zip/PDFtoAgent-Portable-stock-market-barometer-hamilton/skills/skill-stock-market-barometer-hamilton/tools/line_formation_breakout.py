import json
from typing import List, Optional


def _floats(values: Optional[List[float]]) -> List[float]:
    if not values:
        return []
    out = []
    for v in values:
        try:
            out.append(float(v))
        except (TypeError, ValueError):
            continue
    return out


def _band_width_pct(window: List[float]) -> float:
    lo = min(window)
    hi = max(window)
    mid = (lo + hi) / 2.0
    if hi == lo:
        return 0.0
    if mid == 0.0:
        return float("inf")
    return (hi - lo) / abs(mid) * 100.0


def _align(a: List[float], b: List[float]):
    n = min(len(a), len(b))
    return a[:n], b[:n], n


def _longest_line(ind: List[float], rail: List[float], max_band_pct: float, min_periods: int):
    n = len(ind)
    best = None
    start = 0
    while start <= n - min_periods:
        length = min_periods
        if _band_width_pct(ind[start:start + length]) > max_band_pct:
            start += 1
            continue
        if _band_width_pct(rail[start:start + length]) > max_band_pct:
            start += 1
            continue
        while start + length < n:
            nxt = length + 1
            if _band_width_pct(ind[start:start + nxt]) > max_band_pct:
                break
            if _band_width_pct(rail[start:start + nxt]) > max_band_pct:
                break
            length = nxt
        cand = (length, -start)
        if best is None or cand > best:
            best = cand
        start += 1
    if best is None:
        return None
    length = best[0]
    start_idx = -best[1]
    return start_idx, start_idx + length - 1


async def line_formation_breakout(
    industrials: List[float],
    railroads: List[float],
    max_band_pct: float = 6.0,
    min_periods: int = 4,
    confirmation_lag: int = 2,
    verbose: bool = True,
) -> str:
    """Detect a Dow-theory 'making a line' period in two market averages and classify its resolution.

    Use when you have two parallel price averages (e.g. Dow-Jones industrials and
    railroads, aligned period by period, weekly closes) and you want to know whether
    the market has been 'making a line' -- both averages fluctuating inside a narrow
    range for a number of weeks -- and which way that line has resolved. A joint rise
    of both averages above the upper bound of the line is strongly bullish (a secondary
    rally in a bear market or the inception of a primary bull market); a joint break
    below the lower bound is a 'saturation point' where precipitation follows (a
    secondary bear reaction or the inception of a primary downtrend). An unresolved
    line indicates a period of accumulation or distribution.

    Do NOT use this to test whether two averages merely agree in direction -- call
    average_corroboration_check instead. Do NOT use it on a single series; the line
    is defined by the two averages jointly.

    Parameters: industrials (list of floats, one value per period), railroads (same
    length or longer, aligned with industrials), max_band_pct (widest high-low range,
    as percent of the range midpoint, that still counts as a 'narrow range'; the
    chapter's own example of industrials 70-74 / railroads 73-77 is about 5.5%),
    min_periods (fewest periods that count as 'a number of weeks'), confirmation_lag
    (how many periods after the line the second average may lag and still confirm
    the break), verbose (False returns only the verdict and the line bounds).
    """
    try:
        max_band_pct = 6.0 if max_band_pct is None else float(max_band_pct)
        min_periods = 4 if min_periods is None else int(min_periods)
        confirmation_lag = 2 if confirmation_lag is None else int(confirmation_lag)
        if min_periods < 2:
            min_periods = 2
        if confirmation_lag < 0:
            confirmation_lag = 0

        ind, rail, n = _align(_floats(industrials), _floats(railroads))

        provenance = {
            "source_grounded": [
                "making a line = two averages fluctuating within a narrow range for a number of weeks",
                "line indicates a period of distribution or accumulation",
                "joint rise above the high point of the line is strongly bullish (secondary rally or primary bull inception)",
                "joint break below the lower level is a saturation point (secondary bear reaction or primary downtrend)",
            ],
            "model_extrapolated": [
                "numeric width of the narrow range band: max_band_pct default 6.0 percent",
                "minimum number of weeks constituting a line: min_periods default 4",
                "confirmation_lag default 2 for a lagging second average",
                "longest qualifying window selected; ties broken by earliest start",
            ],
        }
        meta = {
            "provenance": provenance,
            "parameters": {
                "max_band_pct": max_band_pct,
                "min_periods": min_periods,
                "confirmation_lag": confirmation_lag,
            },
            "observations_compared": n,
        }

        if n < min_periods:
            result = {
                "line_detected": False,
                "verdict": "insufficient_data",
                "reason": "fewer aligned observations (%d) than the %d periods a line requires" % (n, min_periods),
                "resolution_note": "no line can be identified",
            }
            return json.dumps({"result": result, "error": None, "metadata": meta})

        found = _longest_line(ind, rail, max_band_pct, min_periods)

        if found is None:
            ind_w = _band_width_pct(ind)
            rail_w = _band_width_pct(rail)
            result = {
                "line_detected": False,
                "verdict": "no_line",
                "reason": "no window of %d or more periods keeps both averages inside a %.2f%% band"
                          % (min_periods, max_band_pct),
                "resolution_note": "the averages are still ranging too widely to be making a line",
            }
            if verbose:
                result["widest_full_series_band_pct"] = {
                    "industrials": ind_w,
                    "railroads": rail_w,
                }
            return json.dumps({"result": result, "error": None, "metadata": meta})

        start_idx, end_idx = found
        ind_win = ind[start_idx:end_idx + 1]
        rail_win = rail[start_idx:end_idx + 1]
        ind_hi, ind_lo = max(ind_win), min(ind_win)
        rail_hi, rail_lo = max(rail_win), min(rail_win)

        post_ind = ind[end_idx + 1:end_idx + 1 + confirmation_lag + 1]
        post_rail = rail[end_idx + 1:end_idx + 1 + confirmation_lag + 1]

        def _break(post, hi, lo):
            up_at = None
            down_at = None
            up_pct = 0.0
            down_pct = 0.0
            span = max(abs(hi), abs(lo), 1e-12)
            for k, v in enumerate(post):
                if v > hi and up_at is None:
                    up_at = end_idx + 1 + k
                    up_pct = (v - hi) / span * 100.0
                if v < lo and down_at is None:
                    down_at = end_idx + 1 + k
                    down_pct = (lo - v) / span * 100.0
            return up_at, down_at, up_pct, down_pct

        i_up, i_dn, i_up_pct, i_dn_pct = _break(post_ind, ind_hi, ind_lo)
        r_up, r_dn, r_up_pct, r_dn_pct = _break(post_rail, rail_hi, rail_lo)

        ind_up = i_up is not None and (i_dn is None or i_up <= i_dn)
        ind_down = i_dn is not None and (i_up is None or i_dn < i_up)
        rail_up = r_up is not None and (r_dn is None or r_up <= r_dn)
        rail_down = r_dn is not None and (r_up is None or r_dn < r_up)

        if ind_up and rail_up:
            verdict = "bullish_breakout"
            note = ("both averages rose above the high point of the line: strongly bullish -- "
                    "a secondary rally in a bear market or the inception of a primary bull movement")
        elif ind_down and rail_down:
            verdict = "saturation_point"
            note = ("both averages broke below the lower level: saturation point reached, precipitation follows -- "
                    "a secondary bear reaction in a bull market or the inception of a primary downward movement")
        elif (ind_up and rail_down) or (ind_down and rail_up):
            verdict = "conflicting_break"
            note = "the two averages broke in opposite directions; the line gives no usable indication"
        elif ind_up or rail_up or ind_down or rail_down:
            which = "industrials" if (ind_up or ind_down) else "railroads"
            verdict = "unconfirmed_break"
            note = "only the %s broke its line; the two averages do not corroborate the move" % which
        else:
            verdict = "line_intact"
            note = ("the line is still intact: neither average has left its range, indicating a period of "
                    "accumulation or distribution")

        result = {
            "line_detected": True,
            "verdict": verdict,
            "line_start_index": start_idx,
            "line_end_index": end_idx,
            "line_periods": end_idx - start_idx + 1,
            "industrials_upper": ind_hi,
            "industrials_lower": ind_lo,
            "railroads_upper": rail_hi,
            "railroads_lower": rail_lo,
            "resolution_note": note,
        }

        if verbose:
            result["band_stats"] = {
                "industrials_band_pct": _band_width_pct(ind_win),
                "railroads_band_pct": _band_width_pct(rail_win),
                "max_band_pct_allowed": max_band_pct,
            }
            result["post_line_observations"] = {
                "industrials": post_ind,
                "railroads": post_rail,
            }
            result["break_details"] = {
                "industrials_broke_above_at": i_up,
                "industrials_broke_above_pct": i_up_pct,
                "industrials_broke_below_at": i_dn,
                "industrials_broke_below_pct": i_dn_pct,
                "railroads_broke_above_at": r_up,
                "railroads_broke_above_pct": r_up_pct,
                "railroads_broke_below_at": r_dn,
                "railroads_broke_below_pct": r_dn_pct,
            }

        return json.dumps({"result": result, "error": None, "metadata": meta})
    except Exception as exc:
        return json.dumps({"result": None, "error": str(exc), "metadata": {}})