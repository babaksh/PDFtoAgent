"""Detect the end of a bear swing from the shortened swing of the pendulum.

Extends `panic_shock_retracement_and_sag_test` (chA LITTLE CLOUD OUT OF THE
SEA, LIKE A MAN'S HAND): that tool tests a single post-shock retracement
fraction against a template. This one asks for a SEQUENCE of successively
shorter swings converging on equilibrium -- the chapter's own worked instance
for the railroad average after the November 21st, 1907 low:

    "It declined twenty-six points from July 20th to November 21st. It rallied
    nine points in the following fortnight, reacted four points in the next ten
    days, and has rallied two points in the past week. This is really the
    shortened swing of the pendulum, as it approaches equilibrium."

and it adds the further condition that the reaction "was checked before it
reached the old low", with the movement of the other average "roughly parallel
and confirmatory".
"""

import json
import math
from typing import Dict, List, Optional


def _clean(values) -> List[float]:
    if not values:
        return []
    out = []
    for v in values:
        try:
            f = float(v)
        except (TypeError, ValueError):
            continue
        if math.isnan(f) or math.isinf(f):
            continue
        out.append(f)
    return out


def _num(x, default=0.0) -> float:
    try:
        f = float(x)
    except (TypeError, ValueError):
        return default
    if math.isnan(f) or math.isinf(f):
        return default
    return f


async def shortened_pendulum_equilibrium_test(
    swings: List[Dict],
    old_low: float,
    reaction_low: Optional[float] = None,
    confirming_average: Optional[List[float]] = None,
    min_swings: int = 3,
    shortening_tolerance: float = 0.05,
    old_low_tolerance_pct: float = 1.0,
    verbose: bool = True,
) -> str:
    """Detect the end of a bear swing from successively shortening swings converging on equilibrium.

    Use after a market low, when you have the sequence of swings that followed
    it (each with an amplitude in points and a duration in periods) and you need
    to know whether the bear swing has ended. The test is the chapter's: each
    successive swing must be shorter than the one before, in BOTH amplitude and
    duration, like a pendulum settling -- and the reaction must be checked above
    the old low, with a second average moving roughly parallel and confirmatory.

    Do NOT use this on a single retracement measured as a fraction of a prior
    move -- that is `panic_shock_retracement_and_sag_test`. Do NOT use it before
    a low has been established; the sequence starts with the decline into it.

    Args:
        swings: list of swings oldest first, each {"amplitude": points, "duration": periods,
                "direction": "up"|"down" (optional)}. Amplitudes are magnitudes, never signed.
        old_low: the prior low price the reaction must stay above.
        reaction_low: the lowest price reached by the reaction after the low; defaults to
                old_low plus the net of the swings.
        confirming_average: price series of the second average over the same span.
        min_swings: number of successive swings the chapter's sequence requires (its example has 4).
        shortening_tolerance: fraction by which each swing must beat the previous one (0.05 = 5% shorter).
        old_low_tolerance_pct: how far above the old low the reaction must stop, in percent, to count as checked.
        verbose: False returns the compact verdict; True adds the per-swing detail.

    Returns:
        JSON {"result": {...}, "error": None, "metadata": {...}} with
        `bear_swing_ended`, `pendulum_shortening` and a short `reason`.
    """
    try:
        min_swings = 3 if min_swings is None else int(min_swings)
        shortening_tolerance = (
            0.05 if shortening_tolerance is None else float(shortening_tolerance)
        )
        old_low_tolerance_pct = (
            1.0 if old_low_tolerance_pct is None else float(old_low_tolerance_pct)
        )
        low = _num(old_low, 0.0)

        items: List[Dict] = []
        if swings:
            for s in swings:
                if not isinstance(s, dict):
                    continue
                amp = abs(_num(s.get("amplitude", s.get("points", 0.0)), 0.0))
                dur = _num(s.get("duration", s.get("periods", 0.0)), 0.0)
                direction = str(s.get("direction", "")).strip().lower()
                items.append({"amplitude": amp, "duration": dur, "direction": direction})

        n = len(items)
        if n < 2:
            return json.dumps({
                "result": {
                    "bear_swing_ended": False,
                    "pendulum_shortening": False,
                    "reaction_checked_above_old_low": False,
                    "swings_examined": n,
                    "reason": "A pendulum sequence needs at least two swings to compare; with "
                              + str(n) + " supplied there is no shortening to measure and no end "
                              "of the bear swing is read.",
                },
                "error": None,
                "metadata": {
                    "provenance": {
                        "source_grounded": ["shortened swing of the pendulum, as it approaches equilibrium"],
                        "model_extrapolated": ["minimum of two swings to compare"],
                    }
                },
            })

        amplitude_shorter = True
        duration_shorter = True
        amp_pairs = []
        dur_pairs = []
        for i in range(1, n):
            prev_amp = items[i - 1]["amplitude"]
            cur_amp = items[i]["amplitude"]
            amp_ok = cur_amp <= prev_amp * (1.0 - shortening_tolerance)
            amp_pairs.append({
                "from_index": i - 1,
                "to_index": i,
                "previous": prev_amp,
                "current": cur_amp,
                "shorter": amp_ok,
            })
            if not amp_ok:
                amplitude_shorter = False

            prev_dur = items[i - 1]["duration"]
            cur_dur = items[i]["duration"]
            dur_ok = cur_dur <= prev_dur * (1.0 - shortening_tolerance)
            dur_pairs.append({
                "from_index": i - 1,
                "to_index": i,
                "previous": prev_dur,
                "current": cur_dur,
                "shorter": dur_ok,
            })
            if not dur_ok:
                duration_shorter = False

        total_amplitude = sum(it["amplitude"] for it in items)
        pendulum_shortening = amplitude_shorter and duration_shorter

        if reaction_low is None:
            net_down = sum(it["amplitude"] for it in items if it["direction"] == "down")
            net_up = sum(it["amplitude"] for it in items if it["direction"] == "up")
            implied = low + (net_up - net_down)
        else:
            implied = _num(reaction_low, low)

        denom = abs(low) if low != 0.0 else 1.0
        margin_pct = (implied - low) / denom * 100.0
        required_margin = abs(old_low_tolerance_pct)
        checked_above = margin_pct > 0.0 and margin_pct >= required_margin
        if margin_pct > 0.0 and margin_pct < required_margin:
            checked_above = False
        if margin_pct <= 0.0:
            checked_above = False

        conf = _clean(confirming_average) if confirming_average else []
        if len(conf) >= 2:
            conf_change_pct = (conf[-1] - conf[0]) / (abs(conf[0]) if conf[0] != 0.0 else 1.0) * 100.0
            if conf_change_pct > 0.0:
                conf_direction = "up"
            elif conf_change_pct < 0.0:
                conf_direction = "down"
            else:
                conf_direction = "flat"
            last_direction = items[-1]["direction"] if items[-1]["direction"] in ("up", "down") else "up"
            confirmatory = conf_direction == last_direction
            conf_measured = True
        else:
            conf_change_pct = 0.0
            conf_direction = "unmeasured"
            confirmatory = False
            conf_measured = False

        enough_swings = n >= min_swings

        if total_amplitude == 0.0:
            verdict = "no_movement"
            ended = False
            reason = ("Every supplied swing has zero amplitude, so there is no pendulum motion "
                      "to shorten and no turn to read.")
        elif not pendulum_shortening:
            verdict = "not_shortening"
            ended = False
            failed_parts = []
            if not amplitude_shorter:
                failed_parts.append("amplitude")
            if not duration_shorter:
                failed_parts.append("duration")
            reason = ("The successive swings are not shortening in " + " and ".join(failed_parts)
                      + ", so the pendulum is not converging on equilibrium; the bear swing has "
                        "not been shown to have ended.")
        elif not checked_above:
            verdict = "reaction_not_checked_above_low"
            ended = False
            if margin_pct >= 0.0:
                position = "only " + format(margin_pct, ".1f") + "% above it, inside the " + format(required_margin, ".1f") + "% margin the test requires"
            else:
                position = format(-margin_pct, ".1f") + "% BELOW it, so it reached and passed the old low"
            reason = ("The swings shorten like a pendulum, but the reaction was not checked above "
                      "the old low of " + format(low, ".4g") + " -- it came " + position
                      + " -- so the low has not been established as the turn.")
        elif not enough_swings:
            verdict = "too_few_swings"
            ended = False
            reason = ("The swings shorten and the reaction holds above the old low, but only "
                      + str(n) + " swings were supplied against the " + str(min_swings)
                      + " the sequence calls for, so convergence is not yet established.")
        elif not conf_measured:
            verdict = "confirmation_unmeasured"
            ended = False
            reason = ("The swings shorten and the reaction is checked above the old low, but no "
                      "second average was supplied, so the chapter's condition that the other "
                      "average move roughly parallel and confirmatory was NOT measured. Without "
                      "it the end of the bear swing is not established.")
        elif not confirmatory:
            verdict = "not_confirmed_by_second_average"
            ended = False
            reason = ("The swings shorten and the reaction is checked above the old low, but the "
                      "second average moved " + conf_direction + " (" + format(conf_change_pct, ".1f")
                      + "%) instead of parallel and confirmatory, so the bear swing has not been "
                        "shown to have ended.")
        else:
            verdict = "bear_swing_ended"
            ended = True
            reason = ("The swings shorten successively in both amplitude and duration ("
                      + ", ".join(format(it["amplitude"], ".4g") for it in items)
                      + " points over " + ", ".join(format(it["duration"], ".4g") for it in items)
                      + " periods), the reaction was checked " + format(margin_pct, ".1f")
                      + "% above the old low of " + format(low, ".4g")
                      + ", and the second average moved " + conf_direction + " (" + format(conf_change_pct, ".1f")
                      + "%) parallel and confirmatory. This is the shortened swing of the pendulum "
                        "approaching equilibrium: the bear swing has ended.")

        result = {
            "verdict": verdict,
            "bear_swing_ended": ended,
            "pendulum_shortening": pendulum_shortening,
            "amplitude_shorter": amplitude_shorter,
            "duration_shorter": duration_shorter,
            "reaction_checked_above_old_low": checked_above,
            "margin_above_old_low_pct": round(margin_pct, 4),
            "second_average_confirmatory": confirmatory,
            "second_average_direction": conf_direction,
            "swings_examined": n,
            "reason": reason,
        }
        if verbose:
            result["detail"] = {
                "min_swings": min_swings,
                "shortening_tolerance": shortening_tolerance,
                "old_low_tolerance_pct": old_low_tolerance_pct,
                "old_low": round(low, 4),
                "implied_reaction_low": round(implied, 4),
                "amplitude_pairs": amp_pairs,
                "duration_pairs": dur_pairs,
                "second_average_pct_change": round(conf_change_pct, 4),
                "rule_quote": "the shortened swing of the pendulum, as it approaches equilibrium",
            }

        return json.dumps({
            "result": result,
            "error": None,
            "metadata": {
                "provenance": {
                    "source_grounded": [
                        "shortened swing of the pendulum, as it approaches equilibrium",
                        "worked sequence 26 down, 9 up, 4 down, 2 up points",
                        "durations shortening: four months, a fortnight, ten days, a week",
                        "the reaction was checked before it reached the old low",
                        "movement of the other average roughly parallel and confirmatory",
                    ],
                    "model_extrapolated": [
                        "minimum of 3 swings required for the sequence",
                        "shortening tolerance of 5% per successive swing",
                        "reaction must stop at least 1.0% above the old low to count as checked",
                    ],
                }
            },
        })
    except Exception as exc:
        return json.dumps({
            "result": {
                "verdict": "not_established",
                "bear_swing_ended": False,
                "pendulum_shortening": False,
                "reaction_checked_above_old_low": False,
                "reason": "Could not evaluate the swing sequence: " + str(exc),
            },
            "error": None,
            "metadata": {
                "provenance": {
                    "source_grounded": ["shortened swing of the pendulum, as it approaches equilibrium"],
                    "model_extrapolated": ["boundary reading on unusable input"],
                }
            },
        })