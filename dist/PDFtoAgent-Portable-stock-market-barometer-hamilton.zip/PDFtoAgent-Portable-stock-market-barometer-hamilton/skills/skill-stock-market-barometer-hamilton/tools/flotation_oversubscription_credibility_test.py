"""Test a claimed oversubscription against the price the stock sells at.

Use when a new issue is reported as subscribed many times over and you want to
know whether to believe the claim: the chapter's test is to look at what the
stock actually sells at in the aftermarket, and to rule the flotation a failure
when a stock said to be many times oversubscribed trades at a heavy discount
within weeks.

Inputs: reported oversubscription multiple, the subscription/issue price, and
the aftermarket price path with the weeks elapsed (or a single aftermarket
price and elapsed weeks). Do NOT use this for a seasoned stock's price
behaviour -- it is specific to a new flotation. Do NOT use it to judge whether
the capital was watered -- call promotion_carry_in_valuation_test.
"""

import json
from typing import Any, List, Optional


async def flotation_oversubscription_credibility_test(
    reported_oversubscription_multiple: Optional[float] = None,
    subscription_price: Optional[float] = None,
    aftermarket_prices: Optional[List[float]] = None,
    aftermarket_weeks: Optional[List[float]] = None,
    aftermarket_price: Optional[float] = None,
    elapsed_weeks: Optional[float] = None,
    heavy_discount_pct: float = 5.0,
    aftermarket_window_weeks: float = 4.0,
    min_oversubscription_multiple: float = 2.0,
    verbose: bool = True,
) -> str:
    """Rule a flotation credible or a failure from its aftermarket price."""

    def _f(v: Any, default: Optional[float] = None) -> Optional[float]:
        try:
            if v is None:
                return default
            return float(v)
        except (TypeError, ValueError):
            return default

    try:
        mult = _f(reported_oversubscription_multiple, 0.0) or 0.0
        sub = _f(subscription_price, 0.0) or 0.0
        heavy_discount_pct = _f(heavy_discount_pct, 5.0) or 0.0
        window = _f(aftermarket_window_weeks, 4.0) or 0.0
        min_mult = _f(min_oversubscription_multiple, 2.0) or 0.0

        prices_in = [p for p in (aftermarket_prices or []) if p is not None]
        weeks_in = [w for w in (aftermarket_weeks or []) if w is not None]
        if not prices_in and aftermarket_price is not None:
            prices_in = [aftermarket_price]
            weeks_in = [elapsed_weeks if elapsed_weeks is not None else 1.0]
        prices = [_f(p, 0.0) or 0.0 for p in prices_in]
        if len(weeks_in) < len(prices):
            weeks_in = list(weeks_in) + [float(i + 1) for i in range(len(weeks_in), len(prices))]
        weeks = [(_f(w, 0.0) or 0.0) for w in weeks_in[: len(prices)]]

        rows = []
        for p, w in zip(prices, weeks):
            diff_pct = ((p - sub) / sub * 100.0) if sub > 0 else 0.0
            rows.append({
                "weeks_elapsed": w,
                "price": p,
                "discount_pct": round(-diff_pct, 4),
                "premium_pct": round(diff_pct, 4),
                "at_a_discount": bool(p < sub),
            })

        in_window = [r for r in rows if r["weeks_elapsed"] <= window] if window > 0 else list(rows)
        if not in_window and rows:
            in_window = [rows[0]]

        worst = min(rows, key=lambda r: r["premium_pct"]) if rows else None
        worst_in_window = min(in_window, key=lambda r: r["premium_pct"]) if in_window else None

        discount_pct = (worst_in_window["discount_pct"] if worst_in_window else 0.0)
        heavy = bool(discount_pct >= heavy_discount_pct)
        claim_worth_testing = bool(mult >= min_mult)
        within_window = bool(worst_in_window and worst_in_window["weeks_elapsed"] <= window)

        if sub <= 0:
            verdict = "not_testable"
            reason = "no subscription price supplied, so no discount can be measured"
            failed = False
        elif not claim_worth_testing:
            verdict = "claim_not_material"
            reason = ("reported oversubscription of %.2fx is below the %.2fx level worth "
                      "testing" % (mult, min_mult))
            failed = False
        elif not within_window:
            verdict = "credible_on_price"
            reason = ("the worst price in the record came after the %.1f week window, "
                      "so the claim is not contradicted within the window" % window)
            failed = False
        elif heavy:
            verdict = "flotation_failure"
            reason = ("a stock said to be %.2fx oversubscribed sold %.2f%% below the "
                      "subscription price within %.1f weeks"
                      % (mult, discount_pct, worst_in_window["weeks_elapsed"]))
            failed = True
        else:
            verdict = "credible_on_price"
            if discount_pct > 0:
                worst_note = "was only %.2f%% below the subscription price" % discount_pct
            else:
                worst_note = "never fell below the subscription price (worst level %.2f%% above it)" % (-discount_pct)
            reason = ("the worst aftermarket level within %.1f weeks %s, under the "
                      "%.2f%% heavy-discount test" % (window, worst_note, heavy_discount_pct))
            failed = False

        result = {
            "verdict": verdict,
            "reason": reason,
            "flotation_failed": bool(failed),
            "reported_oversubscription_multiple": round(mult, 4),
            "subscription_price": sub,
            "worst_discount_within_window_pct": round(discount_pct, 4),
            "worst_discount_ever_pct": (round(worst["discount_pct"], 4) if worst else 0.0),
            "weeks_to_worst_price_in_window": (worst_in_window["weeks_elapsed"] if worst_in_window else None),
            "heavy_discount_pct_threshold": heavy_discount_pct,
            "aftermarket_window_weeks": window,
            "observations": len(rows),
        }
        if verbose and rows:
            result["aftermarket_path"] = rows
        return json.dumps({
            "result": result,
            "error": None,
            "metadata": {"provenance": {
                "source_grounded": [
                    "reported oversubscription multiple as the claim under test",
                    "subscription price as the comparison basis",
                    "stock selling at a heavy discount in less than a month",
                    "verdict that the flotation had been a failure despite the oversubscription reports",
                ],
                "model_extrapolated": [
                    "heavy discount set at 5.0 percent below the subscription price",
                    "aftermarket window set at 4.0 weeks, standing for 'less than a month'",
                    "claims below 2.0x oversubscription ruled not material to test",
                    "absence of a dated price path treated as one observation at the elapsed weeks given",
                ],
            }},
        })
    except Exception as exc:  # pragma: no cover - defensive
        return json.dumps({
            "result": None,
            "error": "%s: %s" % (type(exc).__name__, exc),
            "metadata": {"provenance": {
                "source_grounded": [],
                "model_extrapolated": [],
            }},
        })