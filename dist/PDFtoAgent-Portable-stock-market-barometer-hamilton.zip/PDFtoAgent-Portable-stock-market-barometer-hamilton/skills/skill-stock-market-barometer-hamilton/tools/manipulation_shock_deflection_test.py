import json
from typing import Any, Dict, List, Optional


def _months(periods: float, periods_per_year: float) -> float:
    return float(periods) * 12.0 / periods_per_year if periods_per_year else 0.0


async def manipulation_shock_deflection_test(
    prices: List[float],
    event_index: Optional[int] = None,
    periods_per_year: float = 12.0,
    pre_event_lookback_periods: int = 24,
    reaction_window_periods: int = 6,
    min_culmination_gap_months: float = 6.0,
    verbose: bool = True,
) -> str:
    """Classify an alleged manipulation event (corner, scandal, panic) as a mere
    secondary reaction or a genuine reversal of the primary trend, and report whether
    the stock market barometer was materially deflected by it.

    Use when you have a market average (or any price series of the average) and the
    position of an alleged manipulation event in it -- e.g. the Northern Pacific corner
    of May 1901, which produced a purely stock market panic inside a primary bull
    market: the upward movement was resumed afterwards and did not culminate until
    sixteen months later, so the corner was only a severe secondary reaction and did not
    deflect the barometer. The test is therefore: did the prior primary move RESUME
    (a new extreme in its own direction after the event) and only CULMINATE later?

    Extends dow_three_movement_classification (chCYCLES AND STOCK MARKET RECORDS):
    that tool labels a movement primary/secondary/daily from its own duration and size;
    this one takes an EXOGENOUS manipulation event date as an input and adds the
    resumption-and-culmination check, so the output is a verdict on whether
    manipulation deflected the barometer rather than merely a movement label.

    Inputs: prices (the average, oldest first), event_index (position of the event;
    defaults to the middle of the series if omitted), periods_per_year (12 for monthly
    data, 252 for daily), pre_event_lookback_periods (window used to establish the prior
    primary direction), reaction_window_periods (window after the event searched for the
    shock low/high), min_culmination_gap_months (how late the culmination must fall to
    count as "did not culminate until later"; the chapter's example is 16 months).
    Do NOT use this to judge whether a scandal is old or retrospective -- for dated
    act-versus-accusation lags use retrospective_objection_lag_test.
    """
    provenance = {
        "source_grounded": [
            "test: whether the prior primary movement resumed and only culminated afterwards",
            "worked example: Northern Pacific corner 1901 in a primary bull market = severe secondary reaction, resumed, culminated 16 months later",
            "consequence: manipulation cannot materially deflect the barometer",
        ],
        "model_extrapolated": [
            "numeric cutoffs: pre_event_lookback_periods=24, reaction_window_periods=6",
            "resumption rule: a new extreme beyond the pre-event extreme in the primary direction",
            "min_culmination_gap_months default of 6 months (chapter's instance was 16)",
            "periods_per_year default of 12 (monthly average)",
        ],
    }

    def payload(result: Dict[str, Any]) -> str:
        return json.dumps(
            {"result": result, "error": None, "metadata": {"provenance": provenance}}
        )

    try:
        series = [float(p) for p in (prices or []) if p is not None]
        ppy = 12.0 if periods_per_year is None else float(periods_per_year)
        if ppy <= 0:
            ppy = 12.0
        lookback = 24 if pre_event_lookback_periods is None else int(pre_event_lookback_periods)
        if lookback < 1:
            lookback = 1
        react = 6 if reaction_window_periods is None else int(reaction_window_periods)
        if react < 1:
            react = 1
        min_gap = (
            6.0 if min_culmination_gap_months is None else float(min_culmination_gap_months)
        )

        n = len(series)
        if n == 0:
            return payload(
                {
                    "num_points": 0,
                    "event_index": 0,
                    "prior_trend": "none",
                    "classification": "unmeasurable",
                    "materially_deflected": False,
                    "reason": "No price observations were supplied, so the effect of the alleged manipulation cannot be measured.",
                }
            )

        idx = n // 2 if event_index is None else int(event_index)
        if idx < 0:
            idx = 0
        if idx > n - 1:
            idx = n - 1

        base: Dict[str, Any] = {
            "num_points": n,
            "event_index": idx,
            "periods_per_year": ppy,
            "event_price": series[idx],
        }

        if n < 2 or idx >= n - 1:
            base.update(
                {
                    "prior_trend": "none" if n < 2 else _trend(series, idx, lookback)[0],
                    "classification": "unmeasurable",
                    "materially_deflected": False,
                    "shock_move_pct": 0.0,
                    "resumption_confirmed": False,
                    "culmination_after_event": False,
                    "culmination_gap_months": 0.0,
                    "reason": "There are no observations after the event, so resumption and culmination cannot be tested.",
                }
            )
            if verbose:
                base["post_event_periods"] = 0
            return payload(base)

        trend, prior_move_pct, window_start = _trend(series, idx, lookback)
        pre_window = series[window_start : idx + 1]
        for_up = trend == "up"
        pre_extreme = max(pre_window) if for_up else min(pre_window)
        pre_extreme = series[idx] if trend == "none" else pre_extreme

        base["prior_trend"] = trend
        base["prior_move_pct"] = prior_move_pct
        base["pre_event_extreme"] = pre_extreme

        if trend == "none":
            base.update(
                {
                    "classification": "no_primary_movement",
                    "materially_deflected": False,
                    "shock_move_pct": 0.0,
                    "resumption_confirmed": False,
                    "culmination_after_event": False,
                    "culmination_gap_months": 0.0,
                    "reason": (
                        "The average shows no net movement in the window before the event, so there is no "
                        "primary trend for the alleged manipulation to deflect."
                    ),
                }
            )
            if verbose:
                base["pre_event_window_start"] = window_start
                base["post_event_periods"] = n - 1 - idx
            return payload(base)

        post = series[idx + 1 : idx + 1 + react]
        shock_extreme = min(post) if for_up else max(post)
        shock_idx = idx + 1 + post.index(shock_extreme)
        shock_move_pct = (
            (shock_extreme - pre_extreme) / pre_extreme if pre_extreme else 0.0
        )

        resumption_index = None
        for j in range(idx + 1, n):
            if (for_up and series[j] > pre_extreme) or (
                (not for_up) and series[j] < pre_extreme
            ):
                resumption_index = j
                break

        post_all = series[idx:]
        extreme_after = max(post_all) if for_up else min(post_all)
        culmination_index = idx + post_all.index(extreme_after)

        resumption_confirmed = resumption_index is not None
        culmination_after_event = culmination_index > idx
        gap_months = _months(culmination_index - idx, ppy)
        culminated_later = culmination_after_event and gap_months >= min_gap

        if resumption_confirmed:
            classification = "secondary_reaction"
            deflected = False
            reason = (
                "The prior %s movement resumed %d periods after the event (new %s at %.4g versus the "
                "pre-event extreme of %.4g) and only culminated %.2f months later, so the event was a "
                "severe secondary reaction inside the primary %s market and did not materially deflect "
                "the barometer."
                % (
                    trend,
                    resumption_index - idx,
                    "high" if for_up else "low",
                    series[resumption_index],
                    pre_extreme,
                    gap_months,
                    trend,
                )
            )
            if not culminated_later:
                reason += (
                    " Note: the culmination came only %.2f months after the event, inside the %.2f-month "
                    "gap the chapter's own example treats as late." % (gap_months, min_gap)
                )
        else:
            classification = "primary_reversal"
            deflected = True
            reason = (
                "The prior %s movement never resumed: the average did not make a new %s above the "
                "pre-event extreme of %.4g anywhere after the event, so the event reversed the primary "
                "trend and materially deflected the barometer."
                % (trend, "high" if for_up else "low", pre_extreme)
            )

        base.update(
            {
                "shock_move_pct": shock_move_pct,
                "shock_magnitude_pct": abs(shock_move_pct),
                "shock_extreme": shock_extreme,
                "shock_index": shock_idx,
                "resumption_confirmed": resumption_confirmed,
                "resumption_index": resumption_index,
                "resumption_periods_after_event": (
                    None if resumption_index is None else resumption_index - idx
                ),
                "culmination_index": culmination_index,
                "culmination_price": extreme_after,
                "culmination_after_event": culmination_after_event,
                "culmination_gap_months": gap_months,
                "culminated_later": culminated_later,
                "min_culmination_gap_months": min_gap,
                "classification": classification,
                "materially_deflected": deflected,
                "reason": reason,
            }
        )
        if verbose:
            base["pre_event_window_start"] = window_start
            base["post_event_periods"] = n - 1 - idx
            base["reaction_window_periods"] = react
        return payload(base)
    except Exception as exc:  # noqa: BLE001 - contract requires a JSON error payload
        return json.dumps(
            {
                "result": None,
                "error": "%s: %s" % (type(exc).__name__, exc),
                "metadata": {"provenance": provenance},
            }
        )


def _trend(series: List[float], idx: int, lookback: int):
    start = max(0, idx - lookback)
    reference = series[start]
    if idx <= start:
        return "none", 0.0, start
    move = (series[idx] - reference) / reference if reference else 0.0
    if move > 0:
        return "up", move, start
    if move < 0:
        return "down", move, start
    return "none", 0.0, start