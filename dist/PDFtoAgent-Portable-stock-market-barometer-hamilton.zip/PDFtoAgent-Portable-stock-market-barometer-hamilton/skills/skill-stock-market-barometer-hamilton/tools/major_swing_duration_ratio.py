"""Major (primary) swing duration ratio test."""

import json
import math
import re
from typing import Any, Dict, List, Optional

_MONTH_NAMES = {
    "jan": 1, "feb": 2, "mar": 3, "apr": 4, "may": 5, "jun": 6,
    "jul": 7, "aug": 8, "sep": 9, "sept": 9, "oct": 10, "nov": 11, "dec": 12,
}


def _parse_month_year(value: Any) -> Optional[int]:
    """Convert a date into an absolute month count (year*12 + month-1)."""
    if value is None or isinstance(value, bool):
        return None
    if isinstance(value, (int, float)):
        v = float(value)
        if 1000.0 <= v <= 3000.0:
            year = int(math.floor(v))
            frac = v - year
            month = int(round(frac * 12.0)) + 1
            if month > 12:
                year += 1
                month = 1
            return year * 12 + (month - 1)
        return None
    text = str(value).strip().lower().replace(",", " ")
    text = re.sub(r"\s+", " ", text)
    if not text:
        return None
    m = re.match(r"^(\d{4})\s*[-/\.]\s*(\d{1,2})", text)
    if m:
        year = int(m.group(1))
        month = int(m.group(2))
        if 1 <= month <= 12:
            return year * 12 + (month - 1)
        return None
    m = re.match(r"^(\d{4})(\d{2})$", text)
    if m:
        year = int(m.group(1))
        month = int(m.group(2))
        if 1 <= month <= 12:
            return year * 12 + (month - 1)
        return None
    m = re.match(r"^([a-z]{3,9})\.?\s*[-/]\s*[a-z]{3,9}\.?\s+(\d{4})$", text)
    if m:
        month = _MONTH_NAMES.get(m.group(1)[:4], _MONTH_NAMES.get(m.group(1)[:3]))
        if month:
            return int(m.group(2)) * 12 + (month - 1)
        return None
    m = re.match(r"^([a-z]{3,9})\.?\s+(\d{4})$", text)
    if m:
        month = _MONTH_NAMES.get(m.group(1)[:4], _MONTH_NAMES.get(m.group(1)[:3]))
        if month:
            return int(m.group(2)) * 12 + (month - 1)
        return None
    m = re.match(r"^([a-z]{3,9})\.?\s+\d{1,2}\s+(\d{4})$", text)
    if m:
        month = _MONTH_NAMES.get(m.group(1)[:4], _MONTH_NAMES.get(m.group(1)[:3]))
        if month:
            return int(m.group(2)) * 12 + (month - 1)
        return None
    m = re.match(r"^\d{1,2}\s+([a-z]{3,9})\.?\s+(\d{4})$", text)
    if m:
        month = _MONTH_NAMES.get(m.group(1)[:4], _MONTH_NAMES.get(m.group(1)[:3]))
        if month:
            return int(m.group(2)) * 12 + (month - 1)
        return None
    m = re.match(r"^(\d{4})\s+([a-z]{3,9})$", text)
    if m:
        month = _MONTH_NAMES.get(m.group(2)[:4], _MONTH_NAMES.get(m.group(2)[:3]))
        if month:
            return int(m.group(1)) * 12 + (month - 1)
        return None
    return None


def _normalize_direction(value: Any) -> Optional[str]:
    if value is None:
        return None
    text = str(value).strip().lower()
    if text in ("up", "u", "bull", "bullish", "rise", "rising", "advance", "+", "1"):
        return "up"
    if text in ("down", "d", "bear", "bearish", "fall", "falling", "decline", "-", "-1"):
        return "down"
    return None


async def major_swing_duration_ratio(
    swings: List[Dict],
    bull_benchmark_months: float = 25.0,
    bear_benchmark_months: float = 15.0,
    ratio_benchmark: float = 2.0,
    ratio_tolerance_pct: float = 15.0,
    duration_tolerance_pct: float = 20.0,
    verbose: bool = True,
) -> str:
    """Compute mean bull-swing and bear-swing duration from a dated table of major
    (primary) market swings and judge them against this chapter's benchmarks.

    Use when you have a dated table of major swings -- each with a direction
    (up/down) and a start and end date -- and you want the chapter's test:
    bull swings average about 25 months, bear swings about 15 months, and the
    bull markets last "rather less than twice as long" as the bear markets.
    Dates may be "YYYY-MM", "YYYY/MM", "Mon YYYY", "YYYY Mon", "June-Aug. 1921"
    (first month is used) or a decimal year such as 1900.5. Swings whose end
    date is missing (an unfinished swing) are skipped, as the chapter's averages
    are taken over completed swings only.

    Extends primary_swing_duration_bound_test (chCHARLES H. DOW, AND HIS THEORY):
    that tool tests every swing length against Dow's overall extent bounds, while
    this one splits the swings by DIRECTION and compares the two means and their
    ratio against the 25 / 15 month benchmarks.

    Do NOT use for secondary reactions (use secondary_swing_duration_asymmetry_test)
    and do NOT use it to date the end of a single movement (use
    primary_movement_termination_rule).
    """
    try:
        bull_benchmark_months = 25.0 if bull_benchmark_months is None else float(bull_benchmark_months)
        bear_benchmark_months = 15.0 if bear_benchmark_months is None else float(bear_benchmark_months)
        ratio_benchmark = 2.0 if ratio_benchmark is None else float(ratio_benchmark)
        ratio_tolerance_pct = 15.0 if ratio_tolerance_pct is None else float(ratio_tolerance_pct)
        duration_tolerance_pct = 20.0 if duration_tolerance_pct is None else float(duration_tolerance_pct)

        rows: List[Dict[str, Any]] = []
        skipped: List[Dict[str, Any]] = []
        bull_lengths: List[float] = []
        bear_lengths: List[float] = []

        for raw in swings or []:
            if not isinstance(raw, dict):
                skipped.append({"swing": raw, "reason": "not an object"})
                continue
            direction = _normalize_direction(raw.get("direction", raw.get("dir", raw.get("kind"))))
            start_raw = raw.get("start", raw.get("start_date", raw.get("from")))
            end_raw = raw.get("end", raw.get("end_date", raw.get("to")))
            start = _parse_month_year(start_raw)
            end = _parse_month_year(end_raw)
            if direction is None:
                skipped.append({"swing": raw, "reason": "direction not up/down"})
                continue
            if start is None or end is None:
                skipped.append({"swing": raw, "reason": "start or end date missing/unparseable"})
                continue
            months = float(end - start)
            if months < 0.0:
                months = -months
            row = {
                "direction": direction,
                "start": start_raw,
                "end": end_raw,
                "months": months,
            }
            rows.append(row)
            if direction == "up":
                bull_lengths.append(months)
            else:
                bear_lengths.append(months)

        n_bull = len(bull_lengths)
        n_bear = len(bear_lengths)
        mean_bull = sum(bull_lengths) / n_bull if n_bull else None
        mean_bear = sum(bear_lengths) / n_bear if n_bear else None

        if mean_bull is not None and mean_bear is not None and mean_bear > 0.0:
            ratio = mean_bull / mean_bear
        else:
            ratio = None

        def _within(actual: Optional[float], benchmark: float) -> bool:
            if actual is None:
                return False
            band = abs(benchmark) * duration_tolerance_pct / 100.0
            return abs(actual - benchmark) <= band

        bull_matches = _within(mean_bull, bull_benchmark_months)
        bear_matches = _within(mean_bear, bear_benchmark_months)

        ratio_lower = ratio_benchmark * (1.0 - ratio_tolerance_pct / 100.0)
        if ratio is None:
            ratio_reading = "unmeasurable"
            ratio_holds = False
        elif ratio >= ratio_benchmark:
            ratio_reading = "at_or_above_twice"
            ratio_holds = False
        elif ratio >= ratio_lower:
            ratio_reading = "rather_less_than_twice"
            ratio_holds = True
        else:
            ratio_reading = "well_below_twice"
            ratio_holds = False

        verdict = bool(bull_matches and bear_matches and ratio_holds)

        if not rows:
            reason = "No completed dated swings were supplied, so no duration comparison can be made."
        elif not verdict:
            parts = []
            if not bull_matches:
                parts.append("mean bull duration does not match the 25-month benchmark")
            if not bear_matches:
                parts.append("mean bear duration does not match the 15-month benchmark")
            if not ratio_holds:
                parts.append("bull/bear duration ratio is not 'rather less than twice' (%s)" % ratio_reading)
            reason = "Chapter's rule not confirmed: " + "; ".join(parts) + "."
        else:
            reason = (
                "Bull swings average %.2f months against the 25-month benchmark, bear swings "
                "%.2f months against the 15-month benchmark, and bulls are %.2fx as long as bears "
                "-- rather less than twice as long." % (mean_bull, mean_bear, ratio)
            )

        result: Dict[str, Any] = {
            "n_bull_swings": n_bull,
            "n_bear_swings": n_bear,
            "n_skipped": len(skipped),
            "mean_bull_months": mean_bull,
            "mean_bear_months": mean_bear,
            "bull_bear_ratio": ratio,
            "bull_benchmark_months": bull_benchmark_months,
            "bear_benchmark_months": bear_benchmark_months,
            "bull_matches_benchmark": bull_matches,
            "bear_matches_benchmark": bear_matches,
            "ratio_benchmark": ratio_benchmark,
            "ratio_reading": ratio_reading,
            "ratio_rule_holds": ratio_holds,
            "verdict": verdict,
            "reason": reason,
        }
        if verbose:
            result["swings"] = rows
            result["skipped"] = skipped
            result["thresholds"] = {
                "ratio_tolerance_pct": ratio_tolerance_pct,
                "duration_tolerance_pct": duration_tolerance_pct,
                "ratio_lower_bound": ratio_lower,
            }

        return json.dumps({
            "result": result,
            "error": None,
            "metadata": {
                "provenance": {
                    "source_grounded": [
                        "dated table of fifteen major swings with direction",
                        "average duration of seven major bull swings is twenty-five months",
                        "average duration of seven major bear swings is fifteen months",
                        "bull markets lasted rather less than twice as long as bear markets",
                        "unfinished swing (Oct 1923) excluded from the averages",
                    ],
                    "model_extrapolated": [
                        "duration_tolerance_pct=20 band around the 25/15 month benchmarks",
                        "ratio_tolerance_pct=15 lower bound for 'rather less than twice'",
                        "date parsing formats (YYYY-MM, Mon YYYY, decimal year)",
                        "bear market 'normally appreciably shorter' folded into the ratio test",
                    ],
                }
            },
        })
    except Exception as exc:  # noqa: BLE001
        return json.dumps({
            "result": None,
            "error": "major_swing_duration_ratio failed: %s" % exc,
            "metadata": {
                "provenance": {
                    "source_grounded": [],
                    "model_extrapolated": ["error handling path"],
                }
            },
        })