"""Rebut a post-event 'the good news is out, sell it' argument from the betting odds.

Chapter rule: when the outcome of a known event was already near-certain in the
openly quoted odds (Coolidge over Davis: openly twelve to one before the
election, real odds something like forty to one), the event cannot be the news
the market is discounting -- a result at 40 to 1 is not news when it happens.
The advance is then attributed to the resumed expansion of general business which
the stock market barometer had been predicting, and the tipsters' advice to take
profits and sell short is ruled invalid.

This tool converts the quoted odds into an implied probability, tests it against
a near-certainty threshold, and then checks the two corroborating facts the
chapter supplies: the market had been rising BEFORE the event (the barometer
forecasting expansion) and general business actually expanded afterwards.

Extends `policy_announcement_discount_horizon_test` (chAN EXCEPTION TO PROVE THE
RULE): that tool measures the LAG with which a known public act is discounted in
prices. This one uses the event's own implied probability (openly quoted odds) as
the measure of how fully it is already discounted, and returns a verdict on the
rival 'news is out' sell argument rather than only a lag.

Use when: an event with openly quoted betting odds (an election, a rate decision,
a ruling) is followed by a rally and someone argues the good news is out.
Do NOT use for measuring how many periods ahead a policy act was discounted
(use `policy_announcement_discount_horizon_test`), or for classifying a move as
manipulation (use `manipulation_shock_deflection_test`).
"""

import json
import math
from typing import List, Optional


def _num(value):
    try:
        out = float(value)
    except (TypeError, ValueError):
        return None
    if math.isnan(out) or math.isinf(out):
        return None
    return out


def _clean_series(values):
    out = []
    for v in values or []:
        f = _num(v)
        if f is not None:
            out.append(f)
    return out


def _implied_probability(odds_to_one):
    """Odds quoted as 'n to 1' in favor -> implied probability n/(n+1)."""
    n = _num(odds_to_one)
    if n is None or n < 0.0:
        return None
    return n / (n + 1.0)


def _pct_change(before, after):
    if before == 0.0:
        return None
    return (after - before) / before * 100.0


async def known_event_odds_anticipation_rebuttal(
    odds_series: List[float],
    market_prices: List[float],
    event_index: Optional[int] = None,
    business_series: Optional[List[float]] = None,
    true_odds_to_one: Optional[float] = None,
    near_certain_probability: float = 0.9,
    min_forecast_pct: float = 5.0,
    min_expansion_pct: float = 1.0,
    forecast_lookback_periods: Optional[int] = None,
    verbose: bool = True,
) -> str:
    """Rule a 'the good news is out, sell it' argument invalid using the event's odds.

    Inputs: `odds_series` -- the odds quoted for the event's expected outcome,
    expressed as 'n to 1' in favor (12.0 means twelve to one), aligned with
    `market_prices`; `market_prices` -- the average around the event;
    `event_index` -- where the event falls in those series;
    `business_series` -- a general-business series on the same periods;
    `true_odds_to_one` -- the real odds if better than the quoted (40.0 = 40 to 1).
    Returns a classification (news_already_discounted / genuine_news /
    unmeasurable) plus a short reason and the verdict on the sell argument.

    Use when an odds-quoted event is followed by a rally and someone says the good
    news is out. Do NOT use to measure how far ahead a policy act was discounted
    (`policy_announcement_discount_horizon_test`).
    """
    provenance = {
        "source_grounded": [
            "tipster argument to rebut: take profits and sell short because 'the good news was out'",
            "openly quoted odds of twelve to one before the election",
            "real odds something like forty to one",
            "attribution: the good news was the resumed expansion of general business",
            "which the market barometer had been predicting",
        ],
        "model_extrapolated": [
            "implied probability = n/(n+1) from odds quoted as n to 1",
            "near_certain_probability default 0.9",
            "min_forecast_pct default 5.0 for the pre-event barometer advance",
            "min_expansion_pct default 1.0 for the post-event business expansion",
            "forecast_lookback_periods default is the whole pre-event record",
            "event_index defaults to the last observation",
            "verdict is unmeasurable, not true, when a claim cannot be measured",
        ],
    }
    try:
        prices = _clean_series(market_prices)
        odds = _clean_series(odds_series)
        biz = _clean_series(business_series)
        if len(biz) != len(prices):
            biz = []
        if len(odds) != len(prices):
            odds_raw = odds
            odds = []
        else:
            odds_raw = []

        near_certain_probability = 0.9 if near_certain_probability is None else float(near_certain_probability)
        near_certain_probability = min(1.0, max(0.0, near_certain_probability))
        min_forecast_pct = 5.0 if min_forecast_pct is None else float(min_forecast_pct)
        min_expansion_pct = 1.0 if min_expansion_pct is None else float(min_expansion_pct)
        lookback = None
        if forecast_lookback_periods is not None:
            try:
                lb = int(forecast_lookback_periods)
                if lb > 0:
                    lookback = lb
            except (TypeError, ValueError):
                lookback = None

        n = len(prices)
        idx = None
        if event_index is not None:
            try:
                cand = int(event_index)
                if 0 <= cand < n:
                    idx = cand
            except (TypeError, ValueError):
                idx = None
        if idx is None and n > 0:
            idx = n - 1

        # implied probability from the odds openly quoted before the event
        quoted_odds = None
        if odds and idx is not None:
            pre = [o for k, o in enumerate(odds) if k <= idx]
            quoted_odds = pre[-1] if pre else None
        elif odds_raw:
            quoted_odds = odds_raw[-1]
        true_odds = _num(true_odds_to_one)
        if true_odds is not None and true_odds < 0.0:
            true_odds = None

        p_quoted = _implied_probability(quoted_odds)
        p_true = _implied_probability(true_odds) if true_odds is not None else None
        evidence = [p for p in (p_quoted, p_true) if p is not None]
        best_p = max(evidence) if evidence else None
        worst_p = min(evidence) if evidence else None
        near_certain = (worst_p is not None and worst_p >= near_certain_probability) if evidence else None

        # the move the tipsters were arguing about
        post_move_pct = None
        post_direction = "none"
        if n >= 2 and idx is not None and idx < n - 1:
            post_move_pct = _pct_change(prices[idx], prices[-1])
            if post_move_pct is not None:
                if post_move_pct > 0.0:
                    post_direction = "up"
                elif post_move_pct < 0.0:
                    post_direction = "down"
                else:
                    post_direction = "none"

        pre_advance_pct = None
        if idx is not None and idx > 0:
            start = 0 if lookback is None else max(0, idx - lookback)
            if idx > start:
                pre_advance_pct = _pct_change(prices[start], prices[idx])
        barometer_forecast_confirmed = (
            pre_advance_pct is not None and pre_advance_pct >= min_forecast_pct
        ) if pre_advance_pct is not None else None

        biz_change_pct = None
        if biz and n >= 2 and idx is not None and idx < n - 1:
            biz_change_pct = _pct_change(biz[idx], biz[-1])
        business_expansion_confirmed = (
            biz_change_pct is not None and biz_change_pct >= min_expansion_pct
        ) if biz_change_pct is not None else None

        unmeasured = [
            name
            for name, v in (
                ("odds", near_certain),
                ("post_event_move", post_move_pct),
                ("barometer_forecast", barometer_forecast_confirmed),
                ("business_expansion", business_expansion_confirmed),
            )
            if v is None
        ]
        claims_hold = (
            near_certain is True
            and post_direction == "up"
            and barometer_forecast_confirmed is True
            and business_expansion_confirmed is True
        )

        if unmeasured:
            classification = "unmeasurable"
            rebuttal_upheld = False
            reason = (
                "cannot rule on the 'good news is out' argument: no measurement for "
                + ", ".join(unmeasured)
                + ". Supply the odds, a post-event market record, and a business series."
            )
        elif near_certain is False:
            classification = "genuine_news"
            rebuttal_upheld = False
            reason = (
                "the event was genuinely in doubt (implied probability "
                + format(worst_p, ".3f")
                + ", below the "
                + format(near_certain_probability, ".3f")
                + " near-certainty bar), so its outcome was real news and the "
                + "'good news is out' argument stands"
            )
        elif post_direction != "up":
            classification = "no_rally_to_explain"
            rebuttal_upheld = False
            reason = (
                "the market did not advance after the event (post-event move "
                + format(post_move_pct if post_move_pct is not None else 0.0, ".2f")
                + "%), so there is no 'good news' rally for the argument to explain"
            )
        elif claims_hold:
            classification = "news_already_discounted"
            rebuttal_upheld = True
            reason = (
                "at "
                + format(best_p, ".3f")
                + " implied probability the outcome was already discounted in the odds, "
                + "so it was not the news; the advance of "
                + format(post_move_pct, ".2f")
                + "% is attributed to the resumed expansion of general business, "
                + "which the barometer had forecast with a "
                + format(pre_advance_pct, ".2f")
                + "% advance into the event"
            )
        elif business_expansion_confirmed is False:
            classification = "genuine_news"
            rebuttal_upheld = False
            reason = (
                "the event was near-certain, but general business did not expand afterwards "
                + "(business change "
                + format(biz_change_pct, ".2f")
                + "%), so the chapter's alternative attribution fails and the "
                + "sell argument is not rebutted"
            )
        else:
            classification = "genuine_news"
            rebuttal_upheld = False
            reason = (
                "the event was near-certain in the odds, but the barometer had not forecast "
                + "an expansion (pre-event advance "
                + format(pre_advance_pct, ".2f")
                + "%, below "
                + format(min_forecast_pct, ".2f")
                + "%), so the chapter's attribution to forecast business expansion is unproven"
            )

        result = {
            "classification": classification,
            "rebuttal_upheld": rebuttal_upheld,
            "reason": reason,
            "attribution": (
                "resumed expansion of general business forecast by the barometer"
                if rebuttal_upheld
                else ("the event outcome itself" if classification == "genuine_news" else "undetermined")
            ),
            "quoted_odds_to_one": quoted_odds,
            "true_odds_to_one": true_odds,
            "implied_probability_quoted": p_quoted,
            "implied_probability_true": p_true,
            "near_certain": near_certain,
            "post_event_move_pct": post_move_pct,
            "post_event_direction": post_direction,
            "pre_event_advance_pct": pre_advance_pct,
            "barometer_forecast_confirmed": barometer_forecast_confirmed,
            "business_change_pct": biz_change_pct,
            "business_expansion_confirmed": business_expansion_confirmed,
            "unmeasured_claims": unmeasured,
        }
        if verbose:
            result["thresholds"] = {
                "near_certain_probability": near_certain_probability,
                "min_forecast_pct": min_forecast_pct,
                "min_expansion_pct": min_expansion_pct,
                "forecast_lookback_periods": lookback,
                "event_index": idx,
                "n_periods": n,
            }

        return json.dumps({"result": result, "error": None, "metadata": {"provenance": provenance}})
    except Exception as exc:  # noqa: BLE001 - contract: never raise
        return json.dumps(
            {"result": None, "error": "known_event_odds_anticipation_rebuttal failed: " + str(exc),
             "metadata": {"provenance": provenance}}
        )