import json
from typing import Dict, List, Optional


async def public_response_follow_through_test(
    put_up_events: List[Dict],
    follower_moves: List[Dict],
    leading_stocks: Optional[List[str]] = None,
    min_leading_stocks: int = 2,
    max_leading_stocks: int = 3,
    follow_through_window_hours: float = 2.0,
    min_follower_move_pct: float = 0.5,
    min_response_share: float = 0.5,
    verbose: bool = True,
) -> str:
    """Run Dow's "method of responses" on an intraday record of transactions.

    Dow: a large operator seeking to advance the market does not buy everything
    on the list, but puts up two or three leading stocks, then watches the
    effect on the other stocks. If the public is disposed to take hold, buyers
    begin buying other stocks and the market rises to a higher level -- that is
    the public response, and it indicates the leading stocks will be given
    another lift and the general market will follow. If leading stocks are
    advanced and others do NOT follow, the public is not disposed to buy and
    the attempt to advance prices is generally discontinued. Dow notes this can
    be read at the close from the record of transactions by seeing what stocks
    were put up within specified hours and whether the general market followed.

    Use when you have a record of WHICH stocks were put up and at WHAT hour
    (`put_up_events`) and the moves of the rest of the market over the same
    session (`follower_moves`), and want the advance/no-advance verdict.

    Do NOT use for the corroboration of two market averages over days or weeks
    -- that is `average_corroboration_check` (chCYCLES AND STOCK MARKET
    RECORDS); this tool is intraday and deliberately asymmetric: 2-3 leaders
    are put up FIRST and the general market is judged as the follower.

    Event dict keys: "stock" (str), "hour" (float, e.g. 11.5), "advance_pct"
    (float, percent the stock was put up). Follower dict keys: "stock" (str),
    "hour" (float), "move_pct" (float, signed percent change).
    """
    provenance = {
        "source_grounded": [
            "two or three leading stocks are put up first, not the whole list",
            "public response: others buy other stocks and the market rises to a higher level",
            "no follow-through is evidence the public is not disposed to buy",
            "absence of response: the attempt to advance prices is generally discontinued",
            "reading taken from the record of transactions within specified hours",
        ],
        "model_extrapolated": [
            "follow_through_window_hours = 2.0 (chapter says 'specified hours' without specifying)",
            "min_follower_move_pct = 0.5 threshold for a stock counting as following",
            "min_response_share = 0.5 as the breadth needed to call a public response",
            "leading group taken as the first three distinct stocks put up when not supplied",
            "a follower is credited if it responds within any leader's window",
        ],
    }
    try:
        events = [e for e in (put_up_events or []) if isinstance(e, dict)]
        moves = [m for m in (follower_moves or []) if isinstance(m, dict)]
        window = 2.0 if follow_through_window_hours is None else float(follow_through_window_hours)
        min_move = 0.5 if min_follower_move_pct is None else float(min_follower_move_pct)
        min_share = 0.5 if min_response_share is None else float(min_response_share)
        min_lead = 2 if min_leading_stocks is None else int(min_leading_stocks)
        max_lead = 3 if max_leading_stocks is None else int(max_leading_stocks)
        if window < 0.0:
            window = 0.0

        advances = []
        for e in events:
            stock = str(e.get("stock", ""))
            hour = e.get("hour", 0.0)
            hour = 0.0 if hour is None else float(hour)
            adv = e.get("advance_pct", e.get("move_pct", 0.0))
            adv = 0.0 if adv is None else float(adv)
            if adv > 0.0:
                advances.append({"stock": stock, "hour": hour, "advance_pct": adv})

        if leading_stocks:
            named = [str(s) for s in leading_stocks if s is not None]
            named_set = set(named)
            candidates = [a for a in advances if a["stock"] in named_set]
        else:
            seen = []
            for a in advances:
                if a["stock"] not in seen:
                    seen.append(a["stock"])
            seen = seen[:max_lead] if max_lead > 0 else []
            candidates = [a for a in advances if a["stock"] in seen]

        leading_names = []
        for a in candidates:
            if a["stock"] not in leading_names:
                leading_names.append(a["stock"])
        leading_set = set(leading_names)
        num_leading_put_up = len(leading_names)

        follower_names = []
        for m in moves:
            stock = str(m.get("stock", ""))
            if stock and stock not in leading_set and stock not in follower_names:
                follower_names.append(stock)
        total_followers = len(follower_names)

        responding = []
        for a in candidates:
            lo = a["hour"]
            hi = a["hour"] + window
            for m in moves:
                stock = str(m.get("stock", ""))
                if stock in leading_set:
                    continue
                hour = m.get("hour", 0.0)
                hour = 0.0 if hour is None else float(hour)
                mv = m.get("move_pct", m.get("advance_pct", 0.0))
                mv = 0.0 if mv is None else float(mv)
                if lo <= hour <= hi and mv >= min_move:
                    responding.append({"stock": stock, "hour": hour, "move_pct": mv,
                                       "responded_to": a["stock"]})

        responding_names = []
        for r in responding:
            if r["stock"] not in responding_names:
                responding_names.append(r["stock"])
        num_responding = len(responding_names)

        response_share = None
        if total_followers > 0:
            response_share = num_responding / float(total_followers)

        follower_avg_move = None
        if moves:
            vals = []
            for m in moves:
                mv = m.get("move_pct", m.get("advance_pct", 0.0))
                mv = 0.0 if mv is None else float(mv)
                vals.append(mv)
            follower_avg_move = sum(vals) / float(len(vals))

        if num_leading_put_up < min_lead:
            market_followed = False
            verdict = "no_test_possible"
            reason = ("Fewer than %d leading stocks were put up, so Dow's method of "
                      "responses cannot be applied; it requires two or three leading "
                      "stocks advanced first." % min_lead)
        elif response_share is None:
            market_followed = False
            verdict = "no_follower_record"
            reason = ("Leading stocks were put up, but no moves of other stocks were "
                      "supplied, so no public response can be measured.")
        elif num_responding >= 1 and response_share >= min_share:
            market_followed = True
            verdict = "public_response"
            reason = ("The general market followed the leaders within the window, so "
                      "the public is disposed to buy: the leading stocks are likely to "
                      "be given another lift and the general market to follow.")
        else:
            market_followed = False
            verdict = "no_public_response"
            reason = ("Leading stocks were advanced and others did not follow, which is "
                      "evidence the public is not disposed to buy; as soon as this is "
                      "clear the attempt to advance prices is generally discontinued.")

        result = {
            "verdict": verdict,
            "market_followed": market_followed,
            "reason": reason,
            "leading_stocks_put_up": leading_names,
            "num_leading_stocks_put_up": num_leading_put_up,
            "num_follower_stocks": total_followers,
            "num_follower_stocks_responding": num_responding,
            "response_share": response_share,
            "follower_avg_move_pct": follower_avg_move,
        }
        if verbose:
            result["put_up_events"] = candidates
            result["follower_responses"] = responding
            result["non_responding_followers"] = [s for s in follower_names
                                                  if s not in responding_names]
            result["params"] = {
                "follow_through_window_hours": window,
                "min_follower_move_pct": min_move,
                "min_response_share": min_share,
                "min_leading_stocks": min_lead,
                "max_leading_stocks": max_lead,
            }
        return json.dumps({"result": result, "error": None,
                           "metadata": {"provenance": provenance}})
    except Exception as exc:
        return json.dumps({"result": None, "error": str(exc),
                           "metadata": {"provenance": provenance}})