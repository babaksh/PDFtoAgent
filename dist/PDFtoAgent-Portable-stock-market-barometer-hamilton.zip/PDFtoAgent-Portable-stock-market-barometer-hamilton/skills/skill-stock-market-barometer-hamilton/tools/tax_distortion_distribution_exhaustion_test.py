"""Test whether the tax-induced overhang of salable stock has cured itself.

Chapter test: the surtax distortion will have cured itself when every one of the
forty stocks taken in the two averages (20 active railroad common stocks, 20
industrials) is as widely held as Pennsylvania Railroad -- roughly fifty shares
per stockholder -- at which point the steady tax-driven selling by large holders
has exhausted the supply overhanging the market.

This tool compares each constituent's average holding per stockholder against the
Pennsylvania benchmark and reports how far distribution has progressed and
whether a cure has been reached.

Use when: you have per-stock shareholder counts and share counts (or average
holding per stockholder) for the constituents of the two averages and want the
chapter's cure test applied. Do NOT use for judging whether a price is a real
market price from ownership concentration (use `ownership_distribution_real_market_test`).
"""

import json
import math
from typing import Dict, List, Optional


def _num(value):
    try:
        out = float(value)
    except (TypeError, ValueError):
        return None
    if math.isnan(out) or math.isinf(out):
        return None
    return out


def _below(value, threshold, tolerance_pct):
    return value < threshold * (1.0 + tolerance_pct / 100.0)


def _above(value, threshold, tolerance_pct):
    return value > threshold * (1.0 - tolerance_pct / 100.0)


async def tax_distortion_distribution_exhaustion_test(
    constituents: List[Dict],
    benchmark_shares_per_stockholder: float = 50.0,
    tolerance_pct: float = 0.0,
    require_all: bool = True,
    min_passing_share: float = 1.0,
    verbose: bool = True,
) -> str:
    """Rule whether the tax-induced overhang of salable stock has cured itself.

    Compares each constituent stock's average holding per stockholder against the
    Pennsylvania benchmark of about fifty shares. Inputs: a list of dicts, each
    with `label` (and optionally `group` = 'railroad' or 'industrial') plus either
    `shares_per_stockholder` or both `shares_outstanding` and `stockholders`.
    Constituents with missing or unusable data are reported as `unknown`, not
    silently passed.

    Use when you have per-constituent ownership data and want the chapter's
    distribution-exhaustion verdict. Do NOT use for concentration-based real
    market price tests (`ownership_distribution_real_market_test`).
    """
    provenance = {
        "source_grounded": [
            "benchmark: Pennsylvania Railroad average holding round about fifty shares per stockholder",
            "test applies to every one of the twenty active railroad common stocks and the twenty industrials",
            "cure condition: all constituents as widely held as Pennsylvania",
            "cure means the surtax-induced pressure of stock for sale has spent itself",
        ],
        "model_extrapolated": [
            "require_all toggle: by default every constituent must pass; with require_all=False the min_passing_share rule applies",
            "min_passing_share default 1.0",
            "tolerance_pct default 0.0 (no latitude around the fifty-share benchmark)",
            "constituents with missing/unusable holding data are reported as unknown and do not count as passing",
            "'progressing'/'stalled' trend labels for the not-yet-cured state",
        ],
    }
    try:
        bench = 50.0 if benchmark_shares_per_stockholder is None else float(benchmark_shares_per_stockholder)
        tolerance_pct = 0.0 if tolerance_pct is None else float(tolerance_pct)
        require_all = bool(require_all)
        min_share = 1.0 if min_passing_share is None else float(min_passing_share)
        min_share = min(1.0, max(0.0, min_share))
        if bench < 0.0:
            bench = 50.0

        rows = []
        for pos, c in enumerate(constituents or []):
            if not isinstance(c, dict):
                continue
            label = str(c.get("label") or ("constituent_" + str(pos)))
            group = str(c.get("group") or "").strip().lower()
            if group not in ("railroad", "industrial"):
                group = "unspecified"
            sph = _num(c.get("shares_per_stockholder"))
            if sph is None:
                shares = _num(c.get("shares_outstanding"))
                holders = _num(c.get("stockholders"))
                if shares is not None and holders is not None and holders > 0.0:
                    sph = shares / holders
            if sph is None or sph < 0.0:
                rows.append({
                    "label": label,
                    "group": group,
                    "shares_per_stockholder": None,
                    "gap_to_benchmark": None,
                    "status": "unknown",
                })
                continue
            gap = sph - bench
            if _below(sph, bench, tolerance_pct):
                status = "not_widely_held"
            elif _above(sph, bench, tolerance_pct):
                status = "widely_held"
            else:
                status = "at_benchmark"
            rows.append({
                "label": label,
                "group": group,
                "shares_per_stockholder": sph,
                "gap_to_benchmark": gap,
                "status": status,
            })

        known = [r for r in rows if r["status"] != "unknown"]
        passing = [r for r in known if r["status"] in ("widely_held", "at_benchmark")]
        failing = [r for r in known if r["status"] == "not_widely_held"]
        unknown = [r for r in rows if r["status"] == "unknown"]

        evaluated = len(known)
        pass_share = (len(passing) / evaluated) if evaluated else 0.0
        cured = (evaluated > 0 and not failing and not unknown) if require_all else (
            evaluated > 0 and pass_share >= min_share
        )
        if evaluated == 0:
            cured = False

        mean_holding = (sum(r["shares_per_stockholder"] for r in known) / evaluated) if evaluated else 0.0
        worst = min((r["shares_per_stockholder"] for r in known), default=0.0)
        mean_gap = mean_holding - bench

        if evaluated == 0:
            verdict = "no_data"
            reason = "no constituent carries usable holding data; the cure test cannot be applied"
        elif cured:
            verdict = "cured"
            reason = (
                "every one of the "
                + str(evaluated)
                + " evaluated constituents averages at least the Pennsylvania "
                + format(bench, ".1f")
                + " shares per stockholder; the tax-induced overhang has spent itself"
            )
        else:
            if unknown:
                extra = " (" + str(len(unknown)) + " constituents unevaluated for want of data)"
            else:
                extra = ""
            if failing:
                verdict = "not_cured"
                reason = (
                    str(len(failing))
                    + " of "
                    + str(evaluated)
                    + " constituents still average less than "
                    + format(bench, ".1f")
                    + " shares per stockholder; selling pressure from large holders persists"
                    + extra
                )
            else:
                verdict = "not_cured"
                reason = "the cure test could not be completed for all constituents" + extra

        if not cured and evaluated > 0 and failing:
            phase = "progressing" if mean_holding > bench * 0.5 else "stalled"
        elif evaluated == 0:
            phase = "unknown"
        else:
            phase = "complete"

        result = {
            "verdict": verdict,
            "cured": cured,
            "reason": reason,
            "phase": phase,
            "n_constituents": len(rows),
            "n_evaluated": evaluated,
            "n_passing": len(passing),
            "n_not_widely_held": len(failing),
            "n_unknown": len(unknown),
            "passing_share": pass_share,
            "mean_shares_per_stockholder": mean_holding,
            "mean_gap_to_benchmark": mean_gap,
            "lowest_shares_per_stockholder": worst,
            "not_widely_held_labels": [r["label"] for r in failing],
            "unknown_labels": [r["label"] for r in unknown],
        }
        if verbose:
            result["constituents"] = rows

        return json.dumps({"result": result, "error": None, "metadata": {"provenance": provenance}})
    except Exception as exc:  # noqa: BLE001 - contract: never raise
        return json.dumps(
            {"result": None, "error": "tax_distortion_distribution_exhaustion_test failed: " + str(exc),
             "metadata": {"provenance": provenance}}
        )