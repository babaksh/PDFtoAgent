import json
from typing import Optional


def _v(x, default: float) -> float:
    try:
        if x is None:
            return float(default)
        return float(x)
    except (TypeError, ValueError):
        return float(default)


async def barometer_record_adequacy_gate(
    number_of_stocks: float = 40.0,
    years_of_history: float = 25.0,
    compiled_years_after_events: float = 0.0,
    contemporaneous: Optional[bool] = None,
    double_average: Optional[bool] = None,
    record_label: str = "",
    min_stocks: float = 40.0,
    min_years: float = 25.0,
    verbose: bool = True,
) -> str:
    """Gate a record before trusting it as a barometer, on the three defects of history
    the chapter names: too few stocks, too short a history, and compilation years after
    the events instead of contemporaneously.

    Use when you are about to read a price record or business tabulation as a barometer
    and you need to know whether it is entitled to conclusive teaching value. The
    chapter's three disqualifiers:

      * stock count -- "When we say that the twenty active railroad stocks must confirm
        the twenty industrials ... less than forty stocks do not give a sufficiently
        inclusive picture of the market."
      * history length -- "Our table of averages is only truly effective for rather over
        a quarter of a century."
      * contemporaneity -- the author offers a partial record of 1860-1880 from fifteen
        miscellaneous stocks and says he does not think it has any conclusive teaching
        value; "if it had been kept contemporaneously with the events of that time, and
        not compiled years after", it could have given thoroughly trustworthy
        indications.

    A record failing ANY of the three is disqualified from conclusive teaching value --
    it remains a record, not a barometer. Pass number_of_stocks, years_of_history and
    compiled_years_after_events (0.0, or contemporaneous=True, means kept at the time).

    Do NOT use this to test whether two averages CORROBORATE (call
    average_corroboration_check) or whether a rebuilt index still reproduces the
    recorded one (call index_vintage_comparability_test); this gate only rules on a
    record's fitness to be read as a barometer at all.
    """
    try:
        stocks = _v(number_of_stocks, 40.0)
        years = _v(years_of_history, 25.0)
        lag = _v(compiled_years_after_events, 0.0)
        min_s = _v(min_stocks, 40.0)
        min_y = _v(min_years, 25.0)
        if min_s < 0:
            min_s = 0.0
        if min_y < 0:
            min_y = 0.0

        is_contemp = (lag <= 0.0) if contemporaneous is None else bool(contemporaneous)
        if lag > 0.0:
            is_contemp = False
        if is_contemp:
            lag = 0.0

        counts = (stocks >= min_s) or (isinstance(double_average, bool) and double_average)
        long_enough = years >= min_y
        timely = is_contemp

        failures: list = []
        if not counts:
            failures.append("fewer than " + str(round(min_s, 4)) + " stocks: not a sufficiently inclusive picture")
        if not long_enough:
            failures.append("less than " + str(round(min_y, 4)) + " years of history: too brief to be truly effective")
        if not timely:
            failures.append("compiled " + str(round(lag, 4)) + " years after the events, not contemporaneously")

        trustworthy = bool(counts and long_enough and timely)

        result = {
            "record_label": str(record_label),
            "number_of_stocks": stocks,
            "years_of_history": years,
            "compiled_years_after_events": lag,
            "contemporaneous": is_contemp,
            "breadth_adequate": counts,
            "history_adequate": long_enough,
            "contemporaneity_adequate": timely,
            "conditions_passed": int(counts) + int(long_enough) + int(timely),
            "conditions_failed": len(failures),
            "failures": failures,
            "trustworthy_barometer": trustworthy,
            "teaching_value": "conclusive" if trustworthy else "none: a record, not a barometer",
            "verdict": (
                "record qualifies as a trustworthy barometer"
                if trustworthy else
                "disqualified from conclusive teaching value: " + "; ".join(failures)
                if failures else "disqualified from conclusive teaching value"
            ),
        }

        if verbose:
            result["min_stocks"] = min_s
            result["min_years"] = min_y
            result["chapter_reference"] = {
                "breadth": "twenty active railroad stocks confirming twenty industrials; less than forty insufficient",
                "length": "the table of averages is only truly effective for rather over a quarter of a century",
                "contemporaneity": "kept contemporaneously with the events, and not compiled years after",
            }
            result["chapter_example"] = {
                "label": "1860-1880 record, fifteen miscellaneous stocks, compiled years after",
                "expected": "no conclusive teaching value",
            }

        return json.dumps({
            "result": result,
            "error": None,
            "metadata": {"provenance": {
                "source_grounded": ["under forty stocks do not give a sufficiently inclusive picture",
                                    "twenty rails plus twenty industrials implies the forty-stock breadth",
                                    "table only truly effective for rather over a quarter of a century",
                                    "compiled years after the events rather than contemporaneously",
                                    "consequence: no conclusive teaching value / not thoroughly trustworthy"],
                "model_extrapolated": ["cutoff set at exactly " + str(round(min_s, 4)) + " stocks",
                                       "cutoff set at exactly " + str(round(min_y, 4)) + " years ('rather over a quarter of a century')",
                                       "any single failing condition disqualifies the record outright",
                                       "conditions_failed counts rather than weights the three defects",
                                       "double_average=True may satisfy breadth via confirmation instead of count"],
            }},
        })
    except Exception as exc:
        return json.dumps({
            "result": {"trustworthy_barometer": False, "teaching_value": "unreadable input",
                       "conditions_failed": 0, "failures": [], "verdict": "unreadable input"},
            "error": str(exc),
            "metadata": {"provenance": {
                "source_grounded": ["under forty stocks insufficient; quarter century; contemporaneous"],
                "model_extrapolated": ["exception guard returns a neutral reading"],
            }},
        })