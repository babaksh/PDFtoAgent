"""Weight a January decline as disproportionately bearish.

Implements the rule this chapter states for the January 1907 decline: "A
decline of prices in January is always disturbing to the stock market because
that is a time of year when, other things being equal, the tendency is
oftenest bullish. It is a time for cheap money, and the reinvestment of the
profits of the preceding year. It is a time, moreover, when it is peculiarly
unpopular to talk bearish in Wall Street."

The chapter then shows the weight in practice: the sharp decline in the
averages in January 1907 made the commentator "most cautious, particularly in
declining to predict a rally, much less assume that nothing more than a
secondary reaction had been established"; by early March the existence of a
primary bear market was conceded.

Use this when you have a monthly (or otherwise seasonally labelled) price
record and want the weight to attach to a decline that is running in January -
the season whose normal bias is bullish - rather than to the same decline at
any other time of year.

Do NOT use this to judge whether a JANUARY money market is abnormally tight
(use `money_market_seasonal_tightness_warning`), to date the end of a primary
movement (use `primary_movement_termination_rule`, chMAJOR MARKET SWINGS), or
to decide whether a decline is only a secondary reaction (use
`dow_three_movement_classification`, chCYCLES AND STOCK MARKET RECORDS).
"""

import json
from typing import List, Optional

try:
    import numpy as _np  # noqa: F401  (optional; stdlib path is sufficient)
except ImportError:  # pragma: no cover
    _np = None


def _clean(seq: Optional[List[float]]) -> List[float]:
    out = []
    for v in seq or []:
        try:
            out.append(float(v))
        except (TypeError, ValueError):
            continue
    return out


def _norm_months(months: Optional[List[int]], n: int) -> List[int]:
    out = []
    if months:
        for m in months[:n]:
            try:
                mi = int(m)
            except (TypeError, ValueError):
                mi = 1
            out.append(1 if mi < 1 else (12 if mi > 12 else mi))
    while len(out) < n:
        out.append((len(out) % 12) + 1)
    return out[:n]


def _norm_years(years: Optional[List[float]], months: List[int]) -> List[float]:
    n = len(months)
    if years:
        out = []
        for y in years[:n]:
            try:
                out.append(float(y))
            except (TypeError, ValueError):
                out.append(0.0)
        while len(out) < n:
            out.append(out[-1] if out else 0.0)
        return out[:n]
    out = []
    y = 0.0
    prev = None
    for m in months:
        if prev is not None and m <= prev:
            y += 1.0
        out.append(y)
        prev = m
    return out


async def january_decline_seasonal_bearish_weight(
    prices: List[float],
    months: Optional[List[int]] = None,
    years: Optional[List[float]] = None,
    bearish_season_months: Optional[List[int]] = None,
    min_decline_pct: float = 1.0,
    bearish_weight: float = 2.0,
    verbose: bool = True,
) -> str:
    """Weight a January decline as disproportionately bearish.

    Use when a decline is running in the averages and you want the weight the
    chapter puts on the SEASON it runs in: January is the time of year when,
    other things being equal, the tendency is oftenest bullish - cheap money
    and the reinvestment of the preceding year's profits - so a fall against
    that seasonal bias is a warning out of proportion to its size.

    Args:
        prices: Price series (an average or a single issue) in date order.
        months: Month number (1-12) for each price. When omitted the months
            are cycled 1..12 from January.
        years: Year (or any increasing year label) for each price. When
            omitted a year counter that steps at each January is used.
        bearish_season_months: Months whose normal bias is bullish, so that a
            decline in them is disproportionately bearish. Defaults to [1] -
            January, the month the chapter names.
        min_decline_pct: Decline, in per cent, below which the move counts as
            no decline at all (1.0).
        bearish_weight: Multiplier applied to the January decline to give its
            weighted, disproportionate reading (2.0).
        verbose: True returns the full reading plus the seasonal bias table;
            False returns the compact decision only.

    Returns:
        JSON with result/error/metadata. `result.classification` is one of
        january_decline_disproportionately_bearish,
        january_decline_below_warning_threshold,
        no_decline_in_bearish_season, decline_outside_bearish_season,
        insufficient_data, insufficient_history.
    """
    provenance = {
        "source_grounded": [
            "January decline always disturbing to the stock market",
            "January: tendency is oftenest bullish, other things equal",
            "January: time for cheap money and reinvestment of prior year profits",
            "January 1907 decline made the commentator most cautious",
            "primary bear market conceded by early March 1907",
        ],
        "model_extrapolated": [
            "bearish_season_months default [1] (January)",
            "min_decline_pct = 1.0 before a fall counts as a decline",
            "bearish_weight = 2.0 for 'disproportionately bearish'",
            "normal bias measured as the mean move of the same month in prior years",
        ],
    }

    series = _clean(prices)
    n = len(series)
    mons = _norm_months(months, n)
    yrs = _norm_years(years, mons)

    if bearish_season_months:
        season = set()
        for m in bearish_season_months:
            try:
                mi = int(m)
            except (TypeError, ValueError):
                continue
            if 1 <= mi <= 12:
                season.add(mi)
    else:
        season = {1}
    if not season:
        season = {1}

    min_decline_pct = 1.0 if min_decline_pct is None else float(min_decline_pct)
    try:
        bearish_weight = 2.0 if bearish_weight is None else float(bearish_weight)
    except (TypeError, ValueError):
        bearish_weight = 2.0
    if bearish_weight < 1.0:
        bearish_weight = 1.0

    if n < 2:
        return json.dumps({
            "result": {
                "classification": "insufficient_data",
                "bearish_warning": False,
                "current_month": mons[0] if n else None,
                "in_bearish_season": (mons[0] in season) if n else None,
                "observed_decline_pct": None,
                "weighted_decline_pct": None,
                "seasonal_bias_mean_pct": None,
                "bearish_season_months": sorted(season),
                "min_decline_pct": min_decline_pct,
                "bearish_weight": bearish_weight,
                "reason": "Fewer than two prices supplied; a January decline "
                          "cannot be measured from a single observation.",
            },
            "error": None,
            "metadata": {"provenance": provenance, "n_prices": n},
        })

    target = None
    for i in range(n - 1, -1, -1):
        if mons[i] in season:
            target = i
            break
    if target is None or target == 0:
        return json.dumps({
            "result": {
                "classification": "insufficient_history",
                "bearish_warning": False,
                "current_month": mons[n - 1],
                "in_bearish_season": False,
                "observed_decline_pct": None,
                "weighted_decline_pct": None,
                "seasonal_bias_mean_pct": None,
                "bearish_season_months": sorted(season),
                "min_decline_pct": min_decline_pct,
                "bearish_weight": bearish_weight,
                "reason": "The record contains no month %s with a preceding "
                          "observation, so no %s decline can be measured."
                          % (sorted(season), sorted(season)),
            },
            "error": None,
            "metadata": {"provenance": provenance, "n_prices": n},
        })

    cur_month = mons[target]
    in_season = True
    prior = series[target - 1]
    last = series[target]
    decline_pct = (prior - last) / prior * 100.0 if prior > 0.0 else None

    season_moves = []
    other_moves = []
    for i in range(1, target):
        p0 = series[i - 1]
        p1 = series[i]
        if p0 <= 0.0:
            continue
        mv = (p1 - p0) / p0 * 100.0
        if mons[i] in season:
            season_moves.append(mv)
        else:
            other_moves.append(mv)
    bias = sum(season_moves) / float(len(season_moves)) if season_moves else None
    other_bias = sum(other_moves) / float(len(other_moves)) if other_moves else None

    weighted = None if decline_pct is None else decline_pct * bearish_weight
    against_bias = None
    if decline_pct is not None and bias is not None:
        against_bias = bool(decline_pct > 0.0 and bias > 0.0)

    if decline_pct is None:
        classification = "insufficient_history"
        warning = False
        reason = ("The prior price is zero or missing, so the percentage decline "
                  "into this %d observation cannot be measured." % cur_month)
    elif not in_season:
        classification = "decline_outside_bearish_season"
        warning = False
        reason = (
            "The latest move ends in month %d, outside the season %s whose normal "
            "bias is bullish. A move of %+.2f per cent there carries only its own "
            "weight - the chapter's disproportionate warning is specific to a "
            "January decline." % (cur_month, sorted(season), -decline_pct)
        )
    elif decline_pct < min_decline_pct:
        if decline_pct > 0.0:
            classification = "january_decline_below_warning_threshold"
            reason = (
                "January fell %.2f per cent, inside the %.1f per cent the tool "
                "treats as no decline: the seasonal bias (mean %+.2f per cent in "
                "this month) is not being contradicted materially."
                % (decline_pct, min_decline_pct, bias if bias is not None else 0.0)
            )
        elif decline_pct < 0.0:
            classification = "no_decline_in_bearish_season"
            reason = (
                "January ROSE %.2f per cent - with the seasonal bias, not against "
                "it. There is no January decline to weight as bearish."
                % (-decline_pct)
            )
        else:
            classification = "no_decline_in_bearish_season"
            reason = "January was unchanged: no decline, no seasonal warning."
        warning = False
    else:
        classification = "january_decline_disproportionately_bearish"
        warning = True
        reason = (
            "January fell %.2f per cent, which against a season whose normal bias "
            "is %s carries a weighted reading of %.2f per cent (%.1f times the "
            "move). January is the time of year when, other things being equal, the "
            "tendency is oftenest bullish - cheap money and the reinvestment of the "
            "preceding year's profits - so this decline is a warning out of "
            "proportion to its size, and it is not safe to assume that nothing more "
            "than a secondary reaction has been established."
            % (decline_pct,
               ("bullish, mean %+.2f per cent" % bias) if bias is not None else "bullish",
               weighted if weighted is not None else decline_pct, bearish_weight)
        )

    out = {
        "classification": classification,
        "bearish_warning": warning,
        "current_month": cur_month,
        "current_year": yrs[n - 1],
        "in_bearish_season": in_season,
        "observed_decline_pct": decline_pct,
        "weighted_decline_pct": weighted,
        "seasonal_bias_mean_pct": bias,
        "rest_of_year_bias_mean_pct": other_bias,
        "decline_against_bias": against_bias,
        "bearish_season_months": sorted(season),
        "min_decline_pct": min_decline_pct,
        "bearish_weight": bearish_weight,
        "reason": reason,
    }

    if verbose:
        out["observations"] = [
            {"index": i, "year": yrs[i], "month": mons[i], "price": series[i],
             "bearish_season": mons[i] in season,
             "move_pct": (None if i == 0 or series[i - 1] <= 0.0
                          else (series[i] - series[i - 1]) / series[i - 1] * 100.0)}
            for i in range(n)
        ]
        out["prior_season_moves"] = len(season_moves)
        out["prior_other_moves"] = len(other_moves)

    return json.dumps({
        "result": out,
        "error": None,
        "metadata": {"provenance": provenance, "n_prices": n},
    })