import json
from typing import List, Optional


async def manipulation_scope_by_movement_classifier(
    move_pct: float,
    duration_periods: int,
    issues_affected: int,
    periods_per_year: float = 252.0,
    group_has_leading_issue: bool = False,
    movement_class: str = "",
    primary_min_months: float = 12.0,
    primary_min_move_pct: float = 5.0,
    secondary_max_months: float = 12.0,
    daily_max_periods: int = 21,
    breadth_averages_min_issues: int = 20,
    verbose: bool = True,
) -> str:
    """Classify an observed move by the Dow movement it belongs to (primary, secondary, daily) and by its breadth (both averages, a group with a recognized leading issue, or a single stock), then rule whether manipulation or professional trading could account for it.

    Use when you have a real move you want to attribute: how big it was, how long
    it lasted, and how many issues it touched. The chapter's rule is that
    manipulation and professional trading have no real effect in the primary
    movement, are a small factor in secondary swings, and are mainly influential
    in particular stocks in the daily fluctuation -- and that even in the lesser
    movements they reach only individual stocks or small groups with a
    well-recognized leading issue (a raid on the oil group with special
    attention to Mexican Petroleum).

    Do NOT use this to measure how much one stock's surprise moves a group
    average (call single_stock_average_impact_dilution), and do NOT use it to
    price the friction of a trade (call round_trip_friction_quick_turn_test).

    Args:
        move_pct: size of the observed move, in percent (signed or absolute).
        duration_periods: how many periods (days, by default) the move lasted.
        issues_affected: how many separate issues participated in the move.
        periods_per_year: periods per year of the data (252 daily bars).
        group_has_leading_issue: True when the affected group has one
            well-recognized leading issue that the move centred on.
        movement_class: optional override -- "primary", "secondary" or "daily"
            when you have already dated the movement yourself.
        primary_min_months: a move lasting at least this many months is treated
            as a primary movement (default 12).
        primary_min_move_pct: a move of at least this size, in per cent, is
            treated as a primary movement (default 5.0).
        secondary_max_months: the upper bound of a secondary swing in months
            (default 12); anything shorter and not day-to-day is secondary.
        daily_max_periods: a move lasting no more than this many periods is
            day-to-day fluctuation (default 21, about a month of daily bars).
        breadth_averages_min_issues: number of participating issues at or above
            which the move counts as the averages rather than a group
            (default 20, one full Dow-Jones group).
        verbose: False returns the compact ruling; True adds the full breakdown.

    Returns:
        JSON string with result/error/metadata. Result holds movement_class,
        breadth_scope, influence_rating, manipulation_possible,
        professional_trading_could_account and a short reason.
    """
    try:
        ppy = float(periods_per_year) if periods_per_year else 252.0
        if ppy <= 0.0:
            ppy = 252.0
        dur = int(duration_periods) if duration_periods is not None else 0
        if dur < 0:
            dur = 0
        months = dur / ppy * 12.0
        issues = int(issues_affected) if issues_affected is not None else 0
        if issues < 0:
            issues = 0

        override = (movement_class or "").strip().lower()
        if not override and dur <= 0 and issues <= 0:
            return json.dumps(
                {
                    "result": {
                        "movement_class": "unclassified",
                        "breadth_scope": "undetermined",
                        "influence_rating": "none",
                        "manipulation_possible": False,
                        "professional_trading_could_account": False,
                        "reason": "No movement was supplied (zero duration, no issues "
                        "affected): there is nothing to classify.",
                    },
                    "error": None,
                    "metadata": {
                        "provenance": {
                            "source_grounded": [
                                "primary movement: manipulation has no real effect",
                                "secondary reaction/rally: professional trading a small factor",
                                "daily fluctuation: mainly influential in particular stocks",
                                "manipulation confined to individual stocks or small groups with a well-recognized leading issue",
                                "breadth categories: the averages, a group with a leading issue, a single stock",
                            ],
                            "model_extrapolated": [
                                "primary minimum duration of 12 months",
                                "primary minimum move of 5.0%",
                                "day-to-day maximum of 21 periods",
                                "breadth cutoff of 20 issues for the averages",
                                "grading of 'small factor' versus 'mainly influential' by class x breadth",
                                "unclassified reading when no movement is supplied",
                            ],
                        }
                    },
                }
            )
        if override in ("primary", "major", "main"):
            cls = "primary"
            class_basis = "caller supplied"
        elif override in ("secondary", "reaction", "rally"):
            cls = "secondary"
            class_basis = "caller supplied"
        elif override in ("daily", "day_to_day", "day-to-day"):
            cls = "daily"
            class_basis = "caller supplied"
        else:
            prim = float(primary_min_months) if primary_min_months is not None else 12.0
            prim_move = (
                float(primary_min_move_pct) if primary_min_move_pct is not None else 5.0
            )
            daily_max = (
                int(daily_max_periods)
                if daily_max_periods is not None and int(daily_max_periods) > 0
                else 21
            )
            size = abs(float(move_pct) if move_pct is not None else 0.0)
            if months >= prim and size >= prim_move:
                cls = "primary"
                class_basis = (
                    "duration %.2f months >= primary minimum %.2f months and move "
                    "%.4f%% >= primary minimum %.4f%%" % (months, prim, size, prim_move)
                )
            elif dur <= daily_max:
                cls = "daily"
                class_basis = (
                    "duration %d periods <= day-to-day maximum %d periods"
                    % (dur, daily_max)
                )
            else:
                cls = "secondary"
                class_basis = (
                    "duration %.2f months is inside the secondary band (below %.2f "
                    "months, longer than %d periods)"
                    % (months, float(secondary_max_months) if secondary_max_months else 12.0, daily_max)
                )

        breadth_min = (
            int(breadth_averages_min_issues)
            if breadth_averages_min_issues is not None and int(breadth_averages_min_issues) > 0
            else 20
        )
        if issues >= breadth_min:
            breadth = "the averages"
        elif issues <= 1:
            breadth = "a single stock"
        elif group_has_leading_issue:
            breadth = "a group with a recognized leading issue"
        else:
            breadth = "a group without a recognized leading issue"

        if cls == "primary":
            influence = "no real effect"
            manipulation_possible = False
            professional = False
            reason = (
                "Primary movement: the actuating forces are above and beyond "
                "manipulation and it cannot account for the move."
            )
        elif cls == "secondary":
            if breadth == "the averages":
                influence = "a small factor"
                manipulation_possible = False
                professional = True
                reason = (
                    "Secondary swing across the averages: professional trading is "
                    "a small factor at most, and manipulation cannot account for "
                    "the whole swing."
                )
            elif breadth == "a group without a recognized leading issue":
                influence = "a small factor"
                manipulation_possible = False
                professional = True
                reason = (
                    "Secondary swing in a group with no well-recognized leading "
                    "issue: the chapter confines manipulation to individual stocks "
                    "or such groups, so neither explains this move."
                )
            else:
                influence = "a striking temporary effect"
                manipulation_possible = True
                professional = True
                reason = (
                    "Secondary swing in %s: this is where a raid can shake out weak "
                    "holders or force a few bears to cover." % breadth
                )
        else:
            if breadth == "the averages":
                influence = "negligible"
                manipulation_possible = False
                professional = False
                reason = (
                    "Daily fluctuation across the averages: it is noise in the "
                    "barometer, not a manipulable move."
                )
            elif breadth == "a group without a recognized leading issue":
                influence = "a small factor"
                manipulation_possible = False
                professional = True
                reason = (
                    "Daily fluctuation in a group with no recognized leading issue: "
                    "manipulation does not reach it."
                )
            else:
                influence = "mainly influential"
                manipulation_possible = True
                professional = True
                reason = (
                    "Daily fluctuation in %s: professional trading is mainly "
                    "influential here, at times, in particular stocks." % breadth
                )

        result = {
            "movement_class": cls,
            "breadth_scope": breadth,
            "influence_rating": influence,
            "manipulation_possible": manipulation_possible,
            "professional_trading_could_account": professional,
        }
        if verbose:
            result["duration_months"] = months
            result["duration_periods"] = dur
            result["issues_affected"] = issues
            result["move_pct"] = float(move_pct) if move_pct is not None else 0.0
            result["movement_class_basis"] = class_basis
            result["reason"] = reason
        return json.dumps(
            {
                "result": result,
                "error": None,
                "metadata": {
                    "provenance": {
                        "source_grounded": [
                            "primary movement: manipulation has no real effect",
                            "secondary reaction/rally: professional trading a small factor",
                            "daily fluctuation: mainly influential in particular stocks",
                            "manipulation confined to individual stocks or small groups with a well-recognized leading issue",
                            "breadth categories: the averages, a group with a leading issue, a single stock",
                        ],
                        "model_extrapolated": [
                                "primary minimum duration of 12 months",
                                "primary minimum move of 5.0%",
                                "day-to-day maximum of 21 periods",
                                "breadth cutoff of 20 issues for the averages",
                            "grading of 'small factor' versus 'mainly influential' by class x breadth",
                        ],
                    }
                },
            }
        )
    except Exception as exc:
        return json.dumps(
            {
                "result": None,
                "error": str(exc),
                "metadata": {
                    "provenance": {
                        "source_grounded": [
                            "primary movement: manipulation has no real effect",
                            "secondary swing: professional trading a small factor",
                        ],
                        "model_extrapolated": [
                                "primary minimum duration of 12 months",
                                "primary minimum move of 5.0%",
                        ],
                    }
                },
            }
        )