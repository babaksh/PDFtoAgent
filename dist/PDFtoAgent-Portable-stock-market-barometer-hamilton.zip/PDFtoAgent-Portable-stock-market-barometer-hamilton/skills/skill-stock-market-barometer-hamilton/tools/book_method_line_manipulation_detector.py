import json
from typing import List, Optional


def _record_point_changes(prices: List[float]):
    """Dow's book method: set down each change of one point as it occurs."""
    entries = []
    if not prices:
        return entries
    last_recorded = float(prices[0])
    entries.append({"index": 0, "price": last_recorded})
    for idx in range(1, len(prices)):
        price = float(prices[idx])
        while abs(price - last_recorded) >= 1.0:
            last_recorded = last_recorded + (1.0 if price > last_recorded else -1.0)
            entries.append({"index": idx, "price": last_recorded})
    return entries


async def book_method_line_manipulation_detector(
    prices: List[float],
    band_points: float = 2.0,
    min_line_entries: int = 10,
    min_activity_changes_per_period: float = 0.2,
    verbose: bool = True,
) -> str:
    """Run Dow's "book method" on one active stock and read a long horizontal line.

    Dow, editorial of July 20, 1901: "There is what is called the book method.
    Prices are set down, giving each change of one point as it occurs, forming
    thereby lines having a general horizontal direction but running into
    diagonals as the market moves up and down. There come times when a stock
    with a good degree of activity will stay within a narrow range of prices,
    say two points, until there has formed quite a long horizontal line of
    these figures. The formation of such a line sometimes suggests that stock
    has been accumulated or distributed ... Records of this kind kept for the
    last fifteen years seem to support the theory that the manipulation
    necessary to acquire stock is oftentimes detected in this way."

    Use when you have a price series for ONE active stock and want the book
    record (one entry per one-point change), the long horizontal line inside a
    narrow band, and the accumulation/distribution reading.

    Do NOT use on two market averages (industrial and railroad) -- the
    averages version is `line_formation_breakout` (chCYCLES AND STOCK MARKET
    RECORDS). This tool takes a single stock, records one point per entry, uses
    Dow's ~2-point band, and adds the manipulation reading.

    The accumulation-vs-distribution distinction is NOT given by the chapter --
    the line alone only says one or the other is occurring -- so the tool
    reports the line and, when the line is resolved, resolves the reading from
    the direction of the subsequent diagonal.
    """
    provenance = {
        "source_grounded": [
            "record each change of one point as it occurs",
            "lines run horizontally but turn into diagonals as the market moves up and down",
            "narrow range of about two points",
            "a quite long horizontal line forms",
            "such a line suggests stock has been accumulated or distributed",
            "manipulation necessary to acquire stock is oftentimes detected in this way (fifteen years of records)",
            "applies to a stock with a good degree of activity",
        ],
        "model_extrapolated": [
            "min_line_entries = 10 for 'quite a long horizontal line'",
            "min_activity_changes_per_period = 0.2 for 'a good degree of activity'",
            "accumulation vs distribution distinguished by the direction the line resolves (chapter gives only 'accumulated or distributed')",
            "the book record restarts the entry count at the first observed price",
        ],
    }
    try:
        series = [0.0 if p is None else float(p) for p in (prices or [])]
        band = 2.0 if band_points is None else float(band_points)
        if band < 0.0:
            band = 0.0
        min_entries = 10 if min_line_entries is None else int(min_line_entries)
        if min_entries < 1:
            min_entries = 1
        min_activity = (0.2 if min_activity_changes_per_period is None
                        else float(min_activity_changes_per_period))

        entries = _record_point_changes(series)
        book = [e["price"] for e in entries]

        if series:
            point_changes = sum(1 for k in range(1, len(series))
                                if abs(series[k] - series[k - 1]) >= 1.0)
            activity = point_changes / float(len(series) - 1) if len(series) > 1 else 0.0
        else:
            activity = 0.0
        active_enough = activity >= min_activity

        longest = {"start_entry": 0, "end_entry": 0, "length": 0,
                   "band_high": None, "band_low": None}
        best = None
        start = 0
        while start < len(book):
            end = start
            while end + 1 < len(book):
                seg = book[start:end + 2]
                if max(seg) - min(seg) <= band:
                    end += 1
                else:
                    break
            length = end - start + 1
            seg = book[start:end + 1]
            candidate = (length, {"start_entry": start, "end_entry": end,
                                  "length": length,
                                  "band_high": max(seg), "band_low": min(seg)})
            if best is None or length > best[0]:
                best = candidate
            if end == start:
                start += 1
            else:
                start = end + 1
        if best is not None:
            longest = best[1]

        line_detected = longest["length"] >= min_entries
        horizontal = longest["length"] >= min_entries and longest["band_high"] is not None

        resolution = "unresolved"
        reading = "no_line_detected"
        reason = ""
        if not series:
            reason = "No prices were supplied, so no book record can be set down."
        elif not line_detected:
            reason = ("The book record forms no horizontal line of %d one-point entries within "
                      "a %.1f-point band; the figures run into diagonals as the market moves "
                      "up and down." % (min_entries, band))
        else:
            end_series_index = entries[longest["end_entry"]]["index"]
            after_start = end_series_index + 1
            after = series[after_start:] if after_start < len(series) else []
            if after:
                last_price = series[-1]
                mid = (longest["band_high"] + longest["band_low"]) / 2.0
                if last_price > mid:
                    resolution = "upward_diagonal"
                    reading = "accumulation"
                    reason = ("A horizontal line of %d one-point entries formed within a band of "
                              "%.2f to %.2f, and the line has since turned into an upward diagonal "
                              "(last price %.2f): the stock was accumulated, which is the "
                              "manipulation necessary to acquire stock."
                              % (longest["length"], longest["band_low"], longest["band_high"],
                                 last_price))
                elif last_price < mid:
                    resolution = "downward_diagonal"
                    reading = "distribution"
                    reason = ("A horizontal line of %d one-point entries formed within a band of "
                              "%.2f to %.2f, and the line has since turned into a downward "
                              "diagonal (last price %.2f): the stock was distributed."
                              % (longest["length"], longest["band_low"], longest["band_high"],
                                 last_price))
                else:
                    resolution = "still_horizontal"
                    reading = "line_intact"
                    reason = ("A horizontal line of %d one-point entries is still forming within a "
                              "band of %.2f to %.2f; the line suggests accumulation or distribution "
                              "but has not yet turned into a diagonal."
                              % (longest["length"], longest["band_low"], longest["band_high"]))
            else:
                resolution = "still_horizontal"
                reading = "line_intact"
                reason = ("A horizontal line of %d one-point entries has formed within a band of "
                          "%.2f to %.2f; the line suggests accumulation or distribution but has "
                          "not yet turned into a diagonal."
                          % (longest["length"], longest["band_low"], longest["band_high"]))

        result = {
            "line_detected": bool(horizontal),
            "reading": reading,
            "reason": reason,
            "activity_changes_per_period": activity,
            "active_enough": bool(active_enough),
            "num_book_entries": len(book),
            "longest_line_length": longest["length"],
            "line_band_low": longest["band_low"],
            "line_band_high": longest["band_high"],
            "line_width_points": (longest["band_high"] - longest["band_low"]
                                  if longest["band_high"] is not None else None),
            "line_resolution": resolution,
        }
        if verbose:
            result["book_record"] = entries
            result["line_span"] = {"start_entry": longest["start_entry"],
                                   "end_entry": longest["end_entry"]}
            result["params"] = {
                "band_points": band,
                "min_line_entries": min_entries,
                "min_activity_changes_per_period": min_activity,
            }
            result["note"] = ("Records of this kind kept for the last fifteen years seem to "
                              "support the theory that the manipulation necessary to acquire "
                              "stock is oftentimes detected in this way.")
        return json.dumps({"result": result, "error": None,
                           "metadata": {"provenance": provenance}})
    except Exception as exc:
        return json.dumps({"result": None, "error": str(exc),
                           "metadata": {"provenance": provenance}})