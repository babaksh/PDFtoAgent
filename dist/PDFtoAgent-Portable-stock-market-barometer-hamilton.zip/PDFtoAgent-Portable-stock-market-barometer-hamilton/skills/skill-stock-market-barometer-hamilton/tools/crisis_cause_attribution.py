import json
from typing import Any, Dict, List, Optional


async def crisis_cause_attribution(
    war_or_capture_shock: bool = False,
    bank_circulation_change_pct: float = 0.0,
    crop_yield_change_pct: float = 0.0,
    breadstuffs_imported: bool = False,
    bank_charter_refused: bool = False,
    public_deposits_to_state_banks: bool = False,
    state_banks_created: bool = False,
    enterprises_ahead_of_time_pct: float = 0.0,
    specie_to_loans_pct: Optional[float] = None,
    specie_to_deposits_pct: Optional[float] = None,
    floating_to_fixed_conversion_share: float = 0.0,
    currency_standard_uncertainty: float = 0.0,
    foreign_investment_withdrawal_pct: float = 0.0,
    tariff_legislation_fear: float = 0.0,
    foreign_crisis_severity: float = 0.0,
    foreign_crisis_years_before: Optional[float] = None,
    circulation_contraction_pct: float = 20.0,
    crop_deficiency_pct: float = 15.0,
    enterprises_excess_pct: float = 50.0,
    specie_adequacy_pct: float = 20.0,
    floating_to_fixed_reference: float = 0.5,
    foreign_withdrawal_pct: float = 25.0,
    foreign_crisis_recency_years: float = 3.0,
    supporting_score: float = 0.5,
    verbose: bool = True,
) -> str:
    """Attribute a crisis episode to the cause-categories Charles H. Dow names.

    Use when you have ONE crisis episode described by its measurable antecedents
    and you want Dow's own cause label for it, plus the dominant ("chief") cause
    among those present. The categories are exactly those Dow names in his
    account of the American crises:

      * war_capture_shock -- precipitated by war or a capture (1814, the capture
        of Washington);
      * contraction_of_bank_circulation -- the tremendous contraction that
        prompted speculation and then broke prices (1819);
      * deficient_crops_and_imported_breadstuffs -- crops deficient, breadstuffs
        imported (1837);
      * banking_structure_change -- refusal to extend the charter of the United
        States Bank, withdrawal of the public deposits and their lodgment with
        state banks, state banks created without capital (1837, 1814);
      * enterprises_established_ahead_of_the_time -- a multitude of enterprises
        established ahead of the time (1837);
      * specie_too_small_relative_to_loans_and_deposits -- the proportion of
        specie held by banks very small in proportion to their loans and
        deposits (1857);
      * conversion_of_floating_into_fixed_capital -- the enormous conversion of
        floating into fixed capital, business expanded beyond the money supply
        (1873);
      * currency_standard_uncertainty_with_foreign_withdrawal_and_tariff_fear --
        uncertainty as to the currency, withdrawal of foreign investments, fear
        of radical tariff legislation; anxiety over the gold standard "the chief
        factor, as it bore upon many others" (1893);
      * transmission_from_a_foreign_crisis -- a European or London panic
        importing the disturbance (1825-26, 1847, 1866).

    Every category is scored 0-1 from the evidence you supply; the highest score
    is returned as the dominant cause with a short reason, and the rest are
    returned as a ranked list.

    Do NOT use this to name the KIND of disturbance (commercial panic, money
    panic, Stock Exchange smash) -- call `crisis_type_classification`. Do NOT
    use it to grade how far a foreign crisis actually reached prices here --
    call `foreign_crisis_transmission_assessment` (its output can be fed back in
    here as `foreign_crisis_severity` / `foreign_crisis_years_before`).

    Depends on: nothing from earlier chapters.
    """
    try:
        war_or_capture_shock = bool(war_or_capture_shock)
        breadstuffs_imported = bool(breadstuffs_imported)
        bank_charter_refused = bool(bank_charter_refused)
        public_deposits_to_state_banks = bool(public_deposits_to_state_banks)
        state_banks_created = bool(state_banks_created)

        bank_circulation_change_pct = 0.0 if bank_circulation_change_pct is None else float(bank_circulation_change_pct)
        crop_yield_change_pct = 0.0 if crop_yield_change_pct is None else float(crop_yield_change_pct)
        enterprises_ahead_of_time_pct = 0.0 if enterprises_ahead_of_time_pct is None else float(enterprises_ahead_of_time_pct)
        floating_to_fixed_conversion_share = (
            0.0 if floating_to_fixed_conversion_share is None else float(floating_to_fixed_conversion_share)
        )
        currency_standard_uncertainty = 0.0 if currency_standard_uncertainty is None else float(currency_standard_uncertainty)
        foreign_investment_withdrawal_pct = (
            0.0 if foreign_investment_withdrawal_pct is None else float(foreign_investment_withdrawal_pct)
        )
        tariff_legislation_fear = 0.0 if tariff_legislation_fear is None else float(tariff_legislation_fear)
        foreign_crisis_severity = 0.0 if foreign_crisis_severity is None else float(foreign_crisis_severity)
        circulation_contraction_pct = 20.0 if circulation_contraction_pct is None else float(circulation_contraction_pct)
        crop_deficiency_pct = 15.0 if crop_deficiency_pct is None else float(crop_deficiency_pct)
        enterprises_excess_pct = 50.0 if enterprises_excess_pct is None else float(enterprises_excess_pct)
        specie_adequacy_pct = 20.0 if specie_adequacy_pct is None else float(specie_adequacy_pct)
        floating_to_fixed_reference = 0.5 if floating_to_fixed_reference is None else float(floating_to_fixed_reference)
        foreign_withdrawal_pct = 25.0 if foreign_withdrawal_pct is None else float(foreign_withdrawal_pct)
        foreign_crisis_recency_years = 3.0 if foreign_crisis_recency_years is None else float(foreign_crisis_recency_years)
        supporting_score = 0.5 if supporting_score is None else float(supporting_score)

        def _clamp01(value: float) -> float:
            return 0.0 if value < 0.0 else (1.0 if value > 1.0 else value)

        def _shortfall(ratio_pct: Optional[float]) -> float:
            if ratio_pct is None or specie_adequacy_pct <= 0.0:
                return 0.0
            ratio = float(ratio_pct)
            if ratio >= specie_adequacy_pct:
                return 0.0
            return _clamp01((specie_adequacy_pct - ratio) / specie_adequacy_pct)

        circulation_score = _clamp01(
            max(0.0, -bank_circulation_change_pct) / circulation_contraction_pct
            if circulation_contraction_pct > 0.0
            else 0.0
        )
        crop_score = _clamp01(
            0.6 * (max(0.0, -crop_yield_change_pct) / crop_deficiency_pct if crop_deficiency_pct > 0.0 else 0.0)
            + 0.4 * (1.0 if breadstuffs_imported else 0.0)
        )
        banking_score = _clamp01(
            0.4 * (1.0 if bank_charter_refused else 0.0)
            + 0.35 * (1.0 if public_deposits_to_state_banks else 0.0)
            + 0.25 * (1.0 if state_banks_created else 0.0)
        )
        enterprise_score = _clamp01(
            max(0.0, enterprises_ahead_of_time_pct) / enterprises_excess_pct
            if enterprises_excess_pct > 0.0
            else 0.0
        )
        specie_score = max(_shortfall(specie_to_loans_pct), _shortfall(specie_to_deposits_pct))
        fixed_capital_score = _clamp01(
            max(0.0, floating_to_fixed_conversion_share) / floating_to_fixed_reference
            if floating_to_fixed_reference > 0.0
            else 0.0
        )
        currency_score = _clamp01(
            0.4 * _clamp01(currency_standard_uncertainty / 10.0)
            + 0.35 * (max(0.0, foreign_investment_withdrawal_pct) / foreign_withdrawal_pct if foreign_withdrawal_pct > 0.0 else 0.0)
            + 0.25 * _clamp01(tariff_legislation_fear / 10.0)
        )
        recency = _clamp01(
            max(0.0, 1.0 - (float(foreign_crisis_years_before) / foreign_crisis_recency_years))
            if foreign_crisis_years_before is not None and foreign_crisis_recency_years > 0.0
            else 0.0
        )
        transmission_score = (
            0.0
            if foreign_crisis_severity <= 0.0
            else _clamp01(0.5 * _clamp01(foreign_crisis_severity / 10.0) + 0.5 * recency)
        )

        ranked: List[Dict[str, Any]] = [
            {"cause": "war_capture_shock", "score": 1.0 if war_or_capture_shock else 0.0},
            {"cause": "contraction_of_bank_circulation", "score": circulation_score},
            {"cause": "deficient_crops_and_imported_breadstuffs", "score": crop_score},
            {"cause": "banking_structure_change", "score": banking_score},
            {"cause": "enterprises_established_ahead_of_the_time", "score": enterprise_score},
            {"cause": "specie_too_small_relative_to_loans_and_deposits", "score": specie_score},
            {"cause": "conversion_of_floating_into_fixed_capital", "score": fixed_capital_score},
            {
                "cause": "currency_standard_uncertainty_with_foreign_withdrawal_and_tariff_fear",
                "score": currency_score,
            },
            {"cause": "transmission_from_a_foreign_crisis", "score": transmission_score},
        ]
        ranked.sort(key=lambda row: -row["score"])

        identified = [row for row in ranked if row["score"] > 0.0]
        top = ranked[0]
        dominant_present = top["score"] > 0.0
        dominant_cause = top["cause"] if dominant_present else None
        dominant_score = top["score"]
        supporting = [
            row["cause"] for row in ranked if row is not top and row["score"] >= supporting_score
        ]

        if not dominant_present:
            reason = (
                "No cause identified: every antecedent supplied is at its neutral value / zero severity, so "
                "none of Dow's named causes is present in the evidence given."
            )
        else:
            reason = (
                "Dominant cause is %s with an evidence score of %.2f"
                % (dominant_cause, dominant_score)
                + (
                    "; it also bore upon %d other named cause(s) present at or above %.2f (%s), as Dow says of "
                    "the 1893 gold-standard anxiety, 'the chief factor, as it bore upon many others'."
                    % (len(supporting), supporting_score, ", ".join(supporting))
                    if supporting
                    else "; no other named cause reaches the supporting level of %.2f." % supporting_score
                )
            )

        result: Dict[str, Any] = {
            "dominant_cause": dominant_cause,
            "dominant_score": round(dominant_score, 4),
            "causes_present": len(identified),
            "supporting_causes": supporting,
            "reason": reason,
        }
        if verbose:
            result["ranked_causes"] = [
                {"cause": row["cause"], "score": round(row["score"], 4)} for row in ranked
            ]
            result["components"] = {
                "war_or_capture_shock": war_or_capture_shock,
                "circulation_contraction_measured_pct": round(max(0.0, -bank_circulation_change_pct), 4),
                "crop_shortfall_pct": round(max(0.0, -crop_yield_change_pct), 4),
                "breadstuffs_imported": breadstuffs_imported,
                "bank_charter_refused": bank_charter_refused,
                "public_deposits_to_state_banks": public_deposits_to_state_banks,
                "state_banks_created": state_banks_created,
                "enterprises_ahead_of_time_pct": round(max(0.0, enterprises_ahead_of_time_pct), 4),
                "specie_to_loans_pct": specie_to_loans_pct,
                "specie_to_deposits_pct": specie_to_deposits_pct,
                "floating_to_fixed_conversion_share": round(max(0.0, floating_to_fixed_conversion_share), 4),
                "currency_standard_uncertainty": round(currency_standard_uncertainty, 4),
                "foreign_investment_withdrawal_pct": round(max(0.0, foreign_investment_withdrawal_pct), 4),
                "tariff_legislation_fear": round(tariff_legislation_fear, 4),
                "foreign_crisis_severity": round(foreign_crisis_severity, 4),
                "foreign_crisis_years_before": foreign_crisis_years_before,
            }
            result["thresholds"] = {
                "circulation_contraction_pct": circulation_contraction_pct,
                "crop_deficiency_pct": crop_deficiency_pct,
                "enterprises_excess_pct": enterprises_excess_pct,
                "specie_adequacy_pct": specie_adequacy_pct,
                "floating_to_fixed_reference": floating_to_fixed_reference,
                "foreign_withdrawal_pct": foreign_withdrawal_pct,
                "foreign_crisis_recency_years": foreign_crisis_recency_years,
                "supporting_score": supporting_score,
            }
        return json.dumps({
            "result": result,
            "error": None,
            "metadata": {"provenance": {
                "source_grounded": [
                    "war or capture precipitating the crisis (1814 capture of Washington)",
                    "tremendous contraction of bank circulation",
                    "crops deficient and breadstuffs imported",
                    "refusal to extend the charter of the United States Bank",
                    "withdrawal of public deposits and their lodgment with state banks",
                    "state banks taking the place of the old United States Bank, lacking capital and issuing currency without sufficient security",
                    "a multitude of enterprises established ahead of the time",
                    "proportion of specie held by banks very small in proportion to their loans and deposits",
                    "enormous conversion of floating into fixed capital; business expanded beyond the money supply",
                    "uncertainty as to the currency, withdrawal of foreign investments, fear of radical tariff legislation; gold-standard anxiety the chief factor",
                    "transmission from a European or London panic",
                ],
                "model_extrapolated": [
                    "0-1 evidence score per cause and the weights inside each score (0.4 charter refusal / 0.35 public deposits / 0.25 state-bank creation, 0.6 crop shortfall / 0.4 imported breadstuffs, 0.4 uncertainty / 0.35 withdrawal / 0.25 tariff fear, 0.5 severity / 0.5 recency for transmission)",
                    "numeric thresholds: 20% contraction of bank circulation, 15% crop shortfall, 50% excess enterprise formation, 20% specie adequacy, 0.5 floating-to-fixed reference, 25% foreign withdrawal, 3 years foreign-crisis recency, 0.5 supporting-cause level",
                    "0-10 severity scales for currency-standard uncertainty, tariff fear and foreign-crisis severity",
                    "dominance rule: highest score wins, ties broken by the order the causes are listed",
                ],
            }},
        })
    except Exception as exc:  # pragma: no cover - defensive
        return json.dumps({
            "result": None,
            "error": "%s: %s" % (type(exc).__name__, exc),
            "metadata": {"provenance": {
                "source_grounded": [],
                "model_extrapolated": ["error path only"],
            }},
        })