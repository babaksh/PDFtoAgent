"""Screen candidate constituents for an average on representative AND consistently active."""

import json
import math
from typing import List, Optional


def _clean(values) -> List[float]:
    if not values:
        return []
    out: List[float] = []
    for v in values:
        try:
            f = float(v)
        except (TypeError, ValueError):
            continue
        if math.isnan(f) or math.isinf(f):
            continue
        out.append(f)
    return out


def _finite(v) -> bool:
    return v is not None and not (math.isnan(v) or math.isinf(v))


def _r(v, nd: int = 4):
    return None if not _finite(v) else round(float(v), nd)


def _mean(xs: List[float]):
    return sum(xs) / len(xs) if xs else None


def _std(xs: List[float]):
    if len(xs) < 2:
        return None
    m = _mean(xs)
    var = sum((x - m) ** 2 for x in xs) / (len(xs) - 1)
    return math.sqrt(var) if var > 0.0 else 0.0


async def constituent_activity_consistency_screen(
    constituents: List[dict],
    required_size: int = 12,
    min_periods: int = 12,
    max_activity_cv: float = 1.0,
    min_traded_share: float = 0.9,
    min_representative_share: float = 0.01,
    verbose: bool = True,
) -> str:
    """Screen candidate constituents for an average on the two qualities the chapter
    requires -- REPRESENTATIVE and CONSISTENTLY ACTIVE -- and rule whether enough
    qualify to make an average at all.

    Use when you are assembling (or re-assembling) a price average and must decide
    which issues may go into it, and whether the list can be filled without
    contamination. The chapter: "Ten years before [1902], it would have been impossible
    to find a sufficient number of representative and consistently active industrial
    stocks to make an average at all", and "when McKinley was re-elected it was
    necessary to include Western Union even in the railroad averages, for lack of a
    consistent degree of activity in a sufficient number of stocks" -- Western Union is
    a telegraph company, an OUT-OF-CLASS issue admitted only to fill the list.

    Per constituent, from the data you pass in:
      * REPRESENTATIVE -- it carries enough turnover to stand for the class it belongs
        to (`turnover_share`, its share of the total turnover of the candidate list,
        against `min_representative_share`);
      * CONSISTENTLY ACTIVE -- it traded in at least `min_traded_share` of the periods
        supplied, and the variability of its turnover across those periods is not more
        than `max_activity_cv` (coefficient of variation), i.e. a CONSISTENT degree of
        activity rather than occasional bursts;
      * IN CLASS -- the issue belongs to the class the average purports to measure
        (`in_class`, from the constituent's own flag). This is reported separately as
        `in_class` / `out_of_class`: an out-of-class issue may still be consistently
        active and representative of ITS OWN class, which is exactly why it gets
        admitted, and that admission is what the contamination flag records.

    The verdict is on the LIST, not on one issue: `qualified_count` against
    `required_size`, with `average_possible` True only when the list fills without
    admitting an out-of-class issue, and `contamination` flagged when an out-of-class
    issue has to be admitted to reach the required size.

    Extends `barometer_record_adequacy_gate` (ch1909, AND SOME DEFECTS OF HISTORY): that
    gate only counted stocks and years. This screen applies the PER-CONSTITUENT criteria
    (representative AND consistently active) and raises the contamination flag when an
    out-of-class issue must be included to fill the list.

    Do NOT use this to judge whether a RECORD is long enough or contemporaneous (call
    barometer_record_adequacy_gate) and do NOT use it to test whether a rebuilt average
    still reproduces the recorded one (call index_vintage_comparability_test).

    Args:
        constituents: list of dicts, one per candidate issue, each with
            {"name": str, "in_class": bool, "activity": [float, ...]} where activity is
            per-period turnover (shares traded, or sales), oldest period first.
            `in_class` may be omitted and defaults to True.
        required_size: number of issues the average must contain (the chapter's early
            industrial average used twelve).
        min_periods: periods of activity history a candidate must show.
        max_activity_cv: largest coefficient of variation of turnover that still counts
            as a CONSISTENT degree of activity.
        min_traded_share: share of periods in which an issue must have traded at all
            (activity > 0).
        min_representative_share: share of the candidate list's total turnover an issue
            must carry to be representative.
        verbose: False returns the verdict and the per-issue table; True adds the
            measured activity statistics.

    Returns:
        JSON {"result": {...}, "error": None, "metadata": {...}} with `classification`
        ("average_possible" / "average_possible_only_with_contamination" /
        "insufficient_qualified_issues" / "insufficient_data"), `qualified_count`,
        `contamination` and a short `reason`.
    """
    try:
        required_size = 12 if required_size is None else int(required_size)
        if required_size < 1:
            required_size = 1
        min_periods = 12 if min_periods is None else int(min_periods)
        if min_periods < 1:
            min_periods = 1
        max_activity_cv = 1.0 if max_activity_cv is None else float(max_activity_cv)
        if max_activity_cv < 0.0:
            max_activity_cv = 0.0
        min_traded_share = 0.9 if min_traded_share is None else float(min_traded_share)
        min_rep_share = 0.01 if min_representative_share is None else float(min_representative_share)

        rows_src = [c for c in (constituents or []) if isinstance(c, dict)]
        if not rows_src:
            result = {
                "classification": "insufficient_data",
                "average_possible": False,
                "contamination": False,
                "qualified_count": 0,
                "required_size": required_size,
                "reason": ("No candidate constituents were supplied, so nothing can be "
                           "screened and no average can be ruled on."),
                "constituents": [],
            }
            return json.dumps({
                "result": result,
                "error": None,
                "metadata": {
                    "provenance": {
                        "source_grounded": [
                            "a sufficient number of representative and consistently active stocks",
                        ],
                        "model_extrapolated": ["boundary reading on an empty candidate list"],
                    }
                },
            })

        totals: List[float] = []
        prepared = []
        for c in rows_src:
            activity = _clean(c.get("activity"))
            total = sum(activity)
            totals.append(total)
            prepared.append({
                "name": str(c.get("name", "")),
                "in_class": bool(c.get("in_class", True)),
                "activity": activity,
                "total": total,
            })

        grand_total = sum(totals)

        rows = []
        for item in prepared:
            act = item["activity"]
            periods = len(act)
            traded = sum(1 for v in act if v > 0.0)
            traded_share = traded / periods if periods else 0.0
            mean = _mean(act)
            std = _std(act)
            cv = (std / abs(mean)) if (mean not in (None, 0.0) and std is not None) else None
            share = (item["total"] / grand_total) if grand_total > 0.0 else 0.0

            enough_history = periods >= min_periods
            traded_often = traded_share >= min_traded_share
            consistent = cv is not None and cv <= max_activity_cv
            representative_class = bool(item["in_class"])
            representative_size = share >= min_rep_share

            active = enough_history and traded_often and consistent
            representative = representative_size
            qualified = active and representative

            fails: List[str] = []
            if not enough_history:
                fails.append("only " + str(periods) + " periods of activity against "
                             + str(min_periods) + " required")
            if not traded_often:
                fails.append("traded in only " + format(traded_share * 100.0, ".0f")
                             + "% of periods against " + format(min_traded_share * 100.0, ".0f")
                             + "% required")
            if not consistent:
                fails.append("activity is not consistent (coefficient of variation "
                             + ("unmeasured" if cv is None else format(cv, ".2f"))
                             + " against a limit of " + format(max_activity_cv, ".2f") + ")")
            if not representative_size:
                fails.append("carries only " + format(share * 100.0, ".2f")
                             + "% of the list's turnover against "
                             + format(min_rep_share * 100.0, ".2f") + "% required to be "
                             "representative")

            row = {
                "name": item["name"],
                "in_class": representative_class,
                "periods": periods,
                "traded_share": round(traded_share, 4),
                "activity_cv": _r(cv),
                "turnover_share": round(share, 6),
                "consistently_active": active,
                "representative": representative,
                "out_of_class": not representative_class,
                "qualified": qualified,
                "failures": fails,
            }
            rows.append(row)

        # Fill the list with qualified issues first, preferring in-class ones; an
        # out-of-class issue is admitted only to fill a list that would otherwise
        # fall short of the required size.
        rows.sort(key=lambda r: (not r["qualified"], not r["in_class"], -r["turnover_share"]))

        qualified = [r for r in rows if r["qualified"]]
        qualified_count = len(qualified)
        selected = qualified[:required_size]
        contamination = any(not r["in_class"] for r in selected)

        if qualified_count >= required_size and not contamination:
            classification = "average_possible"
            average_possible = True
            reason = (str(qualified_count) + " of " + str(len(rows))
                      + " candidates are both representative and consistently active, "
                      + str(required_size) + " or more, and the list fills entirely from "
                        "in-class issues: an average can be made of them.")
        elif qualified_count >= required_size and contamination:
            classification = "average_possible_only_with_contamination"
            average_possible = True
            out_names = [r["name"] for r in selected if not r["in_class"]]
            reason = (str(qualified_count) + " candidates qualify, enough to fill "
                      + str(required_size)
                      + ", but filling the list forces the admission of the out-of-class "
                      + (", ".join(out_names) if out_names else "issue(s)")
                      + ". This is the Western Union case: an issue admitted for want of a "
                        "consistent degree of activity in a sufficient number of stocks of "
                        "the right class, and a defect in the average.")
        elif qualified_count > 0:
            classification = "insufficient_qualified_issues"
            average_possible = False
            reason = ("Only " + str(qualified_count) + " of " + str(len(rows))
                      + " candidates are both representative and consistently active, "
                      "short of the " + str(required_size)
                      + " required: it would be impossible to make an average of them at "
                        "all.")
        else:
            classification = "insufficient_qualified_issues"
            average_possible = False
            reason = ("No candidate is both representative and consistently active, so "
                      "there is not a sufficient number to make an average at all.")

        result = {
            "classification": classification,
            "average_possible": average_possible,
            "contamination": contamination,
            "qualified_count": qualified_count,
            "candidates": len(rows),
            "required_size": required_size,
            "selected": [r["name"] for r in selected],
            "out_of_class_admitted": [r["name"] for r in selected if not r["in_class"]],
            "reason": reason,
            "constituents": rows,
            "min_periods": min_periods,
            "max_activity_cv": max_activity_cv,
            "min_traded_share": min_traded_share,
            "min_representative_share": min_rep_share,
        }

        if verbose:
            result["detail"] = {
                "turnover_totals": [round(v, 4) for v in totals],
                "total_turnover": round(grand_total, 4),
                "rule_quote": ("Ten years before, it would have been impossible to find a "
                               "sufficient number of representative and consistently "
                               "active industrial stocks to make an average at all ... "
                               "it was necessary to include Western Union even in the "
                               "railroad averages, for lack of a consistent degree of "
                               "activity in a sufficient number of stocks."),
            }

        return json.dumps({
            "result": result,
            "error": None,
            "metadata": {
                "provenance": {
                    "source_grounded": [
                        "a sufficient number of representative and consistently active industrial stocks to make an average at all",
                        "Western Union had to be included even in the railroad averages, for lack of a consistent degree of activity in a sufficient number of stocks",
                    ],
                    "model_extrapolated": [
                        "consistency of activity measured as coefficient of variation <= 1.0 of per-period turnover",
                        "activity must appear in >= 0.9 of the supplied periods",
                        "representativeness measured as >= 0.01 share of the candidate list's total turnover plus an in-class flag",
                        "required_size default of 12 (the chapter's early industrial average used twelve)",
                        "min_periods default of 12 periods of activity history",
                        "selection by qualification then turnover share; contamination flagged when an out-of-class issue enters the selected list",
                        "boundary reading on an empty candidate list",
                    ],
                }
            },
        })
    except Exception as exc:
        return json.dumps({
            "result": {
                "classification": "insufficient_data",
                "average_possible": False,
                "contamination": False,
                "qualified_count": 0,
                "reason": "Could not screen the candidates: " + str(exc),
            },
            "error": None,
            "metadata": {
                "provenance": {
                    "source_grounded": [
                        "a sufficient number of representative and consistently active stocks",
                    ],
                    "model_extrapolated": ["boundary reading on unusable input"],
                }
            },
        })