import json
from typing import Any, Dict, Optional


def _f(v: Any, default: Optional[float] = None) -> Optional[float]:
    try:
        if v is None:
            return default
        return float(v)
    except (TypeError, ValueError):
        return default


def _norm_trend(v: Any) -> str:
    s = str(v or "").strip().lower()
    if s in ("bull", "up", "rising", "rise", "advance"):
        return "bull"
    if s in ("bear", "down", "falling", "fall", "decline"):
        return "bear"
    if s in ("none", "flat", "line", " sideways", "sideways"):
        return "none"
    return s


async def crisis_position_within_primary_swing_classifier(
    crisis_label: str,
    crisis_year: float = None,
    primary_trend: str = "",
    swing_start_year: float = None,
    swing_end_year: float = None,
    decline_pct_before_crisis: float = None,
    min_foreshadow_decline_pct: float = 10.0,
    mid_swing_band_frac: float = 0.15,
    verbose: bool = True,
) -> str:
    """Classify a financial disturbance by where it falls inside the primary swing.

    Use when you have a dated crisis (a panic or a near-panic) and the dated
    primary swing it occurred in, and you want the chapter's distinction: a crisis
    occurring in the MIDDLE of a bull market (the Northern Pacific panic of 1901)
    versus a NEAR-PANIC of more serious and radical development occurring in the
    course of a major BEAR swing (1907). For a bear-swing near-panic the tool also
    applies the follow-on rule that a business depression follows which had
    already been foreshadowed in the downward market movement.

    Do NOT use this to attribute a crisis to its underlying CAUSE (bank
    suspensions, specie, crops, commodities) -- call crisis_type_classification
    (chCHARLES H. DOW, AND HIS THEORY) for that. This tool reads POSITION in the
    primary swing, not cause.
    """
    try:
        label = str(crisis_label or "")
        trend = _norm_trend(primary_trend)
        cy = _f(crisis_year)
        st = _f(swing_start_year)
        en = _f(swing_end_year)
        dec = _f(decline_pct_before_crisis)
        min_dec = 10.0 if min_foreshadow_decline_pct is None else float(min_foreshadow_decline_pct)
        band = 0.15 if mid_swing_band_frac is None else float(mid_swing_band_frac)
        band = min(max(band, 0.0), 0.49)

        span = None if (st is None or en is None) else (en - st)
        frac: Optional[float] = None
        if span is not None and span > 0.0 and cy is not None:
            frac = (cy - st) / span

        if frac is None:
            inside = False
            band_name = "undated"
        else:
            inside = bool(0.0 < frac < 1.0)
            if not inside:
                band_name = "before_swing" if frac <= 0.0 else "after_swing"
            elif frac < band:
                band_name = "early"
            elif frac > 1.0 - band:
                band_name = "late"
            else:
                band_name = "middle"

        serious: Optional[bool] = None
        radical: Optional[bool] = None
        foreshadowed: Optional[bool] = None
        crisis_type = "undated_disturbance"
        reason = ""

        if trend not in ("bull", "bear"):
            reason = ("primary trend is %r; the chapter's distinction is drawn only inside a bull "
                      "or a bear primary swing" % (trend if trend else "unspecified"))
        elif not inside:
            crisis_type = "outside_primary_swing"
            reason = ("the crisis does not fall inside the dated %s swing (position %s), so the "
                      "mid-bull / mid-bear distinction does not apply"
                      % (trend, band_name))
        elif trend == "bear":
            crisis_type = "near_panic_in_bear_swing"
            serious = True
            radical = True
            if dec is None:
                foreshadowed = True
                reason = ("a near-panic %s inside a major bear swing: the more serious and radical "
                          "development, and the downward market move already made has foreshadowed the "
                          "business depression which follows it"
                          % ("in the middle of the swing" if band_name == "middle"
                             else "in the %s part of the swing" % band_name))
            else:
                foreshadowed = bool(dec >= min_dec)
                if foreshadowed:
                    reason = ("a near-panic inside a major bear swing after a %.1f%% decline (>= %.1f%%): "
                              "the more serious and radical development, and the decline has already "
                              "foreshadowed the business depression which follows it" % (dec, min_dec))
                else:
                    reason = ("a near-panic inside a major bear swing, but the decline so far (%.1f%%) is "
                              "below the %.1f%% needed to say the business depression was already "
                              "foreshadowed in the market's movement" % (dec, min_dec))
        else:
            mid = band_name == "middle"
            crisis_type = "panic_in_bull_swing" if mid else "flank_panic_in_bull_swing"
            serious = False
            radical = False
            foreshadowed = False
            if mid:
                reason = ("a crisis in the middle of a bull market, like the Northern Pacific panic of "
                          "1901: a panic, not the more serious and radical near-panic of a major bear "
                          "swing, and no business depression is foreshadowed in the market's movement")
            else:
                reason = ("a crisis in the %s part of a bull swing rather than in its middle: still a "
                          "bull-market panic, not the radical near-panic of a bear swing" % band_name)

        claims = {
            "more_serious_than_bull_panic": serious,
            "radical_development": radical,
            "depression_foreshadowed": foreshadowed,
        }
        verdict = bool(serious is not None and radical is not None and foreshadowed is not None)

        result: Dict[str, Any] = {
            "crisis_label": label,
            "crisis_year": cy,
            "primary_trend": trend,
            "swing_start_year": st,
            "swing_end_year": en,
            "swing_span_years": span,
            "position_fraction": frac,
            "position_band": band_name,
            "inside_primary_swing": inside,
            "crisis_type": crisis_type,
            "more_serious_than_bull_panic": serious,
            "radical_development": radical,
            "depression_foreshadowed": foreshadowed,
            "decline_pct_before_crisis": dec,
            "min_foreshadow_decline_pct": min_dec,
            "mid_swing_band_frac": band,
            "claims_measured": claims,
            "positions_classified": verdict,
            "reason": reason,
        }
        if verbose:
            result["reference_cases"] = {
                "northern_pacific_1901": "panic_in_bull_swing",
                "panic_of_1907": "near_panic_in_bear_swing",
            }

        return json.dumps({
            "result": result,
            "error": None,
            "metadata": {"provenance": {
                "source_grounded": [
                    "a stock market crisis may occur in the middle of a bull market",
                    "Northern Pacific panic of 1901 as the mid-bull case",
                    "a near-panic may occur in the course of a major bear swing, as in 1907",
                    "the bear-swing case has a development more serious and radical",
                    "1907 was followed by a business depression already foreshadowed in the downward market movement",
                ],
                "model_extrapolated": [
                    "mid_swing_band_frac default 0.15 defining the 'middle' zone of a swing",
                    "min_foreshadow_decline_pct default 10.0 for a depression being foreshadowed",
                    "when no decline percentage is supplied the bear swing in progress is taken as the foreshadowing move",
                    'crises outside the swing span are reported as "outside_primary_swing", unclassified',
                ],
            }},
        })
    except Exception as exc:  # noqa: BLE001
        return json.dumps({
            "result": None,
            "error": "crisis_position_within_primary_swing_classifier failed: %s" % exc,
            "metadata": {"provenance": {
                "source_grounded": [],
                "model_extrapolated": ["error path"],
            }},
        })