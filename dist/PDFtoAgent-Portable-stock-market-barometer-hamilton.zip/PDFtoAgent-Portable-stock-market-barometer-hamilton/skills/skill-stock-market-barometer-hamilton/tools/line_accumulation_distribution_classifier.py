import json
import math
from typing import List, Optional


def _as_float(value, default: float) -> float:
    try:
        if value is None:
            return float(default)
        return float(value)
    except (TypeError, ValueError):
        return float(default)


def _clean(values) -> List[float]:
    out: List[float] = []
    for v in values or []:
        try:
            f = float(v)
        except (TypeError, ValueError):
            continue
        if math.isnan(f) or math.isinf(f):
            continue
        out.append(f)
    return out


async def line_accumulation_distribution_classifier(
    post_line_prices: Optional[List[float]] = None,
    line_low: Optional[float] = None,
    line_high: Optional[float] = None,
    preceding_primary_direction: str = "bear",
    preceding_swing_months: Optional[float] = None,
    supply_absorbed: Optional[bool] = None,
    min_resolution_points: float = 1.0,
    long_swing_months: float = 18.0,
    verbose: bool = True,
) -> str:
    """Classify a completed line as one of accumulation or one of distribution.

    Use when a Dow-theory line has formed and been resolved, and you must name which of
    the two kinds it was. The chapter makes the taxonomy exhaustive: "It can almost be
    set down as axiomatic for all our purposes that a line is and must necessarily be
    either one of accumulation or one of distribution. For a time the buying and selling
    power are in equilibrium." The label is settled by what followed the line: the 1914
    line "proved to have been one of distribution", the market having "become so
    saturated with stocks", whereas the chapter's counterfactual -- a bear market
    operative for nineteen, then twenty-two, months at unrepresentative low prices --
    would have made it "a line of accumulation, followed by the bull market which
    actually started in the ensuing December". Absorption versus saturation of the
    supply coming to market is therefore the reading the classification turns on.

    Extends: line_formation_breakout (chCYCLES AND STOCK MARKET RECORDS), which detects
    a line and classifies its resolution but never names it accumulation or
    distribution. This tool adds the exhaustive two-way label and its two conditioning
    inputs: the months elapsed in the preceding primary swing (19, then 22, in the
    chapter) and whether the supply was absorbed or saturated the market.

    Inputs: `post_line_prices`, the chronological path of the averages after the line
    ended; `line_low` / `line_high`, the boundaries of the line it broke out of;
    `preceding_primary_direction` ('bear' or 'bull'); `preceding_swing_months`, how long
    that primary swing had been operative (19 at the end of April 1914, 22 by July);
    and `supply_absorbed`, True if the supply coming to market was absorbed at bear
    market lows, False if it saturated the market (when omitted it is read from the
    break itself). `min_resolution_points` is how far out of the line the averages must
    travel before the resolution counts as decisive, and `long_swing_months` is how long
    a preceding swing must have run for the chapter's "fair conjecture" to apply.

    Do NOT use this to decide whether a line exists or to measure its dimensions --
    use line_formation_breakout or line_dimensions_measurement. Do NOT use it before
    the line has resolved: with no decisive move out of the band the tool returns only
    a conjecture, never a settled label.
    """
    try:
        series = _clean(post_line_prices)
        lo = _as_float(line_low, float("nan"))
        hi = _as_float(line_high, float("nan"))
        if math.isnan(lo) and series:
            lo = min(series)
        if math.isnan(hi) and series:
            hi = max(series)
        if math.isnan(lo):
            lo = 0.0
        if math.isnan(hi):
            hi = lo
        if hi < lo:
            lo, hi = hi, lo

        trend = str(preceding_primary_direction or "bear").strip().lower()
        is_bear = trend.startswith("bear") or trend in ("down", "decline")
        label = "bear" if is_bear else "bull"

        months = None
        try:
            if preceding_swing_months is not None:
                months = float(preceding_swing_months)
        except (TypeError, ValueError):
            months = None

        min_points = _as_float(min_resolution_points, 1.0)
        if min_points < 0.0:
            min_points = 0.0
        long_months = _as_float(long_swing_months, 18.0)

        absorbed_flag = None
        if supply_absorbed is not None:
            absorbed_flag = bool(supply_absorbed)

        def _respond(result):
            return json.dumps({
                "result": result,
                "error": None,
                "metadata": {
                    "tool": "line_accumulation_distribution_classifier",
                    "provenance": {
                        "source_grounded": [
                            "a line is necessarily either one of accumulation or one of distribution",
                            "buying and selling power are in equilibrium during a line",
                            "the label is settled by what follows the line",
                            "worked case: the 1914 line proved to be one of distribution",
                            "worked case: the market became saturated with stocks",
                            "bear market operative nineteen months at end of April, twenty-two months by July",
                            "fair conjecture of accumulation followed by a bull market starting in December",
                            "absorption of supply at unrepresentative bear market low prices",
                        ],
                        "model_extrapolated": [
                            "min_resolution_points default of 1 point for a decisive resolution",
                            "long_swing_months default of 18 months for the 'fair conjecture' of accumulation",
                            "supply_absorbed read from the direction of the break when not supplied",
                            "conjectured labels returned, never a settled one, while the resolution is indecisive",
                        ],
                    },
                },
            })

        if not series:
            return _respond({
                "preceding_primary_direction": label,
                "classification": "no_evidence",
                "is_accumulation": None,
                "is_distribution": None,
                "confidence": "unmeasurable",
                "resolution_direction": "none",
                "supply_reading": "absorbed" if absorbed_flag else ("saturated" if absorbed_flag is False else "unknown"),
                "reason": "no prices after the line were supplied, and the label of a line is settled by what follows it",
            })

        final_price = series[-1]
        extreme_high = max(series)
        extreme_low = min(series)

        if final_price > hi + min_points:
            resolution = "up"
        elif final_price < lo - min_points:
            resolution = "down"
        else:
            resolution = "none"

        if absorbed_flag is True:
            supply_reading = "absorbed"
        elif absorbed_flag is False:
            supply_reading = "saturated"
        elif resolution == "down":
            supply_reading = "saturated"
        elif resolution == "up":
            supply_reading = "absorbed"
        else:
            supply_reading = "unknown"

        if months is None:
            swing_reading = "unknown"
        elif months >= long_months:
            swing_reading = "long"
        else:
            swing_reading = "short"

        if resolution == "up":
            classification = "accumulation"
            confidence = "settled"
            reason = (
                "the averages closed at %.2f, %.2f points above the top of the line at %.2f, so the "
                "supply was absorbed and the line was one of accumulation"
                % (final_price, final_price - hi, hi)
            )
        elif resolution == "down":
            classification = "distribution"
            confidence = "settled"
            reason = (
                "the averages closed at %.2f, %.2f points below the bottom of the line at %.2f, so "
                "the supply saturated the market and the line was one of distribution"
                % (final_price, lo - final_price, lo)
            )
        elif supply_reading == "saturated":
            classification = "distribution_conjectured"
            confidence = "conjectured"
            reason = (
                "the averages have not yet moved more than %.2f points out of the band %.2f-%.2f, but "
                "the supply saturated the market, so the line is conjectured one of distribution; the "
                "label is settled only by what follows" % (min_points, lo, hi)
            )
        elif supply_reading == "absorbed":
            classification = "accumulation_conjectured"
            confidence = "conjectured"
            reason = (
                "the averages have not yet moved more than %.2f points out of the band %.2f-%.2f, but "
                "the supply was absorbed at low prices, so the line is conjectured one of "
                "accumulation; the label is settled only by what follows" % (min_points, lo, hi)
            )
        elif swing_reading == "long":
            classification = "accumulation_conjectured" if is_bear else "distribution_conjectured"
            confidence = "conjectured"
            if is_bear:
                reason = (
                    "the resolution is still indecisive inside the band %.2f-%.2f, but the preceding "
                    "bear market had been operative %.1f months, so there is fair conjecture that the "
                    "line is one of accumulation to be followed by a bull market"
                    % (lo, hi, months)
                )
            else:
                reason = (
                    "the resolution is still indecisive inside the band %.2f-%.2f, but the preceding "
                    "bull market had run %.1f months, so the conjecture favours a line of distribution"
                    % (lo, hi, months)
                )
        else:
            classification = "undetermined_pending_resolution"
            confidence = "unmeasurable"
            reason = (
                "the averages have not yet moved more than %.2f points out of the band %.2f-%.2f and "
                "neither the supply reading nor the length of the preceding swing is decisive, so the "
                "line cannot yet be named accumulation or distribution" % (min_points, lo, hi)
            )

        is_accumulation = classification.startswith("accumulation")
        is_distribution = classification.startswith("distribution")
        if classification == "undetermined_pending_resolution":
            is_accumulation = None
            is_distribution = None

        result = {
            "preceding_primary_direction": label,
            "preceding_swing_months": months,
            "swing_length_reading": swing_reading,
            "line_low": lo,
            "line_high": hi,
            "final_price": final_price,
            "post_line_extreme_high": extreme_high,
            "post_line_extreme_low": extreme_low,
            "resolution_points": (final_price - hi) if resolution == "up" else (
                (final_price - lo) if resolution == "down" else 0.0
            ),
            "resolution_direction": resolution,
            "supply_reading": supply_reading,
            "classification": classification,
            "confidence": confidence,
            "is_accumulation": is_accumulation,
            "is_distribution": is_distribution,
            "reason": reason,
        }

        if verbose:
            result["post_line_prices"] = series
            result["thresholds"] = {
                "min_resolution_points": min_points,
                "long_swing_months": long_months,
            }
            result["rule"] = (
                "a line is necessarily either one of accumulation or one of distribution; buying and "
                "selling power are in equilibrium while it lasts, and what follows the line settles "
                "which it was"
            )

        return _respond(result)
    except Exception as exc:  # pragma: no cover - defensive
        return json.dumps({
            "result": None,
            "error": str(exc),
            "metadata": {
                "tool": "line_accumulation_distribution_classifier",
                "provenance": {
                    "source_grounded": [
                        "a line is either one of accumulation or one of distribution",
                    ],
                    "model_extrapolated": ["min_resolution_points default"],
                },
            },
        })