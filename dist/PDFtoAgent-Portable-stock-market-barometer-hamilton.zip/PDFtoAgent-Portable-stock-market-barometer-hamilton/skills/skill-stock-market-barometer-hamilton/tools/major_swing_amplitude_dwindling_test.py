import json
from typing import Dict, List, Optional


async def major_swing_amplitude_dwindling_test(
    swings: Optional[List[Dict]] = None,
    dwindle_threshold: Optional[float] = None,
    severe_threshold: Optional[float] = None,
    verbose: bool = True,
) -> str:
    """Detect the "running-down pendulum" dwindling of successive major swings
    and read from it the business verdict: a dull level of trade, not depression.

    Use when you have the POINT extent of several successive major swings of the
    same kind (bull advances and/or bear declines), in the industrials and
    preferably also in the rails, and you want to test whether each swing is
    collapsing toward a fraction of the swing of the same kind that preceded it.
    The chapter's own readings: the bear market of 1909-10 was in BOTH averages
    barely half the extent of the panic-year bear of 1907, and the following bull
    market showed scarcely a third of the range of the 1907-09 bull.

    Extends: action_reaction_balance_falsification_test (chTHE UNPUNCTURED CYCLE)
    -- that tool only rejects the claim that action and reaction are EQUAL; this
    one names the failure shape (successive same-kind swings shrinking toward a
    half and a third) and maps it to a business verdict: a general dwindling
    movement forecasts a dull level of business -- slowing trade, with the
    improvement due to natural growth, but NOT amounting to depression.

    Do NOT use for: judging whether one swing is bullish or bearish, for the
    vigor of secondary movements inside a swing (use
    primary_swing_vigor_boom_vs_recovery_classifier), or for daily fluctuations.

    Args:
        swings: chronological list of dicts, each with "kind" ("bull" or "bear"),
            "extent_industrials" (points, positive), optional
            "extent_railroads", and optional "label" (e.g. "1909-1910 bear").
        dwindle_threshold: fraction of the preceding same-kind swing's extent
            below which the later swing counts as dwindling (default 0.5, the
            chapter's "barely half").
        severe_threshold: fraction below which the shrinkage counts as severe
            (default 0.3333, the chapter's "scarcely a third").
        verbose: False returns the compact verdict and the ratio rows only.

    Returns:
        JSON string with keys result/error/metadata.
    """
    try:
        rows = [r for r in (swings or []) if isinstance(r, dict)]
        dwindle_threshold = 0.5 if dwindle_threshold is None else float(dwindle_threshold)
        severe_threshold = 0.3333 if severe_threshold is None else float(severe_threshold)

        parsed = []
        for idx, row in enumerate(rows):
            kind = str(row.get("kind", "")).strip().lower()
            ext_i = abs(float(row.get("extent_industrials", 0.0) or 0.0))
            raw_r = row.get("extent_railroads", None)
            ext_r = None if raw_r is None else abs(float(raw_r))
            parsed.append({
                "index": idx,
                "kind": kind,
                "label": str(row.get("label", "") or "swing_%d" % idx),
                "extent_industrials": ext_i,
                "extent_railroads": ext_r,
            })

        by_kind: Dict[str, list] = {}
        for item in parsed:
            by_kind.setdefault(item["kind"], []).append(item)

        comparisons = []
        for kind in sorted(by_kind.keys()):
            series = by_kind[kind]
            for pos in range(1, len(series)):
                earlier = series[pos - 1]
                later = series[pos]
                ratio_i = None
                if earlier["extent_industrials"] > 0:
                    ratio_i = later["extent_industrials"] / earlier["extent_industrials"]
                ratio_r = None
                if (earlier["extent_railroads"] is not None
                        and later["extent_railroads"] is not None
                        and earlier["extent_railroads"] > 0):
                    ratio_r = later["extent_railroads"] / earlier["extent_railroads"]

                usable = [v for v in (ratio_i, ratio_r) if v is not None]
                if not usable:
                    dwindling = False
                    severe = False
                    basis = "unmeasurable_zero_prior_extent"
                else:
                    if ratio_r is None:
                        basis = "industrials_only"
                        dwindling = ratio_i is not None and max(usable) <= dwindle_threshold
                        severe = ratio_i is not None and max(usable) <= severe_threshold
                    else:
                        basis = "both_averages"
                        dwindling = max(usable) <= dwindle_threshold
                        severe = max(usable) <= severe_threshold

                comparisons.append({
                    "kind": kind,
                    "earlier_label": earlier["label"],
                    "later_label": later["label"],
                    "ratio_industrials": ratio_i,
                    "ratio_railroads": ratio_r,
                    "dwindling": dwindling,
                    "severe": severe,
                    "measurement_basis": basis,
                })

        dwindling_count = sum(1 for c in comparisons if c["dwindling"])
        severe_count = sum(1 for c in comparisons if c["severe"])
        total = len(comparisons)
        dwindling_share = (dwindling_count / total) if total else 0.0

        if total == 0:
            classification = "insufficient_history"
            reason = (
                "Fewer than two swings of the same kind were supplied, so no "
                "successive same-kind comparison can be made; the dwindling "
                "pendulum cannot be read from a single swing."
            )
        elif dwindling_count == 0:
            classification = "no_dwindling"
            reason = (
                "No successive swing of the same kind collapses to the dwindling "
                "fraction of its predecessor; the swing amplitudes are being "
                "maintained and the pendulum is not running down."
            )
        elif dwindling_count < total:
            classification = "partial_dwindling"
            reason = (
                "Some successive same-kind swings have collapsed toward the "
                "dwindling fraction while others hold their range: a general "
                "dwindling movement is developing but is not uniform."
            )
        else:
            classification = "running_down_pendulum_dull_business"
            reason = (
                "Every successive swing of the same kind is a fraction of the "
                "preceding one, as in a clock that is running down: the forecast "
                "is of a corresponding slowing up of activity in trade -- a dull "
                "level of business, not amounting to depression, and without "
                "enough stimulation for any large volume of speculation."
            )

        result = {
            "classification": classification,
            "reason": reason,
            "dwindling_detected": dwindling_count > 0,
            "dwindling_count": dwindling_count,
            "severe_count": severe_count,
            "comparison_count": total,
            "dwindling_share": dwindling_share,
            "comparisons": comparisons,
            "business_reading": (
                "dull_level_of_business_not_depression"
                if dwindling_count > 0 else "no_dullness_signal"
            ),
        }
        if verbose:
            result["dwindle_threshold"] = dwindle_threshold
            result["severe_threshold"] = severe_threshold
            result["swings"] = [
                {
                    "label": p["label"],
                    "kind": p["kind"],
                    "extent_industrials": p["extent_industrials"],
                    "extent_railroads": p["extent_railroads"],
                }
                for p in parsed
            ]
        else:
            result["comparisons"] = [
                {
                    "kind": c["kind"],
                    "later_label": c["later_label"],
                    "ratio_industrials": c["ratio_industrials"],
                    "ratio_railroads": c["ratio_railroads"],
                    "dwindling": c["dwindling"],
                }
                for c in comparisons
            ]

        return json.dumps({
            "result": result,
            "error": None,
            "metadata": {"provenance": {
                "source_grounded": [
                    "1909-10 bear barely half the extent of the 1907 panic bear, in both averages",
                    "following bull market scarcely a third of the range of the 1907-09 bull",
                    "general dwindling movement in these instructive years",
                    "verdict: slowing of trade, dull level of business, not depression",
                    "not strong enough to stimulate any large volume of speculation",
                ],
                "model_extrapolated": [
                    "dwindle_threshold default 0.5 (barely half)",
                    "severe_threshold default 0.3333 (scarcely a third)",
                    "comparison rule: max of the two averages' ratios must be at or below the threshold",
                    "labels partial_dwindling / insufficient_history for mixed and single-swing input",
                    "zero prior extent reported as unmeasurable rather than as a division error",
                ],
            }},
        })
    except Exception as exc:  # pragma: no cover - defensive
        return json.dumps({
            "result": None,
            "error": "major_swing_amplitude_dwindling_test failed: %s" % exc,
            "metadata": {"provenance": {
                "source_grounded": [],
                "model_extrapolated": ["defensive error wrapper"],
            }},
        })