import json
from typing import List, Optional


async def primary_overrun_crowding_detector(
    primary_trend: str,
    stock_loan_premium_pct: Optional[List[float]] = None,
    bull_side_crowding_pct: Optional[List[float]] = None,
    stock_loan_premium_now_pct: float = 0.0,
    bull_side_crowding_now_pct: float = 0.0,
    loan_premium_threshold_pct: float = 0.0,
    crowding_threshold_pct: float = 60.0,
    persistence_periods: int = 3,
    verbose: bool = True,
) -> str:
    """Detect that a primary bull or bear market has overrun itself from crowding measures -- too much company on the bull side, or the loan crowd charging a premium (backwardation) to lend stock to shorts -- and name the side the professional should take.

    Use when you have crowding data for a market already in a primary move: the
    stock-loan premium (a premium charged for lending stock is a backwardation,
    and shows too many shorts are borrowing), and/or a measure of how much
    company there is on the bull side. The chapter's rule is that every primary
    market, bull or bear, tends to overrun itself, and that this is the
    professional's chance: he buys in a market which is oversold, or with
    testing sales tries out the strength of a market which has been bought not
    wisely but too well.

    Do NOT use this to classify which Dow movement a move belongs to (call
    manipulation_scope_by_movement_classifier), and do NOT use it to price or
    cost a trade (call round_trip_friction_quick_turn_test).

    Args:
        primary_trend: "bull" or "bear" -- the primary movement now in force.
        stock_loan_premium_pct: series of the premium charged to lend stock, per
            cent, oldest first. Values above zero mean backwardation.
        bull_side_crowding_pct: series measuring how much company is on the bull
            side, in per cent (e.g. share of advisory opinion or of margin
            accounts long), oldest first.
        stock_loan_premium_now_pct: single current reading of the loan premium
            (used when no series is supplied).
        bull_side_crowding_now_pct: single current reading of bull-side company
            (used when no series is supplied).
        loan_premium_threshold_pct: premium, per cent, at or above which the
            loan crowd counts as charging a premium (default 0.0 = any premium
            at all, since normally stock lends flat).
        crowding_threshold_pct: bull-side company, per cent, at or above which
            there is "too much company on the bull side" (default 60.0).
        persistence_periods: how many trailing periods the crowding must persist
            for before it counts as an overrun (default 3).
        verbose: False returns the compact ruling; True adds the full breakdown.

    Returns:
        JSON string with result/error/metadata. Result holds overrun_detected,
        crowded_side, the professional's side ("buy" or "testing_sales"), and a
        short reason.
    """
    try:
        trend = (primary_trend or "").strip().lower()
        if trend not in ("bull", "bear"):
            trend = "unknown"

        window = (
            int(persistence_periods)
            if persistence_periods is not None and int(persistence_periods) > 0
            else 1
        )
        premium_thr = (
            float(loan_premium_threshold_pct) if loan_premium_threshold_pct is not None else 0.0
        )
        crowd_thr = (
            float(crowding_threshold_pct) if crowding_threshold_pct is not None else 60.0
        )

        def _tail(values: Optional[List[float]], fallback: float) -> List[float]:
            if values:
                return [float(v) for v in values if v is not None]
            if fallback is None:
                return []
            return [float(fallback)]

        loan = _tail(stock_loan_premium_pct, stock_loan_premium_now_pct)
        bull = _tail(bull_side_crowding_pct, bull_side_crowding_now_pct)

        loan_used = loan[-window:] if loan else []
        bull_used = bull[-window:] if bull else []

        loan_now = loan[-1] if loan else None
        bull_now = bull[-1] if bull else None

        loan_persist = len(loan_used) >= window and all(
            v >= premium_thr for v in loan_used
        )
        loan_partial = bool(loan_used) and (loan_now is not None and loan_now >= premium_thr)
        bull_persist = len(bull_used) >= window and all(v >= crowd_thr for v in bull_used)
        bull_partial = bool(bull_used) and (bull_now is not None and bull_now >= crowd_thr)

        bear_crowded = loan_persist
        bull_crowded = bull_persist

        if bear_crowded and bull_crowded:
            crowded_side = "both"
        elif bear_crowded:
            crowded_side = "bear"
        elif bull_crowded:
            crowded_side = "bull"
        else:
            crowded_side = "none"

        overrun = bear_crowded or bull_crowded

        if bear_crowded and not bull_crowded:
            professional_side = "buy"
            reason = (
                "The loan crowd is charging a premium of %.4f%% to lend stock "
                "(backwardation): too many shorts are borrowing. The market is "
                "oversold -- this is the professional's chance to buy."
                % (loan_now if loan_now is not None else 0.0)
            )
        elif bull_crowded and not bear_crowded:
            professional_side = "testing_sales"
            reason = (
                "There is too much company on the bull side (%.4f%% over %d "
                "periods): the market has been bought not wisely but too well. "
                "The professional tries out its strength with testing sales."
                % (bull_now if bull_now is not None else 0.0, window)
            )
        elif bull_crowded and bear_crowded:
            professional_side = "stand_aside"
            reason = (
                "Both sides are crowded -- a premium to lend stock alongside too "
                "much company on the bull side. Wait for one side to resolve "
                "before taking the professional's position."
            )
        elif loan_partial or bull_partial:
            professional_side = "wait_for_persistence"
            reason = (
                "Crowding is present but has not persisted for %d period(s): the "
                "chapter's overrun is a tendency that builds up, not a one-day "
                "reading." % window
            )
        else:
            professional_side = "none"
            reason = (
                "No crowding measure is at its threshold: no evidence yet that the "
                "primary %s market has overrun itself." % trend
            )

        result = {
            "primary_trend": trend,
            "overrun_detected": overrun,
            "crowded_side": crowded_side,
            "professional_side": professional_side,
        }
        if verbose:
            result["stock_loan_premium_now_pct"] = loan_now
            result["stock_loan_premium_threshold_pct"] = premium_thr
            result["loan_premium_persisting"] = bear_crowded
            result["bull_side_crowding_now_pct"] = bull_now
            result["bull_side_crowding_threshold_pct"] = crowd_thr
            result["bull_crowding_persisting"] = bull_crowded
            result["persistence_periods"] = window
            result["periods_supplied"] = max(len(loan), len(bull))
            result["reason"] = reason
        return json.dumps(
            {
                "result": result,
                "error": None,
                "metadata": {
                    "provenance": {
                        "source_grounded": [
                            "every primary market, bull or bear, tends to overrun itself",
                            "too much company on the bull side",
                            "the loan crowd shows too many shorts are borrowing stocks",
                            "a premium for lending stock corresponds to backwardation",
                            "professional buys an oversold market, tests overbought strength with sales",
                        ],
                        "model_extrapolated": [
                            "loan premium threshold of 0.0% (any premium is backwardation)",
                            "bull-side crowding threshold of 60.0%",
                            "persistence window of 3 periods",
                            "stand_aside and wait_for_persistence readings for the intermediate cases",
                        ],
                    }
                },
            }
        )
    except Exception as exc:
        return json.dumps(
            {
                "result": None,
                "error": str(exc),
                "metadata": {
                    "provenance": {
                        "source_grounded": [
                            "every primary market, bull or bear, tends to overrun itself",
                            "a premium for lending stock corresponds to backwardation",
                        ],
                        "model_extrapolated": [
                            "loan premium threshold of 0.0%",
                            "bull-side crowding threshold of 60.0%",
                        ],
                    }
                },
            }
        )