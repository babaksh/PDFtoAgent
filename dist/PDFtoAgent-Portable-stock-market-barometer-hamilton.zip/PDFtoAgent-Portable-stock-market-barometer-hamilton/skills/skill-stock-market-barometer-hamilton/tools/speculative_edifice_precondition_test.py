import json
import math
from typing import List, Optional


def _median(vals: List[float]) -> float:
    if not vals:
        return 0.0
    s = sorted(vals)
    n = len(s)
    mid = n // 2
    if n % 2 == 1:
        return s[mid]
    return 0.5 * (s[mid - 1] + s[mid])


_PROVENANCE = {
    "source_grounded": [
        "a smash cannot be brought about unless an edifice of speculation is built high enough to make a noise when it topples",
        "the volume of speculative business must be large enough to make a crisis in the anticipated year",
        "no reason for a crisis in 1903 or 1913 because the speculative volume was not large enough",
    ],
    "model_extrapolated": [
        "build_multiple_required default 1.5 (the chapter gives no number for 'high enough')",
        "lookback_years default 5.0 for the build-up window ahead of the date",
        "baseline taken as the median of observations outside the build-up window",
        "peak of the window used as the height of the edifice",
        "insufficient_record reading when no volume is supplied",
    ],
}


def _meta() -> dict:
    return {"provenance": _PROVENANCE}


async def speculative_edifice_precondition_test(
    speculative_volume: List[float],
    volume_years: Optional[List[float]] = None,
    target_year: Optional[float] = None,
    lookback_years: float = 5.0,
    build_multiple_required: float = 1.5,
    baseline_volume: Optional[float] = None,
    verbose: bool = True,
) -> str:
    """Check the precondition the chapter requires before any crisis can occur.

    Use when a cycle theory, a forecaster or a letter prophesies a crisis in a
    particular year and you have a series of the volume of speculative business
    (trading volume, new issues, speculative activity) ahead of that date. The
    chapter's rule is that a smash cannot be brought about unless an edifice of
    speculation has been constructed high enough to make a noise when it topples,
    so the tool measures how high the edifice was built in the window running up to
    the anticipated date, against the normal level of speculative business, and
    rules whether a crisis in that year was even possible.

    Do NOT use to measure or forecast the interval between panics -- call
    panic_interval_rule (chCYCLES AND STOCK MARKET RECORDS) or
    claimed_cycle_period_falsification_test (chTHE UNPUNCTURED CYCLE) instead;
    they date crises, this one tests whether the fuel for one existed.
    """
    try:
        vals: List[float] = []
        for v in speculative_volume or []:
            if v is None:
                continue
            vals.append(float(v))

        n = len(vals)
        if volume_years and len(volume_years) == n:
            years = [float(y) for y in volume_years]
        else:
            years = [float(i) for i in range(n)]

        lookback = 5.0 if lookback_years is None else float(lookback_years)
        required = 1.5 if build_multiple_required is None else float(build_multiple_required)

        pairs = sorted(zip(years, vals))
        years = [p[0] for p in pairs]
        vals = [p[1] for p in pairs]

        target = None if target_year is None else float(target_year)
        if target is None:
            target = years[-1] if years else 0.0

        lo = target - lookback
        window_idx = [i for i, y in enumerate(years) if lo <= y <= target]
        if not window_idx:
            window_idx = [i for i, y in enumerate(years) if y <= target]
        outside_idx = [i for i in range(n) if i not in window_idx]

        if baseline_volume is None:
            base = _median([vals[i] for i in outside_idx]) if outside_idx else _median(vals)
        else:
            base = float(baseline_volume)

        window_vals = [vals[i] for i in window_idx]
        peak = max(window_vals) if window_vals else 0.0
        window_start = window_vals[0] if window_vals else 0.0

        build_multiple = peak / base if base else 0.0
        edifice_height_above_baseline = peak - base
        build_up_rise_pct = ((peak - window_start) / window_start * 100.0) if window_start else 0.0

        edifice_sufficient = bool(n > 0 and build_multiple >= required)

        if n == 0:
            verdict = "insufficient_record"
            reason = "no speculative volume supplied, so the precondition cannot be judged"
        elif edifice_sufficient:
            verdict = "edifice_sufficient"
            reason = (
                "speculative volume reached %.2fx the normal level (%.2fx required) in the "
                "%g years to %g -> an edifice was built high enough to topple noisily"
                % (build_multiple, required, lookback, target)
            )
        else:
            verdict = "edifice_too_low"
            reason = (
                "speculative volume reached only %.2fx the normal level (%.2fx required) in "
                "the %g years to %g -> no edifice of speculation, so no smash was possible "
                "in that year" % (build_multiple, required, lookback, target)
            )

        payload = {
            "target_year": target,
            "lookback_years": lookback,
            "n_observations": n,
            "window_observations": len(window_idx),
            "baseline_volume": base,
            "peak_volume_in_window": peak,
            "edifice_height_above_baseline": edifice_height_above_baseline,
            "build_multiple": build_multiple,
            "build_multiple_required": required,
            "build_up_rise_pct": build_up_rise_pct,
            "edifice_sufficient": edifice_sufficient,
            "crisis_possible": edifice_sufficient,
            "verdict": verdict,
            "window_years": [years[i] for i in window_idx],
            "window_volumes": window_vals,
            "reason": reason,
        }
        if not verbose:
            payload = {
                k: payload[k]
                for k in (
                    "target_year",
                    "lookback_years",
                    "n_observations",
                    "window_observations",
                    "baseline_volume",
                    "peak_volume_in_window",
                    "edifice_height_above_baseline",
                    "build_multiple",
                    "build_multiple_required",
                    "edifice_sufficient",
                    "crisis_possible",
                    "verdict",
                )
            }
        return json.dumps({"result": payload, "error": None, "metadata": _meta()})
    except Exception as exc:  # noqa: BLE001 - contract requires a reading, never a raise
        return json.dumps(
            {
                "result": {"verdict": "indeterminate", "crisis_possible": False, "reason": str(exc)},
                "error": None,
                "metadata": _meta(),
            }
        )