import json
from typing import List, Optional


def _turning_points(values: List[float], swing_window: int) -> List[dict]:
    """Pivot turning points: index i is a top (bottom) when its value is at least
    as extreme as everything to its left within `swing_window` observations and
    strictly more extreme than everything to its right. A turn is only confirmed
    once there are observations on BOTH sides of it, so the first and last
    `swing_window` observations can never be turns. Plateaus yield no turn."""
    pts = []
    n = len(values)
    w = int(swing_window)
    if w < 1:
        w = 1
    if n < 3:
        return pts
    if n < 2 * w + 1:
        w = (n - 1) // 2
        if w < 1:
            return pts
    for i in range(w, n - w):
        lo = max(0, i - w)
        hi = min(n - 1, i + w)
        v = values[i]
        left = values[lo:i]
        right = values[i + 1 : hi + 1]
        if left and right:
            if v >= max(left) and v > max(right):
                pts.append({"index": i, "kind": "top", "value": v})
            elif v <= min(left) and v < min(right):
                pts.append({"index": i, "kind": "bottom", "value": v})
    return pts


async def harvard_three_line_lead_order_test(
    speculation: List[float],
    business: List[float],
    banking: List[float],
    periods: Optional[List[float]] = None,
    swing_window: Optional[int] = None,
    min_lead: Optional[float] = None,
    max_violation_share: Optional[float] = None,
    verbose: bool = True,
) -> str:
    """Run the Harvard three-line lead-order test: does a line of speculation
    UNIFORMLY precede both a line of business and a line of banking, and by how
    much?

    Use when you have the three index lines of the Harvard Committee on Economic
    Research -- speculation (the average stock market prices), business and
    banking -- over a common record, and you want to reproduce the chapter's
    finding: "Its line of speculation, during those twelve years, uniformly
    precedes the lines of business and banking."

    How it decides:
      1. Turning points (tops and bottoms) are located on all three lines by the
         same pivot rule: index i is a turn when it is at least as extreme as
         everything within `swing_window` observations on its left and strictly
         more extreme than everything within that window on its right.
      2. Every turning point on the business line and on the banking line is
         matched to the LAST speculation turning point of the SAME KIND (top to
         top, bottom to bottom) that occurred at or before it.
      3. A match counts as a lead only when the speculation turn is strictly
         earlier and at least `min_lead` periods earlier. A turn of a kind the
         speculation line has not yet made is a violation.
      4. The verdict is positive only when BOTH lines have turning points and the
         violation share across all turns is at or below `max_violation_share` --
         the default of zero is what makes the test "uniformly" rather than
         "on average".

    Extends: `stock_market_lead_time_over_business_record`
    (ch "A UNIQUE QUALITY OF FORECAST"). That tool measures how far market
    primary swings led dated business areas on average. This one adds the banking
    line as a second series the speculation line must lead, and tightens the
    criterion from an average share to a uniform one over every turning point.

    Do NOT use it with only two lines (use the earlier tool), and do NOT use it
    when the three series are not on a common time base -- matching is by
    position in the record.

    Args:
        speculation: The line of speculation (average stock market prices).
        business: The line of business.
        banking: The line of banking.
        periods: Decimal date (or period number) of each observation, shared by
            all three lines. Defaults to 0,1,2,... so leads are in observations.
        swing_window: Half-width, in observations, of the pivot window used to
            confirm a turning point (default 2, i.e. a five-observation window).
        min_lead: Minimum lead in period units required for a turn to count as
            led (default 1.0 period, so a simultaneous turn is not a lead).
        max_violation_share: Largest share of turning points that may fail the
            lead test and still let the verdict stand (default 0.0 = uniform).
        verbose: False returns the compact verdict and per-line stats; True adds
            the turning points and every individual match.

    Returns:
        JSON string {"result": {...}, "error": ..., "metadata": {...}} where
        result.classification is "speculation_leads_uniformly" or
        "speculation_does_not_lead_uniformly".
    """
    try:
        w = 2 if swing_window is None else int(swing_window)
        if w < 1:
            w = 1
        min_lead = 1.0 if min_lead is None else float(min_lead)
        max_violation_share = (
            0.0 if max_violation_share is None else float(max_violation_share)
        )
        if max_violation_share < 0:
            max_violation_share = 0.0
        if max_violation_share > 1:
            max_violation_share = 1.0

        spec = [float(v) for v in (speculation or []) if v is not None]
        bus = [float(v) for v in (business or []) if v is not None]
        bank = [float(v) for v in (banking or []) if v is not None]

        if periods is None:
            n_max = max(len(spec), len(bus), len(bank))
            per = [float(i) for i in range(n_max)]
        else:
            per = [float(p) for p in periods if p is not None]

        def period_at(i: int) -> float:
            return per[i] if 0 <= i < len(per) else float(i)

        spec_pts = _turning_points(spec, w)
        bus_pts = _turning_points(bus, w)
        bank_pts = _turning_points(bank, w)

        def match_line(target_pts: List[dict], label: str) -> dict:
            rows = []
            led = 0
            leads = []
            for tp in target_pts:
                best = None
                for sp in spec_pts:
                    if sp["kind"] != tp["kind"]:
                        continue
                    if sp["index"] > tp["index"]:
                        continue
                    if best is None or sp["index"] > best["index"]:
                        best = sp
                if best is None:
                    rows.append(
                        {
                            "line": label,
                            "target_index": tp["index"],
                            "target_period": period_at(tp["index"]),
                            "kind": tp["kind"],
                            "speculation_index": None,
                            "speculation_period": None,
                            "lead": None,
                            "led": False,
                        }
                    )
                    continue
                lead = period_at(tp["index"]) - period_at(best["index"])
                ok = bool(lead >= min_lead)
                if ok:
                    led += 1
                    leads.append(lead)
                rows.append(
                    {
                        "line": label,
                        "target_index": tp["index"],
                        "target_period": period_at(tp["index"]),
                        "kind": tp["kind"],
                        "speculation_index": best["index"],
                        "speculation_period": period_at(best["index"]),
                        "lead": lead,
                        "led": ok,
                    }
                )
            total = len(target_pts)
            return {
                "label": label,
                "turning_points": total,
                "led_turning_points": led,
                "lead_share": (led / total) if total else 0.0,
                "mean_lead": (sum(leads) / len(leads)) if leads else 0.0,
                "min_lead_observed": min(leads) if leads else None,
                "max_lead_observed": max(leads) if leads else None,
                "rows": rows,
            }

        bus_line = match_line(bus_pts, "business")
        bank_line = match_line(bank_pts, "banking")

        total_turns = bus_line["turning_points"] + bank_line["turning_points"]
        total_led = bus_line["led_turning_points"] + bank_line["led_turning_points"]
        violations = total_turns - total_led
        violation_share = (violations / total_turns) if total_turns else 0.0

        both_lines_have_turns = bool(
            bus_line["turning_points"] > 0 and bank_line["turning_points"] > 0
        )
        uniform = bool(
            total_turns > 0
            and both_lines_have_turns
            and violation_share <= max_violation_share
        )
        classification = (
            "speculation_leads_uniformly"
            if uniform
            else "speculation_does_not_lead_uniformly"
        )

        if total_turns == 0:
            reason = (
                "No turning points were confirmed on the business or banking line "
                "with a pivot window of %d observations, so no lead can be measured."
                % w
            )
        elif not both_lines_have_turns:
            reason = (
                "Turning points were confirmed on only one of the two lines "
                "(business %d, banking %d); the test requires both lines to be led."
                % (bus_line["turning_points"], bank_line["turning_points"])
            )
        elif uniform:
            reason = (
                "Speculation preceded all %d turning points on the business and "
                "banking lines, a violation share of %.3f within the %.3f allowance: "
                "it leads business by %.3f and banking by %.3f periods on average."
                % (
                    total_led,
                    violation_share,
                    max_violation_share,
                    bus_line["mean_lead"],
                    bank_line["mean_lead"],
                )
            )
        else:
            reason = (
                "Speculation preceded only %d of %d turning points, a violation "
                "share of %.3f above the %.3f allowance, so the lead is not uniform."
                % (total_led, total_turns, violation_share, max_violation_share)
            )

        result = {
            "classification": classification,
            "reason": reason,
            "speculation_leads_uniformly": uniform,
            "total_turning_points": total_turns,
            "led_turning_points": total_led,
            "violations": violations,
            "violation_share": violation_share,
            "max_violation_share": max_violation_share,
            "lead_over_business": bus_line["mean_lead"],
            "lead_over_banking": bank_line["mean_lead"],
            "speculation_turning_points": len(spec_pts),
            "business": {
                "turning_points": bus_line["turning_points"],
                "led_turning_points": bus_line["led_turning_points"],
                "lead_share": bus_line["lead_share"],
                "mean_lead": bus_line["mean_lead"],
                "min_lead_observed": bus_line["min_lead_observed"],
                "max_lead_observed": bus_line["max_lead_observed"],
            },
            "banking": {
                "turning_points": bank_line["turning_points"],
                "led_turning_points": bank_line["led_turning_points"],
                "lead_share": bank_line["lead_share"],
                "mean_lead": bank_line["mean_lead"],
                "min_lead_observed": bank_line["min_lead_observed"],
                "max_lead_observed": bank_line["max_lead_observed"],
            },
        }

        if verbose:
            result["matches"] = bus_line["rows"] + bank_line["rows"]
            result["speculation_turns"] = [
                {
                    "index": p["index"],
                    "period": period_at(p["index"]),
                    "kind": p["kind"],
                    "value": p["value"],
                }
                for p in spec_pts
            ]
            result["params"] = {
                "swing_window": w,
                "min_lead": min_lead,
                "max_violation_share": max_violation_share,
                "observations": {
                    "speculation": len(spec),
                    "business": len(bus),
                    "banking": len(bank),
                },
            }

        return json.dumps(
            {
                "result": result,
                "error": None,
                "metadata": {
                    "provenance": {
                        "source_grounded": [
                            "three lines: speculation, business, banking",
                            "speculation line is the average stock market prices",
                            "speculation precedes both business and banking",
                            "the lead must hold uniformly over the record",
                            "record window 1903 to 1914 inclusive",
                        ],
                        "model_extrapolated": [
                            "turning points located by a centred pivot window of 2 observations",
                            "matching of same-kind turns (top to top, bottom to bottom)",
                            "matching to the last speculation turn at or before the target turn",
                            "uniform criterion implemented as zero violations allowed",
                            "minimum lead of one period, so a simultaneous turn is not a lead",
                            "leads measured in the caller's period units, default one per observation",
                        ],
                    }
                },
            }
        )
    except Exception as exc:  # pragma: no cover - defensive
        return json.dumps(
            {
                "result": None,
                "error": str(exc),
                "metadata": {
                    "provenance": {"source_grounded": [], "model_extrapolated": []}
                },
            }
        )