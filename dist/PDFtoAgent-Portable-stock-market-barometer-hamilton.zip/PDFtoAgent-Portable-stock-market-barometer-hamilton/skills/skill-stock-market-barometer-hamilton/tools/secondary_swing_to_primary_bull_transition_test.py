import json
import math
from typing import List, Optional


def _as_float(value, default: float) -> float:
    try:
        if value is None:
            return float(default)
        return float(value)
    except (TypeError, ValueError):
        return float(default)


def _clean(values) -> List[float]:
    out: List[float] = []
    for v in values or []:
        try:
            f = float(v)
        except (TypeError, ValueError):
            continue
        if math.isnan(f) or math.isinf(f):
            continue
        out.append(f)
    return out


async def secondary_swing_to_primary_bull_transition_test(
    prices: Optional[List[float]] = None,
    old_low: Optional[float] = None,
    rally_high: Optional[float] = None,
    rally_high_index: Optional[int] = None,
    old_low_tolerance_pct: float = 1.0,
    min_new_high_points: float = 0.0,
    verbose: bool = True,
) -> str:
    """Decide whether a secondary swing inside a primary bear market has become a new primary bull market.

    Use when a primary bear market is still in force and you must decide whether the
    latest upward secondary swing is only a reaction or the start of a new primary bull
    market. The chapter's test has two parts, both of which must hold: the secondary
    swing "does not decline to the old low figures", and it "subsequently recovers to
    points better than the new high established on the earlier rally". When both hold,
    "we may assume with confidence that a primary bull market of indefinite length has
    been established" -- and the chapter adds explicitly that the barometer cannot
    predict the DURATION of the movement, so the tool never returns a duration forecast.

    Extends: bull_bear_higher_high_lower_low_test (chDOW'S THEORY, APPLIED TO
    SPECULATION), which classifies bull or bear from higher highs and lower lows in
    general. This tool runs the test INSIDE a still-operating primary bear market: it
    requires BOTH the failure to decline to the old low AND a subsequent recovery above
    the earlier rally's new high (the "succession of zig-zag steps"), and it declares a
    bull market of indefinite, explicitly unpredictable duration.

    Inputs: `prices`, the chronological path of the average through the earlier rally,
    the reaction and the subsequent recovery; `old_low`, the low figure of the primary
    bear market; `rally_high`, the new high established on the earlier rally; optionally
    `rally_high_index` (where in `prices` that high was made -- if omitted the highest
    price in the series is used). `old_low_tolerance_pct` is how far above the old low
    the reaction must hold to count as "did not decline to the old low figures";
    `min_new_high_points` is how far the recovery must better the earlier rally high.

    Do NOT use this to classify a market that is already established as bull or bear --
    use bull_bear_higher_high_lower_low_test. Do NOT use it to rule on a secondary
    decline that is still in progress; there must be a subsequent recovery in `prices`.
    """
    try:
        series = _clean(prices)
        tol_pct = _as_float(old_low_tolerance_pct, 1.0)
        if tol_pct < 0.0:
            tol_pct = 0.0
        min_points = _as_float(min_new_high_points, 0.0)

        def _respond(result):
            return json.dumps({
                "result": result,
                "error": None,
                "metadata": {
                    "tool": "secondary_swing_to_primary_bull_transition_test",
                    "provenance": {
                        "source_grounded": [
                            "reaction must not decline to the old low figures",
                            "recovery must better the new high established on the earlier rally",
                            "both conditions together establish a primary bull market",
                            "primary bull market is of indefinite length",
                            "duration of the movement is unpredictable by the barometer",
                            "result read as a succession of zig-zag steps in the averages",
                        ],
                        "model_extrapolated": [
                            "old_low_tolerance_pct default of 1 percent for 'did not decline to the old low'",
                            "min_new_high_points default of 0 points for 'points better than' the rally high",
                            "rally_high defaults to the maximum price of the series when not supplied",
                            "old_low defaults to the minimum price of the series when not supplied",
                        ],
                    },
                },
            })

        if not series:
            return _respond({
                "direction": "bull",
                "classification": "no_evidence",
                "transition_confirmed": False,
                "held_above_old_low": None,
                "bettered_earlier_rally_high": None,
                "duration": None,
                "duration_predictable": False,
                "reason": "no prices were supplied, so neither the reaction nor the recovery can be measured",
            })

        n = len(series)

        if rally_high_index is None:
            rally_index = series.index(max(series))
        else:
            try:
                rally_index = int(rally_high_index)
            except (TypeError, ValueError):
                rally_index = series.index(max(series))
        rally_index = max(0, min(rally_index, n - 1))

        old_low_value = _as_float(old_low, min(series))
        rally_high_value = _as_float(rally_high, max(series))

        reaction_segment = series[rally_index + 1:]
        reaction_low = None
        reaction_low_index = None
        if reaction_segment:
            reaction_low = min(reaction_segment)
            reaction_low_index = rally_index + 1 + reaction_segment.index(reaction_low)

        recovery_high = None
        recovery_high_index = None
        if reaction_low_index is not None:
            recovery_segment = series[reaction_low_index + 1:]
            if recovery_segment:
                recovery_high = max(recovery_segment)
                recovery_high_index = reaction_low_index + 1 + recovery_segment.index(recovery_high)

        required_margin = abs(old_low_value) * tol_pct / 100.0

        if reaction_low is None:
            decline_reading = "unmeasured"
            held_above_old_low = None
            old_low_margin_points = None
        else:
            old_low_margin_points = reaction_low - old_low_value
            if old_low_margin_points > required_margin:
                decline_reading = "held_above_old_low"
                held_above_old_low = True
            elif old_low_margin_points < 0.0:
                decline_reading = "declined_below_old_low"
                held_above_old_low = False
            else:
                decline_reading = "declined_to_old_low"
                held_above_old_low = False

        if recovery_high is None:
            recovery_reading = "unmeasured"
            bettered_earlier_rally_high = None
            new_high_margin_points = None
        else:
            new_high_margin_points = recovery_high - rally_high_value
            if new_high_margin_points > min_points:
                recovery_reading = "bettered_earlier_rally_high"
                bettered_earlier_rally_high = True
            elif new_high_margin_points < 0.0:
                recovery_reading = "below_earlier_rally_high"
                bettered_earlier_rally_high = False
            else:
                recovery_reading = "matched_earlier_rally_high"
                bettered_earlier_rally_high = False

        if held_above_old_low is None or bettered_earlier_rally_high is None:
            confirmed = False
            classification = "undetermined"
            reason = (
                "the test cannot be completed: the reaction after the rally high (index %d) "
                "or the recovery after it is missing from the record supplied" % rally_index
            )
        elif held_above_old_low and bettered_earlier_rally_high:
            confirmed = True
            classification = "primary_bull_market_established"
            reason = (
                "the reaction low of %.2f held %.2f points above the old low of %.2f (tolerance "
                "%.2f points) and the subsequent recovery to %.2f bettered the earlier rally high "
                "of %.2f by %.2f points, so the succession of zig-zag steps establishes a primary "
                "bull market of indefinite length"
                % (
                    reaction_low, old_low_margin_points, old_low_value, required_margin,
                    recovery_high, rally_high_value, new_high_margin_points,
                )
            )
        elif not held_above_old_low:
            confirmed = False
            classification = "still_primary_bear_market"
            reason = (
                "the reaction fell back to %.2f, only %.2f points above the old bear-market low of "
                "%.2f against a required margin of %.2f points, so the swing declined to the old low "
                "figures and the primary bear market stands"
                % (reaction_low, old_low_margin_points, old_low_value, required_margin)
            )
        else:
            confirmed = False
            classification = "secondary_swing_only"
            reason = (
                "the reaction held above the old low of %.2f, but the subsequent recovery reached only "
                "%.2f against the earlier rally high of %.2f, a margin of %.2f points, so the move is "
                "still a secondary swing and not a new primary bull market"
                % (old_low_value, recovery_high, rally_high_value, new_high_margin_points)
            )

        result = {
            "direction": "bull",
            "old_low": old_low_value,
            "rally_high": rally_high_value,
            "rally_high_index": rally_index,
            "reaction_low": reaction_low,
            "reaction_low_index": reaction_low_index,
            "old_low_margin_points": old_low_margin_points,
            "required_margin_points": required_margin,
            "decline_reading": decline_reading,
            "held_above_old_low": held_above_old_low,
            "recovery_high": recovery_high,
            "recovery_high_index": recovery_high_index,
            "new_high_margin_points": new_high_margin_points,
            "recovery_reading": recovery_reading,
            "bettered_earlier_rally_high": bettered_earlier_rally_high,
            "transition_confirmed": confirmed,
            "succession_of_zigzag_steps": confirmed,
            "classification": classification,
            "duration": "indefinite" if confirmed else None,
            "duration_predictable": False,
            "reason": reason,
        }

        if verbose:
            result["prices"] = series
            result["thresholds"] = {
                "old_low_tolerance_pct": tol_pct,
                "min_new_high_points": min_points,
            }
            result["rule"] = (
                "if the secondary swing does not decline to the old low figures and subsequently "
                "recovers to points better than the new high established on the earlier rally, a "
                "primary bull market of indefinite length has been established -- but the barometer "
                "cannot predict how long it will last"
            )

        return _respond(result)
    except Exception as exc:  # pragma: no cover - defensive
        return json.dumps({
            "result": None,
            "error": str(exc),
            "metadata": {
                "tool": "secondary_swing_to_primary_bull_transition_test",
                "provenance": {
                    "source_grounded": ["reaction must not decline to the old low figures"],
                    "model_extrapolated": ["old_low_tolerance_pct default"],
                },
            },
        })