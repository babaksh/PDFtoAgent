"""Decide which market a series is following, and detect the regime shift to bonds."""

import json
import math
from typing import List, Optional


def _clean(values) -> List[float]:
    if not values:
        return []
    out: List[float] = []
    for v in values:
        try:
            f = float(v)
        except (TypeError, ValueError):
            continue
        if math.isnan(f) or math.isinf(f):
            continue
        out.append(f)
    return out


def _finite(v) -> bool:
    return v is not None and not (math.isnan(v) or math.isinf(v))


def _steps(series: List[float]) -> List[float]:
    return [series[i] - series[i - 1] for i in range(1, len(series))]


def _agreement(a: List[float], b: List[float]):
    """Share of overlapping period-steps in which two series move the SAME way."""
    n = min(len(a), len(b))
    if n < 2:
        return None
    agree = 0
    counted = 0
    for i in range(1, n):
        da = a[i] - a[i - 1]
        db = b[i] - b[i - 1]
        if not (_finite(da) and _finite(db)):
            continue
        if da == 0.0 and db == 0.0:
            continue
        counted += 1
        if (da > 0 and db > 0) or (da < 0 and db < 0):
            agree += 1
    if counted == 0:
        return None
    return agree / counted


def _pct(series: List[float]):
    if len(series) < 2 or series[0] == 0.0:
        return None
    return (series[-1] - series[0]) / abs(series[0]) * 100.0


def _direction(pct):
    if pct is None:
        return "none"
    if pct > 0.0:
        return "up"
    if pct < 0.0:
        return "down"
    return "flat"


def _r(v, nd: int = 4):
    return None if not _finite(v) else round(float(v), nd)


async def series_market_tracking_regime_test(
    series: List[float],
    speculative_average: List[float],
    bond_prices: List[float],
    min_segment_periods: int = 3,
    min_bond_agreement: float = 0.6,
    verbose: bool = True,
) -> str:
    """Decide which market a series is actually following -- the speculative equity
    market or the bond market -- and date the regime shift when it abandons the
    speculative average and travels with bonds instead.

    Use when one component of a barometer (the chapter's case: the twenty railroad
    stocks after federal control) stops behaving like the speculative market and you
    need to know which market its price is really governed by. The chapter's finding:
    "during that period the railroads followed not the speculative market but the
    market for bonds", and later "they ran counter to the falling industrials, on the
    way up actually crossing the industrials on the way down ... There was
    simultaneously a confirmatory recovery in bonds."

    Three things are measured, always, on the default call path:
      * `tracking` -- which of the two reference series the series moves with over the
        whole window (three-way: speculative / bond / indeterminate);
      * `regime_shift_detected` + `shift_index` -- the split point at which the series
        switches from moving with the speculative average to moving with bonds;
      * `crossing_index` -- the period at which the series crosses the speculative
        average while the two are travelling in opposite directions, together with
        `bonds_confirm_recovery` (bonds rising with the series in that late segment).

    Extends `average_corroboration_check` (chCYCLES AND STOCK MARKET RECORDS): that
    tool asks only whether two averages corroborate. This one adds a THIRD reference
    series (bonds) and returns the regime-shift decision -- the series may abandon the
    speculative average, run counter to it, and even cross it while moving with bonds.

    Do NOT use this to rule whether a one-average bull move is the legitimate
    guaranty exception (call single_average_exception_government_guaranty_test), and
    do NOT use it to grade the barometer's confidence once the shift is found (call
    barometer_confidence_impairment_weighting).

    Args:
        series: the series under test (e.g. the railroad average), oldest first.
        speculative_average: the speculative equity average (e.g. industrials), aligned.
        bond_prices: the bond / fixed-income average over the same periods, aligned.
        min_segment_periods: shortest segment either side of a candidate regime shift.
        min_bond_agreement: share of periods the series must move with bonds before it
            is said to have adopted the bond market in the late segment.
        verbose: False returns the compact decision; True adds the aligned series and
            per-segment measurements.

    Returns:
        JSON {"result": {...}, "error": None, "metadata": {...}}.
    """
    try:
        min_segment_periods = 3 if min_segment_periods is None else int(min_segment_periods)
        if min_segment_periods < 2:
            min_segment_periods = 2
        min_bond_agreement = 0.6 if min_bond_agreement is None else float(min_bond_agreement)

        s = _clean(series)
        e = _clean(speculative_average)
        b = _clean(bond_prices)

        n = min(len(s), len(e), len(b))
        s = s[:n]
        e = e[:n]
        b = b[:n]

        spec_agreement = _agreement(s, e)
        bond_agreement = _agreement(s, b)

        if n < 3:
            result = {
                "tracking": "insufficient_data",
                "regime_shift_detected": False,
                "shift_index": None,
                "reason": ("At least three aligned observations of the series, the "
                           "speculative average and bonds are needed to say which market "
                           "the series is following."),
                "observations_compared": n,
                "speculative_agreement": _r(spec_agreement),
                "bond_agreement": _r(bond_agreement),
                "crossing_index": None,
                "bonds_confirm_recovery": False,
            }
            return json.dumps({
                "result": result,
                "error": None,
                "metadata": {
                    "provenance": {
                        "source_grounded": [
                            "the railroads followed not the speculative market but the market for bonds",
                        ],
                        "model_extrapolated": ["insufficient-data boundary reading at < 3 observations"],
                    }
                },
            })

        steps_s = _steps(s)
        moving = any(d != 0.0 for d in steps_s) and any(
            d != 0.0 for d in _steps(e)) and any(d != 0.0 for d in _steps(b))
        if not moving:
            result = {
                "tracking": "no_movement",
                "regime_shift_detected": False,
                "shift_index": None,
                "reason": ("One of the three series never moved over the window, so no "
                           "tracking relation can be established."),
                "observations_compared": n,
                "speculative_agreement": _r(spec_agreement),
                "bond_agreement": _r(bond_agreement),
                "crossing_index": None,
                "bonds_confirm_recovery": False,
            }
            return json.dumps({
                "result": result,
                "error": None,
                "metadata": {
                    "provenance": {
                        "source_grounded": [
                            "the railroads followed not the speculative market but the market for bonds",
                        ],
                        "model_extrapolated": ["no-movement boundary reading"],
                    }
                },
            })

        # ---- regime shift: split the window so that the early segment tracks the
        # speculative average and the late segment tracks bonds.
        best_score = None
        best_split = None
        for split in range(min_segment_periods, n - min_segment_periods + 1):
            early = slice(0, split + 1)
            late = slice(split, n)
            e_spec = _agreement(s[early], e[early]) or 0.0
            e_bond = _agreement(s[early], b[early]) or 0.0
            l_spec = _agreement(s[late], e[late]) or 0.0
            l_bond = _agreement(s[late], b[late]) or 0.0
            score = (e_spec + l_bond) - (e_bond + l_spec)
            if best_score is None or score > best_score:
                best_score = score
                best_split = split

        shift_index = None
        regime_shift_detected = False
        late_spec_agreement = None
        late_bond_agreement = None
        early_spec_agreement = None
        early_bond_agreement = None

        if best_split is not None:
            early = slice(0, best_split + 1)
            late = slice(best_split, n)
            early_spec_agreement = _agreement(s[early], e[early])
            early_bond_agreement = _agreement(s[early], b[early])
            late_spec_agreement = _agreement(s[late], e[late])
            late_bond_agreement = _agreement(s[late], b[late])
            if best_score > 0.0 and (late_bond_agreement or 0.0) >= min_bond_agreement:
                regime_shift_detected = True
                shift_index = best_split

        # ---- crossing: the series crosses the speculative average.
        crossing_index = None
        for i in range(1, n):
            prev = s[i - 1] - e[i - 1]
            cur = s[i] - e[i]
            if prev != 0.0 and cur != 0.0 and ((prev > 0.0) != (cur > 0.0)):
                crossing_index = i
                break

        late_slice = slice(shift_index, n) if regime_shift_detected else slice(0, n)
        series_late_pct = _pct(s[late_slice])
        spec_late_pct = _pct(e[late_slice])
        bond_late_pct = _pct(b[late_slice])
        series_late_dir = _direction(series_late_pct)
        spec_late_dir = _direction(spec_late_pct)
        bond_late_dir = _direction(bond_late_pct)

        runs_counter = (
            series_late_dir != "none" and spec_late_dir != "none"
            and series_late_dir != spec_late_dir
            and series_late_dir != "flat" and spec_late_dir != "flat"
        )
        bonds_confirm_recovery = (
            bond_late_dir != "none" and series_late_dir != "none"
            and bond_late_dir == series_late_dir and bond_late_dir != "flat"
        )
        crossed_while_counter = bool(crossing_index is not None and runs_counter)

        if regime_shift_detected:
            tracking = "bond_market_after_regime_shift"
            reason = ("The series abandoned the speculative average at observation "
                      + str(shift_index) + ": before it, it moved with the speculative "
                      "average in " + format((early_spec_agreement or 0.0) * 100.0, ".0f")
                      + "% of steps; after it, it moved with bonds in "
                      + format((late_bond_agreement or 0.0) * 100.0, ".0f")
                      + "% of steps (>= " + format(min_bond_agreement * 100.0, ".0f")
                      + "%) and with the speculative average in only "
                      + format((late_spec_agreement or 0.0) * 100.0, ".0f") + "%.")
            if runs_counter:
                reason += (" In the late segment it also ran counter to the speculative "
                           "average (" + series_late_dir + " while that average went "
                           + spec_late_dir + ")")
                if crossed_while_counter:
                    reason += " and crossed it at observation " + str(crossing_index)
                reason += "."
            else:
                reason += "."
            if bonds_confirm_recovery:
                reason += (" Bonds moved the same way as the series in that segment ("
                           + bond_late_dir + "), the confirmatory recovery in bonds the "
                           "chapter records.")
        elif spec_agreement is None or bond_agreement is None:
            tracking = "indeterminate"
            reason = ("The two reference series supplied no comparable movement, so which "
                      "market the series is following could not be measured.")
        elif spec_agreement > bond_agreement:
            tracking = "speculative_equity_market"
            reason = ("Over the whole window the series moved with the speculative average "
                      "in " + format(spec_agreement * 100.0, ".0f")
                      + "% of steps and with bonds in only "
                      + format(bond_agreement * 100.0, ".0f")
                      + "%: it is following the speculative market, and no regime shift "
                        "was found.")
        elif bond_agreement > spec_agreement:
            tracking = "bond_market"
            reason = ("Over the whole window the series moved with bonds in "
                      + format(bond_agreement * 100.0, ".0f")
                      + "% of steps and with the speculative average in only "
                      + format(spec_agreement * 100.0, ".0f")
                      + "%: it is following the bond market.")
        else:
            tracking = "indeterminate"
            reason = ("The series moved with the speculative average and with bonds in "
                      "exactly the same share of steps ("
                      + format((spec_agreement or 0.0) * 100.0, ".0f")
                      + "%); no market is singled out.")

        result = {
            "tracking": tracking,
            "regime_shift_detected": regime_shift_detected,
            "shift_index": shift_index,
            "reason": reason,
            "observations_compared": n,
            "speculative_agreement": _r(spec_agreement),
            "bond_agreement": _r(bond_agreement),
            "early_speculative_agreement": _r(early_spec_agreement),
            "early_bond_agreement": _r(early_bond_agreement),
            "late_speculative_agreement": _r(late_spec_agreement),
            "late_bond_agreement": _r(late_bond_agreement),
            "runs_counter_to_speculative_average": runs_counter,
            "crossing_index": crossing_index,
            "crossed_while_running_counter": crossed_while_counter,
            "bonds_confirm_recovery": bonds_confirm_recovery,
            "series_late_direction": series_late_dir,
            "speculative_late_direction": spec_late_dir,
            "bond_late_direction": bond_late_dir,
            "series_late_pct_change": _r(series_late_pct),
            "speculative_late_pct_change": _r(spec_late_pct),
            "bond_late_pct_change": _r(bond_late_pct),
            "min_bond_agreement": min_bond_agreement,
        }

        if verbose:
            result["detail"] = {
                "series": [round(v, 4) for v in s],
                "speculative_average": [round(v, 4) for v in e],
                "bond_prices": [round(v, 4) for v in b],
                "min_segment_periods": min_segment_periods,
                "regime_shift_score": round(best_score, 4) if best_score is not None else None,
                "rule_quote": ("they ran counter to the falling industrials, on the way up "
                               "actually crossing the industrials on the way down, in the "
                               "autumn of 1920. There was simultaneously a confirmatory "
                               "recovery in bonds."),
            }

        return json.dumps({
            "result": result,
            "error": None,
            "metadata": {
                "provenance": {
                    "source_grounded": [
                        "the railroads followed not the speculative market but the market for bonds",
                        "they ran counter to the falling industrials, on the way up actually crossing the industrials on the way down",
                        "there was simultaneously a confirmatory recovery in bonds",
                        "the decline in the railroads in 1919 and the recovery in 1920 virtually paralleled the movement of the average daily prices of forty representative bonds",
                    ],
                    "model_extrapolated": [
                        "tracking measured as sign agreement over period-steps",
                        "regime shift located by the split maximising early-speculative + late-bond agreement minus the cross terms",
                        "min_segment_periods default of 3 observations per segment",
                        "min_bond_agreement default of 0.6 of steps to call the late segment a bond regime",
                        "crossing defined as a sign change of series minus speculative average",
                        "insufficient-data (<3 observations) and no-movement boundary readings",
                    ],
                }
            },
        })
    except Exception as exc:
        return json.dumps({
            "result": {
                "tracking": "insufficient_data",
                "regime_shift_detected": False,
                "shift_index": None,
                "reason": "Could not determine which market the series follows: " + str(exc),
            },
            "error": None,
            "metadata": {
                "provenance": {
                    "source_grounded": [
                        "the railroads followed not the speculative market but the market for bonds",
                    ],
                    "model_extrapolated": ["boundary reading on unusable input"],
                }
            },
        })