import json
from typing import Optional


async def water_in_capitalization_test(
    market_price_per_share: float,
    book_value_per_share: Optional[float] = None,
    quick_asset_value_per_share: Optional[float] = None,
    insider_assumed_value_per_share: Optional[float] = None,
    par_value_per_share: Optional[float] = None,
    blood_threshold_pct: float = 50.0,
    verbose: bool = True,
) -> str:
    """Settle a charge of "water" in a capitalization by comparing market price with stated values.

    Use when a critic alleges that a listed company's capitalization is watered
    and you want the chapter's own settlement: set the market price per share
    against the benchmark values -- book value per share, quick-asset
    (liquidating) value per share, and, where a manipulated flotation is
    alleged, the par or offering price the insiders themselves assumed -- and
    read off whether the market has merely squeezed out the water or has gone
    further and squeezed blood.

    The chapter's own worked number is United States Steel common in 1921:
    market price under $80 against a book value of $261 a share and quick
    assets of about $120 a share, with a $550,000,000 common stock capital --
    "The stock market had far more than squeezed out the water in that
    capitalization... It had squeezed blood." The same benchmark logic settles
    Amalgamated Copper: insiders assumed 100 as value when they offered the
    stock at par, Keene advanced it to 130, and the market later knocked 100
    points off that bull-market high.

    Do NOT use this to judge whether a quotation is a real market price (that is
    `ownership_distribution_real_market_test`), and do NOT use it to compare a
    whole railroad system's capitalization per mile (that is
    `railroad_capitalization_per_mile_comparison`).
    """
    provenance = {
        "source_grounded": [
            "the stock market exists for the purpose of squeezing water out",
            "book value per share: the worth of the company's assets",
            "quick assets, largely cash, give the liquidating value with the whole concern scrapped",
            "the par or offering price is the value the insiders themselves assumed (Amalgamated Copper offered at par)",
            "market price of U.S. Steel common under $80 against book value $261 and quick assets about $120 a share",
            "verdict: water squeezed out versus 'it had squeezed blood'",
            "the stock market knocked one hundred points off the highest figure Amalgamated Copper attained",
            "Morgan's defence: intelligently anticipated growth",
        ],
        "model_extrapolated": [
            "blood_threshold_pct = 50.0 (price below half of the primary stated-value benchmark counts as blood, not merely water)",
            "water_threshold_pct = 100.0 (price at or above the benchmark means no water left to squeeze)",
            "primary benchmark preference order: book value, then quick-asset value, then insider-assumed value, then par",
            "sharpness measured as the percentage discount of price to each available benchmark",
            "verdict ladder: above_value / no_water_left / water_squeezed_out / squeezed_blood / no_benchmark_supplied",
            "three-way discount sign: premium, discount and exact parity are distinguished",
        ],
    }
    try:
        price = 0.0 if market_price_per_share is None else float(market_price_per_share)
        blood = 50.0 if blood_threshold_pct is None else float(blood_threshold_pct)

        benchmarks = []
        if book_value_per_share is not None:
            benchmarks.append(("book_value_per_share", float(book_value_per_share)))
        if quick_asset_value_per_share is not None:
            benchmarks.append(("quick_asset_value_per_share", float(quick_asset_value_per_share)))
        if insider_assumed_value_per_share is not None:
            benchmarks.append(("insider_assumed_value_per_share", float(insider_assumed_value_per_share)))
        if par_value_per_share is not None:
            benchmarks.append(("par_value_per_share", float(par_value_per_share)))

        rows = []
        for name, value in benchmarks:
            gap_points = value - price
            premium_pct = None
            price_pct_of_value = None
            if value > 0.0:
                premium_pct = (price / value - 1.0) * 100.0
                price_pct_of_value = price / value * 100.0
            elif value == 0.0:
                price_pct_of_value = None
            rows.append({
                "benchmark": name,
                "value_per_share": value,
                "gap_points": gap_points,
                "premium_pct_of_value": premium_pct,
                "price_pct_of_value": price_pct_of_value,
                "discount_pct_of_value": (None if premium_pct is None else -premium_pct),
            })

        primary = None
        for name in ("book_value_per_share", "quick_asset_value_per_share",
                     "insider_assumed_value_per_share", "par_value_per_share"):
            for row in rows:
                if row["benchmark"] == name:
                    primary = row
                    break
            if primary is not None:
                break

        if primary is None:
            verdict = "no_benchmark_supplied"
            reason = ("No stated-value benchmark was supplied. The chapter settles the charge of water "
                      "by setting the market price against book value, quick-asset liquidating value, or "
                      "the par or offering price the insiders assumed; at least one must be given.")
            price_pct_of_primary = None
            discount_pct = None
            max_discount_pct = None
        else:
            price_pct_of_primary = primary["price_pct_of_value"]
            discount_pct = primary["discount_pct_of_value"]
            max_discount_pct = max([r["discount_pct_of_value"] for r in rows
                                    if r["discount_pct_of_value"] is not None], default=None)
            if discount_pct is None:
                verdict = "no_benchmark_supplied"
                reason = ("The primary benchmark %.4f is zero, so no percentage discount can be formed."
                          % primary["value_per_share"])
            elif discount_pct < 0.0:
                verdict = "above_value"
                reason = ("Market price %.2f is %.2f%% above the %s of %.2f: the market is capitalizing "
                          "prospects, so on that benchmark there is no water left to squeeze -- if "
                          "anything there is intelligently anticipated growth in the price."
                          % (price, -discount_pct, primary["benchmark"], primary["value_per_share"]))
            elif discount_pct == 0.0:
                verdict = "no_water_left"
                reason = ("Market price %.2f exactly equals the %s of %.2f: the market has adjusted "
                          "price to value, and there is no water left in the capitalization."
                          % (price, primary["benchmark"], primary["value_per_share"]))
            elif discount_pct >= blood:
                verdict = "squeezed_blood"
                reason = ("Market price %.2f is only %.2f%% of the %s of %.2f, a discount of %.2f%% "
                          "against a blood threshold of %.2f%%. The chapter's own verdict applies: the "
                          "market has far more than squeezed out the water -- it had squeezed blood."
                          % (price, price_pct_of_primary, primary["benchmark"],
                             primary["value_per_share"], discount_pct, blood))
            else:
                verdict = "water_squeezed_out"
                reason = ("Market price %.2f is %.2f%% of the %s of %.2f, a discount of %.2f%% which is "
                          "less than the %.2f%% blood threshold. The water has been squeezed out of the "
                          "capitalization, but blood has not been drawn."
                          % (price, price_pct_of_primary, primary["benchmark"],
                             primary["value_per_share"], discount_pct, blood))

        result = {
            "verdict": verdict,
            "reason": reason,
            "market_price_per_share": price,
            "primary_benchmark": (primary["benchmark"] if primary is not None else None),
            "primary_benchmark_value_per_share": (primary["value_per_share"] if primary is not None else None),
            "price_pct_of_value": price_pct_of_primary,
            "discount_pct_of_value": discount_pct,
            "max_discount_pct_of_value": max_discount_pct,
            "blood_threshold_pct": blood,
            "benchmarks_compared": [r["benchmark"] for r in rows],
        }
        if verbose:
            result["benchmark_rows"] = rows
            result["params"] = {
                "blood_threshold_pct": blood,
            }
            result["note"] = ("Whatever the capitalization may be called, the stock market is forever "
                              "adjusting prices to values; the water soon evaporates.")
        return json.dumps({"result": result, "error": None,
                           "metadata": {"provenance": provenance}})
    except Exception as exc:
        return json.dumps({"result": None, "error": str(exc),
                           "metadata": {"provenance": provenance}})