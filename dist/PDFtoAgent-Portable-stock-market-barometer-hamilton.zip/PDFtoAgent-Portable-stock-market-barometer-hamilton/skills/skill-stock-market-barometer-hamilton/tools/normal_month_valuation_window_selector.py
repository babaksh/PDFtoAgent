import json
from typing import List, Optional


async def normal_month_valuation_window_selector(
    prices: List[float],
    periods: Optional[List[float]] = None,
    benchmark_value: Optional[float] = None,
    inflation_pct: float = 20.0,
    deflation_pct: float = 20.0,
    window: int = 3,
    verbose: bool = True,
) -> str:
    """Build the valuation basis the chapter trusts: a normal month of a normal year.

    Use when you have a run of market prices (a monthly or comparable record) and
    you want the subset the chapter accepts as the market's estimate of value --
    the prices "taken in a normal month of a normal year, with the prices not
    inflated on overestimated prospects or deflated by forced liquidation."

    The procedure: score each period by how far it stands from a benchmark value
    (supply `benchmark_value`; when it is not given, the median of the supplied
    prices is used as the market's own central estimate). A period standing more
    than `inflation_pct` above the benchmark is excluded as inflated on
    overestimated prospects; one standing more than `deflation_pct` below it is
    excluded as deflated by forced liquidation. From what remains, the most
    normal stretch of `window` consecutive periods is returned, together with its
    mean price as the market's estimate of value.

    Do NOT use this to decide whether a single price is below or above the value
    line (that is `average_vs_value_line_position_classifier`), and do NOT use it
    to value a railroad system per mile (that is
    `railroad_capitalization_per_mile_comparison`).
    """
    provenance = {
        "source_grounded": [
            "the market prices of the securities themselves",
            "taken in a normal month of a normal year",
            "prices not inflated on overestimated prospects",
            "prices not deflated by forced liquidation",
            "forced liquidation brought about largely to protect unsalable securities and warehouse receipts",
            "the Stock Exchange price records the value from day to day, month to month, year to year",
        ],
        "model_extrapolated": [
            "inflation_pct = 20.0 (a period more than 20% above the benchmark is excluded as inflated on overestimated prospects)",
            "deflation_pct = 20.0 (a period more than 20% below the benchmark is excluded as deflated by forced liquidation)",
            "window = 3 (the normal stretch reported is 3 consecutive periods, matching 'a normal month of a normal year')",
            "benchmark_value defaults to the median of the supplied prices when none is given",
            "the most normal stretch chosen by the smallest mean absolute deviation from the benchmark",
            "periods default to 1..n when no period labels are supplied",
            "three-way deviation: inflated, deflated and normal are distinguished, with exact parity normal",
        ],
    }
    try:
        px = [0.0 if p is None else float(p) for p in (prices or [])]
        infl = 20.0 if inflation_pct is None else float(inflation_pct)
        defl = 20.0 if deflation_pct is None else float(deflation_pct)
        win = 3 if window is None else int(window)
        if win < 1:
            win = 1

        labels = None
        if periods:
            labels = []
            for p in periods:
                labels.append(float(p) if p is not None else None)

        if not px:
            return json.dumps({
                "result": {
                    "verdict": "no_window",
                    "reason": ("No prices were supplied, so no normal period can be selected. The "
                               "chapter's valuation basis is built from a record of market prices "
                               "taken in a normal month of a normal year."),
                    "selected_periods": [],
                    "selected_prices": [],
                    "market_estimate_of_value": None,
                    "periods_supplied": 0,
                    "normal_periods": 0,
                    "excluded_inflated": 0,
                    "excluded_deflated": 0,
                    "benchmark_value": None,
                },
                "error": None,
                "metadata": {"provenance": provenance},
            })

        ordered = sorted(px)
        mid = len(ordered) // 2
        if len(ordered) % 2 == 1:
            median = ordered[mid]
        else:
            median = (ordered[mid - 1] + ordered[mid]) / 2.0
        bench = median if benchmark_value is None else float(benchmark_value)

        rows = []
        for i, p in enumerate(px):
            deviation_pct = None
            if bench > 0.0:
                deviation_pct = (p / bench - 1.0) * 100.0
            if deviation_pct is None:
                status = "unmeasurable"
            elif deviation_pct > infl:
                status = "inflated_on_overestimated_prospects"
            elif deviation_pct < -defl:
                status = "deflated_by_forced_liquidation"
            else:
                status = "normal"
            rows.append({
                "index": i,
                "period": (labels[i] if labels and i < len(labels) else float(i + 1)),
                "price": p,
                "deviation_pct": deviation_pct,
                "status": status,
            })

        normal_idx = [r["index"] for r in rows if r["status"] == "normal"]
        excluded_inflated = sum(1 for r in rows if r["status"] == "inflated_on_overestimated_prospects")
        excluded_deflated = sum(1 for r in rows if r["status"] == "deflated_by_forced_liquidation")

        if not normal_idx:
            verdict = "no_normal_period"
            reason = ("Every one of the %d supplied periods stands outside the normal band: %d inflated "
                      "on overestimated prospects and %d deflated by forced liquidation, against a "
                      "benchmark of %.2f. The chapter's valuation basis cannot be built from this "
                      "record." % (len(px), excluded_inflated, excluded_deflated, bench))
            selected = []
        else:
            normal_set = set(normal_idx)
            span = min(win, len(normal_idx))
            chunk = []
            while span >= 1 and not chunk:
                best = None
                for start in range(0, len(px) - span + 1):
                    idxs = list(range(start, start + span))
                    if not all(i in normal_set for i in idxs):
                        continue
                    devs = [abs(rows[i]["deviation_pct"]) if rows[i]["deviation_pct"] is not None
                            else 0.0 for i in idxs]
                    score = sum(devs) / len(devs)
                    if best is None or score < best[0]:
                        best = (score, idxs)
                if best is not None:
                    chunk = best[1]
                else:
                    span -= 1
            selected = [rows[i] for i in chunk]
            verdict = "normal_window_selected"
            reason = ("From %d periods, %d are normal against a benchmark of %.2f (%.2f%% inflation and "
                      "%.2f%% deflation bounds): %d were excluded as inflated on overestimated "
                      "prospects and %d as deflated by forced liquidation. The selected normal window "
                      "averages %.2f, which is the market's estimate of value on the chapter's basis."
                      % (len(px), len(normal_idx), bench, infl, defl, excluded_inflated,
                         excluded_deflated,
                         sum(r["price"] for r in selected) / len(selected)))

        selected_prices = [r["price"] for r in selected]
        selected_periods = [r["period"] for r in selected]
        estimate = None
        if selected_prices:
            estimate = sum(selected_prices) / len(selected_prices)

        result = {
            "verdict": verdict,
            "reason": reason,
            "benchmark_value": bench,
            "benchmark_basis": ("supplied" if benchmark_value is not None else "median_of_supplied_prices"),
            "selected_periods": selected_periods,
            "selected_prices": selected_prices,
            "market_estimate_of_value": estimate,
            "periods_supplied": len(px),
            "normal_periods": len(normal_idx),
            "excluded_inflated": excluded_inflated,
            "excluded_deflated": excluded_deflated,
            "inflation_pct": infl,
            "deflation_pct": defl,
        }
        if verbose:
            result["window"] = span if normal_idx else win
            result["period_rows"] = rows
            result["params"] = {
                "inflation_pct": infl,
                "deflation_pct": defl,
                "window": win,
                "benchmark_value": (None if benchmark_value is None else bench),
            }
            result["note"] = ("No valuation which could be instituted by Congress could begin to "
                              "compare with the market prices of the securities themselves, taken in "
                              "a normal month of a normal year.")
        return json.dumps({"result": result, "error": None,
                           "metadata": {"provenance": provenance}})
    except Exception as exc:
        return json.dumps({"result": None, "error": str(exc),
                           "metadata": {"provenance": provenance}})