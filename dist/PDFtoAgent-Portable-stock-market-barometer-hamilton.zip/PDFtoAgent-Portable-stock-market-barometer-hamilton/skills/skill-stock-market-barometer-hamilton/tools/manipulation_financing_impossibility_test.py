import json
from typing import Any, Dict, List, Optional


def _f(v: Any, default: float) -> float:
    try:
        if v is None:
            return default
        return float(v)
    except (TypeError, ValueError):
        return default


async def manipulation_financing_impossibility_test(
    shares_distributed: float,
    shares_traded: float,
    scaling_factor: float = 100.0,
    net_profit_points: float = 40.0,
    par_value_per_share: float = 100.0,
    financing_capacity_dollars: Optional[float] = None,
    net_realisation_low: float = 90.0,
    net_realisation_high: float = 96.0,
    verbose: bool = True,
) -> str:
    """Scale a known manipulation up to a market-wide super-syndicate and judge financing.

    Use when you have the arithmetic of a real, historical distribution -- the
    number of shares placed, the number of shares that had to be traded to place
    them, and the net price realised -- and you want to test the chapter's claim
    that manufacturing a GENERAL bull market is a financial impossibility. The
    tool derives the traded-per-distributed-share multiplier, applies a scaling
    factor (the chapter uses one hundred times Keene's Amalgamated Copper line),
    computes the share volume and par-value financing the manufactured move would
    require to earn the target net profit, and judges that against what the
    banking system could conceivably finance.

    Do NOT use this to grade the shape of a price path or whether a rise was
    manipulated on price evidence alone -- call manipulation_advance_plausibility_test
    (chMAJOR MARKET SWINGS) or manipulation_shock_deflection_test
    (chWALL STREET OF THE MOVIES) for that.
    """
    try:
        dist = _f(shares_distributed, 0.0)
        traded = _f(shares_traded, 0.0)
        scale = _f(scaling_factor, 100.0)
        points = _f(net_profit_points, 40.0)
        par = _f(par_value_per_share, 100.0)
        low = _f(net_realisation_low, 90.0)
        high = _f(net_realisation_high, 96.0)
        capacity = None if financing_capacity_dollars is None else _f(financing_capacity_dollars, 0.0)

        chapter_benchmark_shares = 120000000.0
        multiplier = (traded / dist) if dist > 0.0 else 0.0
        scaled_distributed = dist * scale
        required_shares = scaled_distributed * multiplier
        required_financing = required_shares * par
        # the syndicate must net `points` on the scaled line it accumulated and distributed
        target_net_profit = scaled_distributed * points
        distribution_proceeds_per_share = (low + high) / 2.0
        accumulation_cost_per_share = distribution_proceeds_per_share - points
        capital_to_accumulate = scaled_distributed * accumulation_cost_per_share
        gross_traded_value = required_shares * distribution_proceeds_per_share

        if capacity is None:
            capacity_multiple = None
            exceeds_capacity = None
            grade = "unmeasurable" if required_shares <= 0.0 else "impossible_arithmetic"
            reason = ("no share volume can be derived from the supplied distribution"
                      if required_shares <= 0.0 else
                      "a syndicate %gx the historical line would have to trade %.0f shares, "
                      "involving %.0f dollars of par-value financing to net %g points on %.0f shares"
                      % (scale, required_shares, required_financing, points, scaled_distributed))
        else:
            capacity_multiple = (required_financing / capacity) if capacity > 0.0 else None
            exceeds_capacity = bool(required_financing > capacity)
            if required_shares <= 0.0:
                grade = "unmeasurable"
                reason = "no share volume can be derived from the supplied distribution"
            elif exceeds_capacity:
                grade = "impossible_arithmetic"
                reason = ("required financing %.0f exceeds capacity %.0f by %.1fx -- impossible"
                          % (required_financing, capacity, capacity_multiple if capacity_multiple else 0.0))
            else:
                grade = "conceivable"
                reason = ("required financing %.0f is within capacity %.0f (%.2fx)"
                          % (required_financing, capacity, capacity_multiple if capacity_multiple else 0.0))

        result: Dict[str, Any] = {
            "shares_distributed": dist,
            "shares_traded": traded,
            "traded_per_distributed_multiplier": multiplier,
            "scaling_factor": scale,
            "scaled_shares_distributed": scaled_distributed,
            "required_shares_traded": required_shares,
            "required_financing_dollars": required_financing,
            "net_profit_points": points,
            "target_net_profit_dollars": target_net_profit,
            "chapter_benchmark_shares": chapter_benchmark_shares,
            "chapter_benchmark_financing_dollars": chapter_benchmark_shares * par,
            "net_realisation_range": [low, high],
            "net_realisation_midpoint": distribution_proceeds_per_share,
            "accumulation_cost_per_share": accumulation_cost_per_share,
            "capital_to_accumulate_dollars": capital_to_accumulate,
            "gross_traded_value_dollars": gross_traded_value,
            "financing_capacity_dollars": capacity,
            "capacity_multiple": capacity_multiple,
            "exceeds_capacity": exceeds_capacity,
            "impossible": grade == "impossible_arithmetic",
            "grade": grade,
            "reason": reason,
        }
        if verbose:
            result["net_realisation_range"] = [low, high]
            result["net_realisation_midpoint"] = (low + high) / 2.0

        return json.dumps({
            "result": result,
            "error": None,
            "metadata": {"provenance": {
                "source_grounded": [
                    "Keene: 220,000 shares Amalgamated Copper distributed",
                    "at least 700,000 shares traded in the course of distribution",
                    "net of 90 to 96 realised for his employers",
                    "assume 100 times 220,000 shares accumulated",
                    "not content with less than a 40-point net profit",
                    "trades alone would amount to something like 120,000,000 shares",
                    "taken at par, financing to the amount of many billions of dollars",
                    "could not have done this, or a tithe of it, under the national banking system",
                ],
                "model_extrapolated": [
                    "scaling_factor default 100.0 (chapter's 'a hundred times that number')",
                    "par_value_per_share default 100.0 (chapter: 'taking them at par')",
                    "financing_capacity_dollars default None: capacity bound is caller-supplied",
                    "grade 'impossible_arithmetic' when no capacity is given (volume/par alone)",
                ],
            }},
        })
    except Exception as exc:  # noqa: BLE001
        return json.dumps({
            "result": None,
            "error": "manipulation_financing_impossibility_test failed: %s" % exc,
            "metadata": {"provenance": {
                "source_grounded": [],
                "model_extrapolated": ["error path"],
            }},
        })