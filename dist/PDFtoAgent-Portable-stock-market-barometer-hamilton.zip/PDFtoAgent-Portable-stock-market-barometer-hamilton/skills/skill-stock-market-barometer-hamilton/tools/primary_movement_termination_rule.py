"""Dating the END of a primary movement when the extreme comes early."""

import json

from typing import Any, Dict, List, Optional

_MONTH_NAMES = {
    "jan": 1, "feb": 2, "mar": 3, "apr": 4, "may": 5, "jun": 6,
    "jul": 7, "aug": 8, "sep": 9, "sept": 9, "oct": 10, "nov": 11, "dec": 12,
}


def _label(periods: Optional[List[str]], index: int) -> Optional[str]:
    if periods and 0 <= index < len(periods):
        return str(periods[index])
    return None


def _normalize_direction(value: Any) -> Optional[str]:
    """Three-way read of a direction label: 'up', 'down', or None when the label
    carries no direction (absent, empty or unrecognised). A movement whose
    direction is not stated has no extreme to date."""
    text = str(value if value is not None else "").strip().lower()
    if text in ("down", "d", "bear", "bearish", "fall", "falling", "decline", "declining", "low", "-1", "-"):
        return "down"
    if text in ("up", "u", "bull", "bullish", "rise", "rising", "advance", "advancing", "high", "1", "+"):
        return "up"
    return None


async def primary_movement_termination_rule(
    prices: List[float],
    periods: Optional[List[str]] = None,
    direction: Optional[str] = None,
    closeness_tolerance_pct: float = 3.0,
    min_intervening_move_pct: float = 5.0,
    min_tail_share: float = 0.2,
    max_recovery_periods: Optional[int] = None,
    verbose: bool = True,
) -> str:
    """Date the END of a primary (major) movement from the price path of the averages.

    Use when the extreme of the averages (the highest point of an up movement, the
    lowest point of a down movement) occurs well BEFORE the close of the movement.
    This chapter's rule: the movement is not ended at that extreme -- it runs on
    through the subsequent irregular decline and the like irregular recovery, back
    to a figure close to the old high (or low) point, and THAT point is taken as
    the end of the primary movement. Worked example in the chapter: the 1903-07
    bull swing whose actual top was January 22, 1906, followed within the year by
    an irregular decline and an irregular recovery to a figure close to the old
    high point.

    Inputs: prices -- the average's successive values over the movement (monthly
    closes are what the chapter uses); periods -- optional aligned date labels;
    direction -- "up" for a bull movement, "down" for a bear movement. If it is
    omitted or unrecognised the tool reports direction='none' and leaves the
    movement undated rather than assuming a high point.

    Do NOT use to split a whole era into swings (use major_swing_duration_ratio),
    and do NOT use for secondary reactions inside a movement (use
    secondary_swing_duration_asymmetry_test).
    """
    try:
        prices = [float(p) for p in (prices or []) if p is not None]
        direction = _normalize_direction(direction)
        closeness_tolerance_pct = 3.0 if closeness_tolerance_pct is None else float(closeness_tolerance_pct)
        min_intervening_move_pct = 5.0 if min_intervening_move_pct is None else float(min_intervening_move_pct)
        min_tail_share = 0.2 if min_tail_share is None else float(min_tail_share)
        max_recovery_periods = None if max_recovery_periods in (None, 0) else int(max_recovery_periods)

        n = len(prices)
        net_change = float(prices[-1] - prices[0]) if n else 0.0
        is_flat = bool(n > 1 and max(prices) == min(prices))
        if direction is None and n > 1 and not is_flat:
            if net_change > 0.0:
                direction = "up"
            elif net_change < 0.0:
                direction = "down"
        if is_flat:
            direction = None
        base: Dict[str, Any] = {
            "direction": direction if direction is not None else "none",
            "n_periods": n,
            "extreme_index": None,
            "extreme_price": None,
            "extreme_label": None,
            "tail_share_after_extreme": None,
            "extreme_well_before_close": False,
            "intervening_move_pct": None,
            "trough_index": None,
            "trough_price": None,
            "recovery_index": None,
            "recovery_price": None,
            "recovery_gap_pct": None,
            "termination_index": None,
            "termination_price": None,
            "termination_label": None,
            "ends_at_extreme": None,
            "rule_applied": False,
            "verdict": False,
            "reason": "No price path supplied, so the end of the movement cannot be dated.",
        }
        if n == 0:
            return json.dumps({
                "result": base,
                "error": None,
                "metadata": {"provenance": {
                    "source_grounded": [],
                    "model_extrapolated": ["empty-input neutral reading"],
                }},
            })

        if n == 1:
            base["direction"] = direction if direction is not None else "none"
            base["extreme_index"] = 0
            base["extreme_price"] = prices[0]
            base["extreme_label"] = _label(periods, 0)
            base["tail_share_after_extreme"] = 0.0
            base["termination_index"] = 0
            base["termination_price"] = prices[0]
            base["termination_label"] = _label(periods, 0)
            base["ends_at_extreme"] = True
            base["reason"] = (
                "A single observation gives no path, so the movement is dated at that "
                "observation; there is no subsequent decline and recovery to date."
            )
            return json.dumps({
                "result": base,
                "error": None,
                "metadata": {"provenance": {
                    "source_grounded": [],
                    "model_extrapolated": ["single-element boundary reading"],
                }},
            })

        if direction is None:
            if is_flat:
                base["reason"] = (
                    "The averages show no movement at all over the %d periods supplied, so the "
                    "path has no direction and no high or low point to take as the extreme; "
                    "there is no decline and recovery to date and the movement is left undated."
                    % n
                )
            else:
                base["reason"] = (
                    "The direction of the movement was not given and the path gives no net "
                    "direction to infer it from, so there is no high or low point to take as "
                    "the extreme and the movement cannot be dated."
                )
            return json.dumps({
                "result": base,
                "error": None,
                "metadata": {"provenance": {
                    "source_grounded": [],
                    "model_extrapolated": [
                        "unspecified direction -> 'none' reading, movement left undated",
                        "flat path -> 'none' reading, movement left undated",
                    ],
                }},
            })

        if direction == "up":
            extreme = max(prices)
        else:
            extreme = min(prices)
        extreme_index = prices.index(extreme)
        tail = n - 1 - extreme_index
        tail_share = float(tail) / float(n - 1) if n > 1 else 0.0

        base["extreme_index"] = extreme_index
        base["extreme_price"] = extreme
        base["extreme_label"] = _label(periods, extreme_index)
        base["tail_share_after_extreme"] = tail_share
        base["extreme_well_before_close"] = bool(tail_share >= min_tail_share)

        if tail == 0:
            base["termination_index"] = extreme_index
            base["termination_price"] = extreme
            base["termination_label"] = _label(periods, extreme_index)
            base["ends_at_extreme"] = True
            base["reason"] = (
                "The extreme is the last observation of the path, so the movement is "
                "ended at the extreme; there is no subsequent decline and recovery to date."
            )
            return json.dumps({
                "result": base,
                "error": None,
                "metadata": {"provenance": {
                    "source_grounded": ["extreme occurs at the close -> movement ends at the extreme"],
                    "model_extrapolated": ["terminal-extreme boundary reading"],
                }},
            })

        tail_prices = prices[extreme_index + 1:]
        if direction == "up":
            adverse_index_rel = min(range(len(tail_prices)), key=lambda i: tail_prices[i])
        else:
            adverse_index_rel = max(range(len(tail_prices)), key=lambda i: tail_prices[i])
        adverse_price = tail_prices[adverse_index_rel]
        adverse_index = extreme_index + 1 + adverse_index_rel
        if extreme != 0.0:
            intervening_pct = abs(adverse_price - extreme) / abs(extreme) * 100.0
        else:
            intervening_pct = 0.0
        base["trough_index"] = adverse_index
        base["trough_price"] = adverse_price
        base["intervening_move_pct"] = intervening_pct

        window_end = n if max_recovery_periods is None else min(n, adverse_index + 1 + max_recovery_periods)
        tol_frac = closeness_tolerance_pct / 100.0
        recovery_slice = list(range(adverse_index + 1, window_end))
        if direction == "up":
            recovery_index = max(recovery_slice, key=lambda i: prices[i]) if recovery_slice else None
        else:
            recovery_index = min(recovery_slice, key=lambda i: prices[i]) if recovery_slice else None

        if recovery_index is not None:
            recovery_price: Any = prices[recovery_index]
            close_to_old = abs(recovery_price - extreme) <= abs(extreme) * tol_frac
        else:
            recovery_price = None
            close_to_old = False

        if extreme == 0.0 or not close_to_old or intervening_pct < min_intervening_move_pct:
            base["termination_index"] = extreme_index
            base["termination_price"] = extreme
            base["termination_label"] = _label(periods, extreme_index)
            base["ends_at_extreme"] = True
            if extreme == 0.0:
                reason = (
                    "The extreme is zero, so no percentage comparison to the old high/low "
                    "point is possible; the movement is dated at the extreme."
                )
            elif intervening_pct < min_intervening_move_pct:
                reason = (
                    "The intervening adverse move of %.2f%% is below the %.2f%% required "
                    "for an irregular decline and recovery, so the movement is dated at "
                    "the extreme." % (intervening_pct, min_intervening_move_pct)
                )
            else:
                reason = (
                    "After the extreme the averages never came back to a figure within "
                    "%.2f%% of it, so the chapter's rule does not apply and the movement "
                    "is dated at the extreme." % closeness_tolerance_pct
                )
            base["reason"] = reason
            return json.dumps({
                "result": base,
                "error": None,
                "metadata": {"provenance": {
                    "source_grounded": ["irregular decline and recovery back to a figure close to the old high point"],
                    "model_extrapolated": [
                        "closeness_tolerance_pct=3 for 'close to the old high point'",
                        "min_intervening_move_pct=5 for the intervening adverse move",
                        "no-recovery / zero-extreme boundary reading ends the movement at the extreme",
                    ],
                }},
            })

        gap_pct = abs(recovery_price - extreme) / abs(extreme) * 100.0
        base["recovery_index"] = recovery_index
        base["recovery_price"] = recovery_price
        base["recovery_gap_pct"] = gap_pct
        base["termination_index"] = recovery_index
        base["termination_price"] = recovery_price
        base["termination_label"] = _label(periods, recovery_index)
        base["ends_at_extreme"] = False
        base["rule_applied"] = True
        base["verdict"] = True
        base["reason"] = (
            "The extreme (%s at %s) occurs well before the close (%.0f%% of the path still "
            "to run), and after an irregular adverse move of %.2f%% the averages recovered "
            "to %.4g, within %.2f%% of the old %s point -- so the primary movement is taken "
            "to end at %s, not at the extreme." % (
                "high" if direction == "up" else "low",
                base["extreme_label"] if base["extreme_label"] is not None else "index %d" % extreme_index,
                tail_share * 100.0,
                intervening_pct,
                recovery_price,
                gap_pct,
                "high" if direction == "up" else "low",
                base["termination_label"] if base["termination_label"] is not None else "index %d" % recovery_index,
            )
        )

        if verbose:
            base["recovery_window_end_index"] = window_end - 1
            base["thresholds"] = {
                "closeness_tolerance_pct": closeness_tolerance_pct,
                "min_intervening_move_pct": min_intervening_move_pct,
                "min_tail_share": min_tail_share,
                "max_recovery_periods": max_recovery_periods,
            }

        return json.dumps({
            "result": base,
            "error": None,
            "metadata": {
                "provenance": {
                    "source_grounded": [
                        "actual top of the averages January 22, 1906",
                        "subsequent irregular decline of some months and a like irregular recovery",
                        "recovery to a figure close to the old high point",
                        "that point is taken as the end of the primary movement, not the extreme",
                        "rule applies when the extreme occurs well before the movement's close",
                    ],
                    "model_extrapolated": [
                        "closeness_tolerance_pct=3 for 'close to the old high point'",
                        "min_intervening_move_pct=5 for the intervening adverse move",
                        "min_tail_share=0.2 for 'well before the movement's close'",
                        "max_recovery_periods=None -> search the whole remaining path",
                        "termination taken at the culmination of the recovery (extreme of the post-trough path)",
                        "mirrored for a down movement (old low point)",
                        "unspecified direction -> 'none' reading, movement left undated",
                    ],
                }
            },
        })
    except Exception as exc:  # noqa: BLE001
        return json.dumps({
            "result": None,
            "error": "primary_movement_termination_rule failed: %s" % exc,
            "metadata": {
                "provenance": {
                    "source_grounded": [],
                    "model_extrapolated": ["error handling path"],
                }
            },
        })