import json
from typing import List, Optional


def _floats(values: Optional[List[float]]) -> List[float]:
    if not values:
        return []
    out = []
    for v in values:
        try:
            out.append(float(v))
        except (TypeError, ValueError):
            continue
    return out


def _move(series: List[float], start: int, end: int) -> Optional[float]:
    """Percent change over series[start:end+1]; None if the slice is unusable."""
    if end <= start or start < 0 or end >= len(series):
        return None
    base = series[start]
    if base == 0.0:
        return None
    return (series[end] - base) / abs(base) * 100.0


def _direction(pct: Optional[float]) -> str:
    if pct is None:
        return "none"
    if pct > 0.0:
        return "up"
    if pct < 0.0:
        return "down"
    return "none"


async def average_corroboration_check(
    industrials: List[float],
    railroads: List[float],
    window: int = 12,
    min_move_pct: float = 5.0,
    max_lag: int = 2,
    verbose: bool = True,
) -> str:
    """Test whether two market averages corroborate each other over a common window.

    Use when you have two parallel averages (e.g. Dow-Jones industrials and railroads,
    aligned period by period) and you want to know whether they agree well enough that
    a movement may be read from them. Dow's tested implication is that the two averages
    corroborate each other: there is never a primary movement, and rarely a secondary
    movement, where they do not agree. The test compares the DIRECTION of each average
    over the window -- the chapter explicitly warns that the two groups will not advance
    point for point with each other -- and reports whether a primary or a secondary
    reading is permitted by that agreement.

    Do NOT use this to detect a 'making a line' range or its breakout -- call
    line_formation_breakout instead. Do NOT use it for a single average.

    Parameters: industrials (list of floats, oldest first), railroads (same length or
    longer, aligned with industrials), window (number of trailing observations over
    which each average's net move is measured), min_move_pct (net move, in percent,
    below which an average is read as flat and therefore unable to confirm), max_lag
    (number of periods the slower average may lag and still count as confirming),
    verbose (False returns only the corroboration verdicts and the two net moves).
    """
    try:
        window = 12 if window is None else int(window)
        min_move_pct = 5.0 if min_move_pct is None else float(min_move_pct)
        max_lag = 2 if max_lag is None else int(max_lag)
        if window < 2:
            window = 2
        if max_lag < 0:
            max_lag = 0

        ind, rail, n = _align(_floats(industrials), _floats(railroads))
        del n

        provenance = {
            "source_grounded": [
                "the two averages corroborate each other",
                "never a primary movement where the two averages do not agree",
                "rarely a secondary movement where the two averages do not agree",
                "the two averages need not advance point for point with each other",
            ],
            "model_extrapolated": [
                "window default 12 observations over which the net move is measured",
                "min_move_pct default 5.0 percent as the flat / no-movement cutoff",
                "max_lag default 2 periods for a lagging average",
                "agreement tested on direction only, magnitudes reported not compared",
            ],
        }
        meta = {
            "provenance": provenance,
            "parameters": {"window": window, "min_move_pct": min_move_pct, "max_lag": max_lag},
            "observations_compared": min(len(ind), len(rail)),
        }

        m = min(len(ind), len(rail))
        if m < 2:
            result = {
                "corroborated": False,
                "agreement": "insufficient_data",
                "primary_movement_permitted": False,
                "secondary_movement_permitted": False,
                "reason": "at least two aligned observations are needed to measure a move",
            }
            return json.dumps({"result": result, "error": None, "metadata": meta})

        if window > m:
            window = m

        ends = list(range(m - 1, m - 1 - max_lag - 1, -1))
        ends = [e for e in ends if e - window + 1 >= 0]
        if not ends:
            ends = [m - 1]

        best = None
        for end in ends:
            ind_pct = _move(ind, end - window + 1, end)
            rail_pct = _move(rail, end - window + 1, end)
            d_ind = _direction(ind_pct)
            d_rail = _direction(rail_pct)
            ind_flat = ind_pct is None or abs(ind_pct) < min_move_pct
            rail_flat = rail_pct is None or abs(rail_pct) < min_move_pct
            if d_ind == d_rail and d_ind != "none" and not ind_flat and not rail_flat:
                agree = "agree"
            elif d_ind != d_rail and d_ind != "none" and d_rail != "none":
                agree = "divergent"
            elif d_ind != "none" and d_rail == "none":
                agree = "railroads_flat"
            elif d_rail != "none" and d_ind == "none":
                agree = "industrials_flat"
            else:
                agree = "both_flat"
            cand = {
                "lag_periods": m - 1 - end,
                "window_start_index": end - window + 1,
                "window_end_index": end,
                "industrials_move_pct": ind_pct,
                "railroads_move_pct": rail_pct,
                "industrials_direction": d_ind,
                "railroads_direction": d_rail,
                "industrials_flat": ind_flat,
                "railroads_flat": rail_flat,
                "agreement": agree,
            }
            if agree == "agree":
                best = cand
                break
            if best is None:
                best = cand

        corroborated = best["agreement"] == "agree"
        agreement = best["agreement"]

        if corroborated:
            reason = ("both averages move %s together over the window; they corroborate each other, so a "
                      "primary movement may be read from them and a secondary reading is well supported"
                      % best["industrials_direction"])
        elif agreement == "divergent":
            reason = ("the two averages are moving in opposite directions; they do not corroborate, and there is "
                      "never a primary movement where they do not agree")
        elif agreement in ("industrials_flat", "railroads_flat"):
            flat = "industrials" if agreement == "industrials_flat" else "railroads"
            reason = ("only one average is moving; the %s is flat and cannot confirm it, so no corroboration"
                      % flat)
        else:
            reason = "neither average shows a net move over the window; there is nothing to corroborate"

        result = {
            "corroborated": corroborated,
            "agreement": agreement,
            "industrials_move_pct": best["industrials_move_pct"],
            "railroads_move_pct": best["railroads_move_pct"],
            "industrials_direction": best["industrials_direction"],
            "railroads_direction": best["railroads_direction"],
            "primary_movement_permitted": corroborated,
            "secondary_movement_permitted": agreement != "both_flat",
            "secondary_basis": "corroborated" if corroborated else (
                "no_net_move_to_corroborate" if agreement == "both_flat" else "uncorroborated_rare"),
            "window_used": window,
            "lag_periods_used": best["lag_periods"],
            "reason": reason,
        }

        if verbose:
            result["window_start_index"] = best["window_start_index"]
            result["window_end_index"] = best["window_end_index"]
            result["industrials_flat"] = best["industrials_flat"]
            result["railroads_flat"] = best["railroads_flat"]
            result["secondary_caveat"] = (
                "a secondary movement without corroboration is possible but rare"
                if not corroborated else
                "corroborated, so the secondary reading carries the usual weight"
            )

        return json.dumps({"result": result, "error": None, "metadata": meta})
    except Exception as exc:
        return json.dumps({"result": None, "error": str(exc), "metadata": {}})


def _align(a: List[float], b: List[float]):
    n = min(len(a), len(b))
    return a[:n], b[:n], n