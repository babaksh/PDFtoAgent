"""Decide whether a one-average bull move is the named government-guaranty exception.

Extends `joint_average_turn_confirmation_test` (chMANIPULATION AND PROFESSIONAL
TRADING): that tool asks whether a primary movement has resumed or reversed
from two averages jointly. This chapter names the ONE condition under which a
single average may legitimately be read without the other's confirmation: the
other average has been "taken entirely out of the speculative class" by
government ownership and guaranty, and therefore moves downward with bonds and
other fixed-income securities, which "inevitably decline in price with an
advance in the cost of living". Absent that condition, the single-average
indication is the kind of "unfortunate guess" the chapter records.
"""

import json
import math
from typing import List, Optional


def _clean(values) -> List[float]:
    if not values:
        return []
    out = []
    for v in values:
        try:
            f = float(v)
        except (TypeError, ValueError):
            continue
        if math.isnan(f) or math.isinf(f):
            continue
        out.append(f)
    return out


def _pct_change(series: List[float]) -> float:
    if len(series) < 2:
        return 0.0
    denom = abs(series[0]) if series[0] != 0.0 else 1.0
    return (series[-1] - series[0]) / denom * 100.0


def _sign_agreement(a: List[float], b: List[float]) -> float:
    n = min(len(a), len(b))
    if n < 2:
        return float("nan")
    agree = 0
    counted = 0
    for i in range(1, n):
        da = a[i] - a[i - 1]
        db = b[i] - b[i - 1]
        if da == 0.0 and db == 0.0:
            continue
        counted += 1
        if (da > 0 and db > 0) or (da < 0 and db < 0):
            agree += 1
    if counted == 0:
        return float("nan")
    return agree / counted


def _direction(pct: float, min_move_pct: float) -> str:
    tol = abs(min_move_pct)
    if pct > tol:
        return "up"
    if pct < -tol:
        return "down"
    return "flat"


async def single_average_exception_government_guaranty_test(
    leading_average: List[float],
    other_average: List[float],
    government_ownership_and_guaranty: bool = False,
    bond_prices: Optional[List[float]] = None,
    cost_of_living: Optional[List[float]] = None,
    min_move_pct: float = 1.0,
    min_bond_sign_agreement: float = 0.6,
    verbose: bool = True,
) -> str:
    """Rule whether a bull move shown by only ONE average is the legitimate named exception.

    Use when one average (say the industrials) gives a bullish indication that
    the other average does not confirm, and you must decide whether to act on
    it. The chapter permits single-average confirmation in exactly one case: the
    non-confirming average has been removed from the speculative class by
    government ownership and guaranty, so it travels with bonds instead -- and
    bonds decline as the cost of living advances. That is why the industrials
    could make the 1919 bull market "entirely off their own bat" and why the
    1921 forecast that copied the pattern was an "unfortunate guess".

    Do NOT use this when both averages already agree -- there is no exception to
    test then. Do NOT use it to force a bullish reading: if the government
    condition is absent or unmeasured, the tool returns an unconfirmed signal.

    Args:
        leading_average: the average giving the bullish indication, oldest first.
        other_average: the average called on to confirm it, same window.
        government_ownership_and_guaranty: True if the other average is under government ownership and guaranty.
        bond_prices: bond / fixed-income price series over the same window, needed to test co-movement.
        cost_of_living: cost-of-living index over the same window, to confirm bonds are falling as it rises.
        min_move_pct: percent band inside which a move counts as flat rather than directional.
        min_bond_sign_agreement: share of periods the other average must move the same way as bonds.
        verbose: False returns the compact verdict; True adds the measured condition detail.

    Returns:
        JSON {"result": {...}, "error": None, "metadata": {...}} with
        `classification` plus a short `reason`.
    """
    try:
        min_move_pct = 1.0 if min_move_pct is None else float(min_move_pct)
        try:
            min_bond_sign_agreement = (
                0.6 if min_bond_sign_agreement is None else float(min_bond_sign_agreement)
            )
        except (TypeError, ValueError):
            min_bond_sign_agreement = 0.6
        gov = bool(government_ownership_and_guaranty)

        lead = _clean(leading_average)
        other = _clean(other_average)
        bonds = _clean(bond_prices) if bond_prices else []
        col = _clean(cost_of_living) if cost_of_living else []

        lead_pct = _pct_change(lead)
        other_pct = _pct_change(other)
        lead_dir = _direction(lead_pct, min_move_pct)
        other_dir = _direction(other_pct, min_move_pct)

        if len(lead) < 2 or len(other) < 2:
            return json.dumps({
                "result": {
                    "classification": "insufficient_data",
                    "reason": "Both averages need at least two observations before any "
                              "confirmation question can be put.",
                    "leading_direction": lead_dir,
                    "other_direction": other_dir,
                },
                "error": None,
                "metadata": {
                    "provenance": {
                        "source_grounded": [
                            "an indication by one average which has not been clearly confirmed by the other",
                        ],
                        "model_extrapolated": ["insufficient-data boundary reading"],
                    }
                },
            })

        uses_exception_branch = not (lead_dir == other_dir and lead_dir != "flat")

        # Condition 1: the other average has left the speculative class.
        gov_condition_met = gov

        # Condition 2: it moves with bonds -- measured, not assumed.
        bond_agreement = _sign_agreement(other, bonds) if len(bonds) >= 2 else float("nan")
        if math.isnan(bond_agreement):
            bond_condition_met = False
            bond_condition_measured = False
        else:
            bond_condition_measured = True
            bond_condition_met = bond_agreement >= min_bond_sign_agreement

        # Condition 3: bonds decline while the cost of living advances.
        bond_pct = _pct_change(bonds) if len(bonds) >= 2 else 0.0
        col_pct = _pct_change(col) if len(col) >= 2 else 0.0
        if len(bonds) >= 2 and len(col) >= 2:
            col_condition_measured = True
            col_condition_met = (bond_pct < -min_move_pct) and (col_pct > min_move_pct)
        else:
            col_condition_measured = False
            col_condition_met = False

        conditions_measured = [gov_condition_met, bond_condition_measured, col_condition_measured]
        all_measured = all(conditions_measured)

        if not uses_exception_branch:
            classification = "confirmed_by_both_averages"
            reason = ("Both averages moved " + lead_dir + " over the window, so the indication "
                      "is confirmed in the ordinary way and the exception need not be invoked.")
            exception_applies = False
        elif gov_condition_met and bond_condition_met and col_condition_measured and col_condition_met and all_measured:
            classification = "legitimate_government_guaranty_exception"
            exception_applies = True
            reason = ("The other average did not confirm (" + other_dir + " while the leading "
                      "average moved " + lead_dir + "), but it is under government ownership and "
                      "guaranty, which takes it out of the speculative class; it moved with bonds "
                      "in " + format(bond_agreement * 100.0, ".0f")
                      + "% of periods, and those bonds declined " + format(abs(bond_pct), ".1f")
                      + "% while the cost of living advanced " + format(col_pct, ".1f")
                      + "%. That is the one case in which the single average may be read alone.")
        elif gov_condition_met and bond_condition_met and not col_condition_measured:
            classification = "unconfirmed_false_signal"
            exception_applies = False
            reason = ("The other average is under government ownership and moves with bonds, but "
                      "no cost-of-living series was supplied, so the chapter's third condition "
                      "(bonds declining as the cost of living advances) was NOT measured. An "
                      "unmeasured condition cannot confirm the exception; treat the single-average "
                      "indication as unconfirmed.")
        else:
            classification = "unconfirmed_false_signal"
            exception_applies = False
            failed = []
            if not gov_condition_met:
                failed.append("the other average is not under government ownership and guaranty")
            if not bond_condition_met:
                if bond_condition_measured:
                    failed.append("it did not move with bonds (only "
                                  + format(bond_agreement * 100.0, ".0f") + "% sign agreement, below the "
                                  + format(min_bond_sign_agreement * 100.0, ".0f") + "% required)")
                else:
                    failed.append("no bond series was supplied, so co-movement with bonds could not be measured")
            if not col_condition_met:
                failed.append("bonds were not shown to decline while the cost of living advanced"
                              + ("" if col_condition_measured else " (unmeasured)"))
            reason = ("The leading average moved " + lead_dir + " and the other average moved "
                      + other_dir + ", so there is no confirmation; and the named exception does "
                      "not apply because " + "; ".join(failed)
                      + ". This is the chapter's 'unfortunate guess': do not act on one average.")

        result = {
            "classification": classification,
            "exception_applies": exception_applies,
            "reason": reason,
            "leading_direction": lead_dir,
            "other_direction": other_dir,
            "leading_pct_change": round(lead_pct, 4),
            "other_pct_change": round(other_pct, 4),
            "government_ownership_and_guaranty": gov,
            "bond_sign_agreement": None if math.isnan(bond_agreement) else round(bond_agreement, 4),
            "bond_pct_change": round(bond_pct, 4),
            "cost_of_living_pct_change": round(col_pct, 4),
            "conditions_measured": {
                "government_ownership_declared": True,
                "moves_with_bonds": bond_condition_measured,
                "bonds_down_cost_of_living_up": col_condition_measured,
            },
        }
        if verbose:
            result["detail"] = {
                "min_move_pct": min_move_pct,
                "min_bond_sign_agreement": min_bond_sign_agreement,
                "leading_average_points": [round(v, 4) for v in lead],
                "other_average_points": [round(v, 4) for v in other],
                "bond_points": [round(v, 4) for v in bonds],
                "cost_of_living_points": [round(v, 4) for v in col],
                "rule_quote": "unless our railroad stocks returned to government ownership and guaranty",
            }

        return json.dumps({
            "result": result,
            "error": None,
            "metadata": {
                "provenance": {
                    "source_grounded": [
                        "indication by one average not clearly confirmed by the other is a short way of going wrong",
                        "government ownership and guaranty takes the average out of the speculative class",
                        "removed from the speculative class it moves downward with bonds and other fixed-income securities",
                        "such securities inevitably decline in price with an advance in the cost of living",
                    ],
                    "model_extrapolated": [
                        "bond co-movement measured as sign agreement >= 0.6 of periods",
                        "directional band of 1.0%",
                        "unmeasured conditions reported as unconfirmed rather than confirmed",
                    ],
                }
            },
        })
    except Exception as exc:
        return json.dumps({
            "result": {
                "classification": "insufficient_data",
                "exception_applies": False,
                "reason": "Could not evaluate the two averages: " + str(exc),
            },
            "error": None,
            "metadata": {
                "provenance": {
                    "source_grounded": [
                        "indication by one average not clearly confirmed by the other",
                    ],
                    "model_extrapolated": ["boundary reading on unusable input"],
                }
            },
        })