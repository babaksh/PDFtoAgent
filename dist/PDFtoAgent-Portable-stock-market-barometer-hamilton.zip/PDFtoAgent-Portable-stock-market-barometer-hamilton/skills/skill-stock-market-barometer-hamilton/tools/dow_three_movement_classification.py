import json
from typing import List, Optional


def _floats(values: Optional[List[float]]) -> List[float]:
    if not values:
        return []
    out = []
    for v in values:
        try:
            out.append(float(v))
        except (TypeError, ValueError):
            continue
    return out


async def dow_three_movement_classification(
    prices: List[float],
    primary_trend: str = "unknown",
    periods_per_year: float = 252.0,
    sharp_move_pct: float = 10.0,
    verbose: bool = True,
) -> str:
    """Classify an observed stock-market price movement as one of Dow's three simultaneous movements.

    Use when you have one observed movement -- the sequence of average prices (closes)
    spanning the move -- and you want to know which of the three movements of Dow's
    theory it is: a PRIMARY movement (bull or bear, tending to run at least a year and
    generally much longer), a SECONDARY movement (a sharp rally inside a primary bear
    market or a sharp reaction inside a primary bull market), or the underlying
    DAY-TO-DAY fluctuation that is constant throughout. Use the prevailing primary
    trend you have already established to separate a secondary rally from a secondary
    reaction; if you do not know it, pass 'unknown' and the tool will still separate
    primary from non-primary on duration.

    Do NOT use this to decide whether two averages agree -- call
    average_corroboration_check. Do NOT use it to read a narrow trading range -- call
    line_formation_breakout.

    Parameters: prices (the observed movement's average prices, oldest first),
    primary_trend ('bull', 'bear' or 'unknown' -- the prevailing primary movement the
    observed move sits inside), periods_per_year (observations per year, e.g. 252 for
    daily closes, 12 for monthly, 52 for weekly; used to convert the move's length into
    years), sharp_move_pct (net percent change that counts as a 'sharp' rally or
    reaction rather than ordinary day-to-day noise), verbose (False returns only the
    classification, direction and reason).
    """
    try:
        periods_per_year = 252.0 if periods_per_year is None else float(periods_per_year)
        sharp_move_pct = 10.0 if sharp_move_pct is None else float(sharp_move_pct)
        if periods_per_year <= 0:
            periods_per_year = 252.0
        trend = (primary_trend or "unknown").strip().lower()
        if trend not in ("bull", "bear", "unknown"):
            trend = "unknown"

        series = _floats(prices)

        provenance = {
            "source_grounded": [
                "three movements are simultaneously in progress: primary, secondary, day-to-day",
                "primary movement tends to run over a period of at least a year and generally much longer",
                "secondary movement = sharp rallies in a primary bear market and sharp reactions in a primary bull market",
                "underlying day-to-day fluctuation is concurrent and constant throughout",
            ],
            "model_extrapolated": [
                "sharp_move_pct default 10.0 percent for 'sharp' rally or reaction",
                "periods_per_year default 252 to convert move length into years",
                "a sharp move WITH the prevailing trend is read as the primary movement in progress",
                "a zero net move is read as the degenerate day-to-day fluctuation, direction none",
            ],
        }
        meta = {
            "provenance": provenance,
            "parameters": {
                "periods_per_year": periods_per_year,
                "sharp_move_pct": sharp_move_pct,
                "primary_trend": trend,
            },
            "observations": len(series),
        }

        n = len(series)
        if n == 0:
            result = {
                "classification": "day_to_day",
                "direction": "none",
                "duration_years": 0.0,
                "move_pct": 0.0,
                "reason": "no prices supplied; there is no movement to classify",
            }
            return json.dumps({"result": result, "error": None, "metadata": meta})

        first = series[0]
        last = series[-1]
        move_pct = 0.0 if n < 2 or first == 0.0 else (last - first) / abs(first) * 100.0
        duration_years = (n - 1) / periods_per_year

        if move_pct > 0.0:
            direction = "up"
        elif move_pct < 0.0:
            direction = "down"
        else:
            direction = "none"

        against_trend = (
            (trend == "bear" and direction == "up") or (trend == "bull" and direction == "down")
        )
        with_trend = (
            (trend == "bull" and direction == "up") or (trend == "bear" and direction == "down")
        )

        if direction == "none":
            classification = "day_to_day"
            reason = ("the average shows no net movement over the observations supplied; a flat reading is the "
                      "degenerate day-to-day fluctuation, and neither a primary nor a secondary movement can be "
                      "claimed from it")
        elif duration_years >= 1.0:
            classification = "primary_bull" if direction == "up" else "primary_bear"
            reason = ("the move has run %.2f years, at least the year a primary movement tends to run (and "
                      "generally much longer), so it is read as a primary %s market"
                      % (duration_years, "bull" if direction == "up" else "bear"))
        elif abs(move_pct) >= sharp_move_pct and against_trend:
            if trend == "bear":
                classification = "secondary_rally"
                reason = ("a sharp %.2f%% advance lasting %.2f years against the prevailing primary bear market: "
                          "this is a secondary rally in a bear market" % (move_pct, duration_years))
            else:
                classification = "secondary_reaction"
                reason = ("a sharp %.2f%% decline lasting %.2f years against the prevailing primary bull market: "
                          "this is a secondary reaction in a bull market" % (abs(move_pct), duration_years))
        elif abs(move_pct) >= sharp_move_pct and with_trend:
            classification = "primary"
            reason = ("a sharp %.2f%% move lasting %.2f years with the prevailing primary %s market: it is not a "
                      "secondary movement (those run against the trend) and is read as part of the primary "
                      "movement in progress, still short of the one-year primary threshold"
                      % (abs(move_pct), duration_years, trend))
        elif abs(move_pct) >= sharp_move_pct:
            classification = "secondary"
            reason = ("a sharp %.2f%% move lasting %.2f years, but the prevailing primary trend is unknown, so it "
                      "cannot be separated into a secondary rally in a bear market or a secondary reaction in a "
                      "bull market" % (abs(move_pct), duration_years))
        else:
            classification = "day_to_day"
            reason = ("a %.2f%% move lasting %.2f years is neither a year-long primary movement nor a sharp "
                      "rally or reaction: it belongs to the underlying day-to-day fluctuation that is constant "
                      "throughout" % (move_pct, duration_years))

        result = {
            "classification": classification,
            "direction": direction,
            "duration_years": duration_years,
            "move_pct": move_pct,
            "sharp_move_pct_used": sharp_move_pct,
            "reason": reason,
        }

        if verbose:
            result["start_price"] = first
            result["end_price"] = last
            result["observations"] = n
            result["primary_trend_given"] = trend
            result["movement_family"] = classification.split("_")[0]

        return json.dumps({"result": result, "error": None, "metadata": meta})
    except Exception as exc:
        return json.dumps({"result": None, "error": str(exc), "metadata": {}})