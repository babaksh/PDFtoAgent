import json
from typing import Optional


async def manipulation_distribution_price_durability_test(
    manipulation_sale_price: float,
    bear_market_low_price: float,
    dividends_received_per_share: Optional[float] = None,
    par_value_per_share: Optional[float] = None,
    breakeven_tolerance_pct: float = 0.0,
    verbose: bool = True,
) -> str:
    """Judge the lasting effect of a manipulated distribution against a later bear-swing low.

    Use when you know the price at which a manipulation sold stock to the public
    and the low price that stock reached in a later major bear swing, and you
    want the chapter's own verdict on whether the people who paid for the stock
    and put it away were harmed.

    The chapter's case: the distribution of United States Steel common and
    preferred, made in the major swing of a great bull market, was brought about
    largely by the most stupendous manipulation the market ever saw, under James
    R. Keene. The end of that manipulation was to sell the common at fifty and
    the preferred at par. The chapter's question: "If the people who bought at
    those prices put the stock away after paying for it, would they have anything
    to regret even at the low market prices of August, 1921, attained after a
    major bear swing of unusually long duration?"

    Returns the durability verdict, the points and percentage of regret, and the
    bear low as a percentage of the manipulation price.

    Do NOT use this to settle a charge of water in a capitalization (that is
    `water_in_capitalization_test`), and do NOT use it to judge whether a
    manipulation could move a whole average (that is
    `manipulation_scope_by_movement_classifier`).
    """
    provenance = {
        "source_grounded": [
            "the distribution was brought about largely by the most stupendous manipulation the market ever saw, under James R. Keene",
            "the end of that manipulation was to sell the common stock at fifty and the preferred at par",
            "the people who bought at those prices put the stock away after paying for it",
            "the low market prices of August, 1921, attained after a major bear swing of unusually long duration",
            "verdict framing: would they have anything to regret",
            "Amalgamated Copper: the market knocked one hundred points off the highest figure attained in a general bull market",
        ],
        "model_extrapolated": [
            "breakeven_tolerance_pct = 0.0 (any shortfall below the manipulation price, however small, is regret; the chapter's question is whether there is ANYTHING to regret)",
            "dividends_received_per_share = 0.0 when not supplied: the chapter's question is asked purely on price, but income received while the stock was put away is credited when supplied",
            "net position = bear_market_low_price + dividends received, compared with the manipulation sale price",
            "verdict ladder: no_regret / small_regret / regret / unmeasurable",
            "three-way sign so exact breakeven is not folded onto either side",
        ],
    }
    try:
        sale = 0.0 if manipulation_sale_price is None else float(manipulation_sale_price)
        low = 0.0 if bear_market_low_price is None else float(bear_market_low_price)
        div = 0.0 if dividends_received_per_share is None else float(dividends_received_per_share)
        tol = 0.0 if breakeven_tolerance_pct is None else float(breakeven_tolerance_pct)
        par = None if par_value_per_share is None else float(par_value_per_share)

        par_position = None
        if par is not None and par > 0.0:
            par_position = {
                "bear_low_pct_of_par": low / par * 100.0,
                "bear_low_above_par": low > par,
                "sale_pct_of_par": sale / par * 100.0,
            }

        net_position = low + div
        regret_points = sale - net_position
        regret_pct = None
        if sale > 0.0:
            regret_pct = regret_points / sale * 100.0
        low_pct_of_sale = None
        if sale > 0.0:
            low_pct_of_sale = low / sale * 100.0

        if sale <= 0.0:
            verdict = "unmeasurable"
            reason = ("The manipulation sale price is %.2f, so no regret can be measured. The chapter's "
                      "question compares the price the manipulation sold stock at against the later "
                      "bear-swing low; supply a positive sale price." % sale)
        elif regret_pct is not None and regret_pct <= tol:
            verdict = "no_regret"
            reason = ("Against a manipulation sale price of %.2f, the bear-swing low of %.2f plus %.2f "
                      "of dividends gives a position of %.2f, i.e. %.2f%% of what was paid. That is at "
                      "or above breakeven within the %.2f%% tolerance, so the buyers who paid for the "
                      "stock and put it away have nothing to regret even at the low prices of the "
                      "major bear swing." % (sale, low, div, net_position,
                                             low_pct_of_sale if low_pct_of_sale is not None else 0.0,
                                             tol))
        elif regret_pct is not None and regret_pct <= 20.0:
            verdict = "small_regret"
            reason = ("The bear-swing low of %.2f plus %.2f of dividends leaves the buyer %.2f points, "
                      "or %.2f%%, below the %.2f manipulation sale price. There is something to regret, "
                      "but the manipulation's price has largely held through a major bear swing."
                      % (low, div, regret_points, regret_pct, sale))
        elif regret_pct is not None:
            verdict = "regret"
            reason = ("The bear-swing low of %.2f plus %.2f of dividends leaves the buyer %.2f points, "
                      "or %.2f%%, below the %.2f manipulation sale price -- the low is only %.2f%% of "
                      "what was paid. The buyers who paid for the stock and put it away would have "
                      "something to regret at those low prices."
                      % (low, div, regret_points, regret_pct, sale,
                         low_pct_of_sale if low_pct_of_sale is not None else 0.0))
        else:
            verdict = "unmeasurable"
            reason = ("Neither the sale price nor the bear low supports a comparison; supply positive "
                      "prices for both.")

        result = {
            "verdict": verdict,
            "reason": reason,
            "manipulation_sale_price": sale,
            "bear_market_low_price": low,
            "dividends_received_per_share": div,
            "net_position_per_share": net_position,
            "regret_points": regret_points,
            "regret_pct": regret_pct,
            "low_pct_of_sale_price": low_pct_of_sale,
            "breakeven_tolerance_pct": tol,
            "par_value_per_share": par,
            "par_reference": par_position,
        }
        if verbose:
            result["params"] = {
                "breakeven_tolerance_pct": tol,
                "dividends_received_per_share": div,
            }
            result["note"] = ("The distribution was made in the major swing of a great bull market by "
                              "the most stupendous manipulation the market ever saw; the question is "
                              "what was left of it after a major bear swing of unusually long "
                              "duration.")
        return json.dumps({"result": result, "error": None,
                           "metadata": {"provenance": provenance}})
    except Exception as exc:
        return json.dumps({"result": None, "error": str(exc),
                           "metadata": {"provenance": provenance}})