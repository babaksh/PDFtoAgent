"""Rebut a charge of manipulation by showing recorded sales are at a multi-year low.

Extends `manipulation_advance_plausibility_test` (chMAJOR MARKET SWINGS):
that earlier test judges whether an advance could plausibly have been
manipulated from the price path. This one adds the condition the earlier test
lacks -- the volume of sales. The chapter's own instance: "the recorded sales
at that time were the lowest since 1904, indicating a market so narrow that
manipulation would have been wasted even if it had been possible", so narrow
that "the volume of sales itself would be sufficient to make my point".
"""

import json
import math
from typing import List, Optional


def _clean(values) -> List[float]:
    if not values:
        return []
    out = []
    for v in values:
        try:
            f = float(v)
        except (TypeError, ValueError):
            continue
        if math.isnan(f) or math.isinf(f):
            continue
        out.append(f)
    return out


async def manipulation_implausibility_from_narrow_volume_test(
    recorded_sales: List[float],
    sales_years: Optional[List[float]] = None,
    current_sales: Optional[float] = None,
    lookback_years: float = 25.0,
    near_low_tolerance_pct: float = 10.0,
    verbose: bool = True,
) -> str:
    """Rebut a manipulation charge by testing whether recorded sales stand at a multi-year low.

    Use when someone alleges that a rise (or a fall) was produced by
    manipulation and you have the recorded volume of sales. The chapter's
    argument: if sales are the lowest in many years the market is too narrow for
    manipulation to have been worth attempting -- it would have been wasted even
    if possible. The tool compares the present sales level against the low of a
    multi-year lookback and rules whether the charge is rebutted by narrowness.

    Do NOT use this to accuse anyone: it only tests the rebuttal. Do NOT use it
    on a series with no history -- the test is a comparison against a multi-year
    low, so a single observation supports no conclusion.

    Args:
        recorded_sales: recorded sales / traded volume series, oldest first.
        sales_years: calendar years (or period labels as numbers) matching `recorded_sales`.
        current_sales: present sales level if it is not the last element of `recorded_sales`.
        lookback_years: years of history treated as the baseline (chapter uses 25, and "lowest since 1904").
        near_low_tolerance_pct: how far above the lookback low still counts as "at or near" it.
        verbose: False returns the compact verdict; True adds the baseline detail.

    Returns:
        JSON {"result": {...}, "error": None, "metadata": {...}} with
        `manipulation_rebutted`, `narrow_market` and a short `reason`.
    """
    try:
        near_low_tolerance_pct = (
            10.0 if near_low_tolerance_pct is None else float(near_low_tolerance_pct)
        )
        try:
            lookback_years = 25.0 if lookback_years is None else float(lookback_years)
        except (TypeError, ValueError):
            lookback_years = 25.0

        sales = _clean(recorded_sales)
        years = _clean(sales_years) if sales_years else []

        if current_sales is not None:
            try:
                now = float(current_sales)
            except (TypeError, ValueError):
                now = sales[-1] if sales else 0.0
            history = list(sales)
        else:
            now = sales[-1] if sales else 0.0
            history = list(sales[:-1]) if len(sales) > 1 else []

        n_history = len(history)

        if not sales:
            return json.dumps({
                "result": {
                    "manipulation_rebutted": False,
                    "narrow_market": False,
                    "sales_level": 0.0,
                    "reason": "No recorded sales supplied, so narrowness cannot be established "
                              "and the charge is not rebutted by this test.",
                    "baseline_years_used": 0,
                },
                "error": None,
                "metadata": {
                    "provenance": {
                        "source_grounded": [
                            "recorded sales lowest since 1904",
                            "market so narrow that manipulation would have been wasted",
                        ],
                        "model_extrapolated": ["empty-input boundary reading"],
                    }
                },
            })

        # Restrict the baseline to the stated lookback when years are supplied.
        baseline = list(history)
        baseline_years_used = n_history
        if years and len(years) >= len(sales):
            end_year = years[len(sales) - 1]
            cutoff = end_year - lookback_years
            pairs = []
            for i in range(len(history)):
                y = years[i] if i < len(years) else None
                if y is None or y >= cutoff:
                    pairs.append(history[i])
            if pairs:
                baseline = pairs
                baseline_years_used = len(pairs)
        elif baseline and lookback_years > 0 and len(baseline) > lookback_years:
            baseline = baseline[-int(lookback_years):]
            baseline_years_used = len(baseline)

        if baseline:
            baseline_low = min(baseline)
            baseline_mean = sum(baseline) / len(baseline)
        else:
            baseline_low = now
            baseline_mean = now

        denom = abs(baseline_low) if baseline_low != 0.0 else 1.0
        excess_over_low_pct = (now - baseline_low) / denom * 100.0
        ratio_to_mean = now / baseline_mean if baseline_mean != 0.0 else None

        at_or_near_low = excess_over_low_pct <= near_low_tolerance_pct
        is_lowest = now <= baseline_low

        if not baseline:
            verdict = "not_established"
            narrow = False
            rebutted = False
            reason = ("Only one observation of sales is available; the test is a comparison "
                      "against a multi-year low, so narrowness is not established.")
        elif at_or_near_low:
            narrow = True
            rebutted = True
            verdict = "rebutted_by_narrow_volume"
            if excess_over_low_pct >= 0.0:
                position = (" stand " + format(excess_over_low_pct, ".1f") + "% above the "
                            + str(baseline_years_used) + "-period low")
            else:
                position = (" are " + format(-excess_over_low_pct, ".1f") + "% below the "
                            + str(baseline_years_used) + "-period low")
            reason = ("Recorded sales of " + format(now, ".4g") + position
                      + (" and are themselves the lowest in the record" if is_lowest else "")
                      + ", so the market was too narrow for manipulation to have been worth "
                        "attempting; it would have been wasted even if it had been possible.")
        else:
            narrow = False
            rebutted = False
            verdict = "not_rebutted"
            reason = ("Recorded sales of " + format(now, ".4g") + " stand "
                      + format(excess_over_low_pct, ".1f")
                      + "% above the " + str(baseline_years_used)
                      + "-period low in the baseline, outside the "
                      + format(near_low_tolerance_pct, ".1f")
                      + "% near-low band; the volume of sales does not rebut the charge.")

        result = {
            "verdict": verdict,
            "manipulation_rebutted": rebutted,
            "narrow_market": narrow,
            "sales_level": round(now, 4),
            "baseline_low": round(baseline_low, 4),
            "baseline_mean": round(baseline_mean, 4),
            "excess_over_low_pct": round(excess_over_low_pct, 4),
            "is_lowest_in_baseline": is_lowest,
            "baseline_years_used": baseline_years_used,
            "reason": reason,
        }
        if verbose:
            result["detail"] = {
                "lookback_years": lookback_years,
                "near_low_tolerance_pct": near_low_tolerance_pct,
                "ratio_to_baseline_mean": None if ratio_to_mean is None else round(ratio_to_mean, 4),
                "baseline_series": [round(v, 4) for v in baseline],
                "rule_quote": "a market so narrow that manipulation would have been wasted even if it had been possible",
            }

        return json.dumps({
            "result": result,
            "error": None,
            "metadata": {
                "provenance": {
                    "source_grounded": [
                        "recorded sales lowest since 1904",
                        "twenty-five-year chart of recorded sales",
                        "market so narrow that manipulation would have been wasted even if possible",
                        "volume of sales itself sufficient to make the point",
                    ],
                    "model_extrapolated": [
                        "near-low tolerance of 10.0% above the lookback low",
                        "lookback baseline of 25 years applied when years are given",
                    ],
                }
            },
        })
    except Exception as exc:
        return json.dumps({
            "result": {
                "verdict": "not_established",
                "manipulation_rebutted": False,
                "narrow_market": False,
                "reason": "Could not evaluate the recorded sales series: " + str(exc),
            },
            "error": None,
            "metadata": {
                "provenance": {
                    "source_grounded": ["market so narrow that manipulation would have been wasted"],
                    "model_extrapolated": ["boundary reading on unusable input"],
                }
            },
        })