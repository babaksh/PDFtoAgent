import json
from typing import List, Optional


def _floats(values: Optional[List[float]]) -> List[float]:
    if not values:
        return []
    out = []
    for v in values:
        try:
            out.append(float(v))
        except (TypeError, ValueError):
            continue
    return out


def _changes(series: List[float]) -> List[float]:
    out = []
    for i in range(1, len(series)):
        prev = series[i - 1]
        cur = series[i]
        if prev == 0.0:
            out.append(0.0)
        else:
            out.append((cur - prev) / abs(prev) * 100.0)
    return out


def _pearson(a: List[float], b: List[float]) -> Optional[float]:
    n = len(a)
    if n < 2:
        return None
    ma = sum(a) / n
    mb = sum(b) / n
    sa = sum((x - ma) ** 2 for x in a)
    sb = sum((y - mb) ** 2 for y in b)
    if sa <= 0.0 or sb <= 0.0:
        return None
    cov = sum((a[i] - ma) * (b[i] - mb) for i in range(n))
    return cov / (sa ** 0.5 * sb ** 0.5)


async def index_vintage_comparability_test(
    rebuilt_average: List[float],
    recorded_average: List[float],
    min_correlation: float = 0.9,
    min_sign_agreement: float = 0.8,
    max_deviation_pct: float = 2.0,
    verbose: bool = True,
) -> str:
    """Test whether a rebuilt average (new constituent list) still reproduces the recorded average.

    Use when the constituent list of an average has been changed -- for example the
    industrials raised from twelve stocks to twenty -- and you have carried the NEW list
    back over previous years to rebuild the old record. Pass the rebuilt series and the
    originally recorded series for the same periods and the tool compares them
    period by period, as the students of the averages did: if the fluctuations of the
    rebuilt average coincide with the recorded fluctuations almost from day to day, the
    price record remains comparable and readings taken across the change of constituents
    are still valid.

    Do NOT use this to test whether two DIFFERENT averages corroborate each other -- call
    average_corroboration_check. Do NOT use it to read a breakout from a range -- call
    line_formation_breakout.

    Parameters: rebuilt_average (the new constituent list carried back over the earlier
    years), recorded_average (the original average as it was recorded then, aligned
    period by period with the rebuilt series), min_correlation (correlation of the two
    period-to-period change series required for coincidence), min_sign_agreement
    (fraction of periods in which both series must move the same way), max_deviation_pct
    (largest tolerated gap, in percentage points, between the two series' period
    changes), verbose (False returns only the verdict and the three coincidence metrics).
    """
    try:
        min_correlation = 0.9 if min_correlation is None else float(min_correlation)
        min_sign_agreement = 0.8 if min_sign_agreement is None else float(min_sign_agreement)
        max_deviation_pct = 2.0 if max_deviation_pct is None else float(max_deviation_pct)

        a, b, n = _align(_floats(rebuilt_average), _floats(recorded_average))

        provenance = {
            "source_grounded": [
                "when constituents change, carry the new list back over previous years",
                "compare the rebuilt fluctuations against the recorded average",
                "coincidence almost from day to day means the rebuilt average still reproduces the old one",
            ],
            "model_extrapolated": [
                "coincidence tested on period-to-period percent changes, not price levels",
                "min_correlation default 0.9 for 'almost from day to day'",
                "min_sign_agreement default 0.8 of periods moving the same way",
                "max_deviation_pct default 2.0 percentage points between the two period changes",
            ],
        }
        meta = {
            "provenance": provenance,
            "parameters": {
                "min_correlation": min_correlation,
                "min_sign_agreement": min_sign_agreement,
                "max_deviation_pct": max_deviation_pct,
            },
            "periods_compared": n,
        }

        if n < 3:
            result = {
                "comparable": False,
                "verdict": "insufficient_data",
                "reason": "at least three aligned periods are needed to compare fluctuations; got %d" % n,
            }
            return json.dumps({"result": result, "error": None, "metadata": meta})

        ca = _changes(a)
        cb = _changes(b)

        corr = _pearson(ca, cb)
        devs = [abs(ca[i] - cb[i]) for i in range(len(ca))]
        max_dev = max(devs) if devs else 0.0
        mean_dev = sum(devs) / len(devs) if devs else 0.0

        moving = 0
        agree = 0
        for i in range(len(ca)):
            da = ca[i]
            db = cb[i]
            if da == 0.0 and db == 0.0:
                continue
            moving += 1
            if (da > 0 and db > 0) or (da < 0 and db < 0):
                agree += 1
        sign_agreement = (agree / moving) if moving else 1.0

        corr_ok = corr is not None and corr >= min_correlation
        sign_ok = sign_agreement >= min_sign_agreement
        dev_ok = max_dev <= max_deviation_pct

        if corr is None:
            verdict = "inconclusive"
            reason = ("one of the two series shows no variation over the periods supplied, so the fluctuation "
                      "coincidence cannot be measured")
        elif corr_ok and sign_ok and dev_ok:
            verdict = "comparable"
            reason = ("the rebuilt average reproduces the recorded one almost period by period: the price record "
                      "remains comparable across the change of constituents")
        else:
            failed = []
            if not corr_ok:
                failed.append("the period changes correlate at %.3f, below the required %.3f" % (corr, min_correlation))
            if not sign_ok:
                failed.append("only %.1f%% of periods move the same way, below the required %.1f%%"
                              % (sign_agreement * 100.0, min_sign_agreement * 100.0))
            if not dev_ok:
                failed.append("the largest gap between the two period changes is %.3f points, above the tolerated %.3f"
                              % (max_dev, max_deviation_pct))
            verdict = "not_comparable"
            reason = ("the rebuilt average does not coincide with the recorded one: " + "; ".join(failed)
                      + ". Readings taken across the change of constituents are not supported.")

        result = {
            "comparable": verdict == "comparable",
            "verdict": verdict,
            "change_correlation": corr,
            "sign_agreement": sign_agreement,
            "max_abs_change_deviation": max_dev,
            "periods_compared": n,
            "changes_compared": len(ca),
            "reason": reason,
        }

        if verbose:
            result["mean_abs_change_deviation"] = mean_dev
            result["thresholds"] = {
                "min_correlation": min_correlation,
                "min_sign_agreement": min_sign_agreement,
                "max_deviation_pct": max_deviation_pct,
            }
            result["checks"] = {
                "correlation_passed": corr_ok,
                "sign_agreement_passed": sign_ok,
                "deviation_passed": dev_ok,
            }
            result["rebuilt_changes"] = ca
            result["recorded_changes"] = cb

        return json.dumps({"result": result, "error": None, "metadata": meta})
    except Exception as exc:
        return json.dumps({"result": None, "error": str(exc), "metadata": {}})


def _align(a: List[float], b: List[float]):
    n = min(len(a), len(b))
    return a[:n], b[:n], n