import json
from typing import Optional


async def forced_liquidation_bargain_detector(
    price: float,
    value_estimate: float,
    uncertainty_index: Optional[float] = None,
    uncertainty_series: Optional[list] = None,
    forced_selling_share: Optional[float] = None,
    cash_available: bool = True,
    min_discount_pct: float = 10.0,
    uncertainty_threshold_pct: float = 80.0,
    forced_selling_threshold: float = 0.5,
    verbose: bool = True,
) -> str:
    """Detect the Rothschild bargain: forced selling plus maximum uncertainty puts price below value.

    Use when you have a price, an estimate of what the security is worth, some
    measure of how uncertain the outlook is, and evidence of general forced
    selling, and you want the chapter's decision -- buy, or wait.

    The chapter's case: the Rothschild of the days of Waterloo, a week before
    the result of that battle was known, was buying British consols at
    fifty-four. Asked how he could buy with such confidence on an outlook so
    uncertain, he said that if the outlook were certain consols would not be
    selling at fifty-four. He knew that with that uncertainty they must
    necessarily be selling below their value. Everybody needed money at the same
    time, and he was one of the few people who had any. Russell Sage's version:
    hold quick liquid assets "not to hoard but to buy freely when people who had
    lost sight of values were selling."

    Three conditions, all required: (1) the price is below the value estimate by
    at least `min_discount_pct`; (2) uncertainty is at or near its height --
    supply `uncertainty_index` (0-100) or an `uncertainty_series` from which the
    percentile of the present reading is taken; (3) the need for cash is general,
    measured by `forced_selling_share`. A fourth, buyer-side condition: you must
    have cash when others have none (`cash_available`).

    Extends `value_convergence_market_reading` (ch04): that tool asks whether a
    price is advancing toward an expected value at a horizon; this one names the
    two conditions that open the price-below-value gap -- maximum uncertainty and
    a universal need for cash -- plus the buyer-side condition of holding cash.

    Do NOT use it to test whether a decline has culminated from earnings and
    prices (that is `earnings_yield_vs_price_rise_culmination_test`).
    """
    provenance = {
        "source_grounded": [
            "if the outlook were certain consols would not be selling at fifty-four",
            "with that uncertainty they must necessarily be selling below their value",
            "everybody needed money at the same time",
            "he was one of the few people who had any (money)",
            "people who had lost sight of values were selling",
            "quick and liquid assets -- not to hoard but to buy freely",
            "prices will have passed below the line of values at the close of a major downward movement",
            "people have been compelled to realize their holdings at less than their normal worth, less indeed than book value",
        ],
        "model_extrapolated": [
            "min_discount_pct = 10.0 (how far below the value estimate counts as a bargain)",
            "uncertainty_threshold_pct = 80.0 (the present uncertainty reading's percentile of its own record that counts as 'at its height')",
            "forced_selling_threshold = 0.5 (share of observed sellers forced to sell that counts as 'everybody')",
            "uncertainty_index read on a 0-100 scale and, when a series is given, converted to its percentile within that series",
            "cash_available default True, the buyer-side condition the chapter states",
            "verdict ladder: buy / wait / no_bargain / unmeasurable",
            "three-way discount sign: premium, discount and exact parity are distinguished",
        ],
    }
    try:
        px = 0.0 if price is None else float(price)
        val = 0.0 if value_estimate is None else float(value_estimate)
        min_disc = 10.0 if min_discount_pct is None else float(min_discount_pct)
        unc_thr = 80.0 if uncertainty_threshold_pct is None else float(uncertainty_threshold_pct)
        frc_thr = 0.5 if forced_selling_threshold is None else float(forced_selling_threshold)
        has_cash = True if cash_available is None else bool(cash_available)

        discount_pct = None
        if val > 0.0:
            discount_pct = (val - px) / val * 100.0

        uncertainty_reading = None
        uncertainty_percentile = None
        if uncertainty_index is not None:
            uncertainty_reading = float(uncertainty_index)
        elif uncertainty_series:
            series = [0.0 if u is None else float(u) for u in uncertainty_series]
            if series:
                uncertainty_reading = series[-1]
                below = sum(1 for u in series if u < uncertainty_reading)
                equal = sum(1 for u in series if u == uncertainty_reading)
                uncertainty_percentile = (below + 0.5 * equal) / len(series) * 100.0

        uncertainty_at_height = None
        if uncertainty_percentile is not None:
            uncertainty_at_height = uncertainty_percentile >= unc_thr
        elif uncertainty_reading is not None:
            uncertainty_at_height = uncertainty_reading >= unc_thr

        general_need_for_cash = None
        if forced_selling_share is not None:
            general_need_for_cash = float(forced_selling_share) >= frc_thr

        price_below_value = None
        if discount_pct is not None:
            if discount_pct > 0.0:
                price_below_value = True
            elif discount_pct < 0.0:
                price_below_value = False
            else:
                price_below_value = False

        bargain_gap = None
        if discount_pct is not None:
            bargain_gap = discount_pct >= min_disc

        conditions = [
            ("price_below_value_by_at_least_the_minimum", bargain_gap),
            ("uncertainty_at_its_height", uncertainty_at_height),
            ("general_need_for_cash", general_need_for_cash),
            ("buyer_has_cash_when_others_have_none", has_cash),
        ]
        evaluated = [c for c in conditions if c[1] is not None]
        conditions_evaluated = len(evaluated)
        conditions_met = sum(1 for _, ok in evaluated if ok)

        if val <= 0.0:
            verdict = "unmeasurable"
            reason = ("The value estimate is %.2f, so no discount of price to value can be formed. The "
                      "chapter's decision rests on the price selling below the value; supply a "
                      "positive value estimate." % val)
        elif all(ok for _, ok in evaluated) and conditions_evaluated > 0:
            verdict = "buy"
            reason = ("All %d conditions hold: the price %.2f is %.2f%% below the value estimate %.2f "
                      "(at least the %.2f%% required), uncertainty stands at its height, everybody "
                      "needs money at the same time, and the buyer has cash when others have none. "
                      "This is the Rothschild case -- with that uncertainty the price must necessarily "
                      "be selling below its value, so buy freely rather than hoard."
                      % (conditions_evaluated, px, discount_pct, val, min_disc))
        elif bargain_gap is False:
            verdict = "no_bargain"
            reason = ("The price %.2f is not below the value estimate %.2f by the required %.2f%% "
                      "(discount %.2f%%). Whatever the uncertainty, there is no price-below-value gap "
                      "to buy." % (px, val, min_disc, discount_pct))
        else:
            missing = [name for name, ok in conditions if ok is None or ok is False]
            verdict = "wait"
            reason = ("The price %.2f stands %.2f%% below the value estimate %.2f, so a gap exists, "
                      "but %d of the conditions the chapter names are not established (%s). Rothschild "
                      "bought only when the uncertainty was at its height and everybody needed money "
                      "at the same time; until those are shown, wait."
                      % (px, discount_pct, val, len(missing), ", ".join(missing)))

        result = {
            "verdict": verdict,
            "reason": reason,
            "price": px,
            "value_estimate": val,
            "discount_pct_of_value": discount_pct,
            "price_below_value": price_below_value,
            "bargain_gap_sufficient": bargain_gap,
            "uncertainty_index": uncertainty_reading,
            "uncertainty_percentile_of_record": uncertainty_percentile,
            "uncertainty_at_its_height": uncertainty_at_height,
            "forced_selling_share": (None if forced_selling_share is None else float(forced_selling_share)),
            "general_need_for_cash": general_need_for_cash,
            "buyer_has_cash": has_cash,
            "conditions_met": conditions_met,
            "conditions_evaluated": conditions_evaluated,
        }
        if verbose:
            result["conditions"] = [{"condition": n, "met": ok} for n, ok in conditions]
            result["params"] = {
                "min_discount_pct": min_disc,
                "uncertainty_threshold_pct": unc_thr,
                "forced_selling_threshold": frc_thr,
                "cash_available": has_cash,
            }
            result["note"] = ("If the outlook were certain consols would not be selling at "
                              "fifty-four.")
        return json.dumps({"result": result, "error": None,
                           "metadata": {"provenance": provenance}})
    except Exception as exc:
        return json.dumps({"result": None, "error": str(exc),
                           "metadata": {"provenance": provenance}})