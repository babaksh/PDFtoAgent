import json
import math
from typing import List, Optional


def _round_to_eighth(value: float) -> float:
    return math.floor(value * 8.0 + 0.5) / 8.0


def _floor_to_eighth(value: float) -> float:
    return math.floor(value * 8.0) / 8.0


async def market_turn_effective_execution_price(
    bid: Optional[float] = None,
    asked: Optional[float] = None,
    side: str = "buy",
    is_floor_trader: bool = False,
    price: float = 0.0,
    activity_shares: Optional[float] = None,
    typical_activity_shares: float = 0.0,
    market_turn_pct: float = 0.25,
    floor_trader_turn_saved_pct: float = 100.0,
    verbose: bool = True,
) -> str:
    """Compute the price an order will actually get -- the customer sells at the bid and buys at the asked, while the floor trader may deal at the middle -- and the turn it costs, estimating the turn from activity when no quote is available.

    Use when you need the real fill, not the nominal price. The chapter's worked
    example: United States Steel common at 90-1/4 bid and 90-1/2 asked -- the
    customer who sells cannot expect better than 90-1/4, while to buy he must
    pay 90-1/2; the floor trader can often save the turn or part of it, dealing
    at 90-3/8 or even selling at the asked price. If you have no quote, pass the
    stock's activity (volume) and a reference activity: the more active the
    stock, the closer the turn, which otherwise averages a quarter of one per
    cent.

    Do NOT use this to judge whether a quick turn is worth attempting after
    commissions -- call round_trip_friction_quick_turn_test for that.

    Args:
        bid: the bid price, if a quote is available.
        asked: the asked price, if a quote is available.
        side: "buy" or "sell" -- what the order is trying to do.
        is_floor_trader: True for the member dealing for himself (he may deal at
            the middle, or even sell at the asked price).
        price: reference price, used when no quote is available to build the
            quoted spread from the estimated turn.
        activity_shares: the stock's activity (volume), used to estimate the
            turn when no quote is available.
        typical_activity_shares: the reference activity against which a stock
            counts as active; the turn narrows toward the active end.
        market_turn_pct: the average turn, per cent, used as the fallback and as
            the wide end of the activity scale (default 0.25, a quarter of one
            per cent).
        floor_trader_turn_saved_pct: share of the turn the floor trader saves
            for himself (default 100.0 = he deals at the middle).
        verbose: False returns the compact result; True adds the full breakdown.

    Returns:
        JSON string with result/error/metadata. Result holds the effective
        execution price, the quoted and estimated turn, the source of the quote,
        and the turn paid in points and per cent.
    """
    try:
        side_l = (side or "buy").strip().lower()
        if side_l not in ("buy", "sell"):
            side_l = "buy"
        floor = bool(is_floor_trader)
        turn_pct_default = float(market_turn_pct) if market_turn_pct is not None else 0.25

        estimated_turn_pct = None
        if activity_shares is not None:
            act = float(activity_shares)
            ref = float(typical_activity_shares) if typical_activity_shares else 0.0
            if ref <= 0.0:
                ref = max(act, 1.0)
            ratio = act / ref if ref > 0.0 else 1.0
            estimated_turn_pct = turn_pct_default / ratio if ratio > 0.0 else turn_pct_default
            if estimated_turn_pct > turn_pct_default * 2.0:
                estimated_turn_pct = turn_pct_default * 2.0
            estimated_turn_pct = _round_to_eighth(estimated_turn_pct * 100.0) / 100.0

        b = float(bid) if bid is not None else None
        a = float(asked) if asked is not None else None

        if b is not None and a is not None:
            quote_source = "quoted"
            quoted_turn_points = abs(a - b)
            mid = (a + b) / 2.0
            if mid > 0.0:
                quoted_turn_pct = quoted_turn_points / mid * 100.0
            else:
                quoted_turn_pct = 0.0
        else:
            px = float(price) if price is not None else 0.0
            turn_pts = (
                estimated_turn_pct if estimated_turn_pct is not None else turn_pct_default
            ) / 100.0 * px
            quote_source = (
                "estimated_from_activity" if estimated_turn_pct is not None else "default_average"
            )
            mid = px
            b = _floor_to_eighth(px - turn_pts / 2.0)
            a = _round_to_eighth(px + turn_pts / 2.0)
            if a <= b:
                a = b + 0.125
            quoted_turn_points = abs(a - b)
            quoted_turn_pct = (quoted_turn_points / mid * 100.0) if mid > 0.0 else 0.0

        saved = (
            float(floor_trader_turn_saved_pct)
            if floor_trader_turn_saved_pct is not None
            else 100.0
        )
        saved = max(0.0, min(100.0, saved))

        if side_l == "buy":
            customer_price = a
            floor_price = (
                _round_to_eighth(mid + (a - mid) * (1.0 - saved / 100.0))
                if floor
                else a
            )
        else:
            customer_price = b
            floor_price = (
                _round_to_eighth(mid - (mid - b) * (1.0 - saved / 100.0))
                if floor
                else b
            )
            if floor and saved >= 100.0:
                floor_price = _round_to_eighth(mid)

        effective_price = floor_price if floor else customer_price
        turn_paid_points = abs(effective_price - mid)
        turn_paid_pct = (turn_paid_points / mid * 100.0) if mid > 0.0 else 0.0

        result = {
            "side": side_l,
            "trader": "floor_trader" if floor else "customer",
            "bid": b,
            "asked": a,
            "midpoint": mid,
            "effective_execution_price": effective_price,
            "quoted_turn_points": quoted_turn_points,
            "quoted_turn_pct": quoted_turn_pct,
            "turn_paid_points": turn_paid_points,
            "turn_paid_pct": turn_paid_pct,
            "quote_source": quote_source,
        }
        if verbose:
            result["customer_price"] = customer_price
            result["floor_trader_price"] = floor_price
            result["estimated_turn_pct"] = estimated_turn_pct
            result["market_turn_pct_default"] = turn_pct_default
            result["floor_trader_turn_saved_pct"] = saved
            result["activity_shares"] = (
                float(activity_shares) if activity_shares is not None else None
            )
            result["typical_activity_shares"] = (
                float(typical_activity_shares) if typical_activity_shares else 0.0
            )
        return json.dumps(
            {
                "result": result,
                "error": None,
                "metadata": {
                    "provenance": {
                        "source_grounded": [
                            "market turn is the difference between the bid and asked price",
                            "customer selling gets the bid, buying pays the asked",
                            "floor trader may deal at the middle or even sell at the asked price",
                            "turn averages a quarter of one per cent",
                            "the more active the stock the closer the turn is",
                            "Steel common worked example: 90-1/4 bid, 90-1/2 asked, floor trader 90-3/8",
                        ],
                        "model_extrapolated": [
                            "activity-to-turn mapping: turn = average / (activity / reference activity)",
                            "cap of twice the average turn for inactive stocks",
                            "turn rounded to the nearest eighth of a point",
                            "floor trader credited with 100% of the turn saved by default",
                            "midpoint fallback when bid or asked is missing",
                        ],
                    }
                },
            }
        )
    except Exception as exc:
        return json.dumps(
            {
                "result": None,
                "error": str(exc),
                "metadata": {
                    "provenance": {
                        "source_grounded": [
                            "market turn is the difference between the bid and asked price",
                            "customer selling gets the bid, buying pays the asked",
                        ],
                        "model_extrapolated": [
                            "turn rounded to the nearest eighth of a point",
                            "quarter per cent default turn",
                        ],
                    }
                },
            }
        )