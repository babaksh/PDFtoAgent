import json
from typing import List, Optional


async def harvard_business_phase_sequence_taxonomy(
    phases: List[str],
    phase_years: Optional[List[float]] = None,
    allow_coincident: bool = True,
    strict_order: bool = True,
    verbose: bool = True,
) -> str:
    """Validate a labelled business-state sequence against the Harvard Committee
    on Economic Research five-phase series, and name what the sequence is doing
    now.

    Use when a caller has labelled a record of business states -- or is labelling
    one -- with the Harvard series and wants it checked. The chapter gives the
    series and its two rules verbatim: the order is "Depression," "Revival,"
    "Prosperity," "Strain," "Crisis," the chart assumes "absolute length for
    [none] of these states," and it treats "Strain" and "Crisis," or "Crisis" and
    "Panic," or "Strain" and "Panic," as "in some cases coincident."

    What it checks:
      1. Every label is one of the five states of the series, or "Panic" (which
         the chapter admits as coincident with Strain or Crisis).
      2. ORDER -- labels must not move backwards through the series. A backwards
         step is a cycle restart only when it returns to "Depression"; otherwise
         it is an out-of-order step.
      3. COINCIDENCE -- when `allow_coincident` is true, two adjacent labels may
         be the same state (or one of the permitted pairs) at the same date, and
         the tool reports them as coincident rather than as an error. With
         `allow_coincident` false, a repeated adjacent state is flagged.
      4. LENGTH -- no duration is graded as too long or too short; the tool only
         reports the observed durations, because the chapter assumes no absolute
         length. Pass `strict_order=False` to allow out-of-order labels to be
         reported as observations instead of invalidating the sequence.

    Returns the CLASSIFICATION (valid / invalid sequence) plus a REASON, the
    current phase, and the next phase the series expects.

    Do NOT use this to classify a market price movement into Dow's three
    movements (call `dow_three_movement_classification`), and do NOT use it to
    date a panic from a list of panic years (call `panic_interval_rule`).

    Args:
        phases: The labelled business states in chronological order, e.g.
            ["Depression", "Revival", "Prosperity", "Strain", "Crisis"].
        phase_years: Decimal start year of each labelled state; same length as
            `phases`. Optional -- durations are only reported when supplied.
        allow_coincident: Whether adjacent coincident states are permitted
            (default True, per the chapter).
        strict_order: Whether an out-of-order label invalidates the sequence
            (default True). Set False to have it merely reported.
        verbose: False returns classification, reason and current/next phase;
            True adds the per-step checks and durations.

    Returns:
        JSON string {"result": {...}, "error": ..., "metadata": {...}} where
        result.classification is "valid_harvard_phase_sequence",
        "invalid_harvard_phase_sequence" or "no_phases_supplied".
    """
    try:
        series = ["Depression", "Revival", "Prosperity", "Strain", "Crisis"]
        order = {name: i for i, name in enumerate(series)}
        order["Panic"] = len(series) - 1

        coincident_pairs = [
            ("Strain", "Crisis"),
            ("Crisis", "Panic"),
            ("Strain", "Panic"),
        ]
        coincident_set = set()
        for a, b in coincident_pairs:
            coincident_set.add((a, b))
            coincident_set.add((b, a))

        raw = [str(p).strip() for p in (phases or []) if p is not None and str(p).strip()]
        years_in = [float(y) for y in (phase_years or []) if y is not None]

        labels = []
        for p in raw:
            matched = None
            for name in series + ["Panic"]:
                if p.lower() == name.lower():
                    matched = name
                    break
            labels.append({"raw": p, "canonical": matched})

        def result_for(classification: str, reason: str, extra: dict) -> str:
            payload = dict(extra)
            payload["classification"] = classification
            payload["reason"] = reason
            return json.dumps(
                {
                    "result": payload,
                    "error": None,
                    "metadata": {
                        "provenance": {
                            "source_grounded": [
                                "five-phase series Depression, Revival, Prosperity, Strain, Crisis",
                                "no absolute length assumed for any state",
                                "Strain and Crisis coincident in some cases",
                                "Crisis and Panic coincident in some cases",
                                "Strain and Panic coincident in some cases",
                            ],
                            "model_extrapolated": [
                                "Panic accepted as a sixth label at the Crisis rank of the series",
                                "unknown labels reported as unrecognised rather than rejected outright",
                                "backwards step to Depression read as a cycle restart",
                                "durations reported but never graded, since no absolute length is assumed",
                                "strict_order switch controlling whether an out-of-order step invalidates",
                            ],
                        }
                    },
                }
            )

        if not raw:
            return result_for(
                "no_phases_supplied",
                "No business phases were supplied, so there is no sequence to "
                "validate against the Harvard five-phase series.",
                {
                    "valid": False,
                    "phase_count": 0,
                    "current_phase": None,
                    "next_phase": None,
                    "unrecognised_labels": [],
                    "out_of_order_steps": 0,
                    "coincident_steps": 0,
                },
            )

        unrecognised = [l["raw"] for l in labels if l["canonical"] is None]
        known = [l["canonical"] for l in labels if l["canonical"] is not None]

        steps = []
        out_of_order = 0
        coincident = 0
        restarts = 0
        for i, item in enumerate(labels):
            if i == 0:
                steps.append(
                    {
                        "index": i,
                        "phase": item["canonical"],
                        "previous_phase": None,
                        "step": "start",
                        "ok": True,
                    }
                )
                continue
            prev = labels[i - 1]["canonical"]
            cur = item["canonical"]
            if prev is None or cur is None:
                steps.append(
                    {
                        "index": i,
                        "phase": cur,
                        "previous_phase": prev,
                        "step": "unchecked",
                        "ok": True,
                    }
                )
                continue
            same_year = False
            if len(years_in) == len(labels):
                same_year = years_in[i] == years_in[i - 1]
            if prev == cur:
                coincident += 1
                step = "coincident" if same_year else "repeated"
                ok = bool(allow_coincident)
                if not ok:
                    out_of_order += 1
                steps.append(
                    {
                        "index": i,
                        "phase": cur,
                        "previous_phase": prev,
                        "step": step,
                        "ok": ok,
                    }
                )
                continue
            if order[cur] > order[prev]:
                steps.append(
                    {
                        "index": i,
                        "phase": cur,
                        "previous_phase": prev,
                        "step": "advance",
                        "ok": True,
                    }
                )
                continue
            if (prev, cur) in coincident_set:
                coincident += 1
                ok = bool(allow_coincident)
                if not ok:
                    out_of_order += 1
                steps.append(
                    {
                        "index": i,
                        "phase": cur,
                        "previous_phase": prev,
                        "step": "coincident_pair" if same_year else "permitted_reversal",
                        "ok": ok,
                    }
                )
                continue
            if cur == "Depression":
                restarts += 1
                steps.append(
                    {
                        "index": i,
                        "phase": cur,
                        "previous_phase": prev,
                        "step": "cycle_restart",
                        "ok": True,
                    }
                )
                continue
            out_of_order += 1
            steps.append(
                {
                    "index": i,
                    "phase": cur,
                    "previous_phase": prev,
                    "step": "out_of_order",
                    "ok": False,
                }
            )

        invalid_parts = []
        if unrecognised:
            invalid_parts.append(
                "unrecognised labels %s" % ", ".join(sorted(set(unrecognised)))
            )
        if out_of_order and strict_order:
            invalid_parts.append("%d out-of-order step(s)" % out_of_order)
        valid = not invalid_parts
        classification = (
            "valid_harvard_phase_sequence"
            if valid
            else "invalid_harvard_phase_sequence"
        )

        current = known[-1] if known else None
        if current == "Panic":
            next_phase = "Depression"
        elif current in ("Strain", "Crisis"):
            next_phase = "Depression"
        elif current is None:
            next_phase = None
        else:
            idx = order[current] + 1
            next_phase = series[idx] if idx < len(series) else "Depression"

        if valid:
            reason = (
                "The sequence of %d labelled states follows the Harvard series "
                "(Depression, Revival, Prosperity, Strain, Crisis): %d coincident "
                "step(s) allowed and %d cycle restart(s), with no absolute length "
                "assumed for any state. The record stands at %s, so the series "
                "expects %s next."
                % (
                    len(known),
                    coincident,
                    restarts,
                    current if current else "no recognisable phase",
                    next_phase if next_phase else "no phase",
                )
            )
        else:
            reason = (
                "The sequence does not follow the Harvard series: %s."
                % "; ".join(invalid_parts)
            )

        durations = []
        if len(years_in) == len(labels) and len(years_in) > 1:
            for i in range(len(years_in) - 1):
                durations.append(
                    {
                        "phase": labels[i]["canonical"],
                        "start_year": years_in[i],
                        "end_year": years_in[i + 1],
                        "duration_years": years_in[i + 1] - years_in[i],
                    }
                )

        result = {
            "classification": classification,
            "reason": reason,
            "valid": valid,
            "phase_count": len(known),
            "current_phase": current,
            "next_phase": next_phase,
            "unrecognised_labels": sorted(set(unrecognised)),
            "out_of_order_steps": out_of_order,
            "coincident_steps": coincident,
            "cycle_restarts": restarts,
            "series": series,
        }

        if verbose:
            result["steps"] = steps
            result["durations"] = durations
            result["coincident_pairs_permitted"] = [
                list(p) for p in coincident_pairs
            ]
            result["params"] = {
                "allow_coincident": bool(allow_coincident),
                "strict_order": bool(strict_order),
            }

        return result_for(
            classification,
            reason,
            {k: v for k, v in result.items() if k not in ("classification", "reason")},
        )
    except Exception as exc:  # pragma: no cover - defensive
        return json.dumps(
            {
                "result": None,
                "error": str(exc),
                "metadata": {
                    "provenance": {
                        "source_grounded": [],
                        "model_extrapolated": [],
                    }
                },
            }
        )