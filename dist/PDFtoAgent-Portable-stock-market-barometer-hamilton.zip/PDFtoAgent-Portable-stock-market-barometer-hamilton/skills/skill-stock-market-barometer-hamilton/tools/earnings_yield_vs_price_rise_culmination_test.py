import json
from typing import List, Optional


async def earnings_yield_vs_price_rise_culmination_test(
    surplus_earnings: List[float],
    market_prices: List[float],
    mileage: Optional[List[float]] = None,
    earnings_yield_pct: Optional[List[float]] = None,
    boom_start_index: int = 0,
    mileage_ratio_slack: float = 0.5,
    min_conditions: int = 2,
    verbose: bool = True,
) -> str:
    """Apply the 1903 Wall Street Journal test for the culmination of a decline in stocks.

    Use when you have a series of surplus earnings available for dividends and a
    matching series of market price levels (an average or a representative stock)
    over a period running back to the start of the former boom, and you want the
    chapter's own verdict on whether the decline has culminated.
    Optionally pass `mileage` (railroad mileage over the same period) and an
    explicit `earnings_yield_pct` series (earnings as a percentage of market
    price) if you already have it; otherwise the yield is computed as
    earnings / price * 100 from the two supplied series.

    The three conditions tested, exactly as the chapter states them:
      1. mileage has not increased in anything like the ratio of increase in
         surplus earnings (tested only when `mileage` is supplied);
      2. at all times the ratio of increase in surplus earnings has been in
         excess of the rise in market prices;
      3. the percentage earned on market price is now larger than at any time
         since the former boom started (`boom_start_index`).
    All evaluated conditions must hold before the chapter's cautious
    affirmative answer -- "the question may well be asked whether the decline in
    stocks has not culminated... at least some evidence in favor of an
    affirmative answer" -- is returned.

    Do NOT use this to date a turn in the averages (that is
    `primary_movement_termination_rule` / `joint_average_turn_confirmation_test`),
    and do NOT use it to value a single stock against book value (that is
    `water_in_capitalization_test`).
    """
    provenance = {
        "source_grounded": [
            "surplus earnings available for dividends",
            "rise in market prices",
            "railroad mileage has not increased in anything like the ratio of increase in surplus earnings",
            "ratio of increase in surplus earnings at all times in excess of the rise in market prices",
            "earnings percentage on market price larger than at any time since the former boom started",
            "verdict: whether the decline in stocks has not culminated, with at least some evidence affirmative",
        ],
        "model_extrapolated": [
            "mileage_ratio_slack = 0.5 (mileage growth must be under half the earnings growth to count as 'not anything like the ratio')",
            "min_conditions = 2 (minimum number of conditions that must be evaluated and met before the affirmative verdict)",
            "period-by-period growth measured against the immediately preceding period",
            "earnings yield computed as earnings / price * 100 when earnings_yield_pct is not supplied",
            "boom_start_index default 0 (whole supplied series taken as the post-boom-start record)",
            "verdict ladder: decline_may_have_culminated / partial_evidence / no_evidence",
            "three-way handling: a period of zero growth counts as not in excess",
        ],
    }
    try:
        earnings = [0.0 if e is None else float(e) for e in (surplus_earnings or [])]
        prices = [0.0 if p is None else float(p) for p in (market_prices or [])]
        supplied_yield = None
        if earnings_yield_pct:
            supplied_yield = [None if y is None else float(y) for y in earnings_yield_pct]
        miles = None
        if mileage:
            miles = [0.0 if m is None else float(m) for m in mileage]

        slack = 0.5 if mileage_ratio_slack is None else float(mileage_ratio_slack)
        need = 2 if min_conditions is None else int(min_conditions)

        n = min(len(earnings), len(prices))
        earnings = earnings[:n]
        prices = prices[:n]

        periods = []
        periods_compared = 0
        periods_in_excess = 0
        for i in range(1, n):
            e0, e1 = earnings[i - 1], earnings[i]
            p0, p1 = prices[i - 1], prices[i]
            e_growth = None
            p_growth = None
            if e0 > 0.0:
                e_growth = (e1 / e0 - 1.0) * 100.0
            if p0 > 0.0:
                p_growth = (p1 / p0 - 1.0) * 100.0
            if e_growth is not None and p_growth is not None:
                periods_compared += 1
                if e_growth > p_growth:
                    periods_in_excess += 1
            periods.append({
                "index": i,
                "earnings_growth_pct": e_growth,
                "price_rise_pct": p_growth,
                "earnings_in_excess": (e_growth > p_growth
                                       if (e_growth is not None and p_growth is not None)
                                       else None),
            })

        all_times_in_excess = None
        if periods_compared > 0:
            all_times_in_excess = (periods_in_excess == periods_compared)

        yields = []
        for i in range(n):
            if supplied_yield is not None and i < len(supplied_yield) and supplied_yield[i] is not None:
                yields.append(supplied_yield[i])
            elif prices[i] > 0.0:
                yields.append(earnings[i] / prices[i] * 100.0)
            else:
                yields.append(None)

        start = 0 if boom_start_index is None else int(boom_start_index)
        if start < 0:
            start = 0
        if start > n - 1:
            start = max(0, n - 1)

        current_yield = yields[-1] if yields else None
        prior_yields = [y for y in yields[start:n - 1] if y is not None]
        max_prior_yield = max(prior_yields) if prior_yields else None
        yield_condition_met = None
        if current_yield is not None and max_prior_yield is not None:
            yield_condition_met = current_yield > max_prior_yield

        mileage_growth_pct = None
        earnings_growth_pct = None
        mileage_condition_met = None
        if miles is not None and len(miles) >= 2:
            m0 = miles[0]
            m_last = miles[-1]
            if m0 > 0.0:
                mileage_growth_pct = (m_last / m0 - 1.0) * 100.0
            if n >= 2 and earnings[0] > 0.0:
                earnings_growth_pct = (earnings[-1] / earnings[0] - 1.0) * 100.0
            if mileage_growth_pct is not None and earnings_growth_pct is not None:
                mileage_condition_met = (earnings_growth_pct > 0.0
                                         and mileage_growth_pct < earnings_growth_pct * slack)

        conditions = [
            ("mileage_lags_earnings", mileage_condition_met),
            ("earnings_growth_exceeds_price_rise_at_all_times", all_times_in_excess),
            ("present_earnings_yield_highest_since_boom_start", yield_condition_met),
        ]
        evaluated = [c for c in conditions if c[1] is not None]
        conditions_evaluated = len(evaluated)
        conditions_met = sum(1 for _, ok in evaluated if ok)

        if conditions_evaluated == 0:
            verdict = "no_evidence"
            reason = ("None of the three conditions could be evaluated: the chapter's test needs "
                      "at least two comparable periods of surplus earnings and market prices, and "
                      "mileage if that condition is to be weighed.")
        elif conditions_met == conditions_evaluated and conditions_evaluated >= need:
            verdict = "decline_may_have_culminated"
            if mileage_growth_pct is None:
                mileage_clause = "mileage was not supplied and so was not weighed"
            else:
                mileage_clause = ("mileage growth %.2f%% against surplus-earnings growth %.2f%%"
                                  % (mileage_growth_pct,
                                     earnings_growth_pct if earnings_growth_pct is not None else 0.0))
            reason = ("All %d evaluated conditions hold: %s, earnings growth in excess of the price "
                      "rise in %d of %d periods, and a present earnings yield of %.2f%% on market "
                      "price against a maximum of %.2f%% since the former boom started. The chapter's "
                      "own answer applies: the question may well be asked whether the decline has not "
                      "culminated, and there is at least some evidence in favor of an affirmative "
                      "answer."
                      % (conditions_evaluated, mileage_clause,
                         periods_in_excess, periods_compared,
                         current_yield if current_yield is not None else 0.0,
                         max_prior_yield if max_prior_yield is not None else 0.0))
        elif conditions_met == conditions_evaluated:
            verdict = "partial_evidence"
            reason = ("Every condition that could be evaluated holds, but only %d of the three were "
                      "measurable and the chapter asks for at least %d. Supply mileage, or a longer "
                      "record running back to the former boom start, to complete the test."
                      % (conditions_evaluated, need))
        elif conditions_met > 0:
            verdict = "partial_evidence"
            reason = ("%d of %d evaluated conditions hold; the chapter grants an affirmative answer "
                      "only when the earnings growth has at all times exceeded the price rise and the "
                      "present earnings percentage on market price exceeds every point since the "
                      "former boom started." % (conditions_met, conditions_evaluated))
        else:
            verdict = "no_evidence"
            reason = ("None of the %d evaluated conditions hold, so the chapter's evidence for a "
                      "culmination of the decline is absent." % conditions_evaluated)

        result = {
            "verdict": verdict,
            "reason": reason,
            "conditions_met": conditions_met,
            "conditions_evaluated": conditions_evaluated,
            "conditions_required": need,
            "earnings_growth_pct": earnings_growth_pct,
            "price_rise_pct": ((prices[-1] / prices[0] - 1.0) * 100.0
                               if n >= 2 and prices[0] > 0.0 else None),
            "periods_compared": periods_compared,
            "periods_in_excess": periods_in_excess,
            "earnings_in_excess_at_all_times": all_times_in_excess,
            "mileage_growth_pct": mileage_growth_pct,
            "mileage_lags_earnings": mileage_condition_met,
            "current_earnings_yield_pct": current_yield,
            "max_prior_yield_since_boom_start_pct": max_prior_yield,
            "present_yield_highest_since_boom_start": yield_condition_met,
        }
        if verbose:
            result["period_growth"] = periods
            result["earnings_yield_series_pct"] = yields
            result["boom_start_index"] = start
            result["params"] = {
                "mileage_ratio_slack": slack,
                "min_conditions": need,
                "boom_start_index": start,
            }
            result["note"] = ("Wall Street Journal, December 5, 1903: the question may well be asked "
                              "whether the decline in stocks has not culminated.")
        return json.dumps({"result": result, "error": None,
                           "metadata": {"provenance": provenance}})
    except Exception as exc:
        return json.dumps({"result": None, "error": str(exc),
                           "metadata": {"provenance": provenance}})