import json
from typing import Any, Dict, List, Optional


async def crisis_cycle_halving_falsification_test(
    crisis_years: List[float],
    bull_swings: Optional[List[Dict]] = None,
    bear_swings: Optional[List[Dict]] = None,
    tolerance: float = 0.25,
    support_share: float = 0.5,
    verbose: bool = True,
) -> str:
    """Derive a predicted primary swing length by halving the crisis interval, then falsify it.

    Use when you have a list of recorded financial-crisis years (for example
    Jevons's English commercial crises: 1701, 1711, 1712, 1731-32, 1742, 1752,
    1763, 1772-3, 1783, 1793, 1804-5, 1815, 1825, 1836, 1847, 1857, 1866, 1873)
    and a set of observed primary bull and bear swings, each with a start and
    end year (or an explicit duration). Dow believed crises recur at periodic
    intervals of a little more than ten years, assumed ONE primary bull market
    and ONE primary bear market in that period, and therefore split the ten-year
    period in half -- arriving at five-year primary swings. This tool measures
    the mean interval between the crisis dates you supply, halves it into the
    predicted bull length and the predicted bear length, and then compares that
    prediction against your observed swings.

    Returns the measured mean crisis interval, the halved prediction, a per-swing
    comparison (observed length, predicted length, error, whether it matches
    within tolerance), the share of swings matching, and a verdict: whether the
    halving derivation survives or is falsified.

    Do NOT use this merely to MEASURE the interval between panics and forecast the
    next panic window -- call `panic_interval_rule` (chCYCLES AND STOCK MARKET
    RECORDS). This tool takes that measured interval one step further, into the
    halving derivation and its falsification. Do NOT use it to test a duration
    bound that was not derived from crisis intervals -- call
    `primary_swing_duration_bound_test`.

    Extends: `panic_interval_rule` (chCYCLES AND STOCK MARKET RECORDS) -- it uses
    the measured crisis interval as an input to a further step the earlier
    chapter never named: halving it into one bull and one bear half and
    falsifying that derivation against observed primary swing lengths.
    """
    try:
        tolerance = 0.25 if tolerance is None else float(tolerance)
        support_share = 0.5 if support_share is None else float(support_share)
        years = sorted(float(y) for y in (crisis_years or []) if y is not None)
        if len(years) < 2:
            return json.dumps({
                "result": {
                    "n_crises": len(years),
                    "mean_crisis_interval_years": None,
                    "predicted_bull_years": None,
                    "predicted_bear_years": None,
                    "n_swings_compared": 0,
                    "matches": 0,
                    "match_share": 0.0,
                    "halving_survives": False,
                    "verdict": "insufficient_data",
                    "reason": (
                        "Fewer than two crisis dates were supplied, so no interval can be measured and the "
                        "halving derivation cannot be tested."
                    ),
                },
                "error": None,
                "metadata": {"provenance": {
                    "source_grounded": [
                        "recurrence of financial crises at periodic intervals of a little more than ten years",
                        "Dow assumed one primary bull market and one primary bear market in that period and split it in half",
                        "five-year primary swings arrived at by splitting the assumed ten-year cycle in half",
                        "events disproved Dow's five-year primary swings",
                    ],
                    "model_extrapolated": [
                        "mean interval taken as arithmetic mean of consecutive gaps between sorted crisis dates",
                        "tolerance of 0.25 years around the predicted half",
                        "halving survives when at least 50% (support_share) of observed swings match",
                        "insufficient_data verdict for fewer than two crisis dates",
                    ],
                }},
            })

        gaps = [years[i + 1] - years[i] for i in range(len(years) - 1)]
        mean_interval = sum(gaps) / float(len(gaps))
        predicted = mean_interval / 2.0

        observed: List[Dict[str, Any]] = []
        for kind in ("bull", "bear"):
            source = bull_swings if kind == "bull" else bear_swings
            for raw in source or []:
                if not isinstance(raw, dict):
                    continue
                duration = raw.get("duration_years")
                if duration is None:
                    start = raw.get("start_year")
                    end = raw.get("end_year")
                    if start is None or end is None:
                        continue
                    duration = float(end) - float(start)
                observed.append({
                    "kind": kind,
                    "label": raw.get("label"),
                    "years": float(duration),
                })

        rows: List[Dict[str, Any]] = []
        for row in observed:
            error_years = row["years"] - predicted
            rows.append({
                "kind": row["kind"],
                "label": row["label"],
                "observed_years": row["years"],
                "predicted_years": predicted,
                "error_years": error_years,
                "matches_prediction": bool(abs(error_years) <= tolerance),
            })

        n_swings = len(rows)
        matches = sum(1 for r in rows if r["matches_prediction"])
        match_share = matches / float(n_swings) if n_swings else 0.0

        if n_swings == 0:
            verdict = "insufficient_data"
            reason = (
                "No observed primary swing with a usable duration was supplied, so the halving derivation "
                "cannot be compared against the record."
            )
            halving_survives = False
        elif match_share >= support_share:
            verdict = "halving_survives"
            halving_survives = True
            reason = (
                "The halving derivation survives: the mean interval between the %d crisis dates is %.2f years, "
                "so halving predicts bull and bear swings of %.2f years, and %d of %d observed swings (%.2f) "
                "fall within %.2f years of that prediction."
                % (len(years), mean_interval, predicted, matches, n_swings, match_share, tolerance)
            )
        else:
            verdict = "halving_falsified"
            halving_survives = False
            reason = (
                "The halving derivation is falsified: the mean interval between the %d crisis dates is %.2f "
                "years, so halving predicts bull and bear swings of %.2f years, but only %d of %d observed "
                "swings (%.2f) fall within %.2f years of that prediction, below the %.2f needed."
                % (
                    len(years),
                    mean_interval,
                    predicted,
                    matches,
                    n_swings,
                    match_share,
                    tolerance,
                    support_share,
                )
            )

        result: Dict[str, Any] = {
            "n_crises": len(years),
            "mean_crisis_interval_years": mean_interval,
            "predicted_bull_years": predicted,
            "predicted_bear_years": predicted,
            "n_swings_compared": n_swings,
            "matches": matches,
            "match_share": match_share,
            "halving_survives": halving_survives,
            "verdict": verdict,
            "reason": reason,
        }
        if verbose:
            result["crisis_gaps"] = [round(g, 4) for g in gaps]
            result["crisis_years"] = years
            result["swings"] = rows
            result["thresholds"] = {"tolerance": tolerance, "support_share": support_share}
        return json.dumps({
            "result": result,
            "error": None,
            "metadata": {"provenance": {
                "source_grounded": [
                    "recurrence of financial crises at periodic intervals of a little more than ten years",
                    "Dow assumed one primary bull market and one primary bear market in that period and split it in half",
                    "five-year primary swings arrived at by splitting the assumed ten-year cycle in half",
                    "events disproved Dow's five-year primary swings",
                    "observed falsifying record: bear from Sept 1902 nearly a year; bull Sept 1903 to Jan 1907 = 3 years 4 months; bear Jan to Dec 1907 = 11 months",
                ],
                "model_extrapolated": [
                    "mean interval taken as arithmetic mean of consecutive gaps between sorted crisis dates",
                    "tolerance of 0.25 years around the predicted half",
                    "halving survives when at least 50% (support_share) of observed swings match",
                    "insufficient_data verdict for fewer than two crisis dates or zero observed swings",
                ],
            }},
        })
    except Exception as exc:  # pragma: no cover - defensive
        return json.dumps({
            "result": None,
            "error": "%s: %s" % (type(exc).__name__, exc),
            "metadata": {"provenance": {
                "source_grounded": [],
                "model_extrapolated": ["error path only"],
            }},
        })