"""Classify insider buying as willing or compelled accumulation.

Use when insiders or promoters are reported buying their own stock and you want
to know whether they are accumulating because they want to or because they have
to. The chapter's test: when the price falls while the insiders absorb stock in
a rising general market, the accumulation is compelled -- they cannot help
themselves. That is what happened to the Amalgamated Copper promoters in
December 1900, when the public that had subscribed was unloading on them.

Inputs: the stock's prices during the absorption period, the general market
level over the same period, the sales volume, and the share of the volume
attributed to insiders. Do NOT use this for a line's accumulation reading on an
average -- call line_accumulation_distribution_classifier. Do NOT use it to
name the campaign stage -- call manipulated_distribution_stage_taxonomy.

Depends on: line_accumulation_distribution_classifier (A "LINE" AND AN
EXAMPLE-1914) -- this adds the identity of the buyer (insiders/promoters) and
the test that the price declines during the absorbing while the general market
rises, separating compelled absorption from genuine supply-absorbing
accumulation.
"""

import json
from typing import Any, List, Optional


async def forced_insider_accumulation_classifier(
    prices: List[float],
    market_prices: Optional[List[float]] = None,
    sales_shares: Optional[List[float]] = None,
    insider_share_of_sales: Optional[float] = None,
    min_decline_pct: float = 3.0,
    min_market_rise_pct: float = 2.0,
    min_absorber_share: float = 0.3,
    verbose: bool = True,
) -> str:
    """Classify insider buying as willing or compelled accumulation."""

    def _f(v: Any, default: float = 0.0) -> float:
        try:
            if v is None:
                return default
            return float(v)
        except (TypeError, ValueError):
            return default

    try:
        px = [_f(p) for p in (prices or [])]
        mkt = [_f(p) for p in (market_prices or [])]
        sales = [_f(s) for s in (sales_shares or [])]
        min_decline_pct = _f(min_decline_pct, 3.0)
        min_market_rise_pct = _f(min_market_rise_pct, 2.0)
        min_absorber_share = _f(min_absorber_share, 0.3)

        n = len(px)
        if n == 0:
            return json.dumps({
                "result": {
                    "classification": "no_absorption_evidence",
                    "reason": "no price record supplied, so no absorption can be classified",
                    "periods": 0,
                    "stock_change_pct": 0.0,
                    "stock_direction": "flat",
                    "market_change_pct": 0.0,
                    "market_direction": "unknown",
                    "total_sales_shares": 0.0,
                    "compiled": False,
                },
                "error": None,
                "metadata": {"provenance": {
                    "source_grounded": [
                        "accumulation judged from the movement of the stock while insiders buy",
                    ],
                    "model_extrapolated": [
                        "empty price record reported as no_absorption_evidence rather than an error",
                    ],
                }},
            })

        start = px[0]
        end = px[-1]
        stock_change_pct = ((end - start) / start * 100.0) if start else 0.0
        if stock_change_pct > 1e-12:
            stock_dir = "up"
        elif stock_change_pct < -1e-12:
            stock_dir = "down"
        else:
            stock_dir = "flat"

        if len(mkt) >= 2:
            m_start = mkt[0]
            m_end = mkt[-1]
            market_change_pct = ((m_end - m_start) / m_start * 100.0) if m_start else 0.0
            if market_change_pct > 1e-12:
                market_dir = "up"
            elif market_change_pct < -1e-12:
                market_dir = "down"
            else:
                market_dir = "flat"
        else:
            market_change_pct = 0.0
            market_dir = "unknown"

        total_sales = sum(sales) if sales else 0.0
        if total_sales > 0 and sales:
            avg_rate = total_sales / float(len(sales))
            late = sum(sales[len(sales) // 2:]) / float(len(sales) - len(sales) // 2)
            activity_trend = "increasing" if late > avg_rate else (
                "decreasing" if late < avg_rate else "steady")
        else:
            avg_rate = 0.0
            late = 0.0
            activity_trend = "unknown"

        share = _f(insider_share_of_sales, 0.0) if insider_share_of_sales is not None else 0.0
        absorber = bool(share >= min_absorber_share)

        decline_material = bool(stock_dir == "down" and abs(stock_change_pct) >= min_decline_pct)
        market_rising = bool(market_dir == "up" and market_change_pct >= min_market_rise_pct)

        if decline_material and market_rising and absorber:
            cls = "compelled_accumulation"
            reason = ("insiders absorbed %.1f%% of the volume while the stock fell %.2f%% "
                      "in a general market rising %.2f%%: they were accumulating because "
                      "they could not help themselves"
                      % (share * 100.0, abs(stock_change_pct), market_change_pct))
        elif decline_material and market_rising:
            cls = "compelled_accumulation"
            reason = ("the stock fell %.2f%% in a rising general market (up %.2f%%) while "
                      "insiders were reported buying" % (abs(stock_change_pct),
                                                         market_change_pct))
        elif stock_dir == "down" and market_dir == "up":
            cls = "compelled_accumulation"
            reason = ("the stock fell %.2f%% while the general market rose %.2f%%, a "
                      "divergence too small to be called material absorption"
                      % (abs(stock_change_pct), market_change_pct))
        elif stock_dir == "up":
            cls = "willing_accumulation"
            reason = ("the stock rose %.2f%% while insiders bought, which is consistent "
                      "with willing accumulation" % stock_change_pct)
        elif stock_dir == "down":
            cls = "failed_support"
            reason = ("the stock fell %.2f%% with the general market %s, so the buying "
                      "absorbed nothing and support failed" % (abs(stock_change_pct),
                                                               market_dir))
        else:
            cls = "inconclusive"
            reason = ("the stock ended unchanged and the general market reading is %s"
                      % market_dir)

        result = {
            "classification": cls,
            "reason": reason,
            "compelled": bool(cls == "compelled_accumulation"),
            "periods": n,
            "starting_price": round(start, 4),
            "ending_price": round(end, 4),
            "stock_change_pct": round(stock_change_pct, 4),
            "stock_direction": stock_dir,
            "market_change_pct": round(market_change_pct, 4),
            "market_direction": market_dir,
            "total_sales_shares": round(total_sales, 4),
            "average_sales_rate": round(avg_rate, 4),
            "late_period_sales_rate": round(late, 4),
            "activity_trend": activity_trend,
            "insider_share_of_sales": round(share, 4),
            "insiders_are_principal_absorber": absorber,
            "decline_is_material": decline_material,
            "general_market_is_rising": market_rising,
        }
        if verbose:
            result["thresholds"] = {
                "min_decline_pct": min_decline_pct,
                "min_market_rise_pct": min_market_rise_pct,
                "min_absorber_share": min_absorber_share,
            }
            result["test_applied"] = (
                "insiders absorb stock while the price falls and the general market rises"
            )

        return json.dumps({
            "result": result,
            "error": None,
            "metadata": {"provenance": {
                "source_grounded": [
                    "insiders were buying because they could not help themselves",
                    "compulsion judged from the downward movement of the stock",
                    "absorption took place during the general bull movement of the McKinley boom",
                    "the public which had subscribed was unloading on the promoters",
                    "period sales volume of 160,000 then 295,000 shares as the absorption record",
                ],
                "model_extrapolated": [
                    "material decline set at 3.0 percent",
                    "material general market rise set at 2.0 percent",
                    "principal-absorber share set at 0.3 of period volume",
                    "failed_support and inconclusive readings for non-divergent cases",
                ],
            }},
        })
    except Exception as exc:  # pragma: no cover - defensive
        return json.dumps({
            "result": None,
            "error": "%s: %s" % (type(exc).__name__, exc),
            "metadata": {"provenance": {
                "source_grounded": [],
                "model_extrapolated": [],
            }},
        })