import json
from typing import List, Optional


async def ex_post_business_chart_barometer_gate(
    chart_label: str = "business chart",
    compiled_years_after_events: Optional[float] = None,
    number_of_adjustments: Optional[float] = None,
    conservatism_score: Optional[float] = None,
    abnormal_periods_omitted: Optional[List[str]] = None,
    abnormal_periods_included: Optional[List[str]] = None,
    extreme_conservatism_score: Optional[float] = None,
    numerous_adjustments_floor: Optional[float] = None,
    verbose: bool = True,
) -> str:
    """Gate a business or "cycle" chart before using it in place of the stock
    market barometer.

    Use when someone offers you a constructed chart of business conditions (for
    example the Harvard Committee on Economic Research chart for 1903-1914) as a
    substitute for, or a check on, the day-to-day averages read under Dow's
    theory, and you must rule whether that chart can reach barometrical value.
    The chapter's own ruling on such a chart: it "is a calculation correctly
    extracted after the event, and such a chart, because of its extreme
    conservatism and the numerous adjustments made in its construction, will
    never reach the barometrical value of the stock market averages as recorded
    from day to day."

    The gate tests four things the chapter names:
      1. whether the chart was extracted after the event (post-hoc compilation);
      2. whether its construction required numerous adjustments;
      3. whether it is built with extreme conservatism;
      4. whether it omits -- or excludes -- abnormal periods such as the war boom,
         which the chapter likens to an earthquake and calls "a set of world
         conditions as abnormal as an earthquake or some such natural
         phenomenon."

    Extends: barometer_record_adequacy_gate (ch1909, AND SOME DEFECTS OF
    HISTORY) -- that tool gates a price RECORD on the defects of history; this
    one gates a constructed BUSINESS chart and adds three criteria it never
    named: number of adjustments, extreme conservatism of construction, and the
    omission of abnormal periods.

    Do NOT use for: gating the stock averages themselves, or for judging whether
    a chart is statistically well built -- this gate asks only whether it can
    stand in for the barometer.

    Args:
        chart_label: name of the chart being gated.
        compiled_years_after_events: years after the events charted that the
            calculation was extracted; 0.0 or None means contemporaneous.
        number_of_adjustments: count of adjustments made in constructing it.
        conservatism_score: 0.0-1.0 degree of conservatism in construction.
        abnormal_periods_omitted: abnormal periods left out of the chart
            (e.g. ["war boom 1914-1918"]).
        abnormal_periods_included: abnormal periods deliberately excluded from
            the chart's conclusions, i.e. flagged as abnormal rather than
            silently omitted.
        extreme_conservatism_score: conservatism at or above which construction
            counts as extreme (default 0.7).
        numerous_adjustments_floor: adjustment count at or above which the
            adjustments count as numerous (default 3.0).
        verbose: False returns the compact verdict and the failing criteria only.

    Returns:
        JSON string with keys result/error/metadata.
    """
    try:
        ext_conservatism = (
            0.7 if extreme_conservatism_score is None else float(extreme_conservatism_score)
        )
        numerous_floor = (
            3.0 if numerous_adjustments_floor is None else float(numerous_adjustments_floor)
        )

        years_after = 0.0 if compiled_years_after_events is None else float(compiled_years_after_events)
        adjustments = 0.0 if number_of_adjustments is None else float(number_of_adjustments)
        conservatism = (
            0.0 if conservatism_score is None else float(conservatism_score)
        )
        if conservatism < 0.0:
            conservatism = 0.0
        elif conservatism > 1.0:
            conservatism = 1.0

        omitted = [str(p) for p in (abnormal_periods_omitted or [])]
        excluded = [str(p) for p in (abnormal_periods_included or [])]

        extracted_after_event = bool(years_after > 0.0)
        numerous_adjustments = bool(adjustments >= numerous_floor)
        extreme_conservatism = bool(conservatism >= ext_conservatism)
        omits_abnormal = bool(omitted)
        excludes_abnormal = bool(excluded)

        criteria = [
            {
                "criterion": "extracted_after_the_event",
                "failed": extracted_after_event,
                "value": years_after,
                "detail": "compiled %.2f years after the events charted" % years_after,
            },
            {
                "criterion": "numerous_adjustments",
                "failed": numerous_adjustments,
                "value": adjustments,
                "detail": "%.0f adjustments against a floor of %.0f" % (adjustments, numerous_floor),
            },
            {
                "criterion": "extreme_conservatism",
                "failed": extreme_conservatism,
                "value": conservatism,
                "detail": "conservatism %.2f against a threshold of %.2f"
                % (conservatism, ext_conservatism),
            },
            {
                "criterion": "omits_abnormal_periods",
                "failed": omits_abnormal,
                "value": float(len(omitted)),
                "detail": "omitted: %s" % (", ".join(omitted) if omitted else "none"),
            },
        ]

        failures = [c["criterion"] for c in criteria if c["failed"]]

        if failures:
            classification = "fails_barometer_substitute"
            reason = (
                "%s cannot reach barometrical value: %s. A chart extracted after "
                "the event, built with numerous adjustments and extreme "
                "conservatism, or one that omits abnormal periods such as the "
                "war, will never reach the barometrical value of the stock "
                "market averages as recorded from day to day."
                % (chart_label, "; ".join(failures))
            )
        else:
            classification = "passes_barometer_substitute"
            reason = (
                "%s clears the gate: it is contemporaneous, conservatively but "
                "not extremely constructed, free of numerous adjustments, and "
                "does not silently omit abnormal periods, so it may be used "
                "alongside the day-to-day averages." % chart_label
            )

        if excludes_abnormal:
            reason += (
                " Note: the chart flags %s as abnormal rather than charting it, "
                "which the chapter treats as proper -- conditions as abnormal as "
                "an earthquake are not part of a normal business rhythm."
                % ", ".join(excluded)
            )

        result = {
            "classification": classification,
            "reason": reason,
            "reaches_barometrical_value": not failures,
            "failed_criteria": failures,
            "criteria": criteria,
            "chart_label": chart_label,
            "extracted_after_event": extracted_after_event,
            "numerous_adjustments": numerous_adjustments,
            "extreme_conservatism": extreme_conservatism,
            "omits_abnormal_periods": omits_abnormal,
        }
        if verbose:
            result["abnormal_periods_omitted"] = omitted
            result["abnormal_periods_excluded"] = excluded
            result["extreme_conservatism_threshold"] = ext_conservatism
            result["numerous_adjustments_floor"] = numerous_floor
            result["compiled_years_after_events"] = years_after
        else:
            result["criteria"] = [
                {"criterion": c["criterion"], "failed": c["failed"]} for c in criteria
            ]

        return json.dumps({
            "result": result,
            "error": None,
            "metadata": {"provenance": {
                "source_grounded": [
                    "a chart extracted after the event never reaches barometrical value",
                    "numerous adjustments made in its construction",
                    "extreme conservatism of construction",
                    "abnormal periods such as the war boom, as abnormal as an earthquake",
                    "the day-to-day recorded averages under Dow's theory are the standard it falls short of",
                ],
                "model_extrapolated": [
                    "extreme_conservatism_score threshold default 0.7 on a 0-1 conservatism input",
                    "numerous_adjustments_floor default 3 adjustments",
                    "any post-hoc compilation (years_after > 0) fails the extracted-after-the-event criterion",
                    "distinction between omitted (fails) and explicitly excluded (credited) abnormal periods",
                    "defaults of 0 years, 0 adjustments, 0.0 conservatism mean a contemporaneous chart passes",
                ],
            }},
        })
    except Exception as exc:  # pragma: no cover - defensive
        return json.dumps({
            "result": None,
            "error": "ex_post_business_chart_barometer_gate failed: %s" % exc,
            "metadata": {"provenance": {
                "source_grounded": [],
                "model_extrapolated": ["defensive error wrapper"],
            }},
        })