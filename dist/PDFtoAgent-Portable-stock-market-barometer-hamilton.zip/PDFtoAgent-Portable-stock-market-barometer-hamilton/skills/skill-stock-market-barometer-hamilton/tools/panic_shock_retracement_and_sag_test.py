"""Post-shock panic template test: 40-60 per cent rally, then an irregular sag.

Implements the uniform post-panic template quoted by *The Wall Street Journal*
of July 6, 1906 and reproduced in this chapter: "a panic decline is followed
by a sharp rally of from 40 per cent to 60 per cent of the movement, and then
by an irregular sag ultimately carrying the price to about the old low point."
The chapter then applies the SAME template to a NON-panic shock (the San
Francisco earthquake of April 18, 1906): the twenty railroad stocks fell from
138.36 (January 22) to about 120.36 (May 3), rallied to 131.05 - roughly 60
per cent of the decline - and the inference drawn was that "liquidation of
very much the same kind as that following a panic has been necessary."

Use this when you have a price path covering a BREAK (panic, disaster, shock)
and want to know whether the subsequent recovery fits the panic template, and
therefore whether the liquidation behind the break is of the panic class.
Supply the price series only; the tool locates the pre-break high, the break
low, the rally high and the later sag low by itself.

Do NOT use this to decide whether two averages agree (use
`average_corroboration_check`, chCYCLES AND STOCK MARKET RECORDS), to split a
decline into its scare/confidence phases (use
`panic_decline_scare_then_confidence_phase_test`), or to date the end of a
primary movement (use `primary_movement_termination_rule`, chMAJOR MARKET
SWINGS).

Depends on: `secondary_swing_duration_asymmetry_test` (chMAJOR MARKET SWINGS)
- that tool measures a secondary decline and its recovery inside a primary
movement; this one adds the explicit 40-60 per cent retracement BAND, the
second stage (the irregular sag back to about the old low), and the extension
of the template to a shock that was NOT of the panic class (1906).
"""

import json
from typing import List, Optional

try:
    import numpy as _np  # noqa: F401  (optional; stdlib path is sufficient)
except ImportError:  # pragma: no cover
    _np = None


def _argmax(seq: List[float], start: int = 0) -> int:
    best = start
    for i in range(start + 1, len(seq)):
        if seq[i] > seq[best]:
            best = i
    return best


def _argmin(seq: List[float], start: int = 0) -> int:
    best = start
    for i in range(start + 1, len(seq)):
        if seq[i] < seq[best]:
            best = i
    return best


def _span(periods: Optional[List[float]], i: int, j: int, n: int) -> float:
    if periods is not None and len(periods) >= n and i < len(periods) and j < len(periods):
        try:
            return abs(float(periods[j]) - float(periods[i]))
        except (TypeError, ValueError):
            pass
    return float(abs(j - i))


async def panic_shock_retracement_and_sag_test(
    prices: List[float],
    periods: Optional[List[float]] = None,
    min_rally_fraction: float = 0.40,
    max_rally_fraction: float = 0.60,
    old_low_tolerance_pct: float = 5.0,
    verbose: bool = True,
) -> str:
    """Test a post-shock price path against the uniform panic-break template.

    Use when a market has broken sharply (panic, disaster or other unforeseen
    shock) and you want to know whether the recovery fits the uniform panic
    experience: a sharp rally of 40-60 per cent of the decline, then an
    irregular sag carrying price back to about the old low. The observed rally
    fraction decides whether the liquidation behind a NON-panic shock is of
    the panic class.

    Args:
        prices: Price series (an average or a single issue) spanning the
            pre-break high, the break low, the rally and, if available, the
            later sag. Higher values are prices, in any consistent unit.
        periods: Optional dating for each price (day or month numbers, or
            decimal years). Used to report each leg's duration; index spacing
            is used when omitted.
        min_rally_fraction: Lower edge of the uniform panic rally band (0.40).
        max_rally_fraction: Upper edge of the uniform panic rally band (0.60).
        old_low_tolerance_pct: How near the old low counts as "about the old
            low point" for the second-stage sag, in per cent (5.0).
        verbose: True returns the full reading plus per-leg detail; False
            returns the compact decision only.

    Returns:
        JSON with result/error/metadata. `result.classification` is one of
        panic_class_liquidation, below_panic_band, above_panic_band,
        no_decline, insufficient_data.
    """
    provenance = {
        "source_grounded": [
            "uniform panic rally of 40 to 60 per cent of the movement",
            "subsequent irregular sag carrying price to about the old low",
            "sag bales out weak holders helped over the panic",
            "template applied to a non-panic shock (1906 earthquake)",
            "1906 rails: 138.36 high, break to 120.36, rally to 131.05 ~60 pct",
        ],
        "model_extrapolated": [
            "old_low_tolerance_pct = 5.0 for 'about the old low point'",
            "break low and rally high located as min-then-max of the series",
            "band edges exposed as tunable parameters",
        ],
    }

    min_rally_fraction = 0.40 if min_rally_fraction is None else float(min_rally_fraction)
    max_rally_fraction = 0.60 if max_rally_fraction is None else float(max_rally_fraction)
    old_low_tolerance_pct = 5.0 if old_low_tolerance_pct is None else float(old_low_tolerance_pct)

    try:
        series = [float(p) for p in (prices or [])]
    except (TypeError, ValueError):
        series = []
    per = None
    if periods is not None:
        try:
            per = [float(p) for p in periods]
        except (TypeError, ValueError):
            per = None

    n = len(series)

    if n < 2:
        compact = {
            "classification": "insufficient_data",
            "rally_fraction": None,
            "rally_fraction_pct": None,
            "in_panic_band": None,
            "decline_points": 0.0,
            "rally_points": 0.0,
            "decline_start_price": series[0] if series else None,
            "panic_low_price": series[0] if series else None,
            "rally_high_price": None,
            "sag_low_price": None,
            "sag_carried_to_old_low": None,
            "template_stage": "none",
            "reason": "Fewer than two prices supplied; the panic-break template "
                      "needs at least a high and a low.",
        }
        return json.dumps({
            "result": compact,
            "error": None,
            "metadata": {"provenance": provenance, "n_prices": n},
        })

    peak_idx = _argmax(series)
    low_idx = _argmin(series, peak_idx)
    decline_start = series[peak_idx]
    panic_low = series[low_idx]
    decline_points = decline_start - panic_low

    if decline_points <= 0.0:
        compact = {
            "classification": "no_decline",
            "rally_fraction": None,
            "rally_fraction_pct": None,
            "in_panic_band": None,
            "decline_points": 0.0,
            "rally_points": 0.0,
            "decline_start_price": decline_start,
            "panic_low_price": panic_low,
            "rally_high_price": None,
            "sag_low_price": None,
            "sag_carried_to_old_low": None,
            "template_stage": "none",
            "reason": "No decline after the high of %.2f; there is no break for "
                      "the panic template to describe." % decline_start,
        }
        return json.dumps({
            "result": compact,
            "error": None,
            "metadata": {"provenance": provenance, "n_prices": n},
        })

    rally_idx = _argmax(series, low_idx)
    rally_high = series[rally_idx]
    rally_points = rally_high - panic_low
    rally_fraction = rally_points / decline_points
    in_band = bool(min_rally_fraction <= rally_fraction <= max_rally_fraction)

    sag_idx = None
    sag_low = None
    sag_carried = None
    sag_vs_old_low_pct = None
    if rally_idx < n - 1:
        sag_idx = _argmin(series, rally_idx)
        sag_low = series[sag_idx]
        threshold = panic_low * (1.0 + old_low_tolerance_pct / 100.0)
        sag_carried = bool(sag_low <= threshold)
        sag_vs_old_low_pct = (sag_low - panic_low) / panic_low * 100.0

    if sag_low is None:
        stage = "rally_only"
    elif sag_carried:
        stage = "sag_back_to_old_low"
    else:
        stage = "sag_incomplete"

    if in_band:
        classification = "panic_class_liquidation"
        reason = (
            "Rally recovered %.1f per cent of the %.2f-point decline (uniform band "
            "%.0f-%0.0f per cent); the liquidation behind this break is of the "
            "panic class." % (rally_fraction * 100.0, decline_points,
                              min_rally_fraction * 100.0, max_rally_fraction * 100.0)
        )
        if stage == "sag_back_to_old_low":
            reason += (" The later sag to %.2f carried price back to about the old "
                       "low of %.2f, completing the uniform template."
                       % (sag_low, panic_low))
        elif stage == "sag_incomplete":
            reason += (" The sag to %.2f has not yet carried price back to about "
                       "the old low of %.2f." % (sag_low, panic_low))
        else:
            reason += " No post-rally sag is in the record yet."
    elif rally_fraction < min_rally_fraction:
        classification = "below_panic_band"
        reason = (
            "Rally recovered only %.1f per cent of the %.2f-point decline, short of "
            "the uniform 40-60 per cent panic experience; the liquidation is "
            "weaker than panic class." % (rally_fraction * 100.0, decline_points)
        )
    else:
        classification = "above_panic_band"
        reason = (
            "Rally recovered %.1f per cent of the %.2f-point decline, more than the "
            "uniform 40-60 per cent panic experience; the recovery is stronger than "
            "the panic template and the break looks more like a secondary reaction."
            % (rally_fraction * 100.0, decline_points)
        )

    compact = {
        "classification": classification,
        "rally_fraction": rally_fraction,
        "rally_fraction_pct": rally_fraction * 100.0,
        "in_panic_band": in_band,
        "decline_points": decline_points,
        "decline_pct": decline_points / decline_start * 100.0,
        "rally_points": rally_points,
        "decline_start_price": decline_start,
        "panic_low_price": panic_low,
        "rally_high_price": rally_high,
        "points_below_decline_start": decline_start - rally_high,
        "sag_low_price": sag_low,
        "sag_carried_to_old_low": sag_carried,
        "template_stage": stage,
        "reason": reason,
    }

    payload = dict(compact)
    if verbose:
        payload["expected_band"] = [min_rally_fraction, max_rally_fraction]
        payload["sag_low_vs_old_low_pct"] = sag_vs_old_low_pct
        payload["sag_points_from_rally_high"] = (rally_high - sag_low) if sag_low is not None else None
        payload["old_low_tolerance_pct"] = old_low_tolerance_pct
        payload["legs"] = {
            "decline": {"from_index": peak_idx, "to_index": low_idx,
                        "periods": _span(per, peak_idx, low_idx, n),
                        "from_price": decline_start, "to_price": panic_low},
            "rally": {"from_index": low_idx, "to_index": rally_idx,
                      "periods": _span(per, low_idx, rally_idx, n),
                      "from_price": panic_low, "to_price": rally_high},
            "sag": ({"from_index": rally_idx, "to_index": sag_idx,
                     "periods": _span(per, rally_idx, sag_idx, n),
                     "from_price": rally_high, "to_price": sag_low}
                    if sag_idx is not None else None),
        }

    return json.dumps({
        "result": payload,
        "error": None,
        "metadata": {"provenance": provenance, "n_prices": n},
    })