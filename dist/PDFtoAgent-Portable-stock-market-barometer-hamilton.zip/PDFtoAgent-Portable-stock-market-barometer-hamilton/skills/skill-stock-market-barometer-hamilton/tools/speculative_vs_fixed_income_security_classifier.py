"""Classify a security as speculative or fixed-income (bond-like)."""

import json
import math
from typing import List, Optional


def _clean(values) -> List[float]:
    if not values:
        return []
    out: List[float] = []
    for v in values:
        try:
            f = float(v)
        except (TypeError, ValueError):
            continue
        if math.isnan(f) or math.isinf(f):
            continue
        out.append(f)
    return out


def _finite(v: float) -> bool:
    return not (math.isnan(v) or math.isinf(v))


def _sign_agreement(a: List[float], b: List[float]):
    """Share of period-steps in which two series move the same way."""
    n = min(len(a), len(b))
    if n < 2:
        return None
    agree = 0
    counted = 0
    for i in range(1, n):
        da = a[i] - a[i - 1]
        db = b[i] - b[i - 1]
        if not (_finite(da) and _finite(db)):
            continue
        if da == 0.0 and db == 0.0:
            continue
        counted += 1
        if (da > 0 and db > 0) or (da < 0 and db < 0):
            agree += 1
    if counted == 0:
        return None
    return agree / counted


def _purchasing_power(income: List[float], cost_of_living: List[float]) -> List[float]:
    n = min(len(income), len(cost_of_living)) if cost_of_living else len(income)
    out: List[float] = []
    for i in range(n):
        if cost_of_living:
            den = cost_of_living[i] if i < len(cost_of_living) else float("nan")
            num = income[i] if i < len(income) else float("nan")
            out.append(num / den if den not in (0.0,) and _finite(num) and _finite(den) else float("nan"))
        else:
            out.append(income[i])
    return out


def _r(v, nd: int = 4):
    if v is None:
        return None
    return None if not _finite(v) else round(float(v), nd)


async def speculative_vs_fixed_income_security_classifier(
    prices: List[float],
    income_per_share: Optional[List[float]] = None,
    cost_of_living: Optional[List[float]] = None,
    prospective_earnings: Optional[List[float]] = None,
    debt_ranks_ahead: Optional[bool] = None,
    guaranteed_minimum_return: bool = False,
    min_sign_agreement: float = 0.6,
    verbose: bool = True,
) -> str:
    """Classify one security as SPECULATIVE (usable in a stock-market barometer) or
    FIXED-INCOME / bond-like (unusable in it), from the two governing factors the
    chapter names.

    Use when you must decide whether an issue belongs in a barometer average at all.
    The chapter's test is about what GOVERNS THE PRICE, not about the name of the
    instrument: a speculative issue is a partnership obligation whose price is
    governed by earning capacity, "chiefly by their prospective earning capacity";
    a fixed-income issue is a debt and mortgage ranking ahead of the stock, held for
    its income return, whose "price fluctuates strictly according to the purchasing
    power of the income". A government guaranty of a minimum return puts an issue
    into the fixed-income class outright -- that is why the railroad stocks ceased
    to be speculative under federal control.

    Do NOT use this to test the corroboration of two averages (call
    average_corroboration_check) and do NOT use it to price a guaranty (call
    guaranty_value_discount_ceiling_test). This tool rules on ONE issue only.

    Args:
        prices: the security's price series, oldest first.
        income_per_share: the fixed income (dividend / interest) per share per period.
        cost_of_living: cost-of-living index over the same periods; divides the income
            to give its purchasing power. If omitted, the income series itself is used.
        prospective_earnings: the earning capacity the market is forecasting, same periods.
        debt_ranks_ahead: True if a debt/mortgage/liability ranks ahead of this issue
            (the structural bond test); used when price behaviour is unmeasured.
        guaranteed_minimum_return: True if a government (or equivalent) guaranty of a
            minimum return attaches to the issue.
        min_sign_agreement: share of periods a governing factor must move with price
            before price is said to be governed by it.
        verbose: False returns the classification and its measurements; True adds the
            aligned input series and the rule text.

    Returns:
        JSON {"result": {...}, "error": None, "metadata": {...}} with `classification`
        ("speculative" / "fixed_income" / "insufficient_data") plus a short `reason`.
    """
    try:
        min_sign_agreement = 0.6 if min_sign_agreement is None else float(min_sign_agreement)
        guaranteed = bool(guaranteed_minimum_return)

        price = _clean(prices)
        income = _clean(income_per_share) if income_per_share else []
        col = _clean(cost_of_living) if cost_of_living else []
        earnings = _clean(prospective_earnings) if prospective_earnings else []

        aligned_price = price
        pp = _purchasing_power(income, col) if len(income) >= 2 else []
        pp_agreement = _sign_agreement(aligned_price, pp) if len(pp) >= 2 else None
        earn_agreement = _sign_agreement(aligned_price, earnings) if len(earnings) >= 2 else None

        pp_measured = pp_agreement is not None
        earn_measured = earn_agreement is not None
        pp_governs = bool(pp_measured and pp_agreement >= min_sign_agreement)
        earn_governs = bool(earn_measured and earn_agreement >= min_sign_agreement)

        if len(price) < 2:
            classification = "insufficient_data"
            reason = ("At least two price observations are needed before the governing "
                      "factor of the price can be measured.")
        elif guaranteed:
            classification = "fixed_income"
            reason = ("A guaranty of a minimum return attaches to the issue, and the "
                      "chapter states plainly that with such a guaranty the issue "
                      "'entered the fixed income class'; it is a debt-like claim, held "
                      "for its income, and its price is governed by the purchasing power "
                      "of that income rather than by prospective earning capacity.")
        elif pp_measured and earn_measured:
            if pp_governs and not earn_governs:
                classification = "fixed_income"
                reason = ("Price moved with the purchasing power of the income in "
                          + format(pp_agreement * 100.0, ".0f")
                          + "% of periods (>= " + format(min_sign_agreement * 100.0, ".0f")
                          + "%) but with prospective earning capacity in only "
                          + format(earn_agreement * 100.0, ".0f")
                          + "%: the price is governed by the income return, so the issue "
                            "is in the fixed-income class and useless as a barometer.")
            elif earn_governs and not pp_governs:
                classification = "speculative"
                reason = ("Price moved with prospective earning capacity in "
                          + format(earn_agreement * 100.0, ".0f")
                          + "% of periods (>= " + format(min_sign_agreement * 100.0, ".0f")
                          + "%) but with the purchasing power of the income in only "
                          + format(pp_agreement * 100.0, ".0f")
                          + "%: the price is governed by prospective earning capacity, so "
                            "the issue is speculative and usable in a barometer average.")
            elif pp_governs and earn_governs:
                classification = ("fixed_income" if pp_agreement >= earn_agreement
                                  else "speculative")
                reason = ("Both governing factors tracked price (income purchasing power "
                          + format(pp_agreement * 100.0, ".0f") + "%, prospective earning "
                          "capacity " + format(earn_agreement * 100.0, ".0f")
                          + "%); the stronger one governs, so the issue reads as "
                          + classification + ".")
            else:
                classification = ("fixed_income" if debt_ranks_ahead else "speculative")
                reason = ("Neither factor tracked price well enough to govern it (income "
                          "purchasing power " + format(pp_agreement * 100.0, ".0f")
                          + "%, prospective earning capacity "
                          + format(earn_agreement * 100.0, ".0f") + "%, both below the "
                          + format(min_sign_agreement * 100.0, ".0f")
                          + "% required), so the structural test decides: a debt ranking "
                            "ahead of the issue makes it fixed-income, otherwise it is "
                            "partnership stock and speculative.")
        elif pp_measured or earn_measured:
            if pp_governs:
                classification = "fixed_income"
                reason = ("Price moved with the purchasing power of the income in "
                          + format(pp_agreement * 100.0, ".0f")
                          + "% of periods; no prospective-earnings series was supplied, so "
                            "the measured income test decides: fixed income.")
            elif earn_governs:
                classification = "speculative"
                reason = ("Price moved with prospective earning capacity in "
                          + format(earn_agreement * 100.0, ".0f")
                          + "% of periods; no income series was supplied, so the measured "
                            "earnings test decides: speculative.")
            else:
                classification = ("fixed_income" if debt_ranks_ahead else "speculative")
                measured = ("income purchasing power " + format(pp_agreement * 100.0, ".0f")
                            + "%") if pp_measured else ("prospective earning capacity "
                                                        + format(earn_agreement * 100.0, ".0f") + "%")
                reason = ("The one measured factor did not govern price (" + measured
                          + ", below the " + format(min_sign_agreement * 100.0, ".0f")
                          + "% required), so the structural test decides: "
                          + ("a debt ranks ahead of the issue, so it is fixed-income."
                             if debt_ranks_ahead else
                             "no debt ranks ahead of it, so it is partnership stock and "
                             "speculative -- the default for issues in the averages."))
        else:
            classification = ("fixed_income" if debt_ranks_ahead else "speculative")
            reason = ("No income or earnings series was supplied, so nothing was measured: "
                      "the structural test decides. "
                      + ("A debt and mortgage ranks ahead of the issue, so it is held for "
                         "income and is fixed-income."
                         if debt_ranks_ahead else
                         "It is a partnership obligation and, like the stocks used in the "
                         "averages, essentially speculative."))

        result = {
            "classification": classification,
            "usable_in_barometer": classification == "speculative",
            "reason": reason,
            "guaranteed_minimum_return": guaranteed,
            "debt_ranks_ahead": debt_ranks_ahead,
            "income_purchasing_power_agreement": _r(pp_agreement),
            "prospective_earnings_agreement": _r(earn_agreement),
            "income_purchasing_power_measured": pp_measured,
            "prospective_earnings_measured": earn_measured,
            "min_sign_agreement": min_sign_agreement,
            "price_observations": len(price),
        }

        if verbose:
            result["detail"] = {
                "prices": [round(v, 4) for v in price],
                "purchasing_power_of_income": [None if not _finite(v) else round(v, 6) for v in pp],
                "prospective_earnings": [round(v, 4) for v in earnings],
                "rule_quote": ("The stock is a partnership obligation, while the bond is a "
                               "debt, a mortgage, a liability ranking ahead of the stock ... "
                               "the price fluctuates strictly according to the purchasing "
                               "power of the income."),
            }

        return json.dumps({
            "result": result,
            "error": None,
            "metadata": {
                "provenance": {
                    "source_grounded": [
                        "stock is a partnership obligation; bond is a debt and mortgage ranking ahead of the stock",
                        "bond's speculative feature subordinate or non-existent; held for its income return",
                        "price of a fixed-income security fluctuates according to the purchasing power of the income",
                        "speculative price governed by earning capacity, chiefly prospective earning capacity",
                        "government guaranty of a minimum return puts the issue into the fixed income class",
                        "only speculative issues are usable in a stock market barometer",
                    ],
                    "model_extrapolated": [
                        "governance measured as sign agreement >= 0.6 of periods",
                        "purchasing power of income computed as income / cost of living",
                        "income series used alone when no cost-of-living series is supplied",
                        "structural fallback (debt_ranks_ahead) when neither factor is measured",
                        "stronger of two measured factors decides when both pass",
                    ],
                }
            },
        })
    except Exception as exc:
        return json.dumps({
            "result": {
                "classification": "insufficient_data",
                "usable_in_barometer": False,
                "reason": "Could not classify the security: " + str(exc),
            },
            "error": None,
            "metadata": {
                "provenance": {
                    "source_grounded": ["only speculative issues are usable in a barometer"],
                    "model_extrapolated": ["boundary reading on unusable input"],
                }
            },
        })