import json
from typing import List, Optional


def _runs(signs: List[int]):
    runs = []
    i = 0
    while i < len(signs):
        j = i
        while j + 1 < len(signs) and signs[j + 1] == signs[i]:
            j += 1
        runs.append({"sign": signs[i], "length": j - i + 1,
                     "start_index": i, "end_index": j})
        i = j + 1
    return runs


async def advance_decline_day_balance_test(
    daily_closes: List[float],
    min_record_days: int = 2520,
    series_run_threshold: int = 4,
    imbalance_trigger_share: float = 0.10,
    balancing_window_days: int = 21,
    verbose: bool = True,
) -> str:
    """Test Dow's "trading on averages" system: days of advance against days of decline.

    Dow, editorial of July 20, 1901: "There are those who trade on the theory of
    averages. It is true that in a considerable period of time the market has
    about as many days of advance as it has of decline. If there come a series
    of days of advance, there will almost surely come the balancing days of
    decline. The trouble with this system is that the small swings are always
    part of the larger swings, and while the tendency of events equally liable
    to happen is always toward equality, it is also true that every combination
    possible is liable to occur, and there frequently come long swings, or, in
    the case of stock trading, an extraordinary number of days of advance or
    decline which fit properly into the theory when regarded on a long scale,
    but which are calculated to upset any operations based on the expectation
    of a series of short swings."

    Hamilton adds that showing the equality would require research of records
    covering at least half a century, and would be valueless if obtained.

    Use when you have a long series of daily closes and want the advance/decline
    day counts, the equality test, the longest one-sided run, and whether an
    extraordinary run has upset operations based on short swings.

    Do NOT use to measure the SIZE of moves or to classify a movement by
    duration; this tool counts days only.
    """
    provenance = {
        "source_grounded": [
            "in a considerable period the market has about as many days of advance as of decline",
            "a series of days of advance is almost surely followed by the balancing days of decline",
            "small swings are always part of the larger swings",
            "failure condition: an extraordinary number of days of advance or decline upsets operations based on short swings",
            "equality can only be established by records covering at least half a century, and would be valueless if obtained",
        ],
        "model_extrapolated": [
            "min_record_days = 2520 (about ten market years) as 'a considerable period of time'",
            "series_run_threshold = 4 consecutive same-sign days as 'a series'",
            "imbalance_trigger_share = 0.10 of the record as the imbalance that triggers the balancing expectation",
            "balancing_window_days = 21 as the window in which the balancing days are looked for",
            "half-century record for strict equality taken as 12600 trading days",
        ],
    }
    try:
        closes = [0.0 if p is None else float(p) for p in (daily_closes or [])]
        min_days = 2520 if min_record_days is None else int(min_record_days)
        run_thr = 4 if series_run_threshold is None else int(series_run_threshold)
        if run_thr < 1:
            run_thr = 1
        trig = 0.10 if imbalance_trigger_share is None else float(imbalance_trigger_share)
        bal_win = 21 if balancing_window_days is None else int(balancing_window_days)
        if bal_win < 1:
            bal_win = 1

        signs = []
        for k in range(1, len(closes)):
            d = closes[k] - closes[k - 1]
            if d > 0.0:
                signs.append(1)
            elif d < 0.0:
                signs.append(-1)
            else:
                signs.append(0)

        advance_days = sum(1 for s in signs if s > 0)
        decline_days = sum(1 for s in signs if s < 0)
        unchanged_days = sum(1 for s in signs if s == 0)
        total_change_days = advance_days + decline_days

        if total_change_days > 0:
            advance_share = advance_days / float(total_change_days)
            net_imbalance_days = advance_days - decline_days
            imbalance_share = net_imbalance_days / float(total_change_days)
        else:
            advance_share = None
            net_imbalance_days = 0
            imbalance_share = 0.0

        record_long_enough = len(closes) >= min_days
        equality_tested = record_long_enough and total_change_days > 0
        if not total_change_days:
            equality_holds = None
        elif abs(advance_share - 0.5) <= 0.05:
            equality_holds = True
        else:
            equality_holds = False

        runs = _runs(signs)
        longest_advance_run = max([r["length"] for r in runs if r["sign"] > 0] or [0])
        longest_decline_run = max([r["length"] for r in runs if r["sign"] < 0] or [0])
        longest_run_sign = None
        longest_run_length = max(longest_advance_run, longest_decline_run)
        if longest_run_length > 0:
            longest_run_sign = "advance" if longest_advance_run >= longest_decline_run else "decline"

        extraordinary_run = longest_run_length >= run_thr
        imbalance_triggered = total_change_days > 0 and abs(imbalance_share) >= trig

        last_run = runs[-1] if runs else None
        balancing_pending = None
        balancing_days_observed = None
        if last_run is not None and last_run["sign"] != 0 and last_run["length"] >= run_thr:
            opposite = -last_run["sign"]
            tail = signs[last_run["end_index"] + 1:last_run["end_index"] + 1 + bal_win]
            balancing_days_observed = sum(1 for s in tail if s == opposite)
            balancing_pending = balancing_days_observed == 0
        elif last_run is not None and last_run["sign"] != 0:
            balancing_pending = False
            balancing_days_observed = 0

        if not total_change_days:
            system_status = "no_change_days"
            reason = ("The record contains no day of advance and no day of decline, so nothing "
                      "can be counted on either side of the averages theory.")
        elif extraordinary_run or imbalance_triggered:
            system_status = "upset_by_long_swing"
            reason = ("There has come an extraordinary run - %d consecutive days of %s, with "
                      "advance days exceeding decline days by %d - which fits the theory on a "
                      "long scale but is calculated to upset any operations based on the "
                      "expectation of a series of short swings."
                      % (longest_run_length, longest_run_sign or "movement",
                         net_imbalance_days))
        elif balancing_pending:
            system_status = "balancing_days_expected"
            reason = ("There has come a series of %d days of %s without a balancing day in the "
                      "following %d days, so the balancing days of the opposite kind are still "
                      "expected: they will almost surely come."
                      % (last_run["length"],
                         "advance" if last_run["sign"] > 0 else "decline", bal_win))
        else:
            system_status = "operating_normally"
            reason = ("Days of advance (%d) and days of decline (%d) are close to equal over the "
                      "record and no extraordinary run is present, so operations based on "
                      "balancing short swings are not upset."
                      % (advance_days, decline_days))

        result = {
            "system_status": system_status,
            "reason": reason,
            "advance_days": advance_days,
            "decline_days": decline_days,
            "unchanged_days": unchanged_days,
            "advance_share": advance_share,
            "net_imbalance_days": net_imbalance_days,
            "imbalance_share": imbalance_share,
            "longest_advance_run": longest_advance_run,
            "longest_decline_run": longest_decline_run,
            "longest_run_sign": longest_run_sign,
            "record_days": len(closes),
            "record_long_enough": bool(record_long_enough),
            "equality_tested": bool(equality_tested),
            "equality_holds": equality_holds,
            "extraordinary_run": bool(extraordinary_run),
            "imbalance_triggered": bool(imbalance_triggered),
            "balancing_pending": balancing_pending,
            "balancing_days_observed": balancing_days_observed,
        }
        if verbose:
            result["runs"] = runs
            result["params"] = {
                "min_record_days": min_days,
                "series_run_threshold": run_thr,
                "imbalance_trigger_share": trig,
                "balancing_window_days": bal_win,
            }
            result["note"] = ("It would be impossible to show, except by the research of records "
                              "covering at least half a century, that there are as many days of "
                              "advance as of decline; the information would be valueless if "
                              "obtained.")
        return json.dumps({"result": result, "error": None,
                           "metadata": {"provenance": provenance}})
    except Exception as exc:
        return json.dumps({"result": None, "error": str(exc),
                           "metadata": {"provenance": provenance}})