import json
from typing import List, Optional


def _clean(values: Optional[List]) -> List[float]:
    out: List[float] = []
    if not values:
        return out
    for v in values:
        try:
            f = float(v)
        except (TypeError, ValueError):
            continue
        out.append(f)
    return out


def _new_extremes(series: List[float], kind: str) -> List[int]:
    idx = [0]
    best = series[0]
    for i in range(1, len(series)):
        if (kind == "bottom" and series[i] < best) or (kind != "bottom" and series[i] > best):
            best = series[i]
            idx.append(i)
    return idx


def _denom(x: float) -> float:
    return abs(x) if abs(x) > 1e-12 else 1.0


def _recovery_pct(series: List[float], i: int, kind: str) -> float:
    if i >= len(series) - 1:
        return 0.0
    base = series[i]
    rest = series[i:]
    if kind == "bottom":
        return (max(rest) - base) / _denom(base) * 100.0
    return (base - min(rest)) / _denom(base) * 100.0


def _net_direction(series: List[float]) -> str:
    if len(series) < 2:
        return "flat"
    net = series[-1] - series[0]
    if abs(net) < 1e-12:
        return "flat"
    return "up" if net > 0 else "down"


async def confirmed_turn_dating_test(
    industrials: List[float],
    railroads: List[float],
    periods: Optional[List[str]] = None,
    direction: str = "bottom",
    confirmation_window: int = 2,
    min_recovery_pct: float = 5.0,
    verbose: bool = True,
) -> str:
    """Date a primary market turn at the extreme made JOINTLY by the two averages, and
    score any later one-average extreme as negligible because it is unconfirmed.

    Use when two average series (industrials and railroads) bracket a suspected primary
    top or bottom and you must decide WHICH extreme dates the turn. The chapter's rule:
    the turn is the low or high made by BOTH averages (they need not make it on the same
    day or in the same week -- it is enough that they take the same direction); if one
    average alone later makes a new high or a new low that the other does not confirm,
    that later extreme is negligible and does NOT re-date the turn (June 1921 low stands
    although the industrials made a lower point the following August).

    Depends on / extends: average_corroboration_check (chCYCLES AND STOCK MARKET
    RECORDS) and average_direction_not_strength_confirmation_test (chFORECASTING A BULL
    MARKET) -- those ask WHETHER the averages confirm; this one answers WHICH extreme
    is the turn and rules the unconfirmed later extreme negligible.
    Do NOT use for a single price series (use double_top_bottom_averages_signal or
    bull_bear_higher_high_lower_low_test), and do NOT use it to forecast -- it only
    dates a turn already visible in the data.

    direction: "bottom" dates the turn up out of a bear-market low; "top" dates the turn
    down from a bull-market high. confirmation_window: how many periods apart the two
    averages may make their extremes and still count as one joint turn.
    min_recovery_pct: how far BOTH averages must subsequently travel back in the new
    direction before the joint extreme is accepted as a turn.
    """
    try:
        ind = _clean(industrials)
        rail = _clean(railroads)
        n = min(len(ind), len(rail))
        ind = ind[:n]
        rail = rail[:n]
        kind = "bottom" if str(direction).strip().lower() != "top" else "top"
        window = 2 if confirmation_window is None else int(confirmation_window)
        if window < 0:
            window = 0
        min_rec = 5.0 if min_recovery_pct is None else float(min_recovery_pct)
        labels = list(periods) if periods else []

        def label(i: int):
            return str(labels[i]) if 0 <= i < len(labels) else str(i)

        result = {
            "direction": kind,
            "periods_observed": n,
            "industrial_direction": "flat",
            "railroad_direction": "flat",
            "turn_index": None,
            "turn_period": None,
            "jointly_confirmed": False,
            "later_unconfirmed_count": 0,
            "verdict": "no data -- nothing to date",
        }
        if n == 0:
            return json.dumps({
                "result": result,
                "error": None,
                "metadata": {"provenance": {
                    "source_grounded": ["turn dated at extreme made by both averages",
                                        "later unconfirmed one-average extreme is negligible",
                                        "confirmation need not be same day or week"],
                    "model_extrapolated": ["empty input returns a neutral un-dated reading"],
                }},
            })

        result["industrial_direction"] = _net_direction(ind)
        result["railroad_direction"] = _net_direction(rail)

        ext_ind = _new_extremes(ind, kind)
        ext_rail = _new_extremes(rail, kind)

        def confirmed(i: int, other: List[int]) -> Optional[int]:
            best_j = None
            for j in other:
                if abs(j - i) <= window and (best_j is None or abs(j - i) < abs(best_j - i)):
                    best_j = j
            return best_j

        candidates = []
        for i in ext_ind:
            j = confirmed(i, ext_rail)
            if j is not None:
                candidates.append((i, j))
        for j in ext_rail:
            i = confirmed(j, ext_ind)
            if i is not None:
                candidates.append((i, j))
        candidates = sorted(set(candidates))

        chosen = None
        for (i, j) in sorted(candidates, key=lambda p: max(p[0], p[1]), reverse=True):
            if _recovery_pct(ind, i, kind) >= min_rec and _recovery_pct(rail, j, kind) >= min_rec:
                chosen = (i, j)
                break

        if chosen is None:
            result["verdict"] = ("no jointly confirmed " + kind +
                                 " with a subsequent reversal of at least " +
                                 str(round(min_rec, 4)) + "% in both averages")
            return json.dumps({
                "result": result,
                "error": None,
                "metadata": {"provenance": {
                    "source_grounded": ["turn dated at extreme made by both averages",
                                        "later unconfirmed one-average extreme is negligible"],
                    "model_extrapolated": ["confirmation window of " + str(window) + " periods",
                                           "reversal requirement of " + str(round(min_rec, 4)) + "% in both averages",
                                           "flat series yields no dated turn"],
                }},
            })

        ci, cj = chosen
        turn = max(ci, cj)
        turn_base = min(ci, cj)

        result["turn_index"] = turn
        result["turn_period"] = label(turn)
        result["jointly_confirmed"] = True
        result["industrial_price_at_turn"] = ind[ci]
        result["railroad_price_at_turn"] = rail[cj]
        result["separation_periods"] = abs(ci - cj)
        result["industrial_reversal_pct"] = _recovery_pct(ind, ci, kind)
        result["railroad_reversal_pct"] = _recovery_pct(rail, cj, kind)

        unconfirmed = []
        for i in ext_ind:
            if i > turn and confirmed(i, ext_rail) is None:
                base_i = ind[ci]
                unconfirmed.append({
                    "average": "industrials",
                    "index": i,
                    "period": label(i),
                    "price": ind[i],
                    "beyond_points": (base_i - ind[i]) if kind == "bottom" else (ind[i] - base_i),
                    "beyond_pct": (base_i - ind[i]) / _denom(base_i) * 100.0 if kind == "bottom"
                    else (ind[i] - base_i) / _denom(base_i) * 100.0,
                    "periods_after_turn": i - ci,
                    "confirmed_by_other_average": False,
                    "negligible": True,
                })
        for j in ext_rail:
            if j > turn and confirmed(j, ext_ind) is None:
                base_r = rail[cj]
                unconfirmed.append({
                    "average": "railroads",
                    "index": j,
                    "period": label(j),
                    "price": rail[j],
                    "beyond_points": (base_r - rail[j]) if kind == "bottom" else (rail[j] - base_r),
                    "beyond_pct": (base_r - rail[j]) / _denom(base_r) * 100.0 if kind == "bottom"
                    else (rail[j] - base_r) / _denom(base_r) * 100.0,
                    "periods_after_turn": j - cj,
                    "confirmed_by_other_average": False,
                    "negligible": True,
                })
        unconfirmed.sort(key=lambda d: d["index"])

        result["later_unconfirmed_count"] = len(unconfirmed)
        result["max_unconfirmed_beyond_points"] = max([u["beyond_points"] for u in unconfirmed], default=0.0)
        result["verdict"] = (
            "turn dated at period " + str(label(turn_base)) + "-" + str(result["turn_period"]) +
            " (indices " + str(turn_base) + "-" + str(turn) + "), the " + kind +
            " made by both averages within " + str(window) + " periods; " +
            str(len(unconfirmed)) + " later single-average extreme(s) negligible as unconfirmed"
        )

        if verbose:
            result["industrial_extremes"] = [{"index": i, "period": label(i), "price": ind[i]} for i in ext_ind]
            result["railroad_extremes"] = [{"index": j, "period": label(j), "price": rail[j]} for j in ext_rail]
            result["joint_extreme_pairs"] = [{"industrial_index": i, "railroad_index": j} for (i, j) in candidates]
            result["later_unconfirmed_extremes"] = unconfirmed
            result["confirmation_window"] = window
            result["min_recovery_pct"] = min_rec

        return json.dumps({
            "result": result,
            "error": None,
            "metadata": {"provenance": {
                "source_grounded": ["turn dated at the extreme made by both averages",
                                    "later new high or low by one average alone is negligible",
                                    "averages need not make the extreme on the same day or week",
                                    "same direction in both averages is sufficient confirmation"],
                "model_extrapolated": ["confirmation window of " + str(window) + " periods",
                                       "reversal requirement of " + str(round(min_rec, 4)) + "% in both averages",
                                       "latest qualifying joint extreme chosen as the turn",
                                       "flat series yields no dated turn"],
            }},
        })
    except Exception as exc:
        return json.dumps({
            "result": {"turn_index": None, "jointly_confirmed": False, "verdict": "unreadable input"},
            "error": str(exc),
            "metadata": {"provenance": {
                "source_grounded": ["turn dated at extreme made by both averages"],
                "model_extrapolated": ["exception guard returns a neutral reading"],
            }},
        })