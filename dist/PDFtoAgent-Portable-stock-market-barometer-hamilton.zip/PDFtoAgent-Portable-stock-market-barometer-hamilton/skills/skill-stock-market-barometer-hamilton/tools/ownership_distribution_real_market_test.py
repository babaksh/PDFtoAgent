import json
from typing import Optional


async def ownership_distribution_real_market_test(
    shares_outstanding: float,
    number_of_holders: float,
    largest_group_shares: Optional[float] = None,
    max_average_shares_per_holder: float = 100.0,
    concentration_share_threshold: float = 0.9,
    verbose: bool = True,
) -> str:
    """Decide whether a quoted price is a real market price from how the stock is distributed.

    Use when you have a stock's shares outstanding and its number of holders,
    and ideally the holding of the largest single Wall Street group, and you want
    to know whether the quoted price can be trusted as a market price at all.

    The chapter's rule: one great protection to the public is widely distributed
    stock ownership. The average holding of Pennsylvania or of the five and a
    half million shares of United States Steel common is nothing near one
    hundred shares for each holder -- there is safety in numbers. But when a
    single group in Wall Street owns practically all of the stock in a property
    like Stutz Motor, that group can call the market price anything it chooses,
    and "it will not be the 'market' price because there will be no real
    market."

    Returns the classification (`real_market_price`, `no_real_market`, or the
    intermediate `thin_market`), the average shares per holder, the largest
    group's share of the issue, and a short reason.

    Do NOT use this to value a capitalization against book value (that is
    `water_in_capitalization_test`), and do NOT use it to judge whether a
    manipulation could move the averages (that is
    `manipulation_scope_by_movement_classifier`).
    """
    provenance = {
        "source_grounded": [
            "one great protection to the public is in widely distributed stock ownership",
            "the average holding of Pennsylvania or of the five and a half million shares of U.S. Steel common is nothing near one hundred shares for each holder",
            "there is, indeed, safety in numbers",
            "when a single group in Wall Street owns practically all of the stock, that group can call the market price anything it chooses",
            "it will not be the 'market' price because there will be no real market",
            "worked example: five and a half million shares of U.S. Steel common",
        ],
        "model_extrapolated": [
            "max_average_shares_per_holder = 100.0 (the chapter's own 'nothing near one hundred shares' bound used as the wide-distribution ceiling)",
            "concentration_share_threshold = 0.9 ('practically all of the stock' read as 90% of the issue in one group's hands)",
            "average shares per holder computed as shares_outstanding / number_of_holders",
            "three-way verdict ladder: real_market_price / thin_market / no_real_market, plus an unmeasurable reading when holders is zero",
            "concentration test applied only when largest_group_shares is supplied",
        ],
    }
    try:
        shares = 0.0 if shares_outstanding is None else float(shares_outstanding)
        holders = 0.0 if number_of_holders is None else float(number_of_holders)
        cap = 100.0 if max_average_shares_per_holder is None else float(max_average_shares_per_holder)
        conc = 0.9 if concentration_share_threshold is None else float(concentration_share_threshold)
        group = None if largest_group_shares is None else float(largest_group_shares)

        average_shares_per_holder = None
        if holders > 0.0:
            average_shares_per_holder = shares / holders

        group_share_of_issue = None
        if group is not None and shares > 0.0:
            group_share_of_issue = group / shares

        widely_distributed = None
        if average_shares_per_holder is not None and (shares > 0.0 or holders > 0.0):
            widely_distributed = average_shares_per_holder < cap

        group_controls = None
        if group_share_of_issue is not None:
            group_controls = group_share_of_issue >= conc

        if group_share_of_issue is not None and group_share_of_issue > 1.0:
            verdict = "no_real_market"
            reason = ("The largest single group holds %.4f shares of an issue of %.4f shares -- more "
                      "than the whole issue -- so the distribution figures are inconsistent; on the "
                      "figures as given one group owns all of it and the quotation is not a market "
                      "price." % (group, shares))
        elif group_controls is True:
            verdict = "no_real_market"
            reason = ("One group holds %.2f%% of the %.0f shares outstanding, which is practically all "
                      "of the issue against a threshold of %.2f%%. That group can call the market "
                      "price anything it chooses; it will not be the market price because there will "
                      "be no real market." % (group_share_of_issue * 100.0, shares, conc * 100.0))
        elif holders <= 0.0:
            verdict = "unmeasurable"
            reason = ("The number of holders is %.0f, so the average holding cannot be formed. The "
                      "chapter's test turns on how the stock is distributed among holders, and without "
                      "a holder count no real-market verdict can be given." % holders)
        elif widely_distributed is False:
            verdict = "thin_market"
            reason = ("The average holding is %.2f shares for each of %.0f holders, at or above the "
                      "%.2f-share bound the chapter treats as widely distributed, and no single group "
                      "is shown to hold practically all of the issue. The quotation is not plainly "
                      "fictitious, but it lacks the safety in numbers of a widely held stock."
                      % (average_shares_per_holder, holders, cap))
        else:
            verdict = "real_market_price"
            reason = ("The average holding is %.2f shares for each of %.0f holders, nothing near the "
                      "%.2f-share bound, and no single group holds practically all of the issue"
                      % (average_shares_per_holder, holders, cap)
                      + ("" if group_share_of_issue is None else
                         " (largest group %.2f%% against a %.2f%% threshold)"
                         % (group_share_of_issue * 100.0, conc * 100.0))
                      + ". The stock is widely distributed, so the quotation is a real market price: "
                        "so far as the public is concerned, there is safety in numbers.")

        result = {
            "verdict": verdict,
            "reason": reason,
            "shares_outstanding": shares,
            "number_of_holders": holders,
            "average_shares_per_holder": average_shares_per_holder,
            "widely_distributed": widely_distributed,
            "largest_group_shares": group,
            "largest_group_share_of_issue": group_share_of_issue,
            "single_group_controls_issue": group_controls,
        }
        if verbose:
            result["max_average_shares_per_holder"] = cap
            result["concentration_share_threshold"] = conc
            result["params"] = {
                "max_average_shares_per_holder": cap,
                "concentration_share_threshold": conc,
            }
            result["note"] = ("Abraham Lincoln pointed out long ago that you could not talk five legs "
                              "onto a dog by renaming its tail.")
        return json.dumps({"result": result, "error": None,
                           "metadata": {"provenance": provenance}})
    except Exception as exc:
        return json.dumps({"result": None, "error": str(exc),
                           "metadata": {"provenance": provenance}})